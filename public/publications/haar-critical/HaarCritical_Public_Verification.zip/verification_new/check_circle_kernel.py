"""Numerical checks for the small-depth comparison (requires mpmath)."""
import json
from pathlib import Path

import mpmath as mp

mp.mp.dps = 45


def finite_kernel(n, tilt, t, w):
    a = 1 + tilt
    b = 1 + 2 * tilt
    x = 1 - mp.exp(1j * t / n)
    y = 1 - mp.exp(-1j * w / n)
    prefactor = (abs(x) * abs(y)) ** tilt / (2 * mp.pi * n)
    terms = []
    for j in range(n):
        phi_x = mp.rf(b, j) / mp.rf(a, j) * mp.hyp2f1(-j, a, b, x)
        phi_y = mp.rf(b, j) / mp.rf(a, j) * mp.hyp2f1(-j, a, b, y)
        norm = mp.gamma(j + 1) * mp.gamma(j + b) / mp.gamma(j + a) ** 2
        terms.append(phi_x * phi_y / norm)
    return prefactor * mp.fsum(terms)


def limiting_kernel(tilt, t, w):
    a = 1 + tilt
    b = 1 + 2 * tilt
    prefactor = abs(t * w) ** tilt * (mp.gamma(a) / mp.gamma(b)) ** 2
    prefactor /= 2 * mp.pi
    # v = x^(1+2 Re s) removes the absolute endpoint singularity.
    power = 1 / mp.re(b)

    def integrand(v):
        x = v ** power
        return power * x ** (2j * mp.im(tilt)) * mp.hyp1f1(a, b, 1j*t*x) * mp.hyp1f1(a, b, -1j*w*x)

    return prefactor * mp.quad(integrand, [0, mp.mpf("0.1"), 1])


def compare_mark(n, depth, t):
    z = mp.sqrt(1 - depth / n)
    angle = mp.exp(1j*t/n)
    finite = (1 + z*angle) / (2*n*z*(1-z*angle))
    limiting = 1 / (depth/2 - 1j*t)
    return n * abs(finite - limiting)


def decimal(x):
    return mp.nstr(x, 14)


checks = {"working_decimal_digits": 45, "kernel_comparisons": [], "mark_comparisons": []}
for sr, si, ts, ws in [("-0.35", "0.5", "1.2", "-0.8"), ("0.7", "0.65", "3", "4")]:
    s = mp.mpc(sr, si)
    t, w = mp.mpf(ts), mp.mpf(ws)
    target = limiting_kernel(s, t, w)
    values = {}
    for rank in (16, 32, 64, 128, 256):
        values[str(rank)] = decimal(abs(finite_kernel(rank, s, t, w) - target))
    checks["kernel_comparisons"].append(
        {"s": [sr, si], "t": ts, "w": ws, "absolute_error_by_rank": values}
    )

for depth in ("0", "1e-8", "0.03", "0.5"):
    values = {}
    for rank in (16, 128, 1024):
        values[str(rank)] = {
            t: decimal(compare_mark(rank, mp.mpf(depth), mp.mpf(t)))
            for t in ("1e-9", "0.1", "1", "5")
        }
    checks["mark_comparisons"].append({"c": depth, "N_times_absolute_difference": values})

Path(__file__).with_name("circle_kernel_comparisons.json").write_text(
    json.dumps(checks, indent=2) + "\n"
)
print(json.dumps(checks, indent=2))
