"""Certified low-rank two-exponent moments. Inputs are exact rational numbers."""
import ctypes as ct
import ctypes.util
from dataclasses import dataclass
from contextvars import ContextVar
from fractions import Fraction as F
from math import inf, isfinite, nextafter

def library(name):
    path = ctypes.util.find_library(name)
    if path is None:
        raise ImportError(f"Required system library {name} is unavailable")
    return ct.CDLL(path)

mpfi, mpfr = library("mpfi"), library("mpfr")
P = ct.c_void_p
def bind(lib, name, args, result=ct.c_int):
    fn = getattr(lib, name)
    fn.argtypes, fn.restype = args, result
    return fn

class MPFR(ct.Structure):
    _fields_ = [("prec",ct.c_long), ("sign",ct.c_int), ("exp",ct.c_long), ("limbs",P)]
class MPFI(ct.Structure):
    _fields_ = [("left",MPFR), ("right",MPFR)]

init = bind(mpfi, "mpfi_init2", [P, ct.c_long], None)
clear = bind(mpfi, "mpfi_clear", [P], None)
set_str = bind(mpfi, "mpfi_set_str", [P, ct.c_char_p, ct.c_int])
pi_init = bind(mpfi, "mpfi_const_pi", [P])
get_d = bind(mpfr, "mpfr_get_d", [P, ct.c_int], ct.c_double)
one_arg = {n:bind(mpfi,"mpfi_"+n,[P,P]) for n in ("neg","abs","log","exp","sin","cos","atan","sqrt")}
two_arg = {n:bind(mpfi,"mpfi_"+n,[P,P,P]) for n in ("add","sub","mul","div")}
BITS = 192
precise_export = ContextVar("precise_export", default=False)

class I:
    def __init__(self):
        self.b = MPFI()
        self.p = ct.byref(self.b)
        init(self.p, BITS)
    def __del__(self):
        clear(self.p)
    @classmethod
    def integer(cls, n):
        out = cls()
        if set_str(out.p,str(n).encode(),10):
            raise ValueError(f"Invalid MPFI integer {n}")
        return out
    @classmethod
    def num(cls, n):
        x = F(n)
        if x.denominator == 1:
            return cls.integer(x.numerator)
        return cls.integer(x.numerator)/cls.integer(x.denominator)
    def unary(self, name):
        out = I()
        one_arg[name](out.p,self.p)
        return out
    def binary(self, name, other):
        if not isinstance(other,I):
            other = I.num(other)
        out=I()
        two_arg[name](out.p,self.p,other.p)
        return out
    def __add__(self,x): return self.binary("add",x)
    def __sub__(self,x): return self.binary("sub",x)
    def __mul__(self,x): return self.binary("mul",x)
    def __truediv__(self,x): return self.binary("div",x)
    def __neg__(self): return self.unary("neg")
    def __abs__(self): return self.unary("abs")
    def lo(self): return get_d(ct.byref(self.b.left),3)
    def hi(self): return get_d(ct.byref(self.b.right),2)

@dataclass
class C:
    re:I
    im:I
    @classmethod
    def num(cls, re, im=0): return cls(I.num(re),I.num(im))
    def __add__(self, o): return C(self.re+o.re,self.im+o.im)
    def __sub__(self, o): return C(self.re-o.re,self.im-o.im)
    def __mul__(self, o):
        if isinstance(o,C):
            return C(self.re*o.re-self.im*o.im,self.re*o.im+self.im*o.re)
        return C(self.re*o,self.im*o)
    def inv(self):
        d=self.re*self.re+self.im*self.im
        return C(self.re/d,-self.im/d)
    def exp(self):
        t=self.re.unary("exp")
        return C(t*self.im.unary("cos"),t*self.im.unary("sin"))
    def log_right(self):
        if self.re.lo() <= 0: raise ValueError("log requires a positive real part")
        return C((self.re*self.re+self.im*self.im).unary("log")/2,
                 (self.im/self.re).unary("atan"))
    def l1(self): return abs(self.re)+abs(self.im)

def exact(x):
    if isinstance(x,float):
        raise TypeError("Pass exact decimal strings or rational numbers, not a binary float")
    return F(x)
def pair(x):
    if isinstance(x,(list,tuple)):
        if len(x)!=2: raise ValueError("Use (real, imaginary)")
        return tuple(map(exact,x))
    return exact(x),F(0)
def upward(x):
    f=float(x)
    return nextafter(f,inf) if F.from_float(f)<x else f

@dataclass
class Result:
    real:tuple
    imag:tuple
    value:complex
    abs_error:float
    rel_error:float|None
    meets_relative_target:bool
    method:str
    terms:int

def result(v, tail, method, terms, rtol):
    if precise_export.get():
        from high_precision import exact_result
        return exact_result(v,tail,method,terms,rtol)
    # Round bounds and the radius outward. The midpoint is always the reported binary64 value.
    rad = tail.hi()
    if not isfinite(rad): raise ArithmeticError("Nonfinite enclosure")
    box=[]
    for w in (v.re,v.im):
        if not isfinite(w.lo()) or not isfinite(w.hi()): raise ArithmeticError("Nonfinite enclosure")
        lo,hi=F(w.lo())-F(rad),F(w.hi())+F(rad)
        box.append((-upward(-lo),upward(hi)))
    mids=[float((F(lo)+F(hi))/2) for lo,hi in box]
    distances=[max(F(mid)-F(lo),F(hi)-F(mid)) for (lo,hi),mid in zip(box,mids)]
    absolute=sum(distances)
    lower=max(max(F(lo),-F(hi),F(0)) for lo,hi in box)
    relative=absolute/lower if lower>0 else None
    return Result(*box,complex(*mids),upward(absolute),
                  None if relative is None else upward(relative),
                  relative is not None and relative<=rtol,method,terms)

def rank_one(x,h,s,budget,rtol,max_terms):
    one=C.num(1)
    if x==0: return result(one,I.num(0),"rank-one center",1,rtol)
    v=(C.num(*h)*(I.num(1-x).unary("log")*2)).exp()
    ar,ai=h[0]-s[0],h[1]-s[1]
    d=abs(ar-1)+abs(ai)
    u,total=one,one
    pref_bound=v.l1()
    for n in range(max_terms):
        den=n+1
        b=C.num((ar+n)/den,ai/den)
        u=u*(b*b)*I.num(x)
        if ai==0 and ar==-n:
            return result(total*v,I.num(0),"rank-one terminating Gauss series",den,rtol)
        q=x*(1+d/den)**2
        if q<1:
            tail=(u.l1()*pref_bound)/I.num(1-q)
            if F(tail.hi()) <= budget:
                return result(total*v,tail,"rank-one Gauss series",den,rtol)
        total=total+u
    raise ArithmeticError("max_terms reached before the absolute truncation budget")

# B_2j, j = 1,...,12 (successive exact rational Bernoulli numbers).
BERNOULLI = [F(1,6),F(-1,30),F(1,42),F(-1,30),F(5,66),F(-691,2730),
             F(7,6),F(-3617,510),F(43867,798),F(-174611,330),F(854513,138),
             F(-236364091,2730)]
def stirling_without_constant(w, re_lower):
    inv=w.inv()
    invsq=inv*inv
    power=inv
    val=(w-C.num(F(1,2)))*w.log_right()-w
    for j,b in enumerate(BERNOULLI,1):
        val=val+power*I.num(b/(2*j*(2*j-1)))
        power=power*invsq
    m=2*len(BERNOULLI)
    error=abs(BERNOULLI[-1])/(m*(m-1)*re_lower**(m-1))
    return val,error

def rank_two_center(h,rtol):
    a,b=h[0]+F(1,2),h[0]+2
    if a<=0: raise ValueError("Rank two center requires Re h > -1/2")
    shift=192 if precise_export.get() else 32
    ha,hb=C.num(a+shift,h[1]),C.num(b+shift,h[1])
    g1,e1=stirling_without_constant(ha,a+shift)
    g2,e2=stirling_without_constant(hb,b+shift)
    # Work in logarithms for the large near-boundary correction.
    val=(g1-g2)+C.num(*h)*I.num(4).unary("log")
    for j in range(shift):
        val=val+C.num(b+j,h[1]).log_right()-C.num(a+j,h[1]).log_right()
    pi=I()
    pi_init(pi.p)
    mid=val.exp()*(I.num(1)/pi.unary("sqrt"))
    # If e is the sum of the complex log errors, |exp(e)-1| <= exp(|e|)-1.
    rel_factor=I.num(e1+e2).unary("exp")-1
    return result(mid,mid.l1()*rel_factor,"rank-two center beta integral",shift,rtol)

def evaluate(N,z,h,s,*,budget="1e-22",rtol="1e-10",max_terms=200000):
    """Evaluate E[|S_N|^(2h)|Lambda_N|^(2s)] as defined in the W34 screenshots."""
    z,h,s,budget,rtol=exact(z),pair(h),pair(s),exact(budget),exact(rtol)
    if not (0<=z<1) or budget<=0 or rtol<=0: raise ValueError("Invalid z or tolerance")
    if type(N) is not int or N<1: raise ValueError("N must be a positive integer")
    if not isinstance(max_terms,int) or max_terms<=0: raise ValueError("max_terms must be positive")
    if N==1: return rank_one(z*z,h,s,budget,rtol,max_terms)
    if N==2 and z==0: return rank_two_center(h,rtol)
    if N==2 and h==s: return rank_two_diagonal(z*z,h,budget,rtol,max_terms)
    raise NotImplementedError("Certified scope: rank one, rank-two center, or rank-two diagonal")

# The diagonal rank-two connection formula comes from the planar determinant FN-1.
# Parameter pairs below are exact real/imaginary rationals.
def shift(p, c): return (p[0]+c,p[1])
def neg(p): return (-p[0],-p[1])
def l1p(p): return abs(p[0])+abs(p[1])
def pi_interval():
    v=I()
    pi_init(v.p)
    return v
def inflate(v,r):
    # Construct [-1,1] using union of point intervals.
    span=I()
    left,right=I.num(-1),I.num(1)
    hull(span.p,left.p,right.p)
    box=span*r
    return C(v.re+box,v.im+box)
hull=bind(mpfi,"mpfi_union",[P,P,P])

def gamma_ratio(num, den):
    if len(num)!=len(den): raise ValueError("Only balanced gamma ratios are used")
    logs=C.num(0)
    corr=C.num(1)
    error=F(0)
    for group,sign in ((num,1),(den,-1)):
        for p in group:
            target=192 if precise_export.get() else 32
            steps=max(0,target-int(p[0]//1))
            w=shift(p,steps)
            val,e=stirling_without_constant(C.num(*w),w[0])
            logs=logs+val*sign
            error+=e
            for j in range(steps):
                f=C.num(*shift(p,j))
                corr=corr*(f.inv() if sign==1 else f)
    val=logs.exp()*corr
    return inflate(val,val.l1()*(I.num(error).unary("exp")-1))

def hyper3(x,A,B,pref,budget,max_terms):
    term,total=C.num(1),C.num(1)
    ap=[l1p(shift(a,-1)) for a in A]
    bp=[l1p(shift(b,-1)) for b in B]
    scale=pref.l1()
    for n in range(max_terms):
        den=n+1
        if any(a==(-n,0) for a in A):
            return total*pref,I.num(0),den
        ratio=C.num(x/den)
        for a in A:
            ratio=ratio*C.num(*shift(a,n))
        for b in B:
            ratio=ratio*C.num(*shift(b,n)).inv()
        term=term*ratio
        if all(t<den for t in bp):
            q=x
            for t in ap: q*=1+t/den
            for t in bp: q/=1-t/den
            if q<1:
                tail=scale*term.l1()/I.num(1-q)
                if F(tail.hi())<=budget: return total*pref,tail,den
        total=total+term
    raise ArithmeticError("max_terms reached before the 3F2 series truncation budget")

def rank_two_diagonal(x,h,budget,rtol,max_terms):
    if h[0]<=-1: raise ValueError("Rank two interior requires Re h > -1")
    half=F(1,2)
    beta=shift(h,half)
    if h[1]==0 and beta[0].denominator==1:
        return rank_two_resonance(x,h[0],budget,rtol,max_terms)
    hc=C.num(*h)
    nh=neg(h)
    pival=pi_interval()
    common=(hc*(I.num(4).unary("log")+I.num(1-x).unary("log")*2)).exp()
    first=common*gamma_ratio([beta],[shift(h,2)])*(I.num(1)/pival.unary("sqrt"))
    va,ea,na=hyper3(x,[nh,nh,shift(nh,-1)],[(F(1),F(0)),shift(nh,half)],
                     first,budget/2,max_terms)
    if h[1]==0 and h[0].denominator==1 and h[0]>=0:
        return result(va,ea,"rank-two diagonal terminating 3F2",na,rtol)
    second=common*gamma_ratio([shift(h,1),neg(beta)],[nh,shift(h,3*half)])
    second=second*(I.num(2)/pival)*(C.num(*beta)*I.num(x).unary("log")).exp()
    vb,eb,nb=hyper3(x,[(half,F(0)),(half,F(0)),(-half,F(0))],
                      [shift(h,3*half)]*2,second,budget/2,max_terms)
    return result(va+vb,ea+eb,"rank-two diagonal planar 3F2 branches",na+nb,rtol)


def rank_two_resonance(x,h,budget,rtol,max_terms):
    # H(w) = E[Y**w] for Y=(1-x)^2 |Lambda_2'(z)|^2. Its absolute value
    # on a parameter circle is bounded by the sum of its two real endpoint moments.
    R=F(1,8)
    guard=[rank_two_diagonal(x,(h+sign*R,F(0)),budget,rtol,max_terms)
           for sign in (-1,1)]
    M=sum(F(r.real[1]) for r in guard)
    tau=F(1,10**11)
    while M*(tau/R)**2/(1-(tau/R)**2)>budget:
        tau/=10
    probe=rank_two_diagonal(x,(h,tau),budget,rtol,max_terms)
    # Conjugation makes the symmetric probe average exactly real.
    lo,hi=map(F,probe.real)
    value=C.num((lo+hi)/2)
    analytic=M*(tau/R)**2/(1-(tau/R)**2)
    return result(value,I.num((hi-lo)/2+analytic),"rank-two diagonal Cauchy resonance limit",
                  probe.terms+sum(r.terms for r in guard),rtol)
