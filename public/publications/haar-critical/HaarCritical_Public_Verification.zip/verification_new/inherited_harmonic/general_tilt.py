"""General unequal-complex-tilt, finite rank two, via polynomial harmonic moments."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial
from certified import I,C,exact,pair,shift,neg,gamma_ratio,pi_interval,hyper3,result,evaluate

def mul(a,b): return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]

def general_tilt(z,h,s,*,budget="1e-13",rtol="1e-10",max_degree=40,max_terms=20000):
    z,h,s,budget,rtol=exact(z),pair(h),pair(s),exact(budget),exact(rtol)
    if not 0<z<1 or h[0]<=-1 or h[1]==0 or budget<=0 or rtol<=0:
        raise ValueError("Requires 0<z<1, Re h>-1, nonzero Im h, and positive tolerances")
    if type(max_degree) is not int or max_degree<0: raise ValueError("Invalid degree cap")
    x=z*z
    d=(s[0]-h[0],s[1]-h[1])
    lo,hi=(1-z)**4,(1+z)**4
    c=(lo+hi)/2
    rho=(hi-lo)/(hi+lo)
    guard=evaluate(2,z,h[0],h[0],budget=budget/8,rtol=rtol,max_terms=max_terms)
    mass=I.num(F(guard.real[1]))*(I.num(c).unary("log")*I.num(d[0])).unary("exp")
    binom=(F(1),F(0))
    coefs=[]
    for n in range(max_degree+1):
        coefs.append(binom)
        j=n+1
        binom=mul(binom,((d[0]-n)/j,d[1]/j))
        q=rho*(1+(abs(d[0]+1)+abs(d[1]))/j)
        if not any(binom):
            tail=I.num(0)
            break
        if q<1:
            tail=mass*I.num((abs(binom[0])+abs(binom[1]))*rho**j/(1-q))
            if F(tail.hi())<=budget/2: break
    else:
        raise ArithmeticError("max_degree reached before tilt truncation budget")
    kernel={(0,0):(1+x*x)/c-1,(2,0):4*x/c,(1,1):-2*z*(1+x)/c,
            (1,-1):-2*z*(1+x)/c,(0,2):x/c,(0,-2):x/c}
    power={(0,0):F(1)}
    weights={}
    for n,coef in enumerate(coefs):
        for (ell,k),v in power.items():
            if k<0: continue
            key=(ell,k)
            pr,pi=weights.get(key,(F(0),F(0)))
            factor=v*(2 if k else 1)
            weights[key]=pr+factor*coef[0],pi+factor*coef[1]
        if n+1<len(coefs):
            nxt={}
            for (l1,k1),a in power.items():
                for (l2,k2),b in kernel.items():
                    t=(l1+l2,k1+k2)
                    nxt[t]=nxt.get(t,F(0))+a*b
            power=nxt
    weights={k:v for k,v in weights.items() if any(v)}
    half=F(1,2)
    base=shift(h,half)
    nh=neg(h)
    pi=pi_interval()
    common=(C.num(*h)*I.num(4*(1-x)**2).unary("log")+C.num(*d)*I.num(c).unary("log")).exp()
    ca=common*gamma_ratio([base],[shift(h,2)])*(I.num(1)/pi.unary("sqrt"))
    cb=common*gamma_ratio([shift(h,1),neg(base)],[nh,shift(h,3*half)])*(I.num(2)/pi)
    cb=cb*(C.num(*base)*I.num(x).unary("log")).exp()
    @lru_cache(None)
    def rf(a,n):
        if n<0: return rf(shift(a,n),-n).inv()
        if n==0: return C.num(1)
        return rf(a,n-1)*C.num(*shift(a,n-1))
    v=C.num(0)
    steps=0
    allowance=budget/(4*len(weights))
    for (ell,k),w in weights.items():
        diff=(ell-k)//2
        add=(ell+k)//2
        kd=F(k,2)
        t=shift(h,F(ell,2))
        b=shift(t,half)
        wp=C.num(*w)
        pa=ca*wp*rf(nh,k)*rf(base,diff)*rf(shift(h,2),diff).inv()*I.num(z**k/F(factorial(k)))
        va,ea,na=hyper3(x,[shift(nh,k),nh,shift(neg(t),kd-1)],
                        [(F(1+k),F(0)),shift(neg(b),1+kd)],pa,allowance,max_terms)
        harmonic=rf((half-diff,F(0)),ell)
        pb=cb*wp*rf(neg(base),-diff)*rf(shift(h,3*half),add).inv()*harmonic*I.num(z**ell)
        vb,eb,nb=hyper3(x,[(half+add,F(0)),(half+diff,F(0)),(-half,F(0))],
                        [shift(b,1-kd),shift(b,1+kd)],pb,allowance,max_terms)
        v=v+va+vb
        tail=tail+ea+eb
        steps+=na+nb
    return result(v,tail,f"rank-two Haar harmonics, degree {n}, {len(weights)} harmonics",steps,rtol)
