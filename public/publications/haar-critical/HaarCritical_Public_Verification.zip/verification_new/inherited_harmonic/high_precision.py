"""Opt-in, exact rational endpoints from 50-digit directed MPFR conversion."""
import ctypes as ct
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
from dataclasses import dataclass
from fractions import Fraction as F
from certified import bind,mpfr,precise_export,evaluate,P

digits=50
get_digits=bind(mpfr,"mpfr_get_str",[P,P,ct.c_int,ct.c_size_t,P,ct.c_int],P)

def endpoint(mpfr_value,rnd):
    exponent=ct.c_long()
    buf=ct.create_string_buffer(digits+16)
    get_digits(buf,ct.byref(exponent),10,digits,ct.byref(mpfr_value),rnd)
    raw=buf.value.decode()
    if "@" in raw: raise ArithmeticError("Nonfinite high-precision endpoint")
    integer=int(raw)
    if integer==0: return F(0)
    n=len(raw.lstrip("-"))
    return F(integer)*F(10)**(exponent.value-n)

@dataclass
class PreciseResult:
    real:tuple
    imag:tuple
    value:tuple
    abs_error:F
    rel_error:F|None
    meets_relative_target:bool
    method:str
    terms:int

    def decimal_box(self,significant_digits=36):
        def bound(x,rounding):
            with localcontext() as ctx:
                ctx.prec=significant_digits
                ctx.rounding=rounding
                return str(Decimal(x.numerator)/Decimal(x.denominator))
        return [tuple((bound(lo,ROUND_FLOOR),bound(hi,ROUND_CEILING))) for lo,hi in (self.real,self.imag)]

def exact_result(v,tail,method,terms,rtol):
    rad=endpoint(tail.b.right,2)
    box=[(endpoint(w.b.left,3)-rad,endpoint(w.b.right,2)+rad) for w in (v.re,v.im)]
    mids=tuple((lo+hi)/2 for lo,hi in box)
    absolute=sum((hi-lo)/2 for lo,hi in box)
    lower=max(max(lo,-hi,F(0)) for lo,hi in box)
    rel=absolute/lower if lower>0 else None
    return PreciseResult(*box,mids,absolute,rel,rel is not None and rel<=rtol,method,terms)

def high_precision(N,z,h,s,*,budget="1e-36",rtol="1e-25",max_terms=200000):
    token=precise_export.set(True)
    try: return evaluate(N,z,h,s,budget=budget,rtol=rtol,max_terms=max_terms)
    finally: precise_export.reset(token)
