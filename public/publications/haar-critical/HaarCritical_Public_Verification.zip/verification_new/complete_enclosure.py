"""Exact-input Haar moment dispatcher. Dependency: python-flint 0.9.0."""
import itertools
import json
from fractions import Fraction
from math import factorial
from pathlib import Path

from flint import acb, acb_mat, arb, ctx
from ranktwo_contract import components, complex_rational, enclose as ranktwo, exact, rational


def disk(value, analytic=arb(0)):
    centre = acb(value.real.mid(), value.imag.mid())
    error = (value.real.rad() + value.imag.rad() + analytic).upper()
    modulus = centre.abs_lower() - error
    return centre, error, (error / modulus).upper() if modulus > 0 else None


def characteristic(rank, z, s, method="hypergeometric", terms=1600):
    a = -s
    coefficients = []
    leading = acb(1)
    for k in range(rank):
        if k:
            leading *= z * (a+k-1) / k
        if method == "hypergeometric":
            coefficient = leading * acb(z*z).hypgeom_2f1(a+k, a, k+1, ab=True)
        else:
            term = leading
            coefficient = term
            for j in range(terms):
                term *= z*z * (j+k+a) * (j+a) / ((j+k+1)*(j+1))
                coefficient += term
            ratio = z*z*(1+(abs(a)+1)/(terms+1))**2
            if not ratio < 1:
                raise ArithmeticError("series tail ratio must be less than one")
            tail = (abs(term)*ratio/(1-ratio)).upper()
            coefficient += acb(arb(0, tail), arb(0, tail))
        coefficients.append(coefficient)
    return acb_mat([[coefficients[abs(i-j)] for j in range(rank)]
                    for i in range(rank)]).det()


def cutoff_allowance(rank, z, h, s, radius):
    d = 1-z*z
    u, order = s[0], h[0]
    if rank <= 2:
        raise ValueError("the general cubature is for rank at least three")
    slack = min(exact("1/2"), (2+2*order)/2)
    exponent = 2-slack
    cstar = (rational(d)**rational(rank*rank+2*rank*u)
             *4**(rank*(rank-1)//2-1)/factorial(rank))
    z_ball = rational(z)
    power = rational(-2*(rank+u))
    cstar *= ((1-z_ball)**power).max((1+z_ball)**power)**rank
    mass = cstar * 36/arb.pi() * (2+1/rational(slack))
    bound = mass*rational(2*radius)**rational(exponent+2*order)
    if order < 0:
        bound *= arb(2)**rational(-2*order)/(1-arb(2)**rational(-exponent-2*order))
    return bound.upper()


def square_interval(value):
    lower, upper = value.abs_lower(), value.abs_upper()
    return (lower*lower).union(upper*upper)


def cubature(rank, z, h, s, radius, side):
    z, h, s = rational(z), complex_rational(h), complex_rational(s)
    r2 = rational(radius)**2
    d = 1-z*z
    scale = acb(d).pow(rank*rank+2*rank*s)/factorial(rank)
    parts = []
    for j in range(side):
        angles = 2*arb.pi()*arb(arb(2*j+1)/(2*side), arb(1)/(2*side))
        unit = acb(angles.cos(), angles.sin())
        denominator = (square_interval(1+z*unit.real)+square_interval(z*unit.imag)).max((1-z)**2)
        if not denominator > 0:
            raise ArithmeticError("refine angular mesh")
        parts.append((unit, acb(denominator).pow(-rank-s)))
    totals = [Fraction(0) for _ in range(4)]
    # The integrand is symmetric, so one sorted multi-index covers its
    # permutations. We weight by their number in the full product mesh.
    for indices in itertools.combinations_with_replacement(range(side), rank):
        nodes = [parts[j][0] for j in indices]
        mark = sum(nodes, acb(rank*z))
        q = square_interval(mark.real) + square_interval(mark.imag)
        if q <= r2:
            continue
        cutoff = ((q-r2)/(3*r2)).max(arb(0)).min(arb(1))
        base = q.max(r2)
        if not base > 0:
            raise ArithmeticError("refine angular mesh at the cutoff")
        mult = factorial(rank)
        for key, group in itertools.groupby(indices):
            mult //= factorial(sum(1 for _ in group))
        value = mult*cutoff*acb(base).pow(h)
        for j in indices:
            value *= parts[j][1]
        for j in range(rank):
            for k in range(j):
                delta = nodes[j]-nodes[k]
                value *= square_interval(delta.real)+square_interval(delta.imag)
        endpoints = (value.real.lower(), value.real.upper(),
                     value.imag.lower(), value.imag.upper())
        if not all(endpoint.is_finite() for endpoint in endpoints):
            raise ArithmeticError("refine angular cell arithmetic")
        # Each outward endpoint is exact dyadic. Sum these exactly, so
        # sequential ball-radius rounding cannot accumulate across cells.
        for index, endpoint in enumerate(endpoints):
            mantissa, exponent = endpoint.man_exp()
            totals[index] += Fraction(int(mantissa)) * Fraction(2)**int(exponent)
    total = acb(rational(totals[0]).union(rational(totals[1])),
                rational(totals[2]).union(rational(totals[3])))
    return scale*total/(side**rank)


def moment(rank, z, h, s, tolerance, *, relative=False, max_steps=None):
    z, h, s, tol = exact(z), components(h), components(s), exact(tolerance)
    if type(rank) is not int or not 1 <= rank <= 8 or not 0 <= z <= exact(".9") or tol <= 0:
        raise ValueError("require rank 1–8, radius in [0,.9], positive tolerance")
    if max_steps is not None and (type(max_steps) is not int or max_steps < 1):
        raise ValueError("max_steps must be a positive integer")
    if rank >= 2 and h[0] <= (exact("-.5") if rank == 2 and z == 0 else -1):
        raise ValueError("ordinary expectation diverges")
    if rank == 2 and h != (0,0):
        answer = ranktwo(z, h, s, tol, relative=relative,
                         max_bits=None if max_steps is None else 128*2**(max_steps-1))
        return answer.midpoint, answer.error, answer.relative_error, "rank-two validated quadrature"
    steps, target = 0, tol
    while max_steps is None or steps < max_steps:
        steps += 1
        with ctx.workprec(128*steps):
            zz, hh, ss = rational(z), complex_rational(h), complex_rational(s)
            analytic = arb(0)
            if h == (0,0):
                value = characteristic(rank, zz, ss)
                route = "characteristic Toeplitz"
            elif rank == 1:
                exponent = hh-ss
                value = acb(1-zz*zz).pow(2*hh)*acb(zz*zz).hypgeom_2f1(exponent, exponent, 1)
                route = "rank-one hypergeometric"
            elif h == s == (1,0):
                value = acb((1-zz*zz)**2*sum(j*j*(zz*zz)**(j-1) for j in range(1,rank+1)))
                route = "exact first derivative second moment"
            else:
                radius = exact("1/8")
                analytic = cutoff_allowance(rank,z,h,s,radius)
                while analytic.is_finite() and not analytic < rational(target)/2:
                    radius /= 2
                    analytic = cutoff_allowance(rank,z,h,s,radius)
                if not analytic.is_finite():
                    continue
                try:
                    value = cubature(rank,z,h,s,radius,2**steps)
                except ArithmeticError:
                    continue
                route = "direct angular cubature"
            centre, error, rel = disk(value, analytic)
            if error <= rational(target):
                if not relative or (rel is not None and rel <= rational(tol)):
                    return centre,error,rel,route
                target /= 16
    raise ArithmeticError("resource cap before requested enclosure")


def dyadic(point):
    mantissa, exponent = point.man_exp()
    return [str(mantissa), int(exponent)]


def replay():
    re = ("0.55531500166998305776771944779334394064343666110944"
          "640310748114120165446735891689938322536781453387557")
    im = ("2.79925804247329813485816947400863179935065470224556"
          "14424265455747075165720088800812988552371990472938")
    tests = [("near-zero",8,".9",0,(re,im),"1e-10",True),
             ("rank-three critical radius",3,"1/3",1,1,"1e-10",True),
             ("rank two outside strip",2,".9",("-.95",".3"),(".4","-.5"),"1e-10",True)]
    evidence = []
    for name,n,z,h,s,tol,rel in tests:
        mid, error, relative_error, route = moment(n,z,h,s,tol,relative=rel,max_steps=10)
        evidence.append(dict(case=name,N=n,z=z,h=h,s=s,route=route,
                             midpoint=str(mid.str(28)), abs_error=str(error.str(18)),
                             rel_error=str(relative_error.str(18)),
                             exact_midpoint=[dyadic(mid.real),dyadic(mid.imag)],
                             exact_disk_radius=dyadic(error)))
    with ctx.workprec(720):
        zz, ss = rational(exact(".9")), complex_rational(components((re,im)))
        independent = characteristic(8,zz,ss,"series")
        hyper = characteristic(8,zz,ss)
        assert independent.contains(hyper)
        mid,error,rel = disk(independent)
        assert rel < rational(exact("1e-10"))
        evidence.append(dict(case="near-zero independent coefficient sum",
                             z=".9",N=8,terms=1600,abs_error=error.str(18),
                             rel_error=rel.str(18),contains_hypergeometric=True,
                             exact_midpoint=[dyadic(mid.real),dyadic(mid.imag)],
                             exact_disk_radius=dyadic(error)))
    with ctx.workprec(160):
        for side in (8, 16, 32):
            radius = exact("1/16")
            result = cubature(3, exact(0), components(1), components(0), radius, side)
            allowance = cutoff_allowance(3, exact(0), components(1), components(0), radius)
            mid, error, rel = disk(result, allowance)
            assert error.is_finite() and (mid-acb(1)).abs_upper() <= error
            evidence.append(dict(case="original angular fallback control", N=3, z="0",
                                 h=1,s=0,mesh=side, exact_value="1",
                                 exact_midpoint=[dyadic(mid.real),dyadic(mid.imag)],
                                 exact_disk_radius=dyadic(error),abs_error=error.str(18)))
        for tolerance in ("2", "1/2"):
            mid, error, _, route = moment(3,0,1,0,tolerance,max_steps=8)
            assert (mid-acb(1)).abs_upper() <= error
            evidence.append(dict(case="dispatcher angular tolerances", N=3, z="0",
                                 h=1,s=0,requested_absolute=tolerance, exact_value="1",
                                 route=route,exact_midpoint=[dyadic(mid.real),dyadic(mid.imag)],
                                 exact_disk_radius=dyadic(error),abs_error=error.str(18)))
    path = Path(__file__).with_name("dispatch_receipts.json")
    path.write_text(json.dumps(evidence,indent=2)+"\n")
    print(path.read_text())


if __name__ == "__main__":
    replay()
