#!/usr/bin/env python3
"""Exact-rational CUE/Grover--Mezzadri--Simm checks for k=1,2."""
import json
from fractions import Fraction as Q
from functools import cache
from math import factorial


class Interval:
    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = Q(lo if hi is None else hi)

    def __add__(self, other):
        return Interval(self.lo + other.lo, self.hi + other.hi)

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-other)

    def __mul__(self, other):
        endpoints = [a * b for a in (self.lo, self.hi) for b in (other.lo, other.hi)]
        return Interval(min(endpoints), max(endpoints))

    def contains(self, value):
        return self.lo <= value <= self.hi


@cache
def integral(power, depth):
    # Integrated exponential Taylor series. After index j>=c, the
    # integrated terms decrease monotonically, so adjacent sums bracket.
    index = 0
    coefficient = Q(1)
    value = Q(1, power + 1)
    while True:
        index += 1
        coefficient *= -depth / index
        term = coefficient / (power + index + 1)
        if index >= depth and abs(term) < Q(1, 10**44):
            return Interval(min(value, value + term), max(value, value + term))
        value += term


def gms_coefficient(k, depth):
    # Theorem 1.2. For k=2 the two partitions and both Kostka numbers
    # are (2), (1,1), and 1, respectively.
    if k == 1:
        return integral(2, depth)
    moments = [integral(power, depth) for power in range(7)]
    total = Interval(0)
    for aa in [(3, 0), (2, 1)]:
        for bb in [(3, 0), (2, 1)]:
            weight = Q(1, factorial(aa[0]) * factorial(aa[1]) * factorial(bb[0]) * factorial(bb[1]))
            determinant = moments[aa[0] + bb[0]] * moments[aa[1] + bb[1]]
            determinant -= moments[aa[0] + bb[1]] * moments[aa[1] + bb[0]]
            total += Interval(weight) * determinant
    return total


def correction(k, depth):
    endpoint = integral(0, depth) * Interval(-depth) + Interval(1)

    def entry(a, b):
        p = a + b
        result = endpoint * Interval(Q(2 * k - 1, 2))
        if p == 0:
            result += Interval(Q(1, 2))
        result += integral(p, depth) * Interval(b * depth)
        result -= integral(p + 1, depth) * Interval(depth**2 / 2)
        if a >= 2 or b >= 2:
            result -= integral(p - 1, depth) * Interval((a * (a - 1) + b * (b - 1)) // 2)
        return result

    if k == 1:
        return entry(1, 1)
    total = Interval(0)
    for a, ap in [(3, 0), (2, 1)]:
        for b, bp in [(3, 0), (2, 1)]:
            weight = Q(1, factorial(a) * factorial(ap) * factorial(b) * factorial(bp))
            determinant = entry(a, b) * integral(ap + bp, depth) + integral(a + b, depth) * entry(ap, bp)
            determinant -= entry(a, bp) * integral(ap + b, depth) + integral(a + bp, depth) * entry(ap, b)
            total += Interval(weight) * determinant
    return total


def haar_schur(k, rank, square_radius):
    # Differentiate the Schur polynomial before coalescing. Orthogonality
    # squares individual derivative coefficients. This calculation uses no
    # confluent kernel, leading determinant, or numerical quadrature.
    coefficients = [0] * (k * rank - k + 1)
    if k == 1:
        for a in range(1, rank + 1):
            coefficients[a - 1] = a * a
    else:
        for a in range(1, rank + 1):
            for b in range(a + 1):
                m = a - b
                if a + b >= 2:
                    deriv = (m + 1) * a * b + m * (m + 1) * (m - 1) // 6
                    coefficients[a + b - 2] += deriv * deriv
    result = Q(0)
    for coefficient in reversed(coefficients):
        result = square_radius * result + coefficient
    return result / rank**(k * k + 2 * k)


def falling(ell, order):
    product = 1
    for j in range(order):
        product *= max(ell - j, 0)
    return product


def finite_gms(k, rank, square_radius):
    def entry(a, b):
        val = sum(falling(ell, a) * falling(ell, b) * square_radius**(ell - b)
                  for ell in range(max(a, b), rank + k))
        return val / rank**(a + b + 1)

    if k == 1:
        return entry(1, 1)
    total = Q(0)
    for aa in [(3, 0), (2, 1)]:
        for bb in [(3, 0), (2, 1)]:
            weight = Q(1, factorial(aa[0]) * factorial(aa[1]) * factorial(bb[0]) * factorial(bb[1]))
            total += weight * (entry(aa[0], bb[0]) * entry(aa[1], bb[1]) -
                               entry(aa[0], bb[1]) * entry(aa[1], bb[0]))
    return total


def gaussian(k, x):
    return 1 + x if k == 1 else 2 + 16 * x + 16 * x**2


def absolute_bounds(interval):
    if interval.contains(0):
        return Interval(0, max(abs(interval.lo), abs(interval.hi)))
    return Interval(min(abs(interval.lo), abs(interval.hi)), max(abs(interval.lo), abs(interval.hi)))


def pretty(interval):
    return [format(float(endpoint), '.12e') for endpoint in (interval.lo, interval.hi)]


def record(k, rank, z, x, chart, nominal_depth):
    depth = rank * (1 - x)
    power = k * k + 2 * k
    finite = haar_schur(k, rank, x)
    assert finite == finite_gms(k, rank, x)
    microscopic = gms_coefficient(k, depth)
    absolute = absolute_bounds(Interval(finite) - microscopic)
    gaussian_error = abs(depth**power * finite - gaussian(k, x))
    fixed_depth_error = absolute_bounds(Interval(finite) - gms_coefficient(k, nominal_depth))
    conversion = Interval(0) if depth == nominal_depth else absolute_bounds(microscopic - gms_coefficient(k, nominal_depth))
    corrected = absolute_bounds(Interval(finite) - microscopic - correction(k, depth) * Interval(Q(1, rank)))
    return dict(k=k, N=rank, z=None if z is None else str(z), z_squared=str(x), c=str(depth),
                chart=chart, nominal_c=str(nominal_depth), exact_finite_identity=True,
                finite_normalized=pretty(Interval(finite)),
                normalized_microscopic=pretty(microscopic),
                microscopic_absolute_error=pretty(absolute),
                microscopic_error_c_power_weighted=pretty(absolute * Interval(depth**power)),
                normalized_nominal_depth_error=pretty(fixed_depth_error),
                depth_conversion_charge=pretty(conversion),
                first_correction_absolute_error=pretty(corrected),
                gaussian_error_c_power_weighted=None if chart != 'growing-depth overlap' else pretty(Interval(gaussian_error)))


def main():
    # Exact fixed small-dimensional controls plus asymptotic checks at the
    # circle, positive depth and actual varying growing depths.
    rows = []
    for k in (1, 2):
        for rank in (1, 2, 5, 12):
            for x in (Q(1), Q(3, 4), Q(21, 49)):
                assert haar_schur(k, rank, x) == finite_gms(k, rank, x)
        assert haar_schur(k, 1, Q(0)) == 1
        assert gms_coefficient(1, Q(0)).contains(Q(1, 3))
        assert gms_coefficient(2, Q(0)).contains(Q(61, 10080))
        for rank in (32, 64, 128):
            rows.append(record(k, rank, Q(1), Q(1), 'circle', Q(0)))
            a = Q(13, 10)
            z = 1 - a / rank
            rows.append(record(k, rank, z, z**2, 'GMS fixed radial shift', 2 * a))
        for rank, c in ((128, 16), (256, 24), (512, 32)):
            rows.append(record(k, rank, None, 1 - Q(c, rank), 'growing-depth overlap', Q(c)))

    print(json.dumps(dict(display='Values rounded for display only. Finite identities checked with exact rational arithmetic. Integral bounds use adjacent exact rational Taylor sums.', rows=rows), indent=2))


if __name__ == '__main__':
    main()
