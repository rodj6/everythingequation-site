"""Independent integer-diagonal check by orthogonal exterior characters."""
import json
from pathlib import Path

from mpmath import mp


def check(rank, depth, depth_input):
    rank = int(rank)
    depth = mp.mpf(depth)
    x = 1 - depth / rank
    finite = mp.fsum(k**2 * x ** (k - 1) for k in range(1, rank + 1)) / rank**3
    profile = mp.quad(lambda u: u*u*mp.exp(-depth*u), [0, 1])
    if not depth:
        closed = mp.mpf(rank + 1) * (2 * rank + 1) / (6 * rank**2)
        assert abs(finite - closed) < mp.mpf("1e-80")
        return {"rank": rank, "depth_input": "0", "circle_error": str(finite - profile)}
    poly = depth**2 + 2*depth + 2
    normalized = depth**3 * finite
    normalized_closed = 2 - depth/rank - x**rank * (poly - depth/rank)
    assert abs(normalized - normalized_closed) < mp.mpf("1e-80")
    actual_gaussian = 2 - depth/rank
    corrected_profile = depth**3 * profile + actual_gaussian - 2
    corrected_error = normalized - corrected_profile
    stable_corrected_error = (poly * mp.exp(-depth) * (
        -mp.expm1(rank*mp.log1p(-depth/rank) + depth)
    ) + depth/rank*x**rank)
    assert abs(corrected_error - stable_corrected_error) < mp.mpf("1e-80")
    explicit_allowance = (mp.exp(-depth) / rank) * (
        depth**2 * poly / (2 * (1 - depth/rank)) + depth
    )
    assert 0 <= stable_corrected_error <= explicit_allowance
    return {
        "rank": rank,
        "depth_input": depth_input,
        "normalized_error_without_radius_correction": mp.nstr(normalized - depth**3 * profile, 22),
        "normalized_error_with_radius_correction": mp.nstr(stable_corrected_error, 22),
        "explicit_allowance": mp.nstr(explicit_allowance, 22),
    }


def main():
    mp.dps = 95
    records = []
    for rank in (64, 256, 1024, 4096):
        depth_cases = ((0, "0"), ("0.5", "1/2"), (2, "2"),
                       (mp.log(rank), "log(N)"), (2*mp.log(rank), "2*log(N)"),
                       (mp.mpf(rank)/4, "N/4"))
        for depth, depth_input in depth_cases:
            records.append(check(rank, depth, depth_input))
    out = Path(__file__).with_name("actual_radius_checks.json")
    out.write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
