"""Independent harmonic benchmark and enclosure contraction checks.

Run with the recovered HaarSpectral evaluator directory on PYTHONPATH and
Python-FLINT 0.9.0 available. The harmonic path also uses MPFI and MPFR.
"""
from fractions import Fraction
from pathlib import Path
import json

from flint import ctx
from contract import complex_rational, rational
from certified import precise_export
from general_tilt import general_tilt


def dyadic(parts):
    return Fraction(parts[0]) * Fraction(2)**parts[1]


root = Path(__file__).resolve().parent
records = {row["case"]: row for line in (root / "results-final.jsonl").read_text().splitlines()
           if "case" in (row := json.loads(line))}
record = records["tiny_radius"]
token = precise_export.set(True)
try:
    harmonics = general_tilt(record["z"], record["h"], record["s"],
                             budget="1e-25", max_degree=7)
finally:
    precise_export.reset(token)
with ctx.workprec(256):
    midpoint = complex_rational(tuple(map(dyadic, record["exact_midpoint_dyadics"])))
    radius = rational(dyadic(record["exact_error_dyadic"]))
    harmonic_mid = complex_rational(harmonics.value)
    distance = (midpoint-harmonic_mid).abs_upper()
    total = rational(Fraction(harmonics.abs_error)) + radius
    assert distance <= total

    initial = records["edge_absolute"]
    refined = records["edge_relative"]
    refinement_ratio = dyadic(refined["exact_error_dyadic"]) / dyadic(initial["exact_error_dyadic"])
    assert refinement_ratio < Fraction(1, 70)
    initial_mid = complex_rational(tuple(map(dyadic, initial["exact_midpoint_dyadics"])))
    refined_mid = complex_rational(tuple(map(dyadic, refined["exact_midpoint_dyadics"])))
    assert (initial_mid-refined_mid).abs_upper() <= rational(
        dyadic(initial["exact_error_dyadic"]) + dyadic(refined["exact_error_dyadic"]))

    summary = {"status": "passed", "benchmark": "tiny_radius",
               "harmonic_method": harmonics.method, "harmonic_terms": harmonics.terms,
               "harmonic_real_bounds_outward": list(map(str, harmonics.real)),
               "harmonic_imag_bounds_outward": list(map(str, harmonics.imag)),
               "harmonic_absolute_error_rational": str(harmonics.abs_error),
               "midpoint_distance_upper": str(distance),
               "sum_of_absolute_errors": str(total),
               "edge_refinement_radius_ratio_rational": str(refinement_ratio)}
    print(json.dumps(summary, indent=2))
