"""Rank-two Haar moment disks with independently refined quadrature and rounding.

Python-FLINT 0.9.0. Run `python contract.py` for the recorded controls.
The polynomial-weight construction follows HaarCritical, Proposition 21.2.
"""
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from time import perf_counter
import json

from flint import acb, arb, ctx


def exact(value):
    if isinstance(value, (bool, float)):
        raise TypeError("use an exact integer, rational or decimal string")
    return Fraction(value)


def components(value):
    parts = value if isinstance(value, (tuple, list)) else (value, 0)
    if len(parts) != 2:
        raise ValueError("expected real and imaginary components")
    return tuple(map(exact, parts))


def rational(value):
    return arb(value.numerator) / value.denominator


def complex_rational(value):
    return acb(*(rational(component) for component in value))


def square(value):
    # Interval multiplication is defined at zero-centred balls.
    return value * value


def rectangle(lo, hi, ellipse=False):
    middle = rational((lo + hi) / 2)
    halfwidth = rational((hi - lo) / 2)
    if ellipse:
        return acb(arb(middle, halfwidth * 5 / 3), arb(0, halfwidth * 4 / 3))
    return acb(arb(middle, halfwidth))


@lru_cache(maxsize=None)
def shifted_chebyshev(order):
    if order == 0:
        return (1,)
    if order == 1:
        return (-1, 2)
    result = [0] * (order + 1)
    for index, coefficient in enumerate(shifted_chebyshev(order - 1)):
        result[index] -= 2 * coefficient
        result[index + 1] += 4 * coefficient
    for index, coefficient in enumerate(shifted_chebyshev(order - 2)):
        result[index] -= coefficient
    return tuple(result)


@dataclass
class Chart:
    scale: arb
    start: arb
    width: arb
    flip: bool | None
    exponent: acb
    prefactor: acb


class Cubature:
    def __init__(self, z, h, s):
        self.z = rational(z)
        self.h = complex_rational(h)
        self.tilt = complex_rational(s) - self.h
        self.pi = arb.pi()
        self.a = self.z.asin()
        self.d = 1 - self.z**2
        if not (self.a > 0 and self.d > 0 and (self.h.real+1) > 0):
            raise ArithmeticError("increase precision to separate input from the ordinary boundary")
        self.charts = []
        core_right = self.a if z <= Fraction(1, 2) else self.pi / 2 - self.a
        core_factor = acb(4 * (self.d * self.a)**2).pow(self.h) * (4 / self.pi)
        for width in (-self.a, core_right):
            for flip in (False, True):
                self.charts.append(Chart(self.a, self.a, width, flip,
                                         2 * self.h + 1, core_factor * abs(width)))
        if z <= Fraction(1, 2):
            multiplier = 2
            while multiplier*z < Fraction(1, 4):
                start = multiplier*self.a
                self.add_regular(start, start)
                multiplier *= 2
            start = multiplier*self.a
            self.add_regular(start, self.pi / 2 - start)

    def add_regular(self, start, width):
        factor = acb(4 * (self.d * start)**2).pow(self.h) * (4 / self.pi)
        self.charts.append(Chart(start, start, width, None, acb(0), factor * width))

    def integrand(self, chart, t, y):
        real = t.imag == 0 and y.imag == 0
        if real:
            t, y = t.real, y.real
        if chart.flip is None:
            q = chart.start + chart.width * t
            phi = self.pi * y
            radial = (q / chart.scale) * q.sinc()
            ratio = (self.a / chart.scale) * self.a.sinc()
            mark = square(radial - ratio) + 4 * radial * ratio * square((phi / 2).sin())
        else:
            u, v = (y, 1) if chart.flip else (1, y)
            step = chart.width * t * u
            q = self.a + step
            phi = self.pi * t * v
            radial = (chart.width / self.a) * u * (self.a + step / 2).cos() * (step / 2).sinc()
            scaled_sine = (1 + (chart.width / self.a) * t * u) * q.sinc()
            angular = self.pi * v * (phi / 2).sinc()
            mark = square(radial) + scaled_sine * self.a.sinc() * square(angular)
        minus = square(1 - self.z) + 4 * self.z * square(((phi - q + self.pi / 2) / 2).sin())
        plus = square(1 - self.z) + 4 * self.z * square(((phi + q - self.pi / 2) / 2).sin())
        if real:
            if not(mark > 0 and minus > 0 and plus > 0):
                return None
            result = square(q.cos()) * (self.h*mark.log() + self.tilt*(minus*plus).log()).exp()
            return result if result.is_finite() else None
        if not (mark.real > 0 and minus.real > 0 and plus.real > 0):
            return None
        result = square(q.cos()) * mark.pow(self.h, analytic=True)
        result *= minus.pow(self.tilt, analytic=True) * plus.pow(self.tilt, analytic=True)
        return result if result.is_finite() else None

    def meshes(self, depth_limit):
        self.mesh = []
        self.cover_bounds = []
        self.panel_count = 0
        for chart in self.charts:
            pending = [(Fraction(0), Fraction(1), Fraction(0), Fraction(1), 0)]
            accepted = []
            max_t = arb(0)
            max_y = arb(0)
            while pending:
                lo, hi, yl, yh, level = pending.pop()
                along_t = self.integrand(chart, rectangle(lo, hi, True), rectangle(yl, yh))
                along_y = self.integrand(chart, rectangle(lo, hi), rectangle(yl, yh, True))
                if along_t is not None and along_y is not None:
                    max_t = max(max_t, along_t.abs_upper())
                    max_y = max(max_y, along_y.abs_upper())
                    accepted.append((lo, hi, yl, yh))
                    continue
                if level == depth_limit:
                    raise ArithmeticError("ellipse search exceeded the current bisection depth")
                if hi-lo >= yh-yl:
                    mid = (lo+hi) / 2
                    ends = [(lo, mid, yl, yh, level+1), (mid, hi, yl, yh, level+1)]
                else:
                    mid = (yl+yh) / 2
                    ends = [(lo, hi, yl, mid, level+1), (lo, hi, mid, yh, level+1)]
                pending.extend(ends)
            self.panel_count += len(accepted)
            self.mesh.append(accepted)
            measure = chart.prefactor.abs_upper() / (chart.exponent.real + 1)
            bound_t, bound_y = measure * max_t, measure * max_y
            if not (bound_t.is_finite() and bound_y.is_finite()):
                raise ArithmeticError("insufficient precision for the analytic error bound")
            self.cover_bounds.append((bound_t, bound_y))

    def analytic_error(self, order):
        gauss_order = (order + 1) // 2
        total_t = sum(item[0] for item in self.cover_bounds)
        total_y = sum(item[1] for item in self.cover_bounds)
        return (3*(1+2*order)*total_t / 3**order + 6*total_y / 3**(2*gauss_order)).upper()

    def rule(self, order):
        gauss_order = (order + 1) // 2
        roots = [arb.legendre_p_root(gauss_order, index, weight=True)
                 for index in range(gauss_order)]
        self.gauss = [((x+1)/2, w/2) for x, w in roots]
        self.cosines = [[((2*i+1)*k*self.pi/(2*order)).cos() for k in range(order)]
                        for i in range(order)]
        self.cheb = [(1 + row[1]) / 2 for row in self.cosines]
        self.order = order
        self.weights = {}

    def weighted_nodes(self, lo, hi, weighted):
        key = lo, hi, weighted
        if key in self.weights:
            return self.weights[key]
        a, b = rational(lo), rational(hi)
        width = b-a
        nu = 2*self.h+1 if weighted else acb(0)
        if not weighted:
            moments = [acb(0) if j % 2 else acb(1)/(1-j*j) for j in range(self.order)]
        else:
            prefactor = acb(b).pow(nu)
            if lo == 0:
                monomials = [prefactor/(nu+j+1) for j in range(self.order)]
            else:
                arg = acb(1-a/b)
                monomials = [prefactor*arg.hypgeom_2f1(-nu, 1, j+2)/(j+1)
                             for j in range(self.order)]
            moments = [sum(coeff*monomials[j]
                           for j, coeff in enumerate(shifted_chebyshev(k)))
                       for k in range(self.order)]
        weights = [(moments[0]+2*sum(c*m for c,m in zip(row[1:],moments[1:])))
                   * width / self.order for row in self.cosines]
        nodes = [(a+width*t, w) for t,w in zip(self.cheb,weights)]
        self.weights[key] = nodes
        return nodes

    def evaluate_mesh(self):
        result = acb(0)
        for chart, panels in zip(self.charts, self.mesh):
            chart_sum = acb(0)
            for lo, hi, yl, yh in panels:
                v0 = rational(yl)
                dy = rational(yh-yl)
                nodes_y = [(acb(v0+dy*y), dy*weight) for y,weight in self.gauss]
                for t, w in self.weighted_nodes(lo, hi, chart.flip is not None):
                    inner = acb(0)
                    for y,g in nodes_y:
                        value = self.integrand(chart, acb(t), y)
                        if value is None:
                            raise ArithmeticError("insufficient precision at an integration node")
                        inner += g*value
                    chart_sum += w*inner
            result += chart.prefactor*chart_sum
        if not result.is_finite():
            raise ArithmeticError("nonfinite ball in quadrature")
        return result


@dataclass
class Disk:
    midpoint: acb
    error: arb
    analytic_error: arb
    arithmetic_error: arb
    relative_error: arb | None
    bits: int
    order: int
    panels: int
    attempts: int


def enclose(z, h, s, tolerance, *, relative=False, max_bits=None):
    """Return a certified disk or raise on a supplied resource cap.

    With relative=False termination holds even at a zero. With relative=True
    termination is guaranteed only at nonzero values. The initial tolerance
    is exact and applies to the entire returned disk.
    """
    z, h, s, goal = exact(z), components(h), components(s), exact(tolerance)
    if not 0 <= z < 1 or goal <= 0:
        raise ValueError("require 0 <= z < 1 and a positive tolerance")
    if h[0] <= (Fraction(-1, 2) if z == 0 else -1):
        raise ValueError("ordinary moment diverges at this input")
    if max_bits is not None and (type(max_bits) is not int or max_bits < 32):
        raise ValueError("max_bits must be None or an integer of at least 32")
    bits = min(128, max_bits) if max_bits is not None else 128
    attempts = 0
    target = goal
    geometry = None
    while True:
        attempts += 1
        reason = "finite arithmetic enclosure too broad"
        with ctx.workprec(bits):
            try:
                if z == 0:
                    exponent = complex_rational(h)
                    quadrature = (acb(4).pow(exponent) * (exponent+acb(1)/2).gamma()
                                  / (arb.pi().sqrt()*(exponent+2).gamma()))
                    analytic = arb(0)
                    order = panels = 0
                else:
                    cubature = Cubature(z,h,s)
                    if geometry is None:
                        cubature.meshes(10 + 2*attempts)
                        geometry = cubature.mesh, cubature.cover_bounds, cubature.panel_count
                    else:
                        cubature.mesh, cubature.cover_bounds, cubature.panel_count = geometry
                    order = 4
                    while not cubature.analytic_error(order) <= rational(target) / 2:
                        order += 2
                    analytic = cubature.analytic_error(order)
                    if bits < 2*order:
                        raise ArithmeticError("increase precision before forming polynomial weights")
                    cubature.rule(order)
                    quadrature = cubature.evaluate_mesh()
                    panels = cubature.panel_count
                midpoint = acb(quadrature.real.mid(), quadrature.imag.mid())
                rounding = (quadrature.real.rad()+quadrature.imag.rad()).upper()
                error = (analytic+rounding).upper()
                if error <= rational(target):
                    lower = midpoint.abs_lower()-error
                    relative_error = (error/lower).upper() if lower > 0 else None
                    if not relative or relative_error is not None and relative_error <= rational(goal):
                        return Disk(midpoint,error,analytic,rounding,relative_error,
                                    bits,order,panels,attempts)
                    target /= 16
                    reason = "modulus test needs a smaller complete disk"
            except ArithmeticError as exc:
                reason = str(exc)
        if max_bits is not None and bits == max_bits:
            raise ArithmeticError(f"resource cap at {bits} bits: {reason}")
        bits = 2*bits if max_bits is None else min(2*bits,max_bits)


def controls():
    cases = [
        ("centre", "0", ("-0.49","2"), ("1","2"), "1e-12", False),
        ("tiny_radius", "1e-10", ("-0.82","1.5"), ("0.3","-0.4"), "1e-10", True),
        ("edge_absolute", "0.9", ("-0.95","0.3"), ("0.4","-0.5"), "1e-8", False),
        ("edge_relative", "0.9", ("-0.95","0.3"), ("0.4","-0.5"), "1e-10", True),
        ("integer_outer", "0.9", "1", "1", "1e-12", False),
        ("integer_inner", "0.025", "1", "0", "1e-12", False),
    ]
    rows = []
    for name, z, h, s, goal, relative in cases:
        start = perf_counter()
        disk = enclose(z,h,s,goal,relative=relative,max_bits=512)
        with ctx.workprec(disk.bits):
            def dyadic(ball):
                mantissa, exponent = ball.man_exp()
                return [str(mantissa), int(exponent)]
            row = dict(case=name,z=z,h=h,s=s,tolerance=goal,relative_requested=relative,
                       sec=perf_counter()-start, **{k:str(v) for k,v in vars(disk).items()})
            row["exact_midpoint_dyadics"] = [dyadic(disk.midpoint.real),dyadic(disk.midpoint.imag)]
            row["exact_error_dyadic"] = dyadic(disk.error)
        with ctx.workprec(160):
            if name in {"integer_outer","integer_inner"}:
                radius = exact(z)
                reference = ((1-radius**2)**2 * (1+4*radius**2) if name=="integer_outer"
                             else 1-radius**4)
                discrepancy = (disk.midpoint-complex_rational((reference,Fraction(0)))).abs_upper()
                assert discrepancy <= disk.error
                row.update(exact_reference=str(reference),discrepancy_upper=str(discrepancy))
        rows.append(row)
        print(json.dumps(row),flush=True)
    print(json.dumps({"status":"passed", "cases":len(rows)}),flush=True)


if __name__ == "__main__":
    controls()
