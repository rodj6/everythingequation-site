from fractions import Fraction
import mpmath as mp


def model_integral(c, w):
    # t=(c/2)sinh(v), so even exponentially small depths remain resolved.
    half_depth = c / 2
    extent = mp.asinh(1 / half_depth)
    return 2 * half_depth ** (-w) * mp.quad(
        lambda v: mp.cosh(v) ** (-w), [0, extent]
    )


def threshold_expression(c, w):
    half_depth = c / 2
    if not w:
        return 2 * mp.log(4 / c)
    regular_gamma = (
        mp.sqrt(mp.pi) * mp.gamma(w / 2) / mp.gamma((1 + w) / 2)
        - 2 / w
    )
    return (
        2 * mp.expm1(-w * mp.log(half_depth)) / w
        + half_depth ** (-w) * regular_gamma
    )


def schur_witness():
    for n in (1, 4, 8, 32, 128, 512, 2048):
        schur_mass = sum((n + 1 - k) * k * k for k in range(1, n + 1))
        ratio = Fraction(12 * schur_mass, n**4)
        assert ratio == Fraction((n + 1)**2 * (n + 2), n**3)
        exact_difference = mp.mpf(ratio.numerator - ratio.denominator) / ratio.denominator
        c = mp.exp(-n)
        # This is normalized by B(1), so the predicted witness limit is 8.
        print("rank", n, "resonant coefficient substitution error / B(1)",
              mp.nstr(exact_difference * model_integral(c, mp.mpf(0)), 14))


def transition_checks():
    for c in (mp.mpf("0.01"), mp.mpf("0.0001"), mp.mpf("0.000001")):
        for w in (mp.mpf(0), mp.mpf("0.025"), mp.mpf("-0.025"),
                  mp.mpc(0, "0.25"),
                  (mp.mpc("0.1", "0.7")) / mp.log(1 / c)):
            residual_scaled = abs(model_integral(c, w) - threshold_expression(c, w)) / c**2
            print("depth", mp.nstr(c, 5), "w", mp.nstr(w, 7),
                  "absolute threshold modeling residual / c^2",
                  mp.nstr(residual_scaled, 14))


if __name__ == "__main__":
    mp.mp.dps = 60
    print("Exact Schur coefficient checks and numerical threshold-integral tests")
    schur_witness()
    transition_checks()
