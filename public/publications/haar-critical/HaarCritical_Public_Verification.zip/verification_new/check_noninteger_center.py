import math
from functools import lru_cache

import numpy as np
from scipy import integrate, special


def partitions(total, maximum):
    if total == 0:
        yield ()
        return
    for first in range(min(total, maximum), 0, -1):
        for tail in partitions(total - first, first):
            yield (first,) + tail


def tableaux(partition):
    size = sum(partition)
    hooks = (
        length - j + sum(other > j for other in partition[i + 1:])
        for i, length in enumerate(partition)
        for j in range(length)
    )
    return math.factorial(size) // math.prod(hooks)


@lru_cache(maxsize=None)
def small_rho_coefficients(rank):
    coefficients = []
    for j in range(1, 9):
        moment = sum(tableaux(p)**2 for p in partitions(j, j) if len(p) <= rank)
        coefficients.append((-1)**(j + 1) * moment / (4**j * math.factorial(j)**2))
    return coefficients


def source(rho, rank):
    offsets = np.arange(rank)
    indices = offsets[:, None] - offsets[None, :]
    return np.linalg.det(special.jv(indices, rho))


def finite_part_integrand(rho, rank):
    if rho < .05:
        return np.polynomial.polynomial.polyval(rho * rho, small_rho_coefficients(rank))
    return (1 - source(rho, rank)) / (rho * rho)


def finite_part(rank, cutoff):
    # On the source tail replace only the constant term by its exact
    # integral 1/cutoff. The remaining oscillatory tail is reported below.
    intervals = list(zip([0, .05, 1, 8, 32, 128, 512, 2048],
                         [.05, 1, 8, 32, 128, 512, 2048, 8192]))
    estimates = []
    for start, end in intervals:
        if start >= cutoff:
            break
        value, error = integrate.quad(
            finite_part_integrand, start, min(end, cutoff), args=(rank,),
            epsabs=1e-12, epsrel=1e-12, limit=1000
        )
        estimates.append((value, error))
    return (sum(v for v, _ in estimates) + 1 / cutoff,
            sum(e for _, e in estimates))


if __name__ == "__main__":
    print("CUE z=0, h=s=1/2. Radial Bessel determinant quadrature.")
    print("quadrature estimate only; source tail bound by Hadamard and stationary phase")
    print("rank  R=2048                 R=8192                difference from Gaussian      source tail at R=8192")
    gaussian = math.gamma(1.5)
    for rank in (2, 3, 4, 6, 8, 12):
        left, _ = finite_part(rank, 2048)
        right, _ = finite_part(rank, 8192)
        tail_bound = (4 * math.sqrt(rank) / math.sqrt(8192))**rank / (8192 * (1 + rank / 2))
        print(f"{rank:4d}  {left:.17g}  {right:.17g}  {right-gaussian:+.9g}  {tail_bound:.3g}")
    print("rank 2 exact analytic value:", 8 / (3 * math.pi))
    print("limiting value:", gaussian)
