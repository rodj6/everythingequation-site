"""Verify checksums and replay saved exact ledgers; no source quadrature."""
from pathlib import Path
import hashlib, json, subprocess, sys, shutil, tempfile, os
ROOT=Path(__file__).resolve().parent
def main():
    for row in (ROOT/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        expected,name=row.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected, name
    reports={}
    env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    for name,expected in [('final_disks','final_disks'),('shared_disks','shared_disks'),('audit_final_integers','audit_final_integers'),('positive_controls','positive_controls')]:
        p=subprocess.run([sys.executable,'verification_window/'+name+'.py'],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',check=True)
        actual=json.loads(p.stdout)
        saved=json.loads((ROOT/'verification_window'/ (expected+'.json')).read_text(encoding='utf-8'))
        def portable(value):
            if isinstance(value,dict): return {k: ('/'.join(v.replace(chr(92),'/').split('/')) .replace('//','/') if k=='file' and isinstance(v,str) else portable(v)) for k,v in value.items()}
            if isinstance(value,list): return [portable(v) for v in value]
            return value
        assert portable(actual)==portable(saved), name+' differs from saved receipt'
        reports[name]='PASS: exact JSON equality after normalizing relative file-path separators'
    if '--theorem' in sys.argv:
        with tempfile.TemporaryDirectory(prefix='haar-theorem-') as tmp:
            work=Path(tmp)
            shutil.copyfile(ROOT/'theorem_23_1A/verify_theorem_23_1A.js',work/'verify_theorem_23_1A.js')
            p=subprocess.run(['node','verify_theorem_23_1A.js'],cwd=work,capture_output=True,text=True,encoding='utf-8',check=True)
            actual=json.loads((work/'verification_receipt.json').read_text(encoding='utf-8'))
            expected=json.loads((ROOT/'theorem_23_1A/verification_receipt.json').read_text(encoding='utf-8'))
            assert actual['all_passed'] is True
            def stable(value):
                if isinstance(value,dict): return {k:stable(v) for k,v in value.items() if k not in {'generated_at','elapsed_ms','time_ms','ms'}}
                if isinstance(value,list): return [stable(v) for v in value]
                return value
            assert stable(actual)==stable(expected), 'theorem mathematical receipt differs'
            reports['theorem_23_1A']='PASS: full two-prime and exact-rational checker; mathematical receipt equality excluding timestamp and runtime'
    print(json.dumps(dict(all_passed=True,checks=reports,cold_numerical_regeneration=False),indent=2))
if __name__=='__main__': main()
