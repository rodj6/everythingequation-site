"""Certified [0,1] with the origin finite part, at depth one."""
from pathlib import Path
import argparse,json
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
from time import perf_counter
from flint import acb,arb,ctx
import annulus
from contour_source import Keyhole,C,R,up,dyadic

BASE=Path(__file__).resolve().parent
INHERITED=BASE.parent/'round_release/HaarCritical_Microscopic_Source/verification_microscopic/jet_complex_precision.json'


def mul_shifted_poly(p):
    w=[0]*(len(p)+1)
    for j,x in enumerate(p):
        w[j]-=x
        w[j+1]+=2*x
    return w


def weights(ns,h,th):
    """Integral of the Chebyshev interpolant against rho^(1−2h)."""
    boards=[[1],[ -1, 2 ]]
    while len(boards)<ns:
        target=[2*x for x in mul_shifted_poly(boards[-1])]
        for k,x in enumerate(boards[-2]):
            target[k]-=x
        boards.append(target)
    mu=[sum((q/(k+2-2*h) for k,q in enumerate(co)),acb(0)) for co in boards[:ns]]
    return [(mu[0]+2*sum((v*(theta*j).cos()
                          for j,v in enumerate(mu[1:],1)),acb(0)))/ns
                                   for theta in th]


def run(args):
    start=perf_counter()
    h=C(("1/2","1/8"))
    pref=acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()
    data=json.loads(Path(args.jet).read_text())["exact_dyadic_disks"]["0"]
    mu0=acb(annulus.restore(data["real"]),annulus.restore(data["imag"]))
    muerr=annulus.restore(data["radius"])
    ns=args.radial
    N=args.angular
    th=[arb.pi()*(2*j+1)/(2*ns) for j in range(ns)]
    rr=[(1+a.cos())/2 for a in th]
    ws=weights(ns,h,th)
    originmax=64*(annulus.boundD(R("9/8"),R("3/8"))+mu0.abs_upper()+muerr)
    radial=up(8*originmax*arb(2)**(-ns)/(2-2*h.real))
    annulus.SOURCE=Keyhole(1,("1/2","1/20"),args.extent,n=args.order,project=args.project,
                  laguerre=args.scale)
    annulus.RADII=rr
    positions=[(i,j,N) for i in range(ns) for j in range(N//2+1)]
    if args.cpu>1:
        with ProcessPoolExecutor(max_workers=args.cpu,mp_context=multiprocessing.get_context("fork")) as pool:
            result=list(pool.map(annulus.point, positions))
    else:
        result=[annulus.point(q) for q in positions]
    value=-mu0/(2*h)
    eS=arb()
    eN=arb()
    eJ=up(muerr/(2*h).abs_lower())
    eT=arb()
    cur=0
    for w,r in zip(ws,rr):
        w=w/r**2
        t=R("1/2")/r
        shif=(t+(1+t*t).sqrt()).log()
        m=annulus.boundD((r*r+R("1/4")).sqrt(),R("1/2"))
        eT+=w.abs_upper()*2*m/(N*shif).expm1()
        eJ+=w.abs_upper()*muerr
        value-=w*mu0
        for j in range(N//2+1):
            k=(1 if j==0 or j==N//2 else 2)
            f=w*k/N
            record,_=result[cur]
            re,im,an,mach=map(annulus.restore,record[:4])
            value+=f*acb(re,im)
            eS+=f.abs_upper()*an
            eN+=f.abs_upper()*mach
            cur+=1
    A=pref*value
    m=A.mid()
    fact=pref.abs_upper()
    breakdown={"source":up(eS*fact),"arithmetic":up((A-m).abs_upper()+eN*fact),
        "angular":up(eT*fact),"radial":up(radial*fact),"jet":up(eJ*fact)}
    error=up(sum(breakdown.values(),arb()))
    return dict(input=["c=1","h=1/2+i/8","s=1/2+i/20"],
                description="normalized Mellin contribution through ρ≤1 with finite part",
                parameters=vars(args), midpoint=[m.real.str(16),m.imag.str(16)],
                radius=error.str(16),midpoint_dyadic=[dyadic(m.real),dyadic(m.imag)],
                radius_dyadic=dyadic(error),
                error_breakdown={k:v.str(16) for k,v in breakdown.items()},
                max_ellipse_Xi=originmax.str(8),max_source_terms=annulus.max_source_terms(result),
                points=len(positions),seconds=perf_counter()-start)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--radial",type=int,default=22)
    p.add_argument("--angular",type=int,default=24)
    p.add_argument("--order",type=int,default=18)
    p.add_argument("--project",type=int,default=74)
    p.add_argument("--bits",type=int,default=130)
    p.add_argument("--extent",default="30")
    p.add_argument("--scale",default="2")
    p.add_argument("--cpu",type=int,default=6)
    bundled=BASE/'jet_complex_precision.json'
    default=bundled if bundled.is_file() else INHERITED
    p.add_argument("--jet",default=str(default))
    args=p.parse_args()
    with ctx.workprec(args.bits):
        print(json.dumps(run(args)))

if __name__=="__main__":
    main()
