"""A centred polynomial bound for the integrated depth-one Bessel tail."""
from pathlib import Path
import argparse
from math import comb
import json
from flint import arb, acb, ctx
from analytic_bridge import a, constants, budget
from bessel_bridge import finite_real_moments, p_poly, dyadic

PREV=Path(__file__).resolve().parent.parent / "verification_microscopic"

# Exact decimals. One global polynomial dominates the residual after
# subtracting a complex quadratic whose contribution uses the complex jets.
CASES={
  8:((".590","-1.458",".954"),
     ((".385","-.102"),("-.966",".268"),(".622","-.172"))),
  4:(("0.54","-1.42","1.22"),
     (("0.445","-0.137"),("-1.647","0.373"),("1.155","-0.232"))),
  5:(("0.59","-1.49","1.18"),
     (("0.395","-0.127"),("-1.407","0.384"),("1.101","-0.249"))),
}

def q_bessel(x,h):
    w=-(x*x)/4
    t=arb(1)
    val=acb(t)/(-2*h)
    for k in range(1,96):
        t*=w/(k*k)
        val+=t/(2*k-2*h)
    t*=w/96**2
    error=abs(t)/((192-2*h.real)*(1-abs(w)/(97**2)))
    C=acb(2)**(-2*h-1)*(-h).gamma()/(h+1).gamma()
    return C*acb(x)**(2*h)-val,error.upper(),abs(C).upper()

def poly_product(p,q):
    return [sum(p[j]*q[k-j] for j in range(max(0,k-(len(q)-1)),min(k+1,len(p))))
            for k in range(len(p)+len(q)-1)]

def shift(p,x):
    return [sum(comb(k,j)*p[k]*x**(k-j) for k in range(j,len(p))) for j in range(len(p))]

def certify_shape(R,h,p,q):
    left=a("1/1000")
    right=arb(2)
    # sqrt(x) J_1 solves f''+(1-3/(4x²))f=0; energy/q is decreasing
    x=arb(2)
    j0=x.bessel_j(0)
    j1=x.bessel_j(1)
    fs=x.sqrt()*j1
    fps=x.sqrt()*j0-j1/(2*x.sqrt())
    C=(fs*fs+fps*fps/(1-3/(4*x*x))).sqrt()
    assert C*(1+abs(2*h+2)/(2*h.real+a("3/2")))<3
    # Hence |Q_h(Rr)| <= 3/(Rr)^{3/2} < .14 for r≥2, by Bessel IBP.
    assert 3/(2*R)**a("3/2")<a(".14")
    pp=p[:]
    pp[0]-=a(".14")
    pp=shift(pp,4)
    qq=shift(q,4)
    sq=poly_product(pp,pp)
    rsq=poly_product(qq,[z.conjugate() for z in qq])
    assert all(z>0 for z in pp)
    assert all((z-w.real)>0 for z,w in zip(sq,rsq)), [str(z-w.real) for z,w in zip(sq,rsq)]
    # No power singularity in the centre enclosure. Compare to Q_h(0)=1/(2h).
    _,_,C0=q_bessel(R*left,h)
    w=(R*left)**2/4
    assert (p[0]+p[1]*left**2) > (
      abs(1/(2*h)-q[0])+C0*R*left
              +w/((2-2*h.real)*(1-w/4))+abs(q[1])*left**2+abs(q[2])*left**4)

    stack=[(left,right)]
    margins=[]
    while stack:
        lo,hi=stack.pop()
        mid=(lo+hi)/2
        qm,qe,_=q_bessel(R*mid,h)
        lip=(abs(2*h)+1)/lo + 2*hi*(abs(q[1])+2*abs(q[2])*hi**2)
        upp=abs(qm-p_poly(mid**2,q)).upper()+qe+(hi-lo)*lip/2
        x2=(lo.union(hi))**2
        gap=(p_poly(x2,p)-upp).lower()
        if gap>0:
            margins.append(gap)
        else:
            assert hi-lo > a("1/1000000"), (str(lo),str(hi),str(gap))
            stack.extend([(lo,mid),(mid,hi)])
    return len(margins), min(margins)

def complex_moments(N,jets):
    _,C,q,K,_,_=constants()
    t=a("1/100000")
    # Shifted Gram on rho disk |rho|=1/2 with M<=402.
    b=a("1/2");rho=b
    pi=arb.pi()
    g=a("127/500");KK=(pi/20).exp();J=(pi/20).sinh()/pi
    C0=arb(4).log()/2+3+(2*pi/3).sqrt()
    bound=(b/2+b*b/4+b.exp()/(1-g)*(2*KK*b.exp()*J*(arb(804).log()+C0)+4*KK*KK/10000)).exp()
    assert bound<1000
    # Angular symmetry and a Cauchy disc at radius 1/2 bound the series order 6.
    C_lim=a("128000")
    _,_,M3=finite_real_moments(N,PREV/"jet_half_tight.json")
    C_fin=(N**a("1/400")) * M3/2304
    ef=K*(2+2*t)**(4*a("387/500"))/N**q
    es=(ef, 8*ef/t**2 + (C_lim+C_fin)*t**4*4
                     + (1024*1000 + (N**a("1/400"))*M3**a("2/3"))*t**2/16,
              16*(10*ef+68*(C_lim+C_fin)*t**6)/(3*t**4))
    rows=json.loads(Path(jets).read_text())["exact_dyadic_disks"]
    values=[]
    errors=[]
    for k,e in enumerate(es):
        r=rows[str(k)]
        values.append(acb(dyadic(r["real"]),dyadic(r["imag"])))
        errors.append((dyadic(r["radius"])+e).upper())
    return values,errors

def executed(R,h):
    c,center=CASES[R]
    p=list(map(a,c))
    q=[acb(a(x),a(y)) for x,y in center]
    panels,margin=certify_shape(R,h,p,q)
    N=arb(10)**100
    M=arb(1024)
    real,_,_=finite_real_moments(N,PREV/"jet_half_tight.json")
    comp,erms=complex_moments(N,PREV/"jet_complex_reference.json")
    _,_,nu,K,_,_=constants()
    e=K*(2+M)**(4*a("387/500"))/N**nu
    pref=acb(2)**(2*h+1)*(1+h).gamma()*(-h).rgamma()
    shiftp=pref*acb(R)**(-2*h)
    mid=shiftp*sum(w*m for w,m in zip(q,comp))
    jeterr=abs(shiftp)*sum(abs(w)*e for w,e in zip(q,erms))
    residual=abs(shiftp)*N**a("1/400")*sum(w*m for w,m in zip(p,real))
    remM= abs(pref)*N**a("1/400")*real[0]/M
    bridge=abs(pref)*e*(1/arb(R)-1/M)
    past=budget(M,arithmetic=True)
    radius=(jeterr+residual+remM+bridge+past+mid.real.rad()+mid.imag.rad()).upper()
    mid=acb(mid.real.mid(),mid.imag.mid())
    def d(x):
        m,e=x.man_exp()
        return str(m),int(e)
    return dict(R=R, h=["1/2","1/8"], tilt=["1/2","1/20"], degree=2,
        majorant=c, polynomial_center=center, pilot_panels=panels,
        minimum_margin=str(margin), tail_center=[mid.real.str(18),mid.imag.str(18)],
        tail_radius=radius.str(18), tail_centre_dyadic=[d(mid.real),d(mid.imag)], tail_radius_dyadic=d(radius), radius_breakdown={k:v.str(18) for k,v in zip(
            ["finite_complex_jet","shape","finite_tail_beyond_M","bridge_error","limit_beyond_M"],
            [jeterr,residual,remM,bridge,past])})

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--jets-dir",type=Path,default=PREV)
    a0=parser.parse_args()
    PREV=a0.jets_dir
    with ctx.workprec(128):
        print(json.dumps([executed(R,acb(a("1/2"),a("1/8"))) for R in CASES],indent=2))
