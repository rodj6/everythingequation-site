#!/usr/bin/env python3
"""Outward pricing of the depth-one limiting-Cayley defect bound.

The computations use explicit rational conservative parameters.  To run:
PYTHONPATH=ranktwo/.deps python depthone_tail/price_shell.py
"""
import json
from flint import arb, ctx, fmpq


def q(n, d=1):
    return arb(fmpq(n, d))


def evaluate():
    ctx.prec = 160
    pi = arb.pi()
    eps = q(1, 100)
    K = (pi / 20).exp()
    J = (pi / 20).sinh() / pi
    # For n≥3*rho+3, (19.P1) sharpens with no exponential in rho.
    beta = q(2, 5)
    m0 = 8192
    t = arb(m0).sqrt()
    off_tail = (1 + q(2).sqrt()) * K * 2 * (-beta*t).exp() * (
        t**3/beta + 3*t**2/beta**2 + 6*t/beta**3 + 6/beta**4)
    assert off_tail < eps
    assert beta*t > 2
    # det G > .94 is the previous verified h=0 real tilt mass at c=1.
    gamma = (-q(47,50).log()).sqrt()
    b2 = 8 * gamma * gamma
    eta = 4*K*J/(1-gamma)
    defect = q(3,4)/pi**2
    loss = eps*(5*K*K+2)/(1-gamma)
    H = (eta*(arb(8).log()+5) + loss + q(7,4)*b2 + q(21,16)*defect).exp()
    k = q(7,32)*defect
    sigma = q(2,5)**q(1,3)
    w = q(17,16)
    # Signed limiting density bounds from Fourier inversion and Parseval.
    r0 = arb(m0+4)
    H0 = (eta*((2*r0).log()+5) + loss).exp()
    B0 = H0*(1+r0)**eta
    def gamma_int(power,decay):
        exponent = 3*(power+1)
        return 3*exponent.gamma()/decay**exponent
    pinf = (B0*r0**2/2+H*gamma_int(eta+1,k*sigma))/(2*pi)
    p2 = ((B0**2*r0**2/2+H**2*gamma_int(2*eta+1,2*k*sigma))/(2*pi)).sqrt()
    bes = q(6,5)*(1+(q(145,16)).sqrt()/q(5,2))
    def bessel_budget(R):
        R = arb(R)
        delta = (p2/(2*(2*pi).sqrt()*pinf)).max(1/R)
        price = w*(pi*pinf*R**(-3)+bes*R**q(-5,2)*(4*pi*pinf*delta.sqrt()
                                                 +(2*pi).sqrt()*p2/delta.sqrt()))
        return dict(R=int(R.unique_fmpz()), split_radius=str(delta), hard_tail=str(price), parseval_only=str(w*(pi/2).sqrt()*p2*R**(-2)))
    def budget(R):
        R = arb(R)
        x = sigma*R**q(1,3)
        angular = 2/sigma*(1+1/(k*x)+1/(k*x)**2)
        max_transform = H*R**eta*(-k*x).exp()
        trace_shell = defect*(x-6)
        direct = 3*w*H/(k*sigma)*R**(eta-q(4,3))*(-k*x).exp()
        improved = 3*w*H*angular/(k*sigma)*R**(eta-q(5,3))*(-k*x).exp()
        return dict(R=int(R.unique_fmpz()), main_shell_x=str(x),
                    tr_defect_witness_squared=str(trace_shell),
                    raw_pointwise_upper=str(max_transform),
                    hard_tail_no_angular=str(direct),
                    hard_tail_with_angular=str(improved))
    result = {
        'theta_parameter_convention': 'w=exp(i theta); t=(1/2)*tan(theta/2)',
        'c': 1, 'h_real': '1/2', 'h_imag': '1/8',
        's_real': '1/2', 's_imag': '1/20',
        'm0':m0, 'small_mode_tail_upper':str(off_tail),
        'perturbation_cost_power':str(eta), 'fourier_prefactor':str(H), 
        'decay_in_x':str(k), 'decay_in_rho_to_one_third':str(k*sigma),
        'density_Linf':str(pinf), 'density_L2':str(p2),
        'bessel_constant':str(bes),
        'bessel_price':[bessel_budget(x) for x in [64,1024,10**4,10**5,10**6,10**8,10**9,10**10,10**11]],
        'min_R':m0+4, 'shell_price': [budget(x) for x in [
            10**4, 10**5, 10**6, 10**7, 10**8, 5*10**8,
            10**9, 2*10**9, 4*10**9, 8*10**9, 10**10, 10**11]]}
    return result

if __name__=='__main__':
    print(json.dumps(evaluate(), indent=2))
