"""Audit-ready combination of the depth-one finite part, annuli and tail."""
from pathlib import Path
import argparse
import json
from time import monotonic

from flint import arb, acb, ctx
from contour_source import R, dyadic
from annulus import restore
from analytic_bridge import constants


def analytic_tail(cutoff, delta):
    _, _, q, factor, power, min_rank = constants()
    D = max(R(4), min_rank, ((factor/delta)**(1/q)).upper())
    gamma = power/400
    mass = (D+1)**R("1/400")
    return (R("17/16")*(mass*(cutoff+2)**gamma/(1-gamma)+delta)/cutoff).upper()


def add_receipt(data):
    assert data['input']==["c=1","h=1/2+i/8","s=1/2+i/20"]
    return acb(*(restore(d) for d in data.get('midpoint_dyadic', data.get('dyadic_midpoint')))),restore(data.get('radius_dyadic', data.get('dyadic_radius')))


def combine(origin, annuli, tolerance, tail_file=None, centered_file=None):
    started=monotonic()
    data=json.loads(Path(origin).read_text())
    z,total=add_receipt(data)
    cutoff=R(1)
    archive=[dict(name=Path(origin).name, wall_seconds=data['seconds'],
                  terms=data["error_breakdown"])]
    for file in annuli:
        data=json.loads(Path(file).read_text())
        u,v=map(R,data['parameters']['range'])
        assert u==cutoff
        cutoff=v
        dz, e=add_receipt(data)
        z+=dz
        total+=e
        archive.append(dict(name=Path(file).name, wall_seconds=data['wall_seconds'],
                            terms=data["breakdown"]))
    if centered_file:
        rows=json.loads(Path(centered_file).read_text())
        proof=next(a for a in rows if R(a['R'])==cutoff)
        assert proof['h']==['1/2','1/8'] and proof['tilt']==['1/2','1/20']
        z+=acb(*(restore(v) for v in proof['tail_centre_dyadic']))
        tail=restore(proof['tail_radius_dyadic'])
        tail_method='centered Bessel bridge, '+Path(centered_file).name
    elif tail_file:
        entries=json.loads(Path(tail_file).read_text())
        candidate=[a for a in entries if R(a['radius_R'])==cutoff]
        assert len(candidate)==1
        proof=candidate[0]
        assert proof['c']=='1' and proof['h']==['1/2','1/8'] and proof['s']==['1/2','1/20']
        tail=restore(proof['tail_dyadic'])
        tail_method='integrated Bessel bridge, '+Path(tail_file).name
    else:
        tail=analytic_tail(cutoff,R("1/256"))
        tail_method='short tilt rectangle'

    m=z.mid()
    arithmetic=(z-m).abs_upper()
    error=(total+arithmetic+tail).upper()
    assert error<R(tolerance), (error,tolerance)
    modulus=(m.abs_lower()-error).lower()
    relative=(error/modulus).upper() if modulus>0 else None
    return dict(input=["c=1","h=1/2+i/8","s=1/2+i/20"],
                absolute_tolerance=tolerance, cutoff=str(cutoff),
                midpoint_display=[m.real.str(18),m.imag.str(18)],
                radius_display=error.str(18),
                midpoint_dyadic=[dyadic(m.real),dyadic(m.imag)],
                radius_dyadic=dyadic(error),modulus_lower=modulus.str(18),
                relative_bound=relative.str(18) if relative is not None else None,
                retained_allowance=total.upper().str(18),tail_allowance=tail.str(18),tail_method=tail_method,
                final_arithmetic=arithmetic.str(18),components=archive,
                seconds=monotonic()-started)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--origin',required=True)
    p.add_argument('--tolerance',required=True)
    p.add_argument('--bessel-tail')
    p.add_argument('--centered-tail')
    p.add_argument('annuli',nargs='+')
    with ctx.workprec(176):
        a=p.parse_args()
        print(json.dumps(combine(a.origin,a.annuli,a.tolerance,a.bessel_tail,a.centered_tail),indent=2))


if __name__=='__main__':
    main()
