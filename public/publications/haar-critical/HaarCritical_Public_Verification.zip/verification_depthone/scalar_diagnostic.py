"""Two floating source calculations of the same truncated depth-one scalar."""
import argparse
import json
from time import monotonic

import numpy as np
from scipy.linalg import toeplitz
from scipy.special import gamma, roots_legendre
from threadpoolctl import threadpool_limits

from exterior_probe import Exterior


class Finite:
    def __init__(self,c,s,rank,fft):
        self.rank,self.s,self.fft=rank,s,fft
        z=np.sqrt(1-c/rank)
        theta=2*np.pi*np.arange(fft)/fft
        circle=np.exp(1j*theta)
        den=1-z*circle
        self.log_weight=s*np.log(abs(den)**2)
        self.mark=(c/rank)*circle/den

    def make_base(self,rho):
        return self.log_weight

    def source(self,rho,beta,base=None):
        u=np.exp(-1j*beta)
        values=np.exp(self.log_weight+1j*rho*(u*self.mark).real)
        coef=np.fft.fft(values)/self.fft
        n=self.rank
        mat=toeplitz(coef[:n],np.r_[coef[0],coef[-1:-n:-1]])
        sg,lg=np.linalg.slogdet(mat)
        return sg*np.exp(lg-self.s**2*np.log(n))


def quadrature(pr,operators,nangles):
    out=[]
    for rho in pr:
        base=operators.make_base(rho)
        nodes=(np.arange(nangles)+.5)*2*np.pi/nangles
        out.append(np.mean([operators.source(rho,beta,base) for beta in nodes]))
    return np.array(out)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['finite','exterior'],default='exterior')
    ap.add_argument('--size',type=int,default=120)
    ap.add_argument('--angles',type=int,default=48)
    ap.add_argument('--order',type=int,default=12)
    ap.add_argument('--fft',type=int,default=8192)
    ap.add_argument('--cuts',default='1,2,4,8,16,32,64')
    args=ap.parse_args()
    start=monotonic()
    c,s,h=1, .5+.05j,.5+.125j
    fn=(Finite(c,s,args.size,args.fft) if args.mode=='finite'
        else Exterior(c,s,args.size,args.fft,180))
    fact=2**(2*h+1)*gamma(1+h)/gamma(-h)
    x,w=roots_legendre(args.order)
    with threadpool_limits(limits=1):
        static=fn.source(0,0)
        value=0
        left=0
        for right in map(float,args.cuts.split(',')):
            radii=(left+right+(right-left)*x)/2
            samples=quadrature(radii,fn,args.angles)
            value+=(right-left)*np.dot(w,radii**(-2*h-1)*(samples-static))/2
            scalar=fact*(value-static*right**(-2*h)/(2*h))
            print(json.dumps(dict(mode=args.mode,size=args.size,angles=args.angles,
                                  order=args.order,fft=args.fft,cutoff=right,
                                  truncated=[scalar.real,scalar.imag],
                                  mass=[static.real,static.imag],seconds=monotonic()-start)),flush=True)
            left=right


if __name__=='__main__':
    main()
