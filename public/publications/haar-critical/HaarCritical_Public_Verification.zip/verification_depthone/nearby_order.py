"""Transfer a certified depth-one disk to a distinct complex fractional order."""
import argparse,json
from pathlib import Path
from math import factorial

from flint import arb,acb,ctx
from annulus import restore, boundD
from contour_source import R,C,dyadic
from analytic_bridge import constants


def prefix(h):
    return acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()


def run(source_file, jets_file):
    source=json.loads(Path(source_file).read_text())
    assert source['input']==["c=1","h=1/2+i/8","s=1/2+i/20"]
    center=acb(*(restore(x) for x in source['midpoint_dyadic']))
    error=restore(source['radius_dyadic'])
    data=json.loads(Path(jets_file).read_text())['exact_dyadic_disks']
    jets=[]
    for j in range(3):
        z=data[str(j)]
        value=acb(restore(z['real']),restore(z['imag']))
        jets.append((value.abs_upper()+restore(z['radius']))/(4**j*factorial(j)**2))
    root=R("1/8")
    M=boundD(R("1/2"),R("1/2"))
    residue=M/(R("1/2")**6*(1-4*root**2))
    lg=-root.log()
    def log_integral(j):
        return root**(j-1)*(lg/(j-1)+arb(1)/(j-1)**2)
    near=(jets[1]*log_integral(2)+jets[2]*log_integral(4)+residue*log_integral(6)).upper()
    _,_,q,Dk,d,anchor=constants()
    epsilon=R("1/256")
    N=max(R(4),anchor,((Dk/epsilon)**(1/q)).upper())
    degree=d/400
    base=(N+1)**R("1/400")
    M1=(base*3**degree+epsilon).upper()
    middle=((M1+jets[0])*((lg-1)/root+1)).upper()
    far=(base*3**degree/(1-degree)**2+epsilon).upper()
    h=C(("1/2","1/8"))
    new=C(("1/2","63/500"))
    delta=abs(new-h)
    transport=prefix(new)/prefix(h)
    msg=transport*center
    charge=(prefix(new).abs_upper()*(jets[0]*abs(1/(2*new)-1/(2*h))
                       +2*delta*(near+middle+far))).upper()
    midpoint=msg.mid()
    radius=(transport.abs_upper()*error+charge+(msg-midpoint).abs_upper()).upper()
    lower=(midpoint.abs_lower()-radius).lower()
    assert lower>0
    return dict(c="1",h=["1/2","63/500"],s=["1/2","1/20"],parent=source_file,
       center=[midpoint.real.str(18),midpoint.imag.str(18)],
       dyadic_midpoint=[dyadic(midpoint.real),dyadic(midpoint.imag)],dyadic_radius=dyadic(radius),
       radius=radius.str(18),modulus_lower=lower.str(18),order_change_charge=charge.str(18),
       logarithmic_weight_allowances=[str(v) for v in (near,middle,far)])


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--parent',required=True)
    p.add_argument('--jets',default='../verification_microscopic/jet_complex_reference.json')
    a=p.parse_args()
    with ctx.workprec(180):
        print(json.dumps(run(a.parent,a.jets),indent=2))
