"""Reprice angular error on pre-existing positive annulus exact disks."""
from pathlib import Path
import argparse,json
from flint import acb,arb,ctx
from contour_source import R,C,dyadic,up
from annulus import boundD,restore


def extended_bound(rho,b):
    if b<=R("1/2"):
        return boundD(rho,b)
    assert b<=1
    K=(arb.pi()/20).exp()
    J=(arb.pi()/20).sinh()/arb.pi()
    g=R(".254")
    ep=R(".0001")
    constant=arb(4).log()/2+3+(2*arb.pi()/3).sqrt()
    M=(484+3*rho).upper().ceil()+1
    return up((b/2+b*b/4+b.exp()/(1-g)*
         (2*K*b.exp()*J*((2*M).log()+constant)+4*K*K*ep)).exp())


def log_shift(b,r):
    t=b/r
    return (t+(1+t*t).sqrt()).log()


def price(file):
    result=json.loads(Path(file).read_text())
    assert result["input"]==["c=1","h=1/2+i/8","s=1/2+i/20"]
    p=result["parameters"]
    with ctx.workprec(p["bits"]):
        x,y=map(R,p["range"])
        h=C(("1/2","1/8"))
        N=p["angular"]
        n=p["radial"]
        fac=(acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()).abs_upper()
        radius=[]
        weights=[]
        for j in range(n):
            t,w=arb.legendre_p_root(n,j,weight=True)
            r=(x+y+t*(y-x))/2
            radius.append(r)
            coeff=(y-x)*w/2*acb(r).pow(-2*h-1)
            weights.append(coeff.abs_upper())
        # Replay the exact charged bound of annulus.run.
        upD=boundD((y*y+R("1/4")).sqrt(),R("1/2"))
        angular_local=up(2*upD/(N*log_shift(R("1/2"),y)).expm1())
        old=up(fac*up(angular_local*sum(weights,arb())))
        assert arb(result["breakdown"]["angular"]).contains(old)
        node_prices=[]
        for r in radius:
            cand=[]
            for j in range(10,21):
                b=R(j)/20
                upper=extended_bound((r*r+b*b).sqrt(),b)
                cand.append(up(2*upper/(N*log_shift(b,r)).expm1()))
            node_prices.append(min(cand))
        new=up(fac*sum((w*b for w,b in zip(weights,node_prices)),arb()))
        assert new<=old
        radius=up(restore(result["dyadic_radius"])-old+new)
        result["unoptimized_dyadic_radius"]=result["dyadic_radius"]
        result["dyadic_radius"]=dyadic(radius)
        result["radius"]=radius.str(16)
        result["original_angular"]=result["breakdown"]["angular"]
        result["breakdown"]["angular"]=new.str(16)
        result["old_angular_exact"]=dyadic(old)
        result["new_angular_exact"]=dyadic(new)
        result["repriced_shifts"]="each real radial node, Cartesian imaginary shifts from 1/2 to 1"
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("receipt")
    args=p.parse_args()
    print(json.dumps(price(args.receipt),indent=2))
