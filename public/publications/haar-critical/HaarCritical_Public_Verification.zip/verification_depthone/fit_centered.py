"""Floating candidate search for certified Bessel shape majorants."""
import json
import numpy as np
from scipy.optimize import linprog
from scipy.special import gamma

h=.5+.125j
CG=2**(-2*h-1)*gamma(-h)/gamma(1+h)
m=np.array([.94236463063698,.32129885224487,.22909223895492])
angles=np.linspace(0,2*np.pi,40,endpoint=False)
cos,sin=np.cos(angles),np.sin(angles)
ar=np.zeros(9)
ar[:3]=m


def Q(x):
    x=np.asarray(x)
    t=np.ones_like(x); z=t.astype(complex)/(-2*h)
    for j in range(1,96):
        t=t*(-x*x/4)/(j*j)
        z+=t/(2*j-2*h)
    return CG*x**(2*h)-z


def fit(R):
    rad=np.linspace(.00001,2,1601)
    y=rad**2
    mon=np.array([np.ones_like(y),y,y*y]).T
    q=Q(R*rad)
    pp=[]
    rr=[]
    for v,c,s in zip(range(len(angles)),cos,sin):
        pp.append(np.column_stack([-mon,-c*mon,-s*mon]))
        rr.append(-(q.real*c+q.imag*s+.002))
    # Shifted coefficients in X-4. Preserve triangle bound for r>=2.
    mat=np.array([[1,4,16],[0,1,8],[0,0,1]])
    for c,s in zip(cos,sin):
        pp.append(np.column_stack([-mat,c*mat,s*mat]))
        rr.append(np.array([-.142,-.002,-.002]))
    result=linprog(ar,A_ub=np.vstack(pp),b_ub=np.concatenate(rr),
        bounds=[(None,None)]*9,method='highs')
    assert result.success,result.message
    v=np.round(result.x,3)
    v[0]+=.006
    v[1]+=.003
    v[2]+=.001
    print(json.dumps(dict(R=R,p=list(v[:3]),center=[[a,b] for a,b in zip(v[3:6],v[6:9])],
                          objective=float(m@v[:3])),indent=2))


if __name__=='__main__':
    import sys
    fit(int(sys.argv[1]))
