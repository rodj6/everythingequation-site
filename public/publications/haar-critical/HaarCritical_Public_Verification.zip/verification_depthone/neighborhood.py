"""Price the short-rectangle tail uniformly near the depth-one test."""
from flint import arb, acb, fmpq, ctx
import json

def r(s): return arb(fmpq(str(s)))

def bound(cmin,cmax,u0,u1,h,zmax,R):
    B=r("5/4")
    H=r("1/4")
    lam=r("7/25")
    ar=(zmax/H+2*arb(2).sqrt()*(-arb.pi()*(r("3/4")-r("1/100"))/(2*H)).exp()).upper()
    assert ar<lam
    q=1-lam*(1+H*H)
    A=max(arb(1),(cmin**(-B*B)).upper())
    kap=cmin/4
    S=2**B*(2+1/kap)
    D=1+4*cmax+4*cmax*cmax+2*B*cmax
    K0=A*(B*cmax+2*D*2**B*(2+5*S).exp()*(9+(1/kap+2/kap**2+2/kap**3)/(2*arb.pi())))
    L=((2*K0)**(1-lam)*(A*2**(1+H*H))**lam/(1-2**(-q))).upper()
    d=r("1/256")
    N=max(arb(4),(2*cmax).ceil().upper(),
          ((K0/(A*2**(H*H)))**(1/(1+H*H))).upper(),((L/d)**(1/q)).upper())
    power=4*(1-lam)/q
    gamma=power*zmax*zmax
    assert gamma<2*u0
    c=(cmin.union(cmax))
    pref=(acb(c).pow(-2*h)*acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()).abs_upper()
    e=(pref*R**(-2*u0)*(A*(N+1)**(zmax*zmax)*(R+2)**gamma/(2*u0-gamma)+d/(2*u0))).upper()
    return dict(real_order_lower=u0.str(12),real_order_upper=u1.str(12),order_ball=str(h),
                imag_tilt_upper=zmax.str(12),cutoff=R.str(12),
                gamma=gamma.str(15),prefactor=pref.str(15),tail=e.str(17))

if __name__=='__main__':
    with ctx.workprec(160):
        a,b=r("49/100"),r("51/100")
        h=acb(a.union(b),r("11/100").union(r("7/50")))
        print(json.dumps([
            dict(case="uniform compact",**bound(r("99/100"),r("101/100"),a,b,h,r("3/50"),arb(8))),
            dict(case="distinct nearby tuple c=101/100,h=51/100+7i/50,s=49/100+3i/50",
                 **bound(r("101/100"),r("101/100"),b,b,acb(b,r("7/50")),r("3/50"),arb(8)))],indent=2))
