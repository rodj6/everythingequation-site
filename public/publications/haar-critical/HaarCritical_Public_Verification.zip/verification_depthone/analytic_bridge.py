"""Reprice the microscopic Fourier tail through an analytic comparison rank.

The selected integer rank is used solely in the proof. Nothing at that rank
is evaluated by the script.  Python-FLINT/Arb supplies all bounds.
"""
import argparse
import json
from fractions import Fraction
from flint import arb, ctx, fmpq

def a(x):
    q = Fraction(str(x))
    return arb(fmpq(q.numerator,q.denominator))

def constants(v=a("1/20"), H=a("1/4"), W=a("3/4"), eta=a("113/500")):
    pi = arb.pi()
    B = a("1/2")+W
    edge = v/H+2*arb(2).sqrt()*(-pi*W/(2*H)).exp()
    assert edge < eta
    # These are equation (19.M4) at c_-=c_+=1, U=B.
    kappa = a("1/4")
    S = 2**B*(2+1/kappa)
    Delta = 9+2*B
    I = 1/kappa+2/kappa**2+2/kappa**3
    C = B+2*Delta*2**B*(2+5*S).exp()*(9+I/(2*pi))
    q = 1-eta*(1+H*H)
    K = ((2*C)**(1-eta)*(2**(1+H*H))**eta/(1-2**(-q))).upper()
    rank_power = (4*(1-eta)/q).upper()
    min_D = ((C/2**(H*H))**(1/(1+H*H))).upper()
    return edge, C, q, K, rank_power, min_D

def budget(r, delta=a("1/256"), imag_h=a("1/8"), arithmetic=False):
    edge, C, q, K, power, min_D = constants()
    v = a("1/20")
    D = max(a("4"), min_D, ((K/delta)**(1/q)).upper())
    gamma = power*v*v
    coeff = (1+2*r**(-1)).upper()
    mass = (D+1)**(v*v)
    pref = 1 + 4*imag_h*imag_h
    tail = (pref*(mass*(r+2)**gamma/(1-gamma)+delta)/r).upper()
    if arithmetic:
        return tail
    return dict(c="1", h=["1/2",str(imag_h)], s=["1/2","1/20"], cutoff=str(r),
        gamma=gamma.str(20), eta_actual_upper=edge.str(20), q=q.str(20), 
        C_real=C.str(20), log10_comparison_rank_upper=((D+1).log()/arb(10).log()+power*(r+2).log()/arb(10).log()).str(20),
        mass_envelope_at_cutoff=(mass*(r+2)**gamma+delta).str(20),
        pointwise_telescope_error=delta.str(20), absolute_mellin_tail=tail.str(20))

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--cutoff", nargs="+", default=["8","16","32","64","128","256","512","1024"])
    p.add_argument("--delta",default="1/256")
    with ctx.workprec(160):
        args=p.parse_args()
        print(json.dumps([budget(a(r),a(args.delta)) for r in args.cutoff],indent=2))
