"""Arb reevaluation of the refined exterior comparison at HaarCritical depth 1."""
import argparse
import json
from flint import acb, arb, ctx, fmpq

def real(a):
    return arb(fmpq(str(a)))

def cutoff_budget(R, tol, imag_h):
    R, tol, imag_h = map(real, (R,tol,imag_h))
    if not R >= 1 or not tol > 0:
        raise ValueError("The frequency cutoff must be at least one, and tolerance positive.")
    pi = arb.pi()
    v = real("1/20")
    K = (pi*v).exp()
    J = (pi*v).sinh()/pi
    g = (-real("1/2")).exp()/(4*pi.sqrt())+3*arb(2).sqrt()*(1/arb(2).sqrt()).erfc()/8
    assert g < real("127/500")
    g = real("127/500")
    eps = real("1/10000")
    M0 = 400
    b = arb(2).log() - real("1/4")
    r = (-b).exp()
    exp_series = r**(M0+1)*(M0+1-M0*r)/(1-r)**2
    q = arb(M0).sqrt()
    stretched = 2*(-q).exp()*(q**3+3*q*q+6*q+6)
    trace_tail_bound = K*(arb(2).sqrt()*exp_series+stretched)
    assert trace_tail_bound < eps
    theta = 2*K*J/(1-g)
    c1 = (arb(4).log()/2)+3+(2*pi/3).sqrt()
    defect0 = 4*K*K*eps/(1-g)
    h = acb(real("1/2"),imag_h)
    pref = abs(acb(2)**(2*h+1) * (1+h).gamma() * (-h).rgamma())
    M_R = 401+3*R
    # For r >= R, M(r) <= (401+3R)r/R.  This integrates (M(r)/M_R)^theta exactly.
    tail = pref*(theta*c1+defect0).exp()*(2*M_R)**theta/((1-theta)*R)
    tail = tail.upper()
    # Global M(r)<=404*r if r>=1. Report a sufficient cutoff.
    normed_constant = pref*(theta*c1+defect0).exp()*808**theta/(1-theta)
    sufficient = ((normed_constant/tol).log()/((1-theta)*arb(10).log())).upper()

    def s(x): return x.str(18)
    return dict(c="1", h=["1/2",str(imag_h)], tilt=["1/2","1/20"], R=s(R),
        tolerance=s(tol), defect_exponent=s(theta), cutoff_tail_trace_bound=s(trace_tail_bound),
        static_overlap=s(g), source_bound_at_cutoff=s(((theta*c1+defect0).exp()*(2*M_R)**theta).upper()),
        mellin_prefactor=s(pref), absolute_mellin_tail=s(tail),
        log10_sufficient_cutoff_using_401_plus_3rho_le_404rho=s(sufficient))

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--cutoff", nargs="+", default=["8","16","32","64","128","256","512","1024"])
    p.add_argument("--tol", default="1/1000000000000")
    p.add_argument("--imag-h",default="1/8")
    args=p.parse_args()
    with ctx.workprec(160):
        print(json.dumps([cutoff_budget(r,args.tol,args.imag_h) for r in args.cutoff],indent=2))
