"""Direct finite Haar Toeplitz source and an independent scalar diagnostic."""
import argparse
import json
import math
from time import monotonic
import numpy as np
from scipy.linalg import toeplitz
from scipy.special import gamma
from numpy.polynomial.legendre import leggauss
from threadpoolctl import threadpool_limits


def finite_ball(rank, scale, rho, angle_number, angle_denominator):
    from flint import acb, acb_mat, arb, ctx
    s=acb(arb(1)/2,arb(1)/20)
    d=arb(1)/rank
    z=(1-d).sqrt()
    shift=-z.log()/2
    upper_radius=z*shift.exp()
    amplitude=(-2*s.real.abs_upper()*(1-upper_radius).log()
               +arb.pi()*s.imag.abs_upper()
               +rho*d*shift.exp()/(1-upper_radius)).exp()
    alias=(2*amplitude*(-shift*(scale-rank+1)).exp()
           / (1-(-shift*scale).exp())).upper()
    angle=2*arb.pi()*angle_number/angle_denominator
    p=rho*acb(0,angle).exp()
    q=p.conjugate()
    samples=[]
    for j in range(scale):
        w=acb(0,2*arb.pi()*j/scale).exp()
        m,pw=1-z*w,1-z*w.conjugate()
        sym=s*(m.log()+pw.log())+acb(0,1)*d*(p*w/m+q*w.conjugate()/pw)/2
        samples.append(sym.exp())
    fourier=[v/scale+acb(arb(0,alias),arb(0,alias)) for v in acb.dft(samples)]
    matrix=acb_mat([[fourier[(j-k)%scale] for k in range(rank)]
                   for j in range(rank)])
    out=acb(rank).pow(-s*s)*matrix.det()
    def dy(v):
        a,n=v.man_exp()
        return [str(a),int(n)]
    return dict(rank=rank,grid=scale,rho=rho,angle_turns=f"{angle_number}/{angle_denominator}",
                enclosure=str(out),alias_allowance=str(alias),bits=ctx.prec,
                midpoint_dyadic=[dy(out.real.mid()),dy(out.imag.mid())],
                component_radii_dyadic=[dy(out.real.rad()),dy(out.imag.rad())])


class FloatingFinite:
    def __init__(self,rank,grid,angles):
        self.rank,self.grid,self.angles=rank,grid,angles
        s=.5+.05j
        z=np.sqrt(1-1/rank)
        w=np.exp(2j*np.pi*np.arange(grid)/grid)
        f=w/(rank*(1-z*w))
        self.mass_factor=np.exp(-s*s*np.log(rank))
        self.base=np.exp(s*(np.log(1-z*w)+np.log(1-z*w.conjugate())))
        self.directions=np.exp(2j*np.pi*np.arange(angles)/angles)
        self.project=np.real(self.directions[:,None]*f)
    def average(self,rho):
        block = self.base[None,:]*np.exp(1j*rho*self.project)
        vals=np.fft.fft(block,axis=1)/self.grid
        rank=self.rank
        value=0j
        for c in vals:
            matrix=toeplitz(c[:rank],c[np.r_[0,np.arange(self.grid-1,self.grid-rank,-1)]])
            sign,mag=np.linalg.slogdet(matrix)
            value+=sign*np.exp(mag)
        return value*self.mass_factor/self.angles


def scalar(rank,grid,angles,order,maximum):
    f=FloatingFinite(rank,grid,angles)
    h=.5+.125j
    mass=f.average(0)
    p=2**(2*h+1)*gamma(1+h)/gamma(-h)
    x,w=leggauss(order)
    values=[]
    for a,b in zip([0,.125,.25,.5,1,2,4,8,16,32,64,128], [.125,.25,.5,1,2,4,8,16,32,64,128,256]):
        if a>=maximum:
            break
        b=min(b,maximum)
        nodes=(a+b)/2+(b-a)*x/2
        v=[f.average(t) for t in nodes]
        if b<=1:
            v=[a-mass for a in v]
        values.append(sum(v*w*nodes**(-2*h-1)*(b-a)/2))
    out=p*(-mass/(2*h)+sum(values))
    return dict(rank=rank,grid=grid,angles=angles,order=order,cutoff=maximum,
                mass=[mass.real,mass.imag],coefficient_truncation=[out.real,out.imag],
                status="floating diagnostic without finite-rank or radial-tail certificate")


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--ranks",nargs="+",type=int,default=[16,32,64])
    p.add_argument("--ball",action="store_true")
    p.add_argument("--grid",type=int,default=8192)
    p.add_argument("--angles",type=int,default=48)
    p.add_argument("--order",type=int,default=16)
    p.add_argument("--cutoff",type=int,default=64)
    args=p.parse_args()
    started=monotonic()
    with threadpool_limits(limits=1):
        if args.ball:
            from flint import ctx
            with ctx.workprec(96):
                output=[finite_ball(rank,args.grid,rho,k,4)
                        for rank in args.ranks for rho in (0,1,2,4)
                        for k in ((0,) if rho==0 else (0,1))]
        else:
            output=[scalar(rank,args.grid,args.angles,args.order,args.cutoff)
                    for rank in args.ranks]
    print(json.dumps(dict(rows=output,seconds=monotonic()-started),indent=2))
