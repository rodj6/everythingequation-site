"""Floating Hardy-compression calculation. The output is diagnostic only."""
import argparse
import json
from time import monotonic

import numpy as np
from scipy.linalg import hankel, toeplitz
from scipy.special import jv, roots_legendre
from threadpoolctl import threadpool_limits


class Exterior:
    def __init__(self, c, s, size, fft, gauss):
        self.c, self.s, self.size = c,s,size
        self.a=c/2
        self.fft=fft
        t, wt=roots_legendre(gauss)
        self.cut_grid=(t+1)/2
        self.cut_weights=wt/2
        n=np.arange(size)
        self.diff=n[:,None]-n[None,:]
        self.refl=n[:,None]+n[None,:]+2
        self.angles=2*np.pi*(np.arange(fft)/fft-1/2)+np.pi/fft

    def make_base(self,rho):
        r=1-1/max(3,rho)
        n=np.arange(1,2*self.size)
        w=r*np.exp(1j*self.angles)
        shape=np.exp(-self.s*(np.log(r)+1j*self.angles)-self.a*(1-w)/(1+w))
        x=r+(1-r)*self.cut_grid
        signs=(-1.)**(n-1)
        cut=(np.sin(np.pi*self.s)/np.pi*signs*(1-r))[:,None]*(
            np.exp((n[:,None]-1-self.s)*np.log(x)-self.a*(1+x)/(1-x))*self.cut_weights)
        return r, n, w, shape, x, cut

    def source(self,rho,beta,base=None):
        r,n,w,shape,x,cut=self.make_base(rho) if base is None else base
        g=np.exp(1j*beta)
        p,q=rho*g,rho/g
        vals=[]
        for z,zz in [(p,q),(q,p)]:
            at=shape*np.exp(-.5j*(z*w+zz/w))
            av=np.fft.ifft(at)[n]*r**n*np.exp(1j*n*(-np.pi+np.pi/self.fft))
            val=av+cut@np.exp(.5j*(z*x+zz/x))
            vals.append(hankel(val[:self.size],val[self.size-1:]))
        J=jv(np.arange(-self.size+1,2*self.size+1),rho)
        pos=self.size-1
        U0=1j**self.diff*J[self.diff+pos]
        reflected=1j**self.refl*J[self.refl+pos]
        diag=[]
        evo=[]
        for gauge in (1/g,g):
            G=gauge**self.diff
            evo.append(G*(U0-reflected))
            diag.append(G*((-1j)**self.refl)*J[self.refl+pos])
        A=np.block([[evo[0]@diag[0], evo[0]@vals[0]],
                    [evo[1]@vals[1], evo[1]@diag[1]]])
        A.flat[::A.shape[0]+1]+=1
        sign,log=np.linalg.slogdet(A)
        return sign*np.exp(log-1j*self.s*p.real-self.s**2*np.log(self.c))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--size',type=int,default=100)
    parser.add_argument('--fft',type=int,default=8192)
    parser.add_argument('--angle',type=int,default=32)
    parser.add_argument('--gauss',type=int,default=160)
    parser.add_argument('--rhos',default='0,1,2,4,8,12,16,24,32,48,64,96,128,192,256')
    parser.add_argument('--sre',type=float,default=.5)
    parser.add_argument('--sim',type=float,default=.05)
    args=parser.parse_args()
    est=Exterior(1,args.sre+1j*args.sim,args.size,args.fft,args.gauss)
    with threadpool_limits(limits=1):
        for rho in map(float,args.rhos.split(',')):
            start=monotonic()
            base=est.make_base(rho)
            vals=np.array([est.source(rho,x,base)
                           for x in (np.arange(args.angle)+.5)*(2*np.pi/args.angle)])
            out={"rho":rho,"Phi":[np.mean(vals).real,np.mean(vals).imag],
                 "pointwise_max":max(abs(vals)),
                 "absolute_average":float(np.mean(abs(vals))),
                 "seconds":monotonic()-start}
            print(json.dumps(out),flush=True)

if __name__=='__main__':
    main()
