"""Positive depth-one diagonal upper bound via a certified degree-three jet."""
from pathlib import Path
import sys,json
from math import factorial
from time import perf_counter
from flint import acb, acb_mat, arb, ctx
from contour_source import Keyhole, C, R, up, dyadic, frobenius
BASE=Path(__file__).resolve().parent
OLD=BASE.parent/'verification_microscopic'
sys.path.insert(0,str(BASE/'inherited' if (BASE/'inherited').is_dir() else OLD))
from jet_certificate import multiply, trace, exp_poly, beta_indices


def jets(D,n,r):
    ix=beta_indices(n)
    m=D.project
    d=len(D.nodes)
    e,ct,cq=D.estimates(acb(r),acb(r))
    M={}
    for j,k in ix:
        coefficients=[w*c**j*b**k/(factorial(j)*factorial(k))
                       for w,b,c in D.data]
        a=(D.P*acb_mat(d,1,coefficients)).entries()
        M[j,k]=acb_mat(m,m,[a[i+g] for i in range(m) for g in range(m)])
    extra=up(sum((w.abs_upper()*(r*(b.abs_upper()+c.abs_upper())).exp()*f
                   for (w,b,c),f in zip(D.data,D.proj_factor)),arb()))
    error=up(e+extra)
    norm=up(frobenius(M[0,0])+sum( ( w.abs_upper()*
                    (r*(b.abs_upper()+c.abs_upper())).expm1()/(2*u.real)
                         for (w,b,c),u in zip(D.data,D.nodes)),arb()))
    err_product=error*(2*norm+error)
    err_det=err_product*(1+norm**2+(norm+error)**2).exp()
    err_src=err_det*(D.s.abs_upper()*r+r*r/4).exp()
    A=multiply(M,{(j,k):M[k,j] for j,k in ix},n)
    K=D.I-A.pop((0,0))
    inv=K.inv()
    T={degree:inv*val for degree,val in A.items()}
    L={}
    pw=T
    for a in range(1,2*n+1):
        for degree,val in pw.items():
            L[degree]=L.get(degree,acb(0))-trace(val)/a
        if a<2*n:
            pw=multiply(pw,T,n)
    for deg,val in { (1,0):-acb(0,1)*D.s/2,(0,1):-acb(0,1)*D.s/2,(1,1):-R("1/4")}.items():
        L[deg]=L.get(deg,acb(0))+val
    source=exp_poly(L,n)
    M0=K.det()
    moments=[]
    for j in range(n+1):
        scale=(-4)**j*factorial(j)**2
        A=M0*source[j,j]*scale
        allowance=up(err_src*abs(scale)/r**(2*j))
        moments.append(A.real+arb(0,allowance))
    return moments,dict(hs_minus=error.str(16),hs_quad=cq.str(16),hs_line=ct.str(16),
                          hs_projection=extra.str(16),source_allowance=err_src.str(16),norm=norm.str(16))


def run():
    start=perf_counter()
    D=Keyhole(1,"1/2","42",n=23,project=102,laguerre="2")
    moments,info=jets(D,3,R("1/4"))
    m0,m1,m2,m3=moments
    delta=m0*m2-m1*m1
    # Monic q(x)=x²+beta*x+gamma orthogonal to 1,x.
    beta=(m1*m2-m0*m3)/delta
    gamma=(m1*m3-m2*m2)/delta
    discr=(beta*beta-4*gamma).sqrt()
    x1=(-beta-discr)/2
    x2=(-beta+discr)/2
    w1=(x2*m0-m1)/(x2-x1)
    w2=(m1-x1*m0)/(x2-x1)
    if not (x2>x1 and x1>0 and w1>0 and w2>0):
        raise ArithmeticError("Gaussian normalizer did not validate")
    upper=(w1*x1.sqrt()+w2*x2.sqrt()).upper()
    lower=(m1**R("3/2")/m2.sqrt()).lower()
    return dict(input=dict(c=1,h="1/2",s="1/2"),upper=str(upper),lower=str(lower),
                exact_interval=[dyadic(lower),dyadic(upper)],
                moments=[z.str(17) for z in moments],moment_dyadics=[
                   [dyadic(z.lower()),dyadic(z.upper())] for z in moments],
                nodes=[z.str(17) for z in (x1,x2)],weights=[z.str(17) for z in (w1,w2)],
                bits=ctx.prec,gauss=23,extent=42,radius="1/4",laguerre="2",project=102,
                errors=info,seconds=perf_counter()-start)

if __name__=="__main__":
    with ctx.workprec(140):
        print(json.dumps(run(),indent=2))
