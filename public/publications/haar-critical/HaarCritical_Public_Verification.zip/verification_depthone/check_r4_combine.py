"""An independent exact-rational audit of the R=4 full disk assembly."""
import argparse
from fractions import Fraction
from pathlib import Path
import json


def read(path):
    return json.loads(Path(path).read_text())


def dyadic(pair):
    m,e=pair
    return Fraction(int(m))*Fraction(2)**int(e)


def disk(path):
    z=read(path)
    return (tuple(map(dyadic,z.get("midpoint_dyadic",z.get("dyadic_midpoint")))),
            dyadic(z.get("radius_dyadic",z.get("dyadic_radius"))))


def dyadic_export(frac):
    d=frac.denominator
    e=d.bit_length()-1
    assert d==1<<e
    return [str(frac.numerator),-e]


def rational_audit(origin, panels, tail_file, combined, modulus):
    adds=[disk(f) for f in (origin,*panels)]
    mid=tuple(sum(z[0][i] for z in adds) for i in range(2))
    quadrature_radius=sum(z[1] for z in adds)
    t=[x for x in read(tail_file) if Fraction(x["radius_R"])==4]
    assert len(t)==1 and t[0]["h"]==["1/2","1/8"] and t[0]["s"]==["1/2","1/20"]
    tail_radius=dyadic(t[0]["tail_dyadic"])
    total_radius=quadrature_radius+tail_radius
    combined_mid, combined_rad=disk(combined)
    gap=combined_rad-total_radius
    offset=sum((x-y)**2 for x,y in zip(combined_mid,mid))
    assert gap>=0 and gap*gap>=offset
    desired=Fraction(modulus)
    assert desired>0
    assert sum(z*z for z in combined_mid)>(combined_rad+desired)**2
    return dict(status="proved with exact dyadic rational inequalities",cutoff=4,
                positive_modulus_lower_bound=modulus,
                inputs=[str(x) for x in (origin,*panels,tail_file,combined)],
                finite_part_radius=dyadic_export(quadrature_radius),
                omitted_tail_radius=dyadic_export(tail_radius),
                total_radius=dyadic_export(total_radius),
                exact_summed_midpoint=[dyadic_export(x) for x in mid],
                matches_published_midpoint=(mid==combined_mid))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--origin",required=True)
    parser.add_argument("--tail",required=True)
    parser.add_argument("--combined",required=True)
    parser.add_argument("--modulus",default=".22322327702145355")
    parser.add_argument("panels",nargs=3)
    args=parser.parse_args()
    print(json.dumps(rational_audit(args.origin,args.panels,args.tail,args.combined,args.modulus),indent=2))
