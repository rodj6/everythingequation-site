"""Certify an angular-integrated hard-cutoff Mellin tail, depth 1."""
import argparse
from pathlib import Path
import json
from flint import acb, arb, ctx, fmpq
from analytic_bridge import a, constants, budget

BASE = Path(__file__).resolve().parent
PREVIOUS = BASE.parent / "verification_microscopic/jet_half_tight.json"
if not PREVIOUS.exists():
    PREVIOUS = Path("round_release/HaarCritical_Microscopic_Source/verification_microscopic/jet_half_tight.json")

def q_kernel(x, h, n=64):
    # Q_h(x)=integral_1^infty r^(-2h-1) J_0(rx) dr.
    w = -(x*x)/4
    t = arb(1)
    z = acb(t)/(-2*h)
    for k in range(1, n):
        t = t*w/(k*k)
        z += t/(2*k-2*h)
    t = t*w/(n*n)
    r = abs(w)/(n+1)**2
    assert r < 1
    err = abs(t)/((2*n-2*h.real)*(1-r))
    C = acb(2)**(-2*h-1)*(-h).gamma()/(h+1).gamma()
    q_num = C*acb(x)**(2*h)-z
    return abs(q_num).upper()+err

def p_poly(x2, coefs):
    return coefs[0]+x2*(coefs[1]+x2*coefs[2])

def prove_envelope(R, coefs):
    h = acb(a("1/2"),a("1/8"))
    start, end = a("1/40"), a("5/4")
    assert 1 < coefs[0]+coefs[1]*start*start
    assert p_poly(end*end, coefs) > 1
    assert coefs[1]+2*coefs[2]*end*end > 0
    step = a("1/2000")
    # Endpoints start and end are multiples of the step.
    min_margin = a("1")
    for j in range(50,2500):
        x2 = arb(j)/(2000)
        x1 = arb(j+1)/(2000)
        xc = (x1+x2)/2
        q_upper = q_kernel(R*xc, h).upper() + (abs(2*h)+1)*step/(2*x2)
        span = x1.union(x2)
        margin = (p_poly(span*span, coefs)-q_upper).lower()
        assert margin > 0, (j, str(margin))
        min_margin = min(margin,min_margin)
    return min_margin

def dyadic(parts):
    return arb(int(parts[0]))*arb(2)**parts[1]

def finite_real_moments(N, fname):
    _, C, _, _, _, _ = constants()
    step = a("1/1000")
    # Strong Szegő on e^{3 R cos(theta)} then angular averaged cosh,
    # whose (third positive) radial Taylor coefficient is 3^6/(4^3(3!)^2).
    M3 = (a("15/4").exp()*2304/729).upper()
    M2 = (M3**a("2/3")).upper()
    error = C*(2+2*step)**4/N
    # Phi(t)-m_0=-m_1 t²/4 + m_2 t⁴/64 + remainder <= M_3 t^6/2304.
    delta0 = error
    delta1 = 4*(2*error)/step**2 + 2*M2*step**2/16 + 2*M3*step**4/576
    delta2 = (16/(3*step**4))*(10*error+2*M3*68*step**6/2304)
    limits = json.loads(Path(fname).read_text())["exact_dyadic_disks"]
    out=[]
    for k, remainder in enumerate((delta0, delta1,delta2)):
        row = limits[str(k)]
        val=dyadic(row["real"])
        er=dyadic(row["radius"])+remainder
        out.append(val+arb(0,er.upper()))
    return out, [delta0,delta1,delta2], M3

def integrated_budget(R, M, fname):
    coefs = [a(k) for k in {
        "4": ["1.02","-2.25","1.5"],
        "5": ["1.02","-2.46","1.61"],
        "6": ["1.02","-2.73","2.04"],
        "8": ["1.02","-2.46","1.62"],
    }[R]]
    R=a(R)
    M=a(M)
    assert M>=R
    margin=prove_envelope(R,coefs)
    N=arb(10)**60
    _,C,q,K,l,min_D=constants()
    assert N>min_D*(M+2)**(4/(1+a("1/4")**2))
    uniform_error = (K*(2+M)**(4*a("387/500"))/N**q).upper()
    finite_real, deltas, M3=finite_real_moments(N,fname)
    e= sum(x*y for x,y in zip(coefs,finite_real))
    loss = N**a("1/400")
    pref=a("17/16")
    k1 = (pref*loss*e/R).upper()
    k2 = (pref*loss*finite_real[0]/M).upper()
    k3 = (pref*uniform_error*(1/R-1/M)).upper()
    k4 = budget(M, arithmetic=True)
    tail=(k1+k2+k3+k4).upper()
    return dict(c="1",h=["1/2","1/8"],s=["1/2","1/20"],radius_R=R.str(16),
         bridge_frequency_M=M.str(16),bridge_rank="10^60", absolute_mellin_tail=tail.str(18),
         positive_polynomial_majorant_coefficients=[str(k) for k in coefs],
         minimum_panel_margin=margin.str(16),
         tail_dyadic=[str(tail.man_exp()[0]),int(tail.man_exp()[1])],
         finite_mark_moment_jets=[x.str(18) for x in finite_real],
         finite_to_limit_moment_allowances=[x.str(18) for x in deltas],
         moment_three_upper=M3.str(18), moment_file=str(fname),
         finite_mark_radial_kernel_component=k1.str(16),
         finite_mark_kernel_beyond_M=k2.str(16),uniform_band_bridge_error=k3.str(16),
         residual_limit_tail_beyond_M=k4.str(16))

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--cutoff", nargs="+",default=["4","5","6","8"])
    parser.add_argument("--bridge-frequency",default="1024")
    parser.add_argument("--jets",default=PREVIOUS)
    args=parser.parse_args()
    with ctx.workprec(128):
        print(json.dumps([integrated_budget(R,args.bridge_frequency,args.jets) for R in args.cutoff],indent=2))
