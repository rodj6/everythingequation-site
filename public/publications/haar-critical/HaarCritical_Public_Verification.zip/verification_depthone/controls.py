"""Cross-check a retained-frequency Hankel kernel and the integer normalization."""
from pathlib import Path
import sys
import json

from flint import acb, arb, ctx

from contour_source import Keyhole, R, C, up, dyadic

BASE=Path(__file__).resolve().parent
HERE=BASE/'inherited'
OLD=BASE.parent/'verification_microscopic'
sys.path.insert(0,str(HERE if HERE.is_dir() else OLD))
from finite_source import line_kernel
from jet_certificate import source_jets


def kernel_check():
    D=Keyhole(1,("1/2","1/20"),"40",n=26,project=75)
    p=C(("3/4","1/4"))
    q=p.conjugate()
    a=D.a
    v=R(1)
    z=sum((f*(l*q+r*p).exp() for f,l,r in D.data),acb())
    _,e_tail,e_quad=D.estimates(p,q)
    e_key=up(2*(a+2*D.xmax+D.delta)*e_quad+2*(a+D.xmax)*e_tail)
    # Independent inherited shifted-line Fourier quadrature at t=x-i*c/4.
    cut=R(256)
    shift=a/2
    u=a/2
    exact=line_kernel(v,a,shift,D.s,p,q,1,cut,R(2)**-50,300000,None)
    S=D.s.abs_upper()
    P=p.abs_upper()+q.abs_upper()
    E=(D.s.real.abs_upper()*R(3).log()+D.s.imag.abs_upper()*arb.pi()+a*P/u).exp()
    a1=2*S+a*P/u
    a2=2*S+2*a*P/u
    a3=4*S+6*a*P/u
    K=E*(a1**3+3*a1*a2+a3)
    e_line=up((-shift*v).exp()*K/(2*arb.pi()*v**3*cut**2))
    k=z.mid()
    m=exact.mid()
    key_error=up(e_key+(z-k).abs_upper())
    line_error=up(e_line+(exact-m).abs_upper())
    observed=up((k-m).abs_upper())
    assert observed <= key_error+line_error
    return dict(input=dict(v=1,c=1,s=["1/2","1/20"],p=["3/4","1/4"],
                      q=["3/4","-1/4"],shift_extent=256,
                      keyhole_extent=40,keyhole_gauss_per_panel=26),
          comparison="validated Hankel kernel b_+(1), before operator determinant",
          keyhole_real=k.real.str(17),keyhole_imag=k.imag.str(17),
          keyhole_radius=key_error.str(17),
          line_real=m.real.str(17),line_imag=m.imag.str(17),
          shifted_line_radius=line_error.str(17),
          numerical_discrepancy=observed.str(17),
          keyhole_dyadics=[dyadic(k.real),dyadic(k.imag),dyadic(key_error)],
          shifted_line_dyadics=[dyadic(m.real),dyadic(m.imag),dyadic(line_error)])


def integer_check():
    moments,info=source_jets(R(1),C(1),1,17,R(60),R("1/4"),R(4))
    expected=R(2)-R(5)*(-R(1)).exp()
    ok=moments[1].contains(acb(expected))
    assert ok
    return dict(input=dict(c=1,h=1,s=1,source_degree=1,gauss_per_panel=17,
                           operator_extent=60,source_radius="1/4",ellipse=4),
                integer_schur=expected.str(17),match=bool(ok),**info)

if __name__=="__main__":
 with ctx.workprec(130):
    print(json.dumps(kernel_check()),flush=True)
    print(json.dumps(integer_check()),flush=True)
