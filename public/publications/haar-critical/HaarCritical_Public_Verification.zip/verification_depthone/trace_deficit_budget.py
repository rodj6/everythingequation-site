"""Price the fixed-depth singular-deficit tail, with Arb."""
import json
from flint import acb, arb, ctx

def run():
    pi=arb.pi()
    eps=arb(1)/8
    tau=arb(1)/128
    K=(pi/20).exp()
    J=(pi/20).sinh()/pi
    C=arb(2).sqrt()*K*arb(2).exp()
    m=4
    while True:
        x=arb(m).sqrt()
        tail=2*C*(-x).exp()*(x**3+3*x*x+6*x+6)
        if tail<=tau/2:
            break
        m*=2
    M=(-arb(1)/2).exp()*(1+pi.sqrt())/pi
    gamma=arb(1)/20
    e=arb(1).exp()
    Ceps=m+1+2*(4*C/tau).log()+4/(e*eps)
    p=4*K*J*(1+eps)
    logA=(1+arb(2).sqrt())*2*M+4*K*J*((2*Ceps).log()+5)+tau*(5*K*K+2)
    q0=(arb(1)/2)/(arb(256)+arb(1)/4)/(2*pi)+M/(256*pi*(1-M))
    effective= (4-arb(4)**3/36+arb(4)**5/2880)/(4*pi*pi)-3/(4*pi*pi*(arb(38)/5))-8*q0/pi
    assert effective > gamma
    x8192=arb(8192).sqrt()
    mu=arb(2)/5
    linear_tail=2*(1+arb(2).sqrt())*K*(-mu*x8192).exp()*(
         x8192**3/mu+3*x8192**2/mu**2+6*x8192/mu**3+6/mu**4)
    assert linear_tail<tau
    t=4*K*J
    H=((1+arb(2).sqrt())*2*M+t*(arb(8).log()+5)+tau*(5*K*K+2)+20*gamma).exp()
    k=gamma/2
    h=acb(arb(1)/2,arb(1)/8)
    pref=(acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()).abs_upper()
    rows={}
    for radius in (64,10**3,10**4,10**6,10**7,5*10**7,10**8,12*10**7,2*10**8,3*10**8,10**9):
        R=arb(radius)
        y=R**(arb(1)/3)
        L=y/2
        cubic=(gamma*(20-L)).exp()
        averaged=arb(1).min(cubic).min(8*cubic/R*(L*L+2*L/gamma+2/gamma**2))
        allowance=logA.exp()*(1+2/R)**p*pref*averaged*R**(p-1)/(1-p)
        if radius>=8196:
            AB=8*(arb(1)/4+1/(gamma*y)+2/(gamma*y)**2)
            allowance=allowance.min(3/k*H*AB*R**(t-arb(5)/3)*(-k*y).exp()*pref)
        rows[str(radius)]=str(allowance.upper())
    return dict(M0=m,gram_bound=str(2*M),exponent=str(p),amplitude=str(logA.exp()),
                leakage_rate=str(gamma),verified_rate_floor=str(effective),
                linear_mode_coefficient_tail=str(linear_tail),
                scalar_tail_at_cutoff=rows)

if __name__=="__main__":
    with ctx.workprec(120):
        print(json.dumps(run(),indent=2))
