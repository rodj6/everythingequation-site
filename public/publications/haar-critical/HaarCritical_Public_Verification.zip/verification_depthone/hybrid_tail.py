"""Combine the shifted-Gram defect with the limiting angular deficit."""
from flint import arb, fmpq, ctx
import json


def a(x): return arb(fmpq(str(x)))


def bound(R):
    pi=arb.pi()
    K=(pi/20).exp()
    J=(pi/20).sinh()/pi
    C0=arb(4).log()/2+3+(2*pi/3).sqrt()
    denom=a("373/500")
    exponent=2*K*J/denom
    logamp=exponent*(arb(402).log()+C0)+4*K*K*a("1/10000")/denom
    g=a("1/20")
    L=(R/8)**a("1/3")
    assert L>20
    # L²/rho = (1/4) rho^(-1/3). The 8 from (D.4)
    # yields coefficient 2, consistent with 8^(1/3).
    angular=2*(1+2/(g*L)+2/(g*L)**2)
    det=logamp.exp()*(1+2/R)**exponent
    exact_integral=24*(g*(20-L)).exp()*(L*L/g+2*L/g**2+2/g**3)
    error=(a("17/16")*det*angular*R**(exponent-a("7/3"))*exact_integral).upper()
    return dict(cutoff=R.str(13), error=error.str(18),
                exponent=exponent.str(18),amplitude=logamp.exp().str(18),
                dyadic=list(map(str,error.man_exp())))


if __name__=='__main__':
    with ctx.workprec(160):
        print(json.dumps([bound(arb(R)) for R in
             (10**5,10**6,10**7,2*10**7,3*10**7,5*10**7,6*10**7,10**8)],indent=2))
