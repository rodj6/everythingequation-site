"""Validated keyhole contour rank approximation for HaarCritical's Fourier source."""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from time import perf_counter

from flint import arb, acb, fmpq, acb_mat, ctx


def R(value):
    if isinstance(value, arb):
        return value
    v = Fraction(value)
    return arb(fmpq(v.numerator, v.denominator))


def C(value):
    if isinstance(value, acb):
        return value
    if isinstance(value, (tuple, list)):
        return acb(R(value[0]), R(value[1]))
    return acb(R(value))


def up(value):
    return value.upper()


def lo(value):
    return value.lower()


@dataclass
class Result:
    mid: acb
    analytic: arb
    numerical: arb
    hs_error: arb
    contour_tail: arb
    contour_quad: arb
    projection: arb
    norms: tuple[arb, arb]
    inverse_perturb: arb | None
    evaluations: int
    elapsed: float


def panels(a, xmax):
    """Ellipse parameter 2. Scale near the crossing with a."""
    e = [R(0), a/2, a, 2*a]
    while e[-1] < xmax:
        e.append(2*e[-1])
    e = [x for x in e if x < xmax]+[xmax]
    if len(e) < 2:
        raise ValueError("positive keyhole extent required")
    # Forward upper ray; lower ray reversed in the weights below.
    r = [(sign,e[j],e[j+1]) for sign in (-1,1) for j in range(len(e)-1)]
    return r+[(0,R(j)/4,R(j+1)/4) for j in range(4)]


def panel_coordinates(t, sign, a, delta):
    i = acb(0,1)
    if sign:
        u = a+t+i*sign*delta
        # t+i*sign*delta remains in the proper analytic branch
        lminus = (t+i*sign*delta).log()-sign*i*arb.pi()
        du = acb(sign)
    else:
        theta = -arb.pi()*(t+R("1/2"))
        u = a+delta*(i*theta).exp()
        lminus = delta.log()+i*(theta+arb.pi())
        du = -i*arb.pi()*(u-a)
    return u, du, (a+u).log()-lminus


def bound_panel(sign, l, r, a, delta, s, p, q):
    """HS integrand bound on the Bernstein ellipse of parameter 2."""
    w=r-l
    left=l-w/8
    right=r+w/8
    height=3*w/8
    if sign:
        real_u = lo(a+left)
        u_max = up(a+max(abs(left).upper(),abs(right).upper())+height+delta)
        # For panels whose ellipse may cross the ray's slit extension,
        # control the denominator by its strictly positive real part.
        lowminus = max(lo(left),lo(delta-height))
        highminus = up(max(abs(left).upper(),abs(right).upper())+height+delta)
        du=R(1)
    else:
        mag_high=up(delta*(arb.pi()*height).exp())
        ray_theta_h=up(arb.pi()*height)
        real_u=lo(a-mag_high)
        u_max=up(a+mag_high)
        lowminus=lo(delta*(-ray_theta_h).exp())
        highminus=mag_high
        du=up(arb.pi()*mag_high)
    if real_u <= 0 or lowminus <= 0:
        raise ArithmeticError("operator ellipse crosses contour pole")
    highplus=up(a+u_max)
    lowplus=lo(a+real_u)
    ratio_hi=up(highplus/lowminus)
    ratio_lo=lo(lowplus/highminus)
    power = max(up(ratio_hi**s.real),up(ratio_lo**s.real))
    # Log difference on rays has imaginary part of magnitude at most
    # 5pi/2. On the arc the second log has argument theta+pi with
    # modulus < 2pi, and the first has imaginary part < pi/2.
    arg = 3*arb.pi()
    exp = s.imag.abs_upper()*arg + a*max(
        p.abs_upper()/lowminus+q.abs_upper()/lowplus,
        q.abs_upper()/lowminus+p.abs_upper()/lowplus)
    return up(power*(exp-real_u).exp()*du/(4*arb.pi()*real_u))


def tail_bound(a, delta, xmax, s, p, q):
    lower=a+xmax
    rho=(p.abs_upper()+q.abs_upper())
    power=max(up((1+(2*a+delta)/xmax)**abs(s.real)),R(1))
    exp=s.imag.abs_upper()*3*arb.pi()+a*rho/xmax-lower
    return up(power*exp.exp()/(2*arb.pi()*lower))


def mod_phase(z):
    return acb(z.real.mid(),z.imag.mid())


def diag_times(M, values, *, right=False):
    n=M.nrows()
    return acb_mat(n,n,[x*values[j if right else i]
                        for i, row in enumerate(M.tolist()) for j,x in enumerate(row)])


def frobenius(M):
    return up(sum((x.abs_upper()**2 for x in M.entries()),arb()).sqrt())


class Keyhole:
    def __init__(self,c,s,xmax, *, n=18, project=None, laguerre="2"):
        self.c,self.s,self.n=R(c),C(s),n
        self.a=self.c/2
        self.delta=self.a/2
        self.xmax=R(xmax)
        self.panels=panels(self.a,self.xmax)
        self.nodes=[]
        self.data=[]
        pGauss=[arb.legendre_p_root(n,j,weight=True) for j in range(n)]
        for sign,l,r in self.panels:
            for node,weight in pGauss:
                t=(l+r+(r-l)*node)/2
                u,du,logs=panel_coordinates(t,sign,self.a,self.delta)
                b=(r-l)*weight*du*(-u).exp()/(acb(0,4)*arb.pi())
                self.nodes.append(u)
                self.data.append((b*(self.s*logs).exp(),acb(0,self.a)/(self.a+u),
                                  -acb(0,self.a)/(self.a-u)))
        self.project=project
        n=len(self.nodes)
        if project is None:
            self.G=acb_mat(n,n,[1/(u+v) for u in self.nodes for v in self.nodes])
            self.Hinner=acb_mat(n,n,[1/(u.conjugate()+v)**2
                                   for u in self.nodes for v in self.nodes])
            self.vnorm=up(sum((1/(2*u.real) for u in self.nodes),arb()))
        else:
            b=R(laguerre)
            self.P=acb_mat(project*2-1,n)
            self.proj_factor=[]
            for j,u in enumerate(self.nodes):
                y=(u-b)/(u+b)
                x=2*b/(u+b)**2
                for k in range(project*2-1):
                    self.P[k,j]=x
                    x*=y
                self.proj_factor.append(up(y.abs_upper()**project/u.real))
        M=n if project is None else project
        self.I=acb_mat(M,M,[int(i==j) for i in range(M) for j in range(M)])

    def estimates(self,p,q):
        cquad=up(sum((8*(r-l)*bound_panel(sign,l,r,self.a,self.delta,self.s,p,q)
                          * arb(2)**(-2*self.n)/(1-R("1/2"))
                      for sign,l,r in self.panels),arb()))
        ctail=tail_bound(self.a,self.delta,self.xmax,self.s,p,q)
        return up(cquad+ctail),ctail,cquad

    def hs_norm(self, d):
        n=len(d)
        left=acb_mat(1,n,[x.conjugate() for x in d])
        right=acb_mat(n,1,d)
        a=(left*self.Hinner*right)[0,0].real
        return up(up(a).sqrt())

    def __call__(self,p,q, *, inverse=True):
        start=perf_counter()
        p,q=C(p),C(q)
        e,ctail,cquad=self.estimates(p,q)
        dp=[a*(b*q+c*p).exp() for a,b,c in self.data]
        dm=[a*(b*p+c*q).exp() for a,b,c in self.data]
        pextra=[arb(),arb()]
        if self.project is None:
            nplus,nminus=(self.hs_norm(dp),self.hs_norm(dm))
            A=diag_times(diag_times(self.G,dm,right=True),dp)
            K=self.I-A*self.G
        else:
            n=len(self.nodes)
            m=self.project
            H=[]
            for idx,d in enumerate((dp,dm)):
                vals=(self.P*acb_mat(n,1,d)).entries()
                H.append(acb_mat(m,m,[vals[i+j] for i in range(m) for j in range(m)]))
                pextra[idx]=up(sum((z.abs_upper()*w for z,w in zip(d,self.proj_factor)),arb()))
            nplus,nminus=(frobenius(m) for m in H)
            A=H[0]*H[1]
            K=self.I-A
        pref=(-self.s*self.s*self.c.log()-acb(0,1)*self.s*(p+q)/2-p*q/4).exp()
        det=K.det()
        z=pref*det
        ep=up(e+pextra[0])
        em=up(e+pextra[1])
        terr=up(ep*nminus+em*nplus+ep*em)
        basic=up(terr*(1+nplus*nminus+(nplus+ep)*(nminus+em)).exp()*pref.abs_upper())
        cond=None
        if inverse:
            try:
                ival=K.solve(A)
                invnorm=up(1+(self.vnorm if self.project is None else 1)*frobenius(ival))
                cond=up(terr*invnorm)
                basic=min(basic,up(z.abs_upper()*cond.expm1()))
            except (ZeroDivisionError,ValueError,ArithmeticError):
                pass
        num=up((z-mod_phase(z)).abs_upper())
        return Result(mod_phase(z),basic,num,max(ep,em),ctail,cquad,max(pextra),(nplus,nminus),cond,
                      len(self.nodes),perf_counter()-start)


def mpstring(x,n=18):
    return x.str(n)


def dyadic(x):
    m,p=x.man_exp()
    return str(m),int(p)


def receipt(a):
    radius=up(a.analytic+a.numerical)
    return dict(mid=[mpstring(a.mid.real),mpstring(a.mid.imag)],
                radius=mpstring(radius),
                midpoint_dyadic=[dyadic(a.mid.real),dyadic(a.mid.imag)],
                radius_dyadic=dyadic(radius),
                analytic=mpstring(a.analytic),numeric=mpstring(a.numerical),
                hs=mpstring(a.hs_error),contour_tail=mpstring(a.contour_tail),
                contour_quad=mpstring(a.contour_quad),projection=mpstring(a.projection),
                approx_norms=[mpstring(x) for x in a.norms],
                inverse_perturb=None if a.inverse_perturb is None else mpstring(a.inverse_perturb),
                size=a.evaluations,seconds=a.elapsed)


if __name__ == "__main__":
    import argparse,json
    p=argparse.ArgumentParser()
    p.add_argument("--n",type=int,default=12)
    p.add_argument("--bits",type=int,default=100)
    p.add_argument("--extent",default="32")
    p.add_argument("--s",nargs=2,default=("1/2","1/20"))
    p.add_argument("--c",default="1")
    p.add_argument("--sample",nargs="+",default=["0","1","2"])
    p.add_argument("--angle",default="0")
    p.add_argument("--noinv",action="store_true")
    p.add_argument("--project",type=int,default=None)
    p.add_argument("--laguerre",default="2")
    args=p.parse_args()
    with ctx.workprec(args.bits):
      D=Keyhole(args.c,args.s,args.extent,n=args.n,project=args.project,laguerre=args.laguerre)
      unit=acb(0,R(args.angle)*arb.pi()).exp()
      for sample in args.sample:
        f=R(sample)*unit
        print(json.dumps(dict(config=vars(args),frequency=sample,
                        **receipt(D(f,f.conjugate(),inverse=not args.noinv)))),flush=True)
