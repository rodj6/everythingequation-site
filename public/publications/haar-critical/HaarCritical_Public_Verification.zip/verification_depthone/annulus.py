"""Validated hard-cutoff annulus at the registered depth-one tuple.

Every radial-angle coefficient is a ball or a disk, while analytic
Cauchy/Bernstein and periodic-strip estimates are added as separate
quadrature allowances. The output deliberately excludes the unused annuli.
"""
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
from time import perf_counter
import argparse,json

from flint import acb, arb, ctx

from contour_source import Keyhole, R, C, dyadic, up


SOURCE=None
RADII=None


def point(v):
    i,j,n=v
    r=RADII[i]
    unit=acb(0,2*arb.pi()*j/n).exp()
    p=r*unit
    v=SOURCE(p,p.conjugate())
    return [dyadic(x) for x in (v.mid.real,v.mid.imag,v.analytic,v.numerical,
                                v.contour_tail,v.contour_quad,v.projection)],v.elapsed


def max_source_terms(result):
    labels=("cut_line_tail_HS","analytic_panel_HS","laguerre_projection_HS")
    return {key:max(restore(v[0][j]) for v in result).str(16)
            for j,key in enumerate(labels,4)}


def restore(p):
    m,e=p
    return arb(int(m))*arb(2)**e


def boundD(rho,b):
    """The explicit complex-frequency Hardy envelope at c=1,s=1/2+i/20."""
    K=(arb.pi()/20).exp()
    J=(arb.pi()/20).sinh()/arb.pi()
    g=R(".254")
    ep=R(".0001")
    constant=arb(4).log()/2+3+(2*arb.pi()/3).sqrt()
    M=(400+3*rho).upper().ceil()+1
    return up((b/2+b*b/4+b.exp()/(1-g)*
        (2*K*b.exp()*J*((2*M).log()+constant)+4*K*K*ep)).exp())


def run(lims,h,prefs,params):
    global SOURCE,RADII
    start=perf_counter()
    a,b=lims
    width=b-a
    left=a-width/8
    right=b+width/8
    imag=width*R("3/8")
    if not left>0 or not imag<=R("1/2"):
        raise ValueError("panel outside the certified ellipse conditions")
    n=params.radial
    N=params.angular
    if N%2:
        raise ValueError("angular count must be even")
    radius, weights=[],[]
    for i in range(n):
        x,w=arb.legendre_p_root(n,i,weight=True)
        ri=(a+b+width*x)/2
        radius.append(ri)
        weights.append(width*w/2*acb(ri).pow(-2*h-1))
    M=boundD(right,imag)*left**(-2*h.real-1)*(
        arb.pi()*h.imag.abs_upper()).exp()
    radial=up(16*width*M*arb(2)**(-2*n))
    t=R("1/2")/b
    shift=(t+(1+t*t).sqrt()).log()
    angular_local=up(2*boundD((b*b+R("1/4")).sqrt(),R("1/2"))/(N*shift).expm1())
    angular=up(angular_local*sum((w.abs_upper() for w in weights),arb()))
    SOURCE=Keyhole(1,("1/2","1/20"),params.extent,n=params.order,project=params.project,
                  laguerre=params.scale)
    RADII=radius
    positions=[(i,j,N) for i in range(len(radius)) for j in range(N//2+1)]
    if params.cpu>1:
        with ProcessPoolExecutor(max_workers=params.cpu,mp_context=multiprocessing.get_context("fork")) as pool:
            result=list(pool.map(point, positions))
    else:
        result=[point(q) for q in positions]
    A=acb(0)
    eS=arb()
    eN=arb()
    cur=0
    for w in weights:
        for j in range(N//2+1):
            k=(1 if j==0 or j==N//2 else 2)
            f=w*k/N
            record,_=result[cur]
            re,im,analytic,numerical=map(restore,record[:4])
            A+=f*acb(re,im)
            eS+=f.abs_upper()*analytic
            eN+=f.abs_upper()*numerical
            cur+=1
    G=prefs*A
    m=G.mid()
    eA=(G-m).abs_upper()
    factor=prefs.abs_upper()
    charges={"radial":up(factor*radial),"angular":up(factor*angular),
        "source":up(factor*eS),"arithmetic":up(eA+factor*eN)}
    e=up(sum(charges.values(),arb()))
    return dict(input=["c=1","h=1/2+i/8","s=1/2+i/20"],
                range=[str(a.mid()),str(b.mid())],
                description="normalized Mellin contribution of this annulus only",
                parameters=vars(params),mid=[m.real.str(16),m.imag.str(16)],
                radius=e.str(16),
                dyadic_midpoint=[dyadic(m.real),dyadic(m.imag)],
                dyadic_radius=dyadic(e),
                breakdown={k:v.str(16) for k,v in charges.items()},
                bound_radial=M.str(8),bound_angular=angular_local.str(8),
                max_source_terms=max_source_terms(result),
                worst_sample_radius=max(up(restore(r[0][2])+restore(r[0][3])) for r in result).str(12),
                sample_mean_seconds=sum(r[1] for r in result)/len(result),
                samples=len(result),wall_seconds=perf_counter()-start)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--range",nargs=2,default=["1","2"])
    p.add_argument("--order",type=int,default=17)
    p.add_argument("--radial",type=int,default=6)
    p.add_argument("--angular",type=int,default=26)
    p.add_argument("--project",type=int,default=65)
    p.add_argument("--bits",type=int,default=130)
    p.add_argument("--extent",default="30")
    p.add_argument("--scale",default="2")
    p.add_argument("--cpu",type=int,default=6)
    args=p.parse_args()
    with ctx.workprec(args.bits):
        h=C(("1/2","1/8"))
        pref=acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()
        print(json.dumps(run(tuple(R(v) for v in args.range),h,pref,args)))
if __name__=="__main__":
    main()
