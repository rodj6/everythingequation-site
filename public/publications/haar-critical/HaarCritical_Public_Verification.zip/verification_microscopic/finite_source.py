"""A contracting Arb enclosure of the limiting microscopic Fourier source.

Python-FLINT 0.9.0. Control arguments extent and tail_line accept positive
rationals. Source arguments accept exact rational strings, or Arb/Acb balls.
"""
from dataclasses import dataclass
from fractions import Fraction
from flint import acb, acb_mat, arb, ctx, fmpq


def real(value):
    if isinstance(value, arb):
        return value
    if isinstance(value, fmpq):
        return arb(value)
    a = Fraction(value)
    return arb(fmpq(a.numerator, a.denominator))


def complex_ball(value):
    if isinstance(value, acb):
        return value
    if isinstance(value, (tuple, list)) and len(value) == 2:
        return acb(real(value[0]), real(value[1]))
    return acb(real(value))


@dataclass
class SourceResult:
    value: acb
    finite_matrix_value: acb
    hs_truncation: arb
    hs_cell: arb
    hs_line: arb
    trace_error: arb
    source_determinant_error: arb
    hs_finite_plus: arb
    hs_finite_minus: arb


def integrand_third(t, a, s, p, q, sign, analytic):
    u, v = a + acb(0, 1) * t, a - acb(0, 1) * t
    ui, vi = 1/u, 1/v
    log_b = s * (u.log(analytic=analytic)-v.log(analytic=analytic))
    log_b += acb(0,a) * (q*ui-p*vi)
    first = acb(0,1)*s*(ui+vi)+a*(q*ui**2+p*vi**2)
    second = s*(ui**2-vi**2)+acb(0,2*a)*(-q*ui**3+p*vi**3)
    third = -acb(0,2)*s*(ui**3+vi**3)-6*a*(q*ui**4+p*vi**4)
    return (sign * log_b).exp() * (sign*first**3 + 3*first*second + sign*third)


def line_kernel(vfreq, a, shift, s, p, q, sign, tail_line, goal, max_evals, panels):
    shift_t = acb(0,-sign*shift)
    oscillation = acb(0,-sign*vfreq)

    def integrand(x, analytic):
        return (integrand_third(x+shift_t,a,s,p,q,sign,analytic)
                * (oscillation*x).exp())

    if panels is None:
        integral = acb.integral(integrand,-tail_line,tail_line,
                                abs_tol=goal,rel_tol=goal,eval_limit=max_evals)
    else:
        width = 2*tail_line/panels
        integral = acb(0)
        for j in range(panels):
            left = -tail_line+j*width
            right = left+width
            interval = acb(left.union(right))
            integral += width*integrand(interval, False)
    if not integral.is_finite():
        raise ArithmeticError("Arb line integral did not produce a finite ball")
    return (-shift*vfreq).exp()*integral/(2*arb.pi()*(-oscillation)**3)


def source(c, s, p, q, *, cells=16, extent="12", tail_line="16", bits=80,
           quad_bits=24, max_evals=15000, panels=None):
    """Enclose D_infty(c,s;p,q) of (15.5), including independent sources."""
    if cells < 1 or bits < 20 or quad_bits < 8 or (panels is not None and panels < 1):
        raise ValueError("invalid source controls")
    with ctx.workprec(bits):
        a, s, p, q = real(c)/2, complex_ball(s), complex_ball(p), complex_ball(q)
        extent, tail_line = real(extent), real(tail_line)
        if not (a > 0 and extent > 0 and tail_line > 0):
            raise ValueError("depth and cutoffs must be positive")
        shift, r0 = a/2, a/2
        S = s.abs_upper()
        P = p.abs_upper()+q.abs_upper()
        expo = (s.real.abs_upper()*arb(3).log()+s.imag.abs_upper()*arb.pi()+a*P/r0).exp()
        A1, A2, A3 = 2*S+a*P/r0, 2*S+2*a*P/r0, 4*S+6*a*P/r0
        third_bound = expo*(A1**3+3*A1*A2+A3)
        b_bound = third_bound/(arb.pi()*r0**2)
        derivative_bound = (shift+3)*b_bound+third_bound/(arb.pi()*r0)
        step = extent/cells

        hs_full_envelope = b_bound*(-shift).exp()/(2*shift)
        hs_truncation = (hs_full_envelope*arb(2).sqrt()*(-shift*extent).exp()).upper()
        hs_cell = (derivative_bound*step*(shift*step-shift).exp()/(2*shift)).upper()
        frequencies = [1+(k+1)*step for k in range(2*cells-1)]
        line_prefactors = [(-shift*v).exp()/(2*arb.pi()*v**3) for v in frequencies]
        weights = [k+1 if k < cells else 2*cells-1-k for k in range(2*cells-1)]
        hs_line = (step*third_bound/tail_line**2 *
                   sum((w*d**2 for w,d in zip(weights,line_prefactors)),arb(0)).sqrt()).upper()
        total_hs_error = (hs_truncation+hs_cell+hs_line).upper()

        matrices = []
        matrix_norms = []
        goal = arb(2)**(-quad_bits)
        for sign in (1,-1):
            coeffs = [step*line_kernel(v,a,shift,s,p,q,sign,tail_line,goal,max_evals,panels)
                      for v in frequencies]
            matrices.append(acb_mat([[coeffs[i+j] for j in range(cells)]
                                     for i in range(cells)]))
            matrix_norms.append(sum((w*x.abs_upper()**2 for w,x in zip(weights,coeffs)),
                                    arb(0)).sqrt().upper())
        plus, minus = matrices
        px, mx = matrix_norms
        trace_error = (total_hs_error*(px+mx+total_hs_error)).upper()
        finite_norm = px*mx
        exact_norm = (px+total_hs_error)*(mx+total_hs_error)
        determinant_error = (trace_error*(1+finite_norm+exact_norm).exp()).upper()
        matrix = plus*minus
        residual = acb_mat([[int(i==j) for j in range(cells)]
                            for i in range(cells)])-matrix
        nominal_det = residual.det()
        if not nominal_det.is_finite():
            nominal_det = (-1)**cells*residual.charpoly()[0]
        prefactor = (-s*s*acb(2*a).log()-acb(0,1)*s*(p+q)/2-p*q/4).exp()
        finite_matrix_value = prefactor*nominal_det
        source_error = (determinant_error*prefactor.abs_upper()).upper()
        value = finite_matrix_value + acb(arb(0,source_error),arb(0,source_error))
        return SourceResult(value,finite_matrix_value,hs_truncation,hs_cell,hs_line,
                            trace_error,source_error,px,mx)
