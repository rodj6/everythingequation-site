"""Certified coefficient jets of the limiting Fourier source.

The operator truncation, polynomial kernel approximation, and determinant
perturbation are priced independently of finite matrix ball arithmetic.
Python-FLINT 0.9.0. Only exact rational inputs are accepted.
"""
from fractions import Fraction
from itertools import product
import argparse
import json
from math import factorial, comb
from time import monotonic

from flint import acb, acb_mat, arb, ctx, fmpq


def rational(x):
    a = Fraction(x)
    return arb(fmpq(a.numerator, a.denominator))


def beta_indices(degree):
    return tuple((j,k) for j,k in product(range(degree+1), repeat=2))


def complex_error(x, error):
    return x + acb(arb(0,error.upper()),arb(0,error.upper()))


def kernel_coeff(v, c, s, j, k, peel):
    a = c/2
    z = acb(c*v)
    left = peel-s+k
    pref = (-acb(0,a))**j * acb(0,a)**k / (factorial(j)*factorial(k))
    total = acb(0)
    for l in range(peel+1):
        power=peel+j+k-1-l
        coefficient=comb(peel,l)*(-1)**l*c**(peel-l)*(s+j-l).rgamma()
        if coefficient.is_zero():
            continue
        total += coefficient*v**power*z.hypgeom_u(left,power+1)
    return pref*(-a*v).exp()*total


def gauss(edges,n):
    nodes, weights = [], []
    for i in range(len(edges)-1):
        a,b = edges[i:i+2]
        for k in range(n):
            x,w = arb.legendre_p_root(n,k,weight=True)
            nodes.append((a+b+(b-a)*x)/2)
            weights.append(((b-a)*w/2).sqrt())
    return nodes, weights


def majorants(c, s, indices, peel):
    """Exact norm bounds for the coefficient integrals before exp(−cv/2)."""
    u, imag = s.real, s.imag.abs_upper()
    pi_part=(arb.pi()*imag/2).exp()
    a = c/2
    terms={}
    for j,k in indices:
        q = peel-u+k
        alpha=u+j-1
        g = a**(j+k)*pi_part*(peel-s+k).rgamma().abs_upper()/(factorial(j)*factorial(k))
        terms[j,k]=[(alpha-l,comb(peel,l)*c**(peel-l)*g*(s+j-l).rgamma().abs_upper(),q)
                    for l in range(peel+1)]
    return terms


def integral_monomial(c, q):
    return q.gamma()/c**q


def rectangle_bound(terms,c,r,d,V):
    result=arb(0)
    for (j,k), items in terms.items():
        for alpha,pref,q in items:
            if alpha<=0:
                bound=d**alpha*integral_monomial(c,q)
            else:
                bound=arb(2)**max(arb(0),alpha-1)*(V**alpha*integral_monomial(c,q)
                                                       +integral_monomial(c,q+alpha))
            result+=r**(j+k)*pref*bound
    return result*(-c*d/2).exp()


def operator_budget(edges,n,r,c,s,indices,ellipse,peel):
    terms=majorants(c,s,indices,peel)
    H=(ellipse+1/ellipse)/2
    P=[]
    for a,b in zip(edges[:-1],edges[1:]):
        mid=(a+b)/2
        half=(b-a)/2
        P.append((b-a,mid-half*H,mid+half*H))
    error2=arb(0)
    for (dx,lx,hx),(dy,ly,hy) in product(P, repeat=2):
        d=1+lx+ly
        V=1+hx+hy
        if not d>0:
            raise ValueError("ellipse must stay in Re v>0")
        M=rectangle_bound(terms,c,r,d,V)
        sup_err=16*M*ellipse**(-n)/(1-1/ellipse)**2
        error2+=dx*dy*sup_err**2

    # On real v>=1 bound each power with exponent in [0,D] by v**D.
    D=peel+max(max(key) for key in indices)-1
    tail_pref=arb(0)
    for (j,k),items in terms.items():
        for alpha,pref,q in items:
            if alpha<=0:
                bound=integral_monomial(c,q)
            else:
                bound=arb(2)**max(arb(0),alpha-1)*(integral_monomial(c,q)+integral_monomial(c,q+alpha))
            tail_pref+=pref*r**(j+k)*bound
    # Omitted quadrant region is contained in x+y>=L. Use t=x+y.
    L=edges[-1]
    integ=arb(0)
    for j in range(2*D+1):
        m=j+1
        I=(-c*L).exp()*sum(factorial(m)//factorial(k)*L**k/c**(m-k+1) for k in range(m+1))
        integ+=comb(2*D,j)*I
    tail=tail_pref*(-c/2).exp()*integ.sqrt()
    return error2.sqrt(), tail


def multiply(P,Q,degree):
    W={}
    for (j,k),a in P.items():
        for (l,m),b in Q.items():
            jk=(j+l,k+m)
            if max(jk)>degree:
                continue
            item=a*b
            W[jk]=W[jk]+item if jk in W else item
    return W


def trace(M):
    return sum(M[i,i] for i in range(M.nrows()))


def exp_poly(P,degree):
    """P has zero constant term."""
    Q={(0,0):acb(1)}
    part=Q.copy()
    for j in range(1,2*degree+1):
        part=multiply(part,P,degree)
        for key,value in part.items():
            Q[key]=Q.get(key,acb(0))+value/factorial(j)
    return Q


def source_jets(c,s,degree,n,L,r,ellipse):
    start=monotonic()
    indices=beta_indices(degree)
    sreal=s.real
    if not c>0 or not 0<sreal<2 or not r>0:
        raise ValueError('require c>0, 0<Re(s)<2, radius>0')
    peel=1 if sreal<1 else 2
    edges=[arb(0),rational('2/5'),arb(1),rational('5/2'),arb(6),arb(15),arb(37),arb(90)]
    edges=[a for a in edges if a<L]+[L]
    # Insert additional panels if needed to keep the complex ellipse inside
    # the right half-plane.
    while not (len(edges)<2 or (1+2*edges[-2]-(ellipse+1/ellipse-2)*(edges[-1]-edges[-2])/2)>0):
        edges.insert(-1,(edges[-1]+edges[-2])/2)
    interpolation, trunc=operator_budget(edges,n,r,c,s,indices,ellipse,peel)
    error=interpolation+trunc

    nodes, weights=gauss(edges,n)
    N=len(nodes)
    mats={key:acb_mat(N,N) for key in indices}
    norms={key:arb(0) for key in indices}
    for i in range(N):
        for j in range(i,N):
            v=1+nodes[i]+nodes[j]
            weight=weights[i]*weights[j]
            for key in indices:
                val=weight*kernel_coeff(v,c,s,*key,peel)
                mats[key][i,j]=mats[key][j,i]=val
                norms[key]+=val.abs_upper()**2*(1+(i!=j))
    formal_bound=sum(r**sum(key)*a.sqrt() for key,a in norms.items())
    product_error=error*(2*formal_bound+error)
    # Continuity of Fredholm determinant for trace class operators.
    deterror=product_error*(1+(formal_bound+error)**2+formal_bound**2).exp()
    prefactor_bound=(s*s*(-c.log())).exp().abs_upper()*(s.abs_upper()*r+r*r/4).exp()
    source_err=deterror*prefactor_bound

    A=multiply(mats,{(j,k):mats[k,j] for j,k in indices},degree)
    M=acb_mat(N,N)
    for i in range(N):
        M[i,i]=1
    M=M-A.pop((0,0))
    inv=M.inv()
    T={key:inv*val for key,val in A.items()}
    P={}
    power=T
    for unit in range(1,2*degree+1):
        for key,val in power.items():
            P[key]=P.get(key,acb(0))-trace(val)/unit
        if unit<2*degree:
            power=multiply(power,T,degree)
    if degree:
        for key,value in { (1,0):-acb(0,1)*s/2,
                          (0,1):-acb(0,1)*s/2, (1,1): -arb(1)/4}.items():
            P[key]=P.get(key,acb(0))+value
    detmass=M.det()*(s*s*(-c.log())).exp()
    jets={key:(value*detmass,source_err/r**sum(key))
          for key,value in exp_poly(P,degree).items()}
    exact_moments={}
    raw_moments={}
    allowances={}
    for j in range(degree+1):
        mid,err=jets[j,j]
        scale=(-4)**j*factorial(j)**2*c**(-2*j)
        raw_moments[j]=mid*scale
        allowances[j]=err*abs(scale)
        exact_moments[j]=complex_error(raw_moments[j],allowances[j])
    def dyadic(v):
        m,e=v.man_exp()
        return [str(m),int(e)]
    def disk(v):
        center=v.mid()
        radius=(v-center).abs_upper()
        return dict(real=dyadic(center.real),imag=dyadic(center.imag),radius=dyadic(radius))
    report=dict(exact_dyadic_disks={key:disk(v) for key,v in exact_moments.items()},
                operator_quadrature=interpolation.str(12),operator_omitted=trunc.str(12),
                operator_product=product_error.str(12),determinant=deterror.str(12),
                source_uniform=source_err.str(12),finite_operator_bound=formal_bound.str(12),
                prefactor=prefactor_bound.str(12),
                moment_enclosures={key:val.str(18) for key,val in exact_moments.items()},
                ball_arithmetic_moments={key:val.str(18) for key,val in raw_moments.items()},
                analytic_allowance_moments={key:val.str(12) for key,val in allowances.items()},
                matrix_order=N,seconds=monotonic()-start)
    return exact_moments, report


def main():
    parser=argparse.ArgumentParser()
    for option,default in [('c','1'),('re','1/2'),('im','0'),('r','1/4'),('ellipse','4'),('L','90')]:
        parser.add_argument('--'+option,default=default)
    parser.add_argument('--degree',type=int,default=2)
    parser.add_argument('--order',type=int,default=24)
    parser.add_argument('--bits',type=int,default=128)
    args=parser.parse_args()
    ctx.prec=args.bits
    _,output=source_jets(rational(args.c),acb(rational(args.re),rational(args.im)),
                         args.degree,args.order,rational(args.L),rational(args.r),
                         rational(args.ellipse))
    print(json.dumps(dict(inputs=vars(args),**output),indent=2))


if __name__=='__main__':
    main()
