"""Certified Laplace-Hankel mass and selected positive half-order bounds."""
from math import comb, factorial
import json
from time import monotonic

from flint import acb, acb_mat, arb, ctx


def pair(a):
    return [str(a.lower().man_exp()[0]), int(a.lower().man_exp()[1])], [
        str(a.upper().man_exp()[0]), int(a.upper().man_exp()[1])]


def det_jet(h, hp, hpp):
    results = []
    for sign in (-1, 1):
        v = sign * h
        for i in range(v.nrows()):
            v[i, i] += 1
        first = v.solve(sign * hp)
        second = v.solve(sign * hpp) - first * first
        results.append((v.det(), first.trace(), second.trace()))
    (x, j, k), (y, l, m) = results
    d = x * y
    return d, d * (j + l), d * ((j + l)**2 + k + m)


def hankel_jet(n, limit):
    # s=1/2, Re c=1. The substitution y=x² removes the endpoint.
    cache = [[], [], []]
    upper = arb(limit)
    end = limit**2
    for j in range(3):
        tail = (4 * (-arb(end)).exp() * sum(
            comb(j, k) * (end + 1)**(j-k) * factorial(k) for k in range(j+1))
                / arb.pi()).upper()
        for k in range(2*n-1):
            def integrand(x, analytic):
                t = x*x
                v = 1+t
                return (2*(-(t+arb(1)/2)).exp() * ((1+t).sqrt(analytic=analytic))
                        * (-t-arb(1)/2)**j * (t/v)**k / (arb.pi()*v*v))
            integral = acb.integral(integrand, 0, upper, abs_tol=arb(2)**-65,
                                    rel_tol=arb(2)**-66)
            if not integral.is_finite():
                raise ArithmeticError(f"quadrature failed at jet {j}, index {k}")
            cache[j].append(acb(integral.real + arb(0, tail)))
    return tuple(acb_mat([[a[i+j] for j in range(n)] for i in range(n)]) for a in cache)


def mass_error(n, radius):
    # Re c >= d. sqrt((1+y)/y) <= 1 + 1/sqrt(y).
    d = 1 - radius
    # Trace norms of H and PHP. 2u=1+2y >= 1.
    t = (-d/2).exp()/arb.pi() * (1/d + (arb.pi()/d).sqrt())
    # r(y)^n <= exp(-n/(1+y)), so d*y/2 + n/(1+y) >= sqrt(2dn)-d/2.
    e = (-(2*d*n).sqrt()).exp()/arb.pi() * (2/d + (2*arb.pi()/d).sqrt())
    e *= 2  # two rank-one differences
    product = (2*t*e)
    return (d**(-arb(1)/4) * product * (1 + 2*t*t).exp()).upper()


def check(n, limit):
    now = monotonic()
    radius = arb(1)/8
    d, dd, ddd = (v.real for v in det_jet(*hankel_jet(n, limit)))
    err = mass_error(n, radius)
    errors = (err, (err/radius).upper(), (2*err/radius**2).upper())
    level = d + arb(0, errors[0])
    first = dd - d/4 + arb(0, errors[1])
    second = ddd - dd/2 + 5*d/16 + arb(0, errors[2])
    # M_{1/2} bounded below by |E Re S| and above by Cauchy-Schwarz.
    lo = max(arb(0), (2*first).abs_lower())
    hi = (4*level*second).sqrt().upper()
    return dict(rank=n, limit=limit, precision=ctx.prec,
                mass=str(level), first_depth_jet=str(first), second_depth_jet=str(second),
                cauchy_errors=list(map(str, errors)), endpoints=[str(lo), str(hi)],
                exact_endpoints=[pair(lo)[0], pair(hi)[1]],
                elapsed=monotonic()-now)


if __name__ == "__main__":
    with ctx.workprec(96):
        for n in (64, 96):
            print(json.dumps(check(n, 9)), flush=True)
