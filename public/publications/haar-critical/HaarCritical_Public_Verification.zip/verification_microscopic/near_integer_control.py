"""Outward certificates at c=1, s=i/8, h=(-1+i)*10^(-1,200).

The tiny but exact noninteger order costs a priced Mellin variation; the
static Fredholm determinant is enclosed independently by a branch-cut
integral and a trace-class determinant remainder. Run with python-flint.
"""
from argparse import ArgumentParser
import json
from time import perf_counter

from flint import acb, acb_mat, arb, ctx


def logsum(x, y):
    return max(x, y) + arb(2).log()


def priced_log_b2():
    pi = arb.pi()
    c_min = c_max = arb(1)
    u = arb(5) / 2
    eta = arb(1) / 4
    v0 = arb(1) / 8
    assert 2**arb(".5") / (5*pi/4).cosh() <= eta - v0
    q = 1 - 2*eta
    k = c_min / 4
    cdelta = 12*c_max**2 + 2*u*c_max + 2
    a = 4**u*cdelta
    # Coarsen the integrals after the y=P(-x) substitution; integrate
    # (1+y)^2 e^{-ky} from y=0 rather than y=5/3.
    elementary = 1/k + 2/k**2 + 2/k**3
    a_minus = a*(arb(64)/9*(arb(4)/9+arb(1)/3) + elementary/pi)
    a_plus = a*arb(1).exp()*(16+elementary/pi)
    a_zero = 4**u*(arb(4)/9+1/(2*pi*k))
    log_c1 = 2*(1+arb(2).sqrt())*a_zero + (
        3330*(a_minus+a_plus)+u*c_max).log()
    log_c2 = logsum(log_c1 + arb(2).log(), arb(4).log())
    r = l = 4
    dj = [(2*r)**r, 2*(2*r)**r+r*(2*r)**(r-1)]
    uj = [5*2**r*d*(pi/2)**r for d in dj]
    w = 3**(2*u)
    coeff = (w/(pi*(2*r-2*u-1))).sqrt()
    aj = [coeff*x for x in uj]
    lp = 2*pi*l
    j = w/pi * ((1+lp)**(2*u+1)-1)/(2*u+1) + (
        w/pi*lp**(2*u+1)*(1+1/lp)**(2*u)/(2*l-2*u-1))
    ec = 1/(2*j*aj[0]*aj[1]*3**u)
    k0 = 1/(4*pi*j*3**u)
    d = (ec/(1024*pi))**(arb(1)/3)
    k1 = k0**2*ec*d/(8*5000)
    rho0 = (2/d)**3
    rank_scale = arb(16)
    assert rank_scale > max(4+r+1, 2*l, 4*c_max+2*u+4, 8*d+1)
    m = 2
    a = (m+5)/q
    p = m+eta*a
    a1 = k1*(1-eta)
    log_compare = log_c2-q*rank_scale.log()-(1-2**(-q)).log()
    log_small = p*(1+rho0).log()
    log_big = p*arb(2).log() + 3*p*((3*p/a1).log()-1)
    return logsum(log_compare, eta*(rank_scale+1).log()+logsum(log_small,log_big))


def mellin_variation(log_b2):
    # Price the origin on a small complex disk, then use B2 in
    # the remaining radial intervals. This keeps the priced Cauchy
    # determinant from dominating the variation allowance.
    pi = arb.pi()
    a = arb("0.5")
    v = arb("0.125")
    sigma = arb("0.125")
    d2 = (pi*v+2*sigma).exp()*(
        (2*v+8*v*v)*pi/a+4*sigma/a**2+sigma**2*pi/a**3)
    log_m = v*sigma+sigma**2/4+(d2/(2*pi))**2/6
    log_lipschitz = logsum(arb(81).log()+log_m, arb(61).log()+log_b2)
    exponent = 1200
    log_error = arb(2).log()/2-exponent*arb(10).log()+log_lipschitz
    assert log_error < -20*arb(10).log()
    return log_m, log_error


def static_trace(n):
    pi = arb.pi()
    v = arb("0.125")
    # C = sin(pi*i*v)/pi is imaginary.
    c_squared = -(pi*v).sinh()**2/pi**2
    # Work on x=log(y), then x in [-10,3] in each variable.
    delta = arb(13)/n
    samples = []
    for j in range(n):
        x = -10 + delta*(arb(j)+arb("0.5"))
        y = x.exp()
        phase = acb(0,-v*(x-(1+y).log())).exp()
        samples.append((y, y*(-y).exp()*phase))
    e_minus_one = arb(1).exp()**(-1)
    total = acb(0)
    for row, (x, fx) in enumerate(samples):
        total += (fx/(1+2*x))**2
        for y, fy in samples[:row]:
            total += 2*fx*fy/(1+x+y)**2
    trace_value = c_squared*e_minus_one*delta**2*total
    # The absolute mass of either omitted log-coordinate tail is at
    # most its corresponding e^{-u} integral, and denominators >=1.
    omitted = abs(c_squared)*e_minus_one*2*((-arb(10)).exp()+(-arb(3).exp()).exp())
    # |d_x^2 f| and |d_y^2 f| are <=2 for the double integral of
    # e^{x+y-1-e^x-e^y}(1+e^x+e^y)^-2 times the logarithmic phase.
    e = arb(1).exp()
    derivative_bound = ( (3/e)**3 + arb("7.25")*(2/e)**2
                        + (arb("3.125")**2+arb("2.125"))/e ) / e**2
    assert derivative_bound < 2
    midpoint = abs(c_squared)*13**2*delta**2/6
    tau = abs(c_squared)*e_minus_one/4
    determinant = tau**2*tau.exp()/2
    return 1-trace_value, omitted, midpoint, determinant


def fejer(order):
    """Positive first Fejer weights, exact on polynomials of degree <order."""
    out = []
    for j in range(order):
        theta = arb.pi()*(2*j+1)/(2*order)
        weight = 1-sum(2*(2*k*theta).cos()/(4*k*k-1)
                       for k in range(1,(order-1)//2+1))
        assert weight > 0
        out.append((theta.cos(), 2*weight/order))
    return out


def laguerre_static(rank, order, trunc_negative=33, trunc_positive=4):
    """Certified static determinant via Laguerre projection and Fejer panels."""
    pi = arb.pi()
    v = arb("0.125")
    b = (pi*v).sinh()/pi
    a = arb("0.5")
    expa = (-a).exp()
    length = trunc_negative+trunc_positive
    coefficients = [acb(0) for _ in range(2*rank-1)]
    quadrature = fejer(order)
    for column in range(length):  # panel length 1, analytic radius 1
        centre = arb(column-trunc_negative)+arb("0.5")
        for point, weight in quadrature:
            x = centre+point/2
            y = x.exp()
            q = y/(1+y)
            phase = acb(0,v*((1+y).log()-x)).exp()
            coefficient = acb(0,b)*weight/2*y*(-a-y).exp()*phase/(1+y)**2
            for j in range(len(coefficients)):
                coefficients[j] += coefficient
                coefficient *= q
    h = acb_mat([[coefficients[j+k] for k in range(rank)] for j in range(rank)])
    identity = acb_mat([[int(j==k) for k in range(rank)] for j in range(rank)])
    determinant = (identity-h*h).det()
    # Trace-class Hankel bounds before and after compression.
    outside = b*expa*((-arb(trunc_negative)).exp()+(-arb(trunc_positive).exp()).exp())
    a0 = arb("0.9")
    projection = 2*b*expa*(a0-2*(a0*rank).sqrt()).exp()/(1-a0)
    complex_norm = b*expa*(2*v).exp()/(arb(1).exp()*arb(1).cos())
    quadrature_err = 4*length*complex_norm*arb(2)**(-order)
    h_error = (outside+projection+quadrature_err).upper()
    hs = (b*b*(-2*a).exp()/4).sqrt()
    trace_error = ((2*hs+h_error)*h_error).upper()
    determinant_err = trace_error*(1+hs**2+(hs+h_error)**2).exp()
    return determinant, outside, projection, quadrature_err, determinant_err


def to_dyadic(x):
    mantissa, exponent = x.man_exp()
    return [str(mantissa), int(exponent)]


def main():
    argp = ArgumentParser()
    argp.add_argument("--panels", type=int, nargs="+", default=[256, 1024])
    argp.add_argument("--laguerre", action="store_true")
    args = argp.parse_args()
    ctx.prec = 128
    log_b2 = priced_log_b2()
    log_m, log_error = mellin_variation(log_b2)
    print(json.dumps({"source_tail_power": 2, "log_B2_upper": str(log_b2.upper()),
                      "origin_source_log_upper": str(log_m.upper()),
                      "noninteger_log_error_upper": str(log_error.upper())}), flush=True)
    for n in args.panels:
        clock = perf_counter()
        value, outside, mesh, determinant = static_trace(n)
        varied = log_error.exp().upper()
        arithmetic = value.real.rad()+value.imag.rad()
        radius = (varied+outside+mesh+determinant+arithmetic).upper()
        centre = [value.real.mid(),value.imag.mid()]
        lower = acb(*centre).abs_lower()
        relative = (radius/(lower-radius)).upper()
        print(json.dumps({
            "input": {"c":"1","s":"i/8","h":"(-1+i)*10^-1200"},
            "panel_count_per_axis":n,"precision_bits":ctx.prec,
            "centre_decimal":str(value),"midpoint_dyadic":[to_dyadic(x) for x in centre],
            "radius_dyadic":to_dyadic(radius),"radius":str(radius),
            "relative":str(relative),
            "tail":str(outside.upper()),"midpoint_error":str(mesh.upper()),
            "determinant_remainder":str(determinant.upper()),
            "h_variation_log":str(log_error.upper()),
            "arithmetic":str(arithmetic.upper()),
            "seconds":perf_counter()-clock
        }), flush=True)

    if args.laguerre:
        for n, order in ((112, 32),(192, 46)):
            clock = perf_counter()
            value, outside, projection, meshing, det_error = laguerre_static(n,order)
            variation = log_error.exp().upper()
            arithmetic = value.real.rad()+value.imag.rad()
            radius = (variation+det_error+arithmetic).upper()
            centre = [value.real.mid(),value.imag.mid()]
            lower = acb(*centre).abs_lower()
            relative = (radius/(lower-radius)).upper()
            print(json.dumps({
                "input": {"c":"1","s":"i/8","h":"(-1+i)*10^-1200"},
                "method":"Laguerre compression plus first Fejer quadrature",
                "projection_rank":n,"order_per_panel":order,"log_panels":37,
                "precision_bits":ctx.prec,"centre_decimal":str(value),
                "midpoint_dyadic":[to_dyadic(x) for x in centre],
                "radius_dyadic":to_dyadic(radius),"radius":str(radius),
                "relative":str(relative),"hankel_log_cutoff":str(outside.upper()),
                "hankel_projection":str(projection.upper()),
                "hankel_fejer":str(meshing.upper()),
                "determinant_budget":str(det_error.upper()),
                "h_variation_log":str(log_error.upper()),
                "arithmetic":str(arithmetic.upper()),
                "seconds":perf_counter()-clock
            }), flush=True)


if __name__ == "__main__":
    main()
