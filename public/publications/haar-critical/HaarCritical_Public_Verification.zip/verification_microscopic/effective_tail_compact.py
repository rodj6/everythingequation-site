"""Price the all-compact high-frequency allowance using outward Arb balls.

Run python effective_tail_compact.py. The example is a bound calculation;
it does not evaluate the leading microscopic scalar.
"""
from fractions import Fraction
from math import comb, factorial, floor
from pathlib import Path
import json

from flint import arb, ctx
from check_nonreal_inverse import rational, eta_derivative_bound, dyadic


def compact_bound(c_low, c_high, u0, v0, m):
    c_low, c_high, u0, v0 = map(Fraction, (c_low,c_high,u0,v0))
    assert 0 < c_low <= c_high and u0 >= 0 and v0 >= 0
    assert isinstance(m,int) and m >= 0
    # Choose exact rational bad-edge harmonic measure within (v0/H,1/2).
    order = floor(max(Fraction(1),4*v0*v0))+1
    height = arb(order).sqrt()
    half_slack = Fraction(1,4)
    while not rational(v0)/height < rational(Fraction(1,2)-half_slack):
        half_slack /= 2
    lam, sigma = Fraction(1,2)-half_slack, 2*half_slack
    side = floor(u0)+2
    pi, exp_one = arb.pi(), arb(1).exp()
    while not 2*arb(2).sqrt()*(-pi*rational(Fraction(side)-u0)/(2*height)).exp() < rational(lam)-rational(v0)/height:
        side += 1

    c_lo,c_hi = rational(c_low),rational(c_high)
    mass = arb(1).max(c_lo**(-side*side))
    kap = c_lo/4
    gram = 2**side*(2+1/kap)
    static_poly = 1+4*c_hi+4*c_hi*c_hi+2*side*c_hi
    delta_inv = 1+2*c_hi+static_poly
    delta_phase_inv = 1+2*c_hi+side*c_hi
    # Price each polynomial at R=1; all its coefficients are nonnegative.
    def q_norm(j):
        integral = sum(arb(comb(2*j,k)*factorial(k))/kap**(k+1) for k in range(2*j+1))
        return 2**(side+1)*exp_one**3 * delta_inv**j * (3**(2*j)+integral/(2*pi))
    q = [q_norm(j) for j in range(order+1)]
    kappa_sum = 8*q[1]+sum(q[1:order],arb(0))
    determinant_coeff = (5*gram).exp()*sum(kappa_sum**l for l in range(order))
    determinant_rem = (5*gram).exp()*((8*q[1])**order + sum(
        l*kappa_sum**(l-1)*2**(order+2)*q[order]+kappa_sum**l
        for l in range(1,order)))
    phase_coeff = exp_one*sum(delta_phase_inv**j for j in range(order))
    phase_rem = 2**(order+2)*exp_one*delta_phase_inv**order
    scalar_bound_1 = mass*(determinant_rem+determinant_coeff*(phase_coeff+phase_rem))
    envelope_degree = 2*order*order+2*order

    smoothness = length = side+2
    jacobian = arb(1).max(2/c_lo)**(2*side)
    pre = (smoothness+6)*pi**smoothness*(jacobian/(pi*(2*smoothness-2*side-1))).sqrt()
    derivative = eta_derivative_bound(smoothness,smoothness)
    derivative1 = 2*derivative+smoothness*eta_derivative_bound(smoothness,smoothness-1)
    evaluation0 = pre*rational(max(1,derivative))
    evaluation1 = pre*rational(max(2,derivative1))
    trial_norm = jacobian*(1+2*pi*length)**(2*length)/(pi*(2*length-2*side-1))
    near_weight = (1+2/c_lo)**side
    sep = arb(1).min(1/(2*trial_norm*evaluation0*evaluation1*near_weight))
    kernel = 1/(4*pi*trial_norm*near_weight)
    shell = (sep*c_lo*c_lo/(1024*pi))**rational('1/3')
    rho0 = arb(1).max(((2*c_hi).max(2*sep)/shell)**3)
    decay = rational(sigma)*kernel*kernel*sep*shell/40000
    base_rank = max(2*side,2*length,2,-floor(-2*c_high))
    anchor = arb(base_rank).max(8*shell)

    # w_l = Lagrange weight at the origin for nodes 1/l.
    weights = [Fraction(l**(order-1) * (-1)**(order-l),
                        factorial(l-1)*factorial(order-l)) for l in range(1,order+1)]
    assert all(sum(w/Fraction(l)**j for l,w in enumerate(weights,start=1)) == (j == 0)
               for j in range(order))
    weight_sum = rational(sum(map(abs,weights)))
    comparable = 2*weight_sum*(scalar_bound_1+mass*(2*order)**order+1)
    geometric = 1-2**(-order*rational(sigma))
    envelope_1 = weight_sum*mass*(2*order*anchor)**order+comparable/geometric
    power = m+envelope_degree
    global_high = 3**envelope_degree*2**m*envelope_1*(3*power/(exp_one*decay))**(3*power)
    annulus = (1+rho0)**m*(weight_sum*mass*arb(order*base_rank)**rational(v0*v0)
               +comparable*(2+rho0)**envelope_degree
                / (geometric*arb(base_rank)**(order*rational(sigma))))
    return global_high+annulus, order, sigma, side, decay, rho0


def main():
    with ctx.workprec(160):
        records = []
        for c_lo,c_hi,u0,v0 in (("1","1","0","3/4"),("1/2","3/2","1/2","3/2")):
            bound,j,sigma,b,decay,rho0 = compact_bound(c_lo,c_hi,u0,v0,2)
            power = (bound.log()/arb(10).log()).upper()
            records.append({"c_lower":c_lo,"c_upper":c_hi,"real_tilt_abs":u0,
                            "imag_tilt_abs":v0,"seminorm_order":2,"richardson_order":j,
                            "rectangle_half_width":b,"sigma":str(sigma),
                            "B2_log10_upper_dyadic":dyadic(power),
                            "B2_log10_upper_display":power.str(16),
                            "decay_lower":decay.lower().str(16),
                            "rho0_upper":rho0.upper().str(16)})
    path = Path(__file__).with_name("effective_tail_compact_receipts.json")
    path.write_text(json.dumps(records,indent=2)+"\n")
    print(path.read_text(),end="")


if __name__ == "__main__":
    main()
