"""Contracting enclosure at tested cutoffs by a large-depth Gaussian comparison."""
import json
from time import monotonic

from flint import acb, arb, ctx
from near_integer import disk, pair, round_constants


def rounded_exp(logarithm):
    if logarithm < -512*arb(2).log():
        return arb(2)**-512
    return logarithm.exp().upper()


def trace_cap(c, s, P):
    # P bounds |p|+|q|. Shift by c/4. Bound log of squared HS norm.
    a = arb(c)/2
    delta = a/2
    S = abs(s).upper()
    L1 = 2*S+2*P
    L2 = 2*S+4*P
    log_HS = S*(arb(3).log()+arb.pi())+2*P+(L1*L1+L2).log()
    log_HS -= (a*a).log()+delta
    return rounded_exp(2*log_HS)


def check(Rint, tol):
    started = monotonic()
    c = 2**128
    s = acb(arb(1)/16,arb(1)/16)
    h = acb(arb(1)/2,arb(1)/8)
    U, v = h.real,s.imag
    R = arb(Rint)

    # The real-order interval for the tilt is {1/16}; B=3 and lambda=1/4 obey
    # the harmonic barrier inequality on |Im s|<=1/16.
    A, N, E = round_constants(c,c,3,arb(1)/2)
    T = max(arb(N),(E*E).upper(),arb(1))
    alpha = 8*v*v
    assert 2*U > alpha

    mass = acb(c).pow(-s*s).abs_upper()
    G = acb(c).pow(-2*h)*acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()
    main = acb(c).pow(-s*s-2*h) * (1+h).gamma() * (-s*s).hypgeom_1f1(-h,1)

    tr0 = trace_cap(c,s,arb(4))
    trwide = trace_cap(c,s,2*R)
    sup0 = mass*(2*abs(s)+1).exp() * tr0*tr0.exp()
    supwide = mass*(v*v).exp()*trwide*trwide.exp()
    jet = (abs(G)*sup0/(2*abs(h))).upper()
    origin = (abs(G)*sup0/(3*(2-2*U))).upper()
    finite_interval = (abs(G)*supwide/(2*U)).upper()
    infinite = ((A*(2*T)**(v*v)*3**alpha*R**(alpha-2*U)/(2*U-alpha))+
                 (1+mass*(v*v).exp())*R**(-2*U)/(2*U))
    tail = (abs(G)*infinite).upper()
    midpoint, error = disk(main,jet+origin+finite_interval+tail)
    modlower = (midpoint.abs_lower()-error).lower()
    assert modlower > 0
    rel = (error/modlower).upper()
    assert rel < tol
    return dict(case="far-from-integer nonreal upper positive order", c="2^128",
                h=["1/2","1/8"],s=["1/16","1/16"],cutoff=str(Rint),
                midpoint=str(midpoint), radius=str(error), relative=str(rel),
                requested_relative=str(tol), midpoint_dyadic=[pair(midpoint.real)[0],
                pair(midpoint.imag)[0]], radius_dyadic=pair(error)[1],
                angle_and_radial_comparison=str(finite_interval), origin_jet=str(jet),
                origin_remainder=str(origin), high_frequency_tail=str(tail),
                finite_arithmetic=str(main.real.rad()+main.imag.rad()),
                bits=ctx.prec,elapsed=monotonic()-started)


if __name__ == "__main__":
    with ctx.workprec(256):
        for r,t in [(2**65,arb("1e-14")), (2**100,arb("1e-24"))]:
            print(json.dumps(check(r,t)),flush=True)
