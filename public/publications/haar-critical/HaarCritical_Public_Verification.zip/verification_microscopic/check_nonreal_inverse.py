"""Arb certificates using the effective complex tail near zero order.

Requires python-flint 0.9.0. The half-planes, strip constants, and
finite-reference bounds are proved in the accompanying LaTeX modules.
"""
from fractions import Fraction
from math import comb, factorial
import json
from time import perf_counter
from pathlib import Path

from flint import acb, arb, ctx


def rational(q):
    q = Fraction(q)
    return arb(q.numerator) / q.denominator


def dyadic(value):
    mantissa, exponent = value.man_exp()
    return [str(mantissa), int(exponent)]


def eta_derivative_bound(smoothness, derivative):
    # Coefficient 1-norm on y=|x|-1 in [0,1], exact rationals.
    if derivative == 0:
        return Fraction(1)
    norm = Fraction(factorial(smoothness)**2, factorial(2*smoothness+1))
    total = Fraction(0)
    for k in range(smoothness+1):
        degree = smoothness + k + 1
        total += Fraction(comb(smoothness,k) * factorial(degree),
                          degree * factorial(degree-derivative)) / norm
    return total


def effective_tail(c, m=2):
    """Specialize the proved formula at Re(s)=0, |Im(s)|<=1/8."""
    c = arb(c)
    lam, v0, side = rational('3/8'), rational('1/8'), arb(2)
    pi = arb.pi()
    assert 2*arb(2).sqrt()*(-pi*side/2).exp() < lam-v0
    sigma, kap = 1-2*lam, c/4
    polynomial = 1+4*c+4*c*c+2*side*c
    gram = 4 * (2+1/kap)
    interpolation_integral = 1/kap+2/(kap*kap)+2/(kap*kap*kap)
    axis_error = side*c + 2*polynomial*4*(2+5*gram).exp()*(
        9+interpolation_integral/(2*pi))
    majorant = (2*axis_error).max(arb(4))
    # j_0=L=4 and B=2.
    j0 = length = 4
    derivative = eta_derivative_bound(j0, j0)
    derivative1 = 2*derivative+j0*eta_derivative_bound(j0,j0-1)
    prefactor = (j0+6)*pi**j0
    evaluation0 = prefactor*rational(max(derivative,1))/(pi*(2*j0-5)).sqrt()
    evaluation1 = prefactor*rational(max(derivative1,2))/(pi*(2*j0-5)).sqrt()
    norm = (1+2*pi*length)**(2*length)/(pi*(2*length-5))
    weight = (1+2/c)**2
    sep = (1/(2*norm*evaluation0*evaluation1*weight)).min(arb(1))
    kernel = 1/(4*pi*norm*weight)
    shell = (sep*c*c/(1024*pi))**rational('1/3')
    rho0 = ((2*c).max(2*sep)/shell)**3
    rho0 = rho0.max(arb(1))
    decay = sigma*kernel*kernel*sep*shell/40000
    base_rank = 512
    anchor = arb(base_rank).max(8*shell)
    geometric = 1-2**(-sigma)
    constant = (2*anchor)**lam+majorant/geometric
    global_high = 81*2**m*constant*(3*(m+4)/arb(1).exp()/decay)**(3*(m+4))
    annulus = (1+rho0)**m*(arb(base_rank)**(v0*v0)
               +majorant*(2+rho0)**4/(arb(base_rank)**sigma*geometric))
    return global_high+annulus, rho0, decay


def shifted_error(c, s, source_radius, line):
    """Bound ||H+ H-||_1 by shifted second-derivative integrals."""
    a = c/2
    g = a-line
    assert line > 0 and g > 0
    phase = abs(s)*((a+line).log()-g.log()+arb.pi())+c*source_radius/g
    size = 2*abs(s)+c*source_radius/g
    accel = 2*abs(s)+2*c*source_radius/g
    kernel = phase.exp()*(size*size+accel)/(2*g)
    norm = kernel*(-line).exp()/(2*line)
    return norm*norm


def limit_control(bits, line, tolerance):
    start = perf_counter()
    with ctx.workprec(bits):
        c = arb(256)
        s = acb(0,rational('1/8'))
        tiny = arb((1,-1500000))
        h = acb(-tiny,tiny)
        q = (((2/c).log()*(2*h)).exp()*(1+h).gamma()/(1-h).gamma())
        mass = (c.log()/64).exp()
        tail, rho0, decay = effective_tail(c)
        complex_box = shifted_error(c,s,arb(2),arb(64))
        bound2 = mass*(2*abs(s)+1+complex_box).exp()
        near_zero_integral = bound2/(3*(2-2*h.real))
        high_integral = tail/(2+2*h.real)
        low_error = 2*abs(h*q)*near_zero_integral
        high_error = 2*abs(h*q)*high_integral
        static_trace = shifted_error(c,s,arb(0),arb(line))
        static_error = abs(q)*mass*static_trace.expm1()
        value = q*mass
        centre = acb(value.real.mid(),value.imag.mid())
        arithmetic_error = value.real.rad()+value.imag.rad()
        error = (arithmetic_error+static_error+low_error+high_error).upper()
        relative = (error/(centre.abs_lower()-error)).upper()
        assert error < rational(tolerance)
        assert relative < rational(tolerance)
        return {
            "target": tolerance, "bits":bits, "static_shift":line,
            "seconds":perf_counter()-start,
            "midpoint":[dyadic(centre.real),dyadic(centre.imag)],
            "radius":dyadic(error),
            "midpoint_display":str(centre),
            "absolute_radius_upper":error.str(18),
            "relative_error_upper":relative.str(18),
            "arithmetic_upper":arithmetic_error.upper().str(12),
            "static_determinant_error_upper":static_error.upper().str(12),
            "origin_remainder_upper":low_error.upper().str(12),
            "radial_tail_upper":high_error.upper().str(12),
            "radial_B2_log10_upper":(tail.log()/arb(10).log()).upper().str(14),
            "radial_tail_threshold_upper":rho0.upper().str(14),
            "radial_stretch_exponent_lower":decay.lower().str(14),
        }


def finite_reference():
    start = perf_counter()
    with ctx.workprec(180):
        rank = 512
        c = arb(256)
        z = (1-c/rank).sqrt()
        shift = -z.log()/2
        one_hankel = (arb.pi()/8-(rank+1)*shift).exp()/(-(-2*shift).expm1())
        finite_trace = one_hankel*one_hankel
        mass = (c.log()/64).exp()
        static_bound = mass*finite_trace.expm1()
        tiny = arb((1,-1500000))
        log_weight = (rank*rank)*((c/rank).log()-2*(1-z).log())
        log_weight += (rank*(rank-1)//2-1)*arb(4).log()-arb(factorial(rank)).log()
        small_ball = 12*c*log_weight.exp()/arb.pi()
        log_readout = 4*small_ball*arb(2).sqrt()/(1-1/arb(2).sqrt())+arb(4).log()*arb(4)**rational('1/4')
        order_bound = 2*arb(2).sqrt()*tiny*(arb(rank).log()/64).exp()*log_readout
        centre, error = mass.mid(), (mass.rad()+static_bound+order_bound).upper()
        return {
            "rank":rank, "z_squared_exact":"1/2",
            "seconds":perf_counter()-start,
            "midpoint":[dyadic(centre),["0",0]], "radius":dyadic(error),
            "absolute_radius_upper":error.str(18),
            "finite_rank_determinant_error_upper":static_bound.upper().str(14),
            "finite_rank_order_error_upper":order_bound.upper().str(14),
        }


def from_dyadic(data):
    return arb((int(data[0]),data[1]))


def main():
    limits = [limit_control(96,2,"1e-7"),limit_control(180,64,"1e-12")]
    reference = finite_reference()
    with ctx.workprec(200):
        a,b = [acb(*(from_dyadic(p) for p in record["midpoint"]))
               for record in [limits[-1],reference]]
        difference = abs(a-b)+from_dyadic(limits[-1]["radius"])+from_dyadic(reference["radius"])
        assert difference < rational('1e-50')
    result = {
        "c":"256", "h":{"real":["-1",-1500000],"imag":["1",-1500000]},
        "h_format":"exact dyadics (integer mantissa, binary exponent)",
        "s":["0","1/8"],"finite_reference":reference,"limiting":limits,
        "certified_limit_vs_finite_difference_upper":difference.upper().str(18),
    }
    destination = Path(__file__).with_name("nonreal_inverse_receipts.json")
    destination.write_text(json.dumps(result,indent=2)+"\n")
    print(destination.read_text(),end="")


if __name__ == "__main__":
    main()
