"""Validated Mellin enclosure near h=1 using exact inverse-gamma removal."""
from math import factorial
from time import monotonic
import json

from flint import acb, arb, ctx
from real_control import pair


def round_constants(cminus, cplus, B, sigma):
    """Real comparison and interpolated rank constants from (19.M4),(19.M6)."""
    a = max(arb(1), arb(cminus)**(-B*B))
    k = arb(cminus)/4
    N = max(2*cplus, 2*B, 2)
    S = 2**B * (2+1/k)
    D = 1+4*cplus+4*cplus*cplus+2*B*cplus
    C = a*(B*cplus + 2*D*2**B*(2+5*S).exp()*
           (9+(1/k+2/k**2+2/k**3)/(2*arb.pi())))
    M = max(2*C.upper(), (4*a).upper())  # compare exact outward endpoints
    E = (M/(1-arb(2)**(-sigma))).upper()
    return a,N,E


def stretched(cminus, cplus, B, sigma, lamb):
    A, N, E = round_constants(cminus,cplus,B,sigma)
    j = B+2
    cut = max(arb(1), arb(2)/cminus)**(2*B)
    d = 3*(j+1)*(2*j+1)*factorial(2*j)//factorial(j)**2
    deriv = d*2**j*(2*j)**j
    V = (j+6)*arb.pi()**j * deriv * (cut/(arb.pi()*(2*j-2*B-1))).sqrt()
    L = j
    C_L = cut*(1+2*arb.pi()*L)**(2*L)/(arb.pi()*(2*L-2*B-1))
    W_1 = (1+arb(2)/cminus)**B
    eps = min(arb(1), (1/(2*C_L*V*V*W_1)).lower())
    k0 = 1/(4*arb.pi()*C_L*W_1)
    d0 = (eps*cminus*cminus/(1024*arb.pi()))**(arb(1)/3)
    rho0 = max(arb(1), ((max(arb(2*cplus), 2*eps)/d0)**3).upper())
    b = (sigma*k0*k0*eps*d0/(8*5000)).lower()
    T = max(arb(N), arb(2*L), (8*d0).upper())
    C_star = (A*(2*T)**lamb+E).upper()
    return A,N,E,rho0,b,C_star


def power_tail(c, sigma, v, B, re_h):
    A,N,E = round_constants(c,c,B,sigma)
    D = int((4/sigma).ceil().unique_fmpz())
    a = D*v*v
    if not 2*re_h > a:
        raise ValueError("positive-order polynomial bound is not integrable")
    return (A*(2*N)**(v*v)*3**a/(2*re_h-a)+E/(2*re_h)).upper()


def compact_source(c, s, radius, frac):
    """Suprema on |p|,|q| <= radius. Return total, discrepancy, HS, TD."""
    a = arb(c)/2
    shift = a*frac
    d = a-shift
    S = abs(s).upper()
    P = 2*radius
    exp_L = (S*((a+shift).log()-d.log()+arb.pi())+a*P/d).exp()
    L1 = 2*S+a*P/d
    L2 = 2*S+2*a*P/d
    K = exp_L*(L1*L1+L2)/(2*d)
    HS = K*(-shift).exp()/(2*shift)
    trace = HS*HS
    gauss = (-(s*s).real*arb(c).log() + S*radius+radius*radius/4).exp()
    return ((gauss*trace.exp()).upper(), (gauss*trace*trace.exp()).upper(),
            HS.upper(), trace.upper())


def disk(z, error):
    midpoint = acb(z.real.mid(),z.imag.mid())
    return midpoint,(z.real.rad()+z.imag.rad()+error).upper()


def run(frac, tol):
    now = monotonic()
    c = 256
    s = acb(arb(3)/4, arb(1)/16)
    q = 4096
    h = acb(1, arb(2)**-q)
    radius = arb(2)
    M, discrepancy, hs, trace = compact_source(c,s,radius,frac)
    gaussian = acb(c).pow(-s*s) * (1+s*s)/(-4)
    # Remove the simple denominator before evaluating. rgamma(-h) =
    # (-h)*(1-h)*rgamma(2-h).
    G = acb(c).pow(-2*h)*acb(2).pow(2*h+1)*(1+h).gamma()
    resonant = -h*(2-h).rgamma()/2
    ordinary = (-h)*(1-h)*(2-h).rgamma()
    partial = G*resonant*gaussian
    cauchy = (abs(G*resonant)*discrepancy/radius**2).upper()
    static = (abs(G*ordinary)*M/(2*abs(h))).upper()
    origin = (abs(G*ordinary)*M/(12*(4-2*h.real))).upper()
    tail_raw = power_tail(c,arb(1)/2,arb(1)/16,4,h.real)
    tail = (abs(G*ordinary)*tail_raw).upper()
    m,e = disk(partial,cauchy+static+origin+tail)
    assert e < tol
    modulus=(m.abs_lower()-e).lower()
    assert modulus > 0
    return dict(case="independent complex noninteger near h=1",c=c,
                s=["3/4","1/16"],h=["1","2^-"+str(q)], rho_cutoff=1,
                line_fraction=str(frac), precision=ctx.prec,tolerance=str(tol),
                midpoint=str(m),error=str(e),relative=str((e/modulus).upper()),
                midpoint_dyadic=[pair(m.real)[0],pair(m.imag)[0]],
                radius_dyadic=pair(e)[1], hs_bound=str(hs), trace_bound=str(trace),
                cauchy_jet=str(cauchy), static=str(static), origin=str(origin),
                tail_raw=str(tail_raw), tail=str(tail),
                arithmetic=str(partial.real.rad()+partial.imag.rad()),
                elapsed=monotonic()-now)


def integer_control():
    c=256
    s=acb(1)
    radius=arb(2)
    _,d,_,_=compact_source(c,s,radius,arb(1)/2)
    g=arb(2)/arb(c)**3
    e=(4*d/radius**2/c**2).upper()
    reference=(2-(arb(c)**2+2*c+2)*(-arb(c)).exp())/arb(c)**3
    assert (g-reference).abs_upper()<=e
    return dict(case="integer Schur control",c=c,s=1,h=1,precision=ctx.prec,
                midpoint=str(g),jet_allowance=str(e),schur_limit=str(reference),
                observed_display_difference=str((g-reference).abs_upper()),
                exact_difference_formula="(c^2+2*c+2)*exp(-c)/c^3")


if __name__ == "__main__":
    with ctx.workprec(512):
        for frac, tol in [(arb(1)/4,arb("1e-22")), (arb(1)/2,arb("1e-42"))]:
            print(json.dumps(run(frac,tol)),flush=True)
    with ctx.workprec(640):
        print(json.dumps(integer_control()),flush=True)
