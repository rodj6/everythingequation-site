"""Outward Arb budgets for the exterior Hardy determinant proof."""
import argparse
from fractions import Fraction
from math import comb, factorial
import json

from flint import arb,acb,ctx,fmpq


def a(x):
    f=Fraction(x)
    return arb(fmpq(f.numerator,f.denominator))


def elementary_tail(x,k):
    return 2*(-k*x).exp()*sum(
        factorial(3)//factorial(j)*x**j / k**(4-j) for j in range(4))


def bounds(c,U,V):
    beta=arb(2).log().min(c.sqrt())
    alpha=beta/2
    A=1+arb(2)**U
    E=(arb.pi()*V).exp()
    J=(arb.pi()*V).sinh()/arb.pi()
    n0=int((2*U+2).upper().ceil().unique_fmpz())
    M0=max(1,n0)
    while not (M0>=(2/alpha)**2 and elementary_tail(arb(M0).sqrt(),alpha)<=1):
        M0*=2
    T0=a("5/4")+(A*E).log()
    G=n0*(n0-1)+2*A*(sum(n*(-beta*arb(n).sqrt()).exp() for n in range(n0,M0+1))
                      +elementary_tail(arb(M0).sqrt(),beta))
    if U<1:
        C=c/2
        Gfast=(-C).exp()*(1/C+arb(2)**U*(1-U).gamma()*C**(U-1))/arb.pi()
        G=G.min(Gfast)
    Mfactor=M0+1+4*T0**2/beta**2
    P=8*E*J
    # On the whole box, |c^(−s²)| ≤ exp[(U²+V²)|log c|].
    log_A0=((U*U+V*V)*abs(c.log())+(1+arb(2).sqrt())*G+5*E**2+2
            +4*E*J*((2*Mfactor).log()+5))
    return log_A0,P,M0,G


def poly_envelope(j0,j):
    # eta(1+y) = 1 - int_0^y [t (1−t)]^j0 dt / B(j0+1,j0+1).
    # The coefficient absolute sum bounds its derivatives on 0<=y<=1.
    fac=Fraction(factorial(2*j0+1),factorial(j0)**2)
    p={0:Fraction(1)}
    for i in range(j0+1):
        k=j0+i+1
        p[k]=Fraction((-1)**(i+1)*comb(j0,i),k)*fac
    if j:
        d=p.copy()
        for k,v in p.items():
            d[k+1]=d.get(k+1,Fraction(0))+v
        p=d
    v=sum(abs(f)*Fraction(factorial(k),factorial(k-j0)) for k,f in p.items()
          if k>=j0)
    return a(max(v,sum(abs(x) for x in p.values()),Fraction(1)))


def real_damping(c,B):
    # The last real-axis coherence argument of the inherited
    # Fredholm certification, with the constants made numerical.
    j0=2+int(B.upper().ceil().unique_fmpz()); L=j0
    W=arb(1).max(2/c)**(2*B)
    W1=(1+2/c)**B
    pi=arb.pi()
    constants=[(j0+6)*pi**j0*poly_envelope(j0,j) for j in range(2)]
    U=[K*(W/(pi*(2*j0-2*B-1))).sqrt() for K in constants]
    CL=W*(1+2*pi*L)**(2*L)/(pi*(2*L-2*B-1))
    e=arb(1).min(1/(2*CL*U[0]*U[1]*W1))
    k0=1/(4*pi*CL*W1)
    d0=(e*c*c/(1024*pi))**a("1/3")
    rho0=arb(1).max((2*c.max(e)/d0)**3)
    a0=k0*k0*e*d0/40000
    realmass=(abs(c.log())*B**2)
    return rho0,a0,realmass


def bound_power(log_A,P,H,pref,R,eps):
    if not 2*H>P:
        return None
    z=2*H-P
    tail_log=pref.log()+log_A+P*arb(2).log()-z.log()
    return (tail_log-z*R.log())/arb(10).log(),(tail_log-eps.log())/z/arb(10).log()


def main():
    p=argparse.ArgumentParser()
    for name,default in [('depth','1'),('sre','1/2'),('sim','1/20'),
                         ('hre','1/2'),('him','0'),('radius','1'),('tolerance','1/10000000000')]:
        p.add_argument('--'+name,default=default)
    p.add_argument('--m',type=int,default=2)
    args=p.parse_args()
    c,U,V,H,W,R,eps=[a(getattr(args,n)) for n in ('depth','sre','sim','hre','him','radius','tolerance')]
    h=acb(H,W)
    pref=((acb(2).log()*(2*h+1)-2*h*c.log()).exp()
          *(1+h).gamma()*(-h).rgamma()).abs_upper()
    dlog,P,M,G=bounds(c,abs(U),abs(V))
    power=bound_power(dlog,P,H,pref,R,eps)
    if power is not None:
        power=dict(log10_tail_at_radius=power[0].str(13),log10_required_radius=power[1].str(13))
    # Lower harmonic measure θ>=1/2: height >=4 v_target and horizontal
    # margin forces the side correction to <=1/4.
    V2=arb(1)/4+4*abs(V)
    U2=abs(U)+2*V2/arb.pi()*(8*arb(2).sqrt()).log()
    dlog2,P2,M2,G2=bounds(c,U2,V2)
    rho,a0,log_real_mass=real_damping(c,U2)
    low=dlog2+(args.m+P2)*(1+rho).log()
    k=a0/2
    D=3*(args.m+P2)
    opt=(D/k-1).max(0)
    high=dlog2.max(log_real_mass)+D*(1+opt).log()-k*opt
    log_B=low.max(high)
    log_R=(log_B+pref.log()-(args.m+2*H).log()-eps.log())/(args.m+2*H)
    print(json.dumps(dict(inputs=vars(args),power=dict(exponent=P.str(13),
          log_amplitude=dlog.str(13),M0=M,gram=G.str(13),budget=power),
          all_orders=dict(rectangle_half_width=U2.str(13),rectangle_height=V2.str(13),
          log10_real_damping_magnitude=(a0.log()/arb(10).log()).str(13),
          log10_real_damping_onset=(rho.log()/arb(10).log()).str(13),
          log10_Bm=(log_B/arb(10).log()).str(13),
          log10_required_radius=(log_R/arb(10).log()).str(13))),indent=2))


if __name__=='__main__':
    with ctx.workprec(176):
        main()
