"""Price the first failed direct Mellin budget on a depth-one complex input."""
import json

from flint import arb, acb, ctx

from mellin_enclosure import tail_bound, integrate
from near_integer import pair

with ctx.workprec(120):
    c=arb(1)
    h=acb(arb(1)/2,arb(1)/8)
    s=acb(arb(1)/2,arb(1)/20)
    phase=abs(acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma())
    pref=phase.upper()
    allowance=(pref*tail_bound(c,s,h,arb(1),2)).upper()
    cutoff=((allowance/arb("1e-12")).log()/(3*arb(10).log())).upper()
    at64=(allowance/64**3).upper()
    print(json.dumps({"c":"1","h":["1/2","1/8"],"s":["1/2","1/20"],
                      "tail_power":2,"target_tail_absolute":"1e-12",
                      "log10_allowance_at_64":str(at64.log()/arb(10).log()),
                      "log10_sufficient_cutoff":str(cutoff),
                      "status":"tail bound too large for direct annulus"}))
    # Check the general driver along its integer branch on exact static mass.
    val=integrate("128","0","1",cutoff=1,origin_cut="1/8",jet_count=1,
                  radial_cells=1,angles=1,precision=128,
                  source_options=dict(cells=8,extent="1",tail_line="32",bits=128))
    reference=(1-(-arb(128)).exp())/128
    assert (val.midpoint-acb(reference)).abs_upper()<val.radius
    print(json.dumps({"with_integer_dispatch":True,
                      "radius":str(val.radius),"reference":str(reference),
                      "exact_radius":pair(val.radius)[1],
                      "midpoint":[pair(val.midpoint.real)[0],pair(val.midpoint.imag)[0]]}))
