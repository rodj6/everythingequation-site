"""Independent integer check and rigorous real fractional brackets."""
from pathlib import Path
import json

from flint import arb,ctx

HERE=Path(__file__).resolve().parent


def value(j):
    return arb(int(j[0]))*arb(2)**int(j[1])


def real_bound(js):
    center=value(js['real'])
    radius=value(js['radius'])
    return arb(center,radius)


def read_moments(filename):
    report=json.loads((HERE/filename).read_text())
    return {int(j):real_bound(x) for j,x in report['exact_dyadic_disks'].items()}


def dyadic(a):
    n,d=a.man_exp()
    return [str(n),int(d)]


def half_bracket(filename):
    data=read_moments(filename)
    lo=(data[1]**3/data[2]).sqrt().lower()
    hi=(data[0]*data[1]).sqrt().upper()
    return dict(file=filename, interval=[lo.str(13),hi.str(13)],
                exact_endpoints=[dyadic(lo),dyadic(hi)],
                diameter=(hi-lo).str(12))


def integer_check():
    data=read_moments('jet_integer_reference.json')
    ref=2-5*(-arb(1)).exp()
    assert data[1].contains(ref)
    assert data[0].contains(1-(-arb(1)).exp())
    return dict(method="Schur exterior-character sum, depth 1",
                reference_value=ref.str(24), passed=True)


if __name__=='__main__':
    with ctx.workprec(120):
        print(json.dumps(dict(integer=integer_check(),
                              half_order=[half_bracket(f'jet_half_{p}.json')
                                          for p in ['coarse','tight']]),indent=2))
