"""Executed depth-one fractional brackets and a nonreal near-one readout."""
from pathlib import Path
import json

from flint import arb, acb, ctx
from near_integer import disk, pair, power_tail, compact_source

BASE = Path(__file__).resolve().parent


def db(parts):
    m,e=parts
    return arb(int(m))*arb(2)**e


def jet(filename, j):
    t=json.loads((BASE/filename).read_text())["exact_dyadic_disks"][str(j)]
    return acb(db(t["real"]),db(t["imag"])),db(t["radius"])


def complex_check(name, tol):
    p=10**15
    h=acb(1,arb(2)**-p)
    s=acb(arb(1)/2,arb(1)/20)
    mu,error=jet(name,1)
    M,*_=compact_source(1,s,arb(2),arb(1)/2)
    G=acb(2).pow(2*h+1)*(1+h).gamma()
    reg=(-h)*(1-h)*(2-h).rgamma()
    coefficient=-h*(2-h).rgamma()/2
    partial=-G*coefficient*mu/4
    jet_error=(abs(G*coefficient)*error/4).upper()
    static=(abs(G*reg)*M/(2*abs(h))).upper()
    origin=(abs(G*reg)*M/(12*(4-2*h.real))).upper()
    tail=(abs(G*reg)*power_tail(1,arb(1)/2,arb(1)/16,3,h.real)).upper()
    center,radius=disk(partial,jet_error+static+origin+tail)
    lower=(center.abs_lower()-radius).lower()
    assert lower>0
    rel=(radius/lower).upper()
    assert rel < tol
    return dict(c=1,h=["1",f"2^-{p}"],s=["1/2","1/20"],example="nonreal near integer",
                jet_receipt=name,tolerance=str(tol),relative=str(rel),
                center=str(center),absolute=str(radius),jet=str(jet_error),
                origin=str(origin),static=str(static),tail=str(tail),
                midpoint_dyadics=[pair(center.real)[0],pair(center.imag)[0]],
                absolute_dyadic=pair(radius)[1])


def real_check(name,tol):
    balls=[]
    for j in range(3):
        m,e=jet(name,j)
        balls.append(m.real+arb(0,e))
    A,B,C=balls
    low=(B**(arb(3)/2)/C.sqrt()).lower()
    high=(A*B).sqrt().upper()
    assert (high-low)/2 < tol
    return dict(c=1,h="1/2",s="1/2",example="real diagonal",
                jet_receipt=name,tolerance=str(tol), interval=[pair(low)[0],pair(high)[1]],
                interval_display=[str(low),str(high)], halfwidth=str((high-low)/2),
                source_moments=[str(v) for v in balls])


if __name__ == "__main__":
    with ctx.workprec(256):
        for name,tol in (("jet_half_coarse.json","0.092"),
                         ("jet_half_tight.json","0.085")):
            print(json.dumps(real_check(name,arb(tol))))
        for name,tol in (("jet_complex_reference.json","1e-4"),
                         ("jet_complex_tight.json","1e-7")):
            print(json.dumps(complex_check(name,arb(tol))))
