"""Execute finite-source controls and export exact dyadic rectangle components."""
import json
from pathlib import Path
from time import monotonic
from flint import acb, arb, ctx
from finite_source import source


def dyadic(x):
    m,e = x.man_exp()
    return [str(m),int(e)]


def enclosure(x):
    return {"real": {"mid":dyadic(x.real.mid()),"rad":dyadic(x.real.rad())},
            "imag": {"mid":dyadic(x.imag.mid()),"rad":dyadic(x.imag.rad())}}


cases = [
    ("nonreal_coarse",64,("3/4","1/16"),("1/10","-1/20"),("1/10","1/20"),8,"1","32"),
    ("nonreal_refined",64,("3/4","1/16"),("1/10","-1/20"),("1/10","1/20"),32,"1","64"),
    ("exact_mass",64,1,0,0,32,"1","32"),
    ("real_anchor_width",1,("1/2",0),0,0,64,"8","64"),
]
rows = []
with ctx.workprec(112):
    complex_disks = []
    for label,c,s,p,q,cells,extent,T in cases:
        t = monotonic()
        controls = dict(cells=cells,extent=extent,tail_line=T,bits=112,quad_bits=36)
        result = source(c,s,p,q,**controls)
        row = dict(label=label, inputs=dict(c=c,s=s,p=p,q=q), controls=controls,
                   seconds=monotonic()-t, enclosure=enclosure(result.value),
                   finite_matrix=enclosure(result.finite_matrix_value),
                   enclosure_display=str(result.value))
        for key in ("hs_truncation","hs_cell","hs_line","trace_error","source_determinant_error"):
            value = getattr(result,key)
            row[key] = dyadic(value.upper())
            row[key+"_display"] = str(value)
        if label=="exact_mass":
            exact = acb((1-arb(-c).exp())/c)
            assert result.value.contains(exact)
            row["contains_exact_mass"] = True
            row["independent_mass"] = enclosure(exact)
        if label.startswith("nonreal"):
            complex_disks.append(result.value)
        rows.append(row)
    assert complex_disks[0].overlaps(complex_disks[1])
    assert complex_disks[1].real.rad()<complex_disks[0].real.rad()
out = Path(__file__).with_name("finite_source_receipts.json")
out.write_text(json.dumps(dict(complex_controls_overlap=True,cases=rows),indent=2)+"\n")

