"""Positive noninteger baseline: rigorous moment inequalities from static depth jets."""
import json
from time import perf_counter
from flint import acb, acb_mat, arb, ctx
from near_integer_control import fejer, to_dyadic

R=arb(1)/8
SMALL=arb(1)/32
LOWER_A=(1-R)/2
UPPER_C=1+R
PREF_STATIC=(1-R)**(-arb(1)/4)


def h_constants(rank, order, lower, upper):
    pi=arb.pi()
    base=(-LOWER_A).exp()/(pi*2*LOWER_A)
    half=arb(1)/2
    alpha=arb("0.9")
    h_norm=base*(UPPER_C.sqrt()*pi.sqrt()+1)
    projection=2*base*(alpha*(1-R/2)-2*(alpha*rank*(1-R)).sqrt()).exp()*(
        (UPPER_C*pi/(1-alpha)).sqrt()+1/(1-alpha))
    y_hi=arb(upper).exp()
    log_cut=base*(2*UPPER_C.sqrt()*(-arb(lower)/2).exp()+(-arb(lower)).exp()
                  + (UPPER_C.sqrt()/y_hi.sqrt()+1)*(-y_hi).exp())
    kappa=arb(1).cos()
    complex_norm=base*((UPPER_C/(2*kappa*arb(1).exp())).sqrt()
                       +1/(kappa*arb(1).exp()))
    fejer_err=4*(lower+upper)*complex_norm*(arb(2)**(-order))
    h_error=projection+log_cut+fejer_err
    det_err=((2*h_norm+h_error)*h_error)*(1+h_norm**2+(h_norm+h_error)**2).exp()
    return PREF_STATIC * det_err, PREF_STATIC * (h_norm**2).exp(), {
        "projection":str(projection.upper()),"fejer":str(fejer_err.upper()),
        "log_cutoff":str(log_cut.upper()),"static_determinant":str(det_err.upper())}


def static_approximation(c, rank, nodes, lower, upper):
    coeffs=[acb(0) for _ in range(2*rank-1)]
    for column in range(lower+upper):
        mid=arb(column-lower)+arb("0.5")
        for theta,weight in nodes:
            t=mid+theta/2
            y=t.exp()
            lam=c/2+y
            qt=(lam-arb("0.5"))/(lam+arb("0.5"))
            coeff=weight/2/arb.pi()*(-lam).exp()*(y*(c+y)).sqrt()/(lam+arb("0.5"))**2
            for j in range(len(coeffs)):
                coeffs[j]+=coeff
                coeff*=qt
    h=acb_mat([[coeffs[i+j] for j in range(rank)] for i in range(rank)])
    ident=acb_mat([[int(i==j) for j in range(rank)] for i in range(rank)])
    return c**(-arb(1)/4)*(ident-h*h).det()


def run(rank, order, samples, lower, upper):
    nodes=fejer(order)
    const,bound,analytic=h_constants(rank,order,lower,upper)
    clock=perf_counter()
    vals=[]
    for j in range(samples//2+1):
        theta=2*arb.pi()*j/samples
        e=acb(0,theta).exp()
        vals.append(static_approximation(1+SMALL*e,rank,nodes,lower,upper))
    estimates=[]
    for k in (0,1,2):
        value=vals[0].real+(-1)**k*vals[-1].real
        for j in range(1,len(vals)-1):
            term=vals[j]*acb(0,-2*arb.pi()*k*j/samples).exp()
            value+=2*term.real
        value/=samples*SMALL**k
        alias=bound/R**k*(SMALL/R)**samples/(1-(SMALL/R)**samples)
        error=const/SMALL**k+alias
        estimates.append(value+arb(0,error.upper()))
    a,deriv,halfsecond=estimates
    mean=2*deriv
    second=8*halfsecond
    assert a>0 and second>0
    lower=mean.abs_lower()
    upper=(a*second).sqrt().upper()
    assert upper > lower
    centre=(lower+upper).mid()/2
    radius=((centre-lower).abs_upper().max((upper-centre).abs_upper())).upper()
    print(json.dumps({
        "input":{"c":"1","h":"1/2","s":"1/2"},"absolute_positive_moment_bounds":{
            "lower":str(lower),"upper":str(upper)},"centre_dyadic":to_dyadic(centre),
        "radius_dyadic":to_dyadic(radius),"radius":str(radius),
        "rank":rank,"fejer_order":order,"depth_cauchy_samples":samples,
        "static_operator_error_terms":analytic,
        "mass":str(a),"real_first_moment":str(mean),"absolute_second_moment":str(second),
        "error_floor":"width of inequality between |E Re S| and sqrt(E 1 E |S|^2)",
        "seconds":perf_counter()-clock}),flush=True)


if __name__=="__main__":
    ctx.prec=128
    run(96,28,12,41,4)
    run(128,36,16,45,4)
