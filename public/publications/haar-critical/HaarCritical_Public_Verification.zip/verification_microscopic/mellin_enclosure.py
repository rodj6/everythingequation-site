"""General interval Mellin reduction at positive depth and Re h>-1.

Use exact rational strings/tuples. The parameters select one independently
priced pass. The conservative general pass can be very expensive.
"""
from dataclasses import dataclass

from flint import acb, arb, ctx

from finite_source import source, complex_ball, real
from near_integer import compact_source, disk


@dataclass
class MellinResult:
    midpoint: acb
    radius: arb
    tail: arb
    origin: arb
    jet_alias: arb
    outer_quadrature: arb
    weighted_source: arb
    arithmetic: arb


def bounds_for_tilt(s):
    v0 = s.imag.abs_upper()
    J = 1 if v0 < arb(1)/2 else int((4*v0*v0).ceil().unique_fmpz())+1
    H = arb(J).sqrt()
    ratio = (v0/H).upper()
    lamb = ((ratio+arb(1)/2)/2).upper()
    B = 1
    while (not arb(B) >= s.real.abs_upper()+1 or
           not 2*arb(2).sqrt()*(-arb.pi()*(B-s.real.abs_upper())/(2*H)).exp()
               <= lamb-ratio):
        B += 1
    return v0,lamb,B,J


def tail_bound(c, s, h, R, m):
    v0,lamb,B,J = bounds_for_tilt(s)
    cl=(c/2).lower()
    cu=(2*c).upper()
    sigma=1-2*lamb
    A,N,E,rho0,b,C = stretched_generic(cl,cu,B,sigma,lamb)
    if m+2*h.real <= 0:
        raise ValueError("m+2 Re h must be positive")
    if J == 1:
        degree=4
        high_coefficient=81*C
        low=A*N**(v0*v0)+E*(2+rho0)**4
    else:
        degree=4*J*J+J
        rich, T = higher_rank_constants(cl,cu,B,J,N,A)
        M = rich[0]
        W = rich[1]
        E_h = M/(1-arb(2)**(-J*sigma))
        high_coefficient=W*A*(6*J*T)**J+E_h
        low=W*A*(J*N)**(v0*v0)+E_h*rho0**degree
    high = (arb(2)**m*high_coefficient
            *(3*(m+degree)/(arb(1).exp()*b))**(3*(m+degree)))
    return ((high+(1+rho0)**m*low)*R**(-m-2*h.real)/(m+2*h.real)).upper()


def higher_rank_constants(cl,cu,B,J,N,A):
    """Compute the positive envelope polynomial at R=3."""
    from math import comb, factorial
    from fractions import Fraction
    k=cl/4
    D=1+4*cu+4*cu**2+2*B*cu
    delta=min(arb(1),(1/(2*cu)).lower(),(1/D).lower())
    Dp=min(arb(1),(1/(2*cu)).lower(),(1/max(arb(1),(B*cu).upper())).lower())
    S=2**B*(2+1/k)
    ecc=arb(1).exp()
    Q={}
    for j in range(1,J+1):
        mass=sum((comb(2*j,t)*factorial(t)/k**(t+1) for t in range(2*j+1)),arb(0))
        Q[j]=2**(B+1)*ecc**3*delta**(-j)*(7**(2*j)*9+mass/(2*arb.pi()))
    K=8*Q[1]+sum((Q[j] for j in range(1,J)),arb(0))
    d0=(5*S).exp()*sum((K**j for j in range(J)),arb(0))
    d1=(5*S).exp()*((8*Q[1])**J+sum(
        (j*K**(j-1)*2**(J+2)*Q[J]+K**j for j in range(1,J)),arb(0)))
    p0=ecc*sum(((3/Dp)**j for j in range(J)),arb(0))
    p1=2**(J+2)*ecc*(3/Dp)**J
    PJ=A*(d1+d0*(p1+p0))
    # The absolute inverse Vandermonde row for evaluation at zero is
    # l^(J-1)/((l-1)!(J-l)!) for nodes 1/l.
    out=sum((Fraction(l**(J-1),factorial(l-1)*factorial(J-l))
             for l in range(1,J+1)),Fraction(0))
    W=real(str(out))
    M=2*W*(PJ+A*(2*J)**J+1)
    # With epsilon<=1, d0=(epsilon*cl^2/(1024*pi))^(1/3).
    T=max(arb(1),N,(8*(cl*cl/(1024*arb.pi()))**(arb(1)/3)).upper())
    return (M,W),T


def stretched_generic(cl,cu,B,sigma,lamb):
    # Numeric implementation of the explicit coherence and rank formula.
    from math import factorial
    A=max(arb(1),(cl**(-B*B)).upper())
    k=cl/4
    j=B+2
    N=max(arb(2*j),(2*cu).ceil().upper(),arb(2*B),arb(2))
    S=2**B*(2+1/k)
    D=1+4*cu+4*cu*cu+2*B*cu
    C=A*(B*cu+2*D*2**B*(2+5*S).exp()*
         (9+(1/k+2/k**2+2/k**3)/(2*arb.pi())))
    E=(max((2*C).upper(),(4*A).upper())/(1-arb(2)**(-sigma))).upper()
    W=max(arb(1),(2/cl).upper())**(2*B)
    normalizer=factorial(2*j+1)//factorial(j)**2
    derivative=3*(j+1)*normalizer*2**j*(2*j)**j
    V=(j+6)*arb.pi()**j*derivative*(W/(arb.pi()*(2*j-2*B-1))).sqrt()
    C_L=W*(1+2*arb.pi()*j)**(2*j)/(arb.pi()*(2*j-2*B-1))
    W_1=(1+2/cl)**B
    eps=min(arb(1),(1/(2*C_L*V*V*W_1)).lower())
    k0=1/(4*arb.pi()*C_L*W_1)
    depth=(eps*cl*cl/(1024*arb.pi()))**(arb(1)/3)
    rho0=max(arb(1),((max((2*cu).upper(),(2*eps).upper())/depth)**3).upper())
    b=(sigma*k0*k0*eps*depth/(8*5000)).lower()
    T=max(N,(8*depth).upper(),arb(1))
    Cstar=(A*(2*T)**lamb+E).upper()
    return A,N,E,rho0,b,Cstar


def integrate(c, h, s, *, cutoff, origin_cut, jet_count, radial_cells,
              angles, source_options, tail_power=4, precision=96):
    with ctx.workprec(precision):
        c,h,s=real(c),complex_ball(h),complex_ball(s)
        U=h.real
        R,delta=real(cutoff),real(origin_cut)
        if not (0<delta<1 and R>=1 and U>-1 and c>0):
            raise ValueError("require c>0, Re h>-1, 0<origin_cut<1<=cutoff")
        if jet_count<1 or radial_cells<1 or angles<1:
            raise ValueError("counts must be positive")
        bounds_for_tilt(s)
        if h==0:
            direct=source(c,s,0,0,**source_options)
            z=direct.finite_matrix_value
            a=z.real.rad()+z.imag.rad()
            mid,radius=disk(z,direct.source_determinant_error)
            return MellinResult(mid,radius,arb(0),arb(0),arb(0),arb(0),
                                direct.source_determinant_error,a)
        is_integer=h.imag==0 and h.real.is_integer() and U>=0
        J=int(U.floor().unique_fmpz())+1
        J=max(0,J) if is_integer else max(1,J)
        if jet_count<J:
            raise ValueError("jet_count must exceed the largest retained jet index")
        M0,_,_,_=compact_source(c,s,arb(2),arb(1)/2)
        count=jet_count
        roots=[acb(0,2*arb.pi()*k/count).exp() for k in range(count)]
        jets=[acb(0) for _ in range(J)]
        source_jet=arb(0)
        for p in roots:
            for q in roots:
                v=source(c,s,p,q,**source_options)
                source_jet+=v.source_determinant_error/count**2
                for j in range(J):
                    jets[j]+=v.finite_matrix_value/(p*q)**j/count**2
        mix=(1-arb(2)**-count)**-2-1
        aliases=[(M0/4**j*mix).upper() for j in range(J)]
        if is_integer:
            from math import factorial
            j=J-1
            C=acb(c).pow(-2*h)*((-4)**j*factorial(j)**2)
            approx=C*jets[j]
            alias=abs(C)*aliases[j]
            src=abs(C)*source_jet
            arithmetic=approx.real.rad()+approx.imag.rad()
            mid,radius=disk(approx,alias+src)
            return MellinResult(mid,radius,arb(0),arb(0),alias,arb(0),src,arithmetic)

        gamma=acb(c).pow(-2*h)*acb(2).pow(2*h+1)*(1+h).gamma()*(-h).rgamma()
        weights=[acb(delta).pow(2*j-2*h)/(2*j-2*h) for j in range(J)]
        approximation=sum((a*w for a,w in zip(jets,weights)),acb(0))
        jet_alias=sum((a*abs(w) for a,w in zip(aliases,weights)),arb(0))
        weighted_source=source_jet*sum((abs(w) for w in weights),arb(0))
        MR,_,_,_=compact_source(c,s,(R+1).upper(),arb(1)/2)
        mesh=(R-delta)/radial_cells
        quadrature=arb(0)
        for j in range(radial_cells):
            x=delta+mesh*j
            y=delta+mesh*(j+1)
            rho=(x+y)/2
            exact_weight=(acb(y).pow(-2*h)-acb(x).pow(-2*h))/(-2*h)
            max_weight=max((x**(-2*U-1)).upper(),(y**(-2*U-1)).upper())*mesh
            quadrature+=max_weight*MR*(mesh+2*R*arb.pi()/angles)
            for k in range(angles):
                q=rho*acb(0,2*arb.pi()*(k+arb(1)/2)/angles).exp()
                val=source(c,s,q.conjugate(),q,**source_options)
                approximation+=exact_weight*val.finite_matrix_value/angles
                weighted_source+=abs(exact_weight)*val.source_determinant_error/angles
        origin = M0*delta**(2*J-2*U)/(4**J*(1-delta*delta/4)*(2*J-2*U))
        tail=tail_bound(c,s,h,R,tail_power)
        approximation*=gamma
        factor=abs(gamma)
        extra=factor*(jet_alias+weighted_source+quadrature+origin+tail)
        arithmetic=approximation.real.rad()+approximation.imag.rad()
        mid,radius=disk(approximation,extra)
        return MellinResult(mid,radius,factor*tail,factor*origin,
                            factor*jet_alias,factor*quadrature,
                            factor*weighted_source,arithmetic)
