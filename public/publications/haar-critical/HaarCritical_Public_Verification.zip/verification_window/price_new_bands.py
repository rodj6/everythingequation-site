"""Outwardly price new sharp frequency-band certificates and overlap controls.

The original annulus engine's unrounded midpoint is an exact dyadic. The
analytic source and arithmetic terms quoted by it enclose its internally
rounded values. Reuse the upper ends of those strings. Replace both old
quadrature allowances by the finite-Haar bridge_quad proof.
"""
import json
from pathlib import Path
from flint import arb, acb, ctx
from bridge_quad import INPUT, ROOT, price_quadrature
from annulus import restore
from contour_source import dyadic

HERE = Path(__file__).resolve().parent


def priced(record):
    assert record['input'] == INPUT
    params = record['parameters']
    left, right = map(int, params['range'])
    assert list(map(arb, record['range'])) == [arb(left), arb(right)]
    price = price_quadrature(left, right, params['radial'], params['angular'])
    errors = {k: price[k] for k in ('angular', 'radial', 'bridge')}
    for label in ('source', 'arithmetic'):
        errors[label] = arb(record['breakdown'][label]).upper()
    radius = sum(errors.values(), arb()).upper()
    return dict(left=left,right=right,params=params,center=record['dyadic_midpoint'],
                radius=dyadic(radius),display=radius.str(22),mid_display=record['mid'],
                terms={k:dyadic(v) for k,v in errors.items()},
                term_display={k:v.str(16) for k,v in errors.items()},
                ellipse=[price['ellipse_numerator'],price['ellipse_denominator']],
                angle_strip=[price['strip_numerator'],price['strip_denominator']],
                calls=record['samples'],seconds=record['wall_seconds'],
                old_price=record['radius'])


def overlap():
    ref = ROOT/'verification_depthone/probe4.jsonl'
    weak, strong = [list(map(json.loads, f.read_text().splitlines()))
                    for f in (HERE/'keyhole_pilot_0.jsonl', ref)]
    out=[]
    for x in weak:
        candidates=[y for y in strong if y['frequency']==x['frequency']]
        if not candidates: continue
        y=candidates[0]
        for t in (x,y):
            assert t['config']['angle']=='0' and t['config']['s']==['1/2','1/20'] and t['config']['c']=='1'
        def disk(d):
            return acb(*(restore(a) for a in d['midpoint_dyadic'])),restore(d['radius_dyadic'])
        vx,ex=disk(x); vy,ey=disk(y)
        diff=abs(vx-vy).upper()
        assert diff < ex+ey
        out.append(dict(frequency=x['frequency'],difference_upper=dyadic(diff),
                        precision_pilot=dyadic(ex), inherited_precision=dyadic(ey),
                        pilot_seconds=x['seconds'], reference='verification_depthone/probe4.jsonl',
                        pilot_file='keyhole_pilot_0.jsonl'))
    return out


def main():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('files',nargs='+')
    args=parser.parse_args()
    with ctx.workprec(320):
        rows=[priced(json.loads(Path(f).read_text())) for f in args.files]
        for x,y in zip(rows,rows[1:]): assert x['right']==y['left']
        print(json.dumps(dict(input=INPUT,bands=rows,source_overlap=overlap()),indent=2))

if __name__=='__main__':
    main()
