"""Noncertifying LP search for rational coefficients. No LP output is used without Arb verification."""
from pathlib import Path
import sys,json
from argparse import ArgumentParser
import numpy as np
from scipy import special, integrate, optimize
from scipy.sparse import csr_matrix
from math import pi
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'verification_depthone'
FILES=['annulus_1_2_b_reprice.json','annulus_2_3_b_reprice.json','annulus_3_4_b_reprice.json']+['panel%d%d_reprice.json'%(k,k+1) for k in range(4,8)]
H=.5+.125j
G=2**(2*H+1)*special.gamma(1+H)/special.gamma(-H)
def d(z): return int(z[0])*2.0**int(z[1])
def nums(maxb):
 out=json.loads((ROOT/'verification_microscopic/jet_half_tight.json').read_text())
 mus=[d(x['real']) for x in out['exact_dyadic_disks'].values()]
 rad=[d(json.loads((D/f).read_text())['dyadic_radius']) for f in FILES]
 mus.append(.32815)
 rep=json.loads((ROOT/'verification_window/retained_repriced.json').read_text())
 rad=[d(row['radius']) for row in rep['bands']]
 files=FILES[:]
 edges=list(range(1,9))
 if maxb>8:
  extra=json.loads((ROOT/'verification_window/new_bands_12.json').read_text())['bands']
  for row in extra:
   if row['right']>maxb: break
   assert row['left']==edges[-1]
   files.append('new_bands_12.json#'+str(row['left']))
   rad.append(d(row['radius']));edges.append(row['right'])
 if maxb>=16:
  extra=json.loads((ROOT/'verification_window/window_1216.json').read_text())
  rad.append(d(extra['sharp']['radius']));edges.append(16);files.append('window_1216.json')
 if maxb>=20:
  extra=json.loads((ROOT/'verification_window/window_1620.json').read_text())
  rad.append(d(extra['sharp']['radius']));edges.append(20);files.append('window_1620.json')
 return np.array(mus),np.array(rad),files,np.array(edges)
def fit(R,dest,maxb,node_files):
 mus,rad,files,edges=nums(maxb)
 r=np.unique(np.r_[0,np.linspace(.0001,.25,80),np.linspace(.25,2,481),np.linspace(2,4.5,751)])
 k=edges[:-1]; hi=edges[1:]; widths=hi-k
 norm=(k**(-2*H)-hi**(-2*H))/(2*H)
 # J0 circular averages integrated exactly up to Gaussian nodes in this pilot only
 t,w=special.roots_legendre(60)
 rho=k[:,None]+widths[:,None]*(t+1)/2
 B=np.einsum('kj,nkj->nk',(widths[:,None]*w/2*rho**(-2*H-1))/norm[:,None],special.j0(r[:,None,None]*rho[None,:,:]))
 C=2**(-2*H-1)*special.gamma(-H)/special.gamma(1+H)
 def q(rs):
  out=np.zeros(rs.shape,dtype=complex)
  ii=rs>0
  x=R*rs[ii]
  base=x[0]
  z=C*base**(2*H)+1/(2*H)+base**2/4/(2-2*H)
  fx=integrate.solve_ivp(lambda t,y:(2*H*y-special.j0(t))/t,[base,x[-1]],np.array([z]),t_eval=x,rtol=1e-10,atol=1e-12)
  out[ii]=fx.y[0];out[~ii]=1/(2*H)
  return out
 value=q(r)
 node_list=[];node_prices=[];node_freq=[]
 for f in node_files:
  with open(ROOT / "verification_window" / f) as fp: tab=json.load(fp)
  nr=tab["parameters"]["radial"];na=tab["parameters"]["angular"];lo,high=map(float,tab["parameters"]["band"])
  roots=special.roots_legendre(nr)[0][::-1]
  for i,root in enumerate(roots):
   rho=(lo+high+(high-lo)*root)/2;row=tab["sharp"]["node_means"][i];
   ts=np.arange(1,36)/50;ds=rho*np.sinh(ts)
   price=d(row["source"])+d(row["arithmetic"])+np.min(2*10**.25*np.exp(ds/2+ds*ds/4)/np.expm1(na*ts))
   node_list.append([f,i]);node_prices.append(price);node_freq.append(rho)
 if node_list: B=np.column_stack([B,special.j0(r[:,None]*np.array(node_freq)[None,:])])
 qbasis=np.column_stack([r**(2*j) for j in range(3)]+list(B.T))
 nb=qbasis.shape[1]
 a=np.array([np.exp(-2j*pi*i/16) for i in range(16)])
 guard=1/np.cos(pi/16)
 pp=np.column_stack([np.ones(len(r)),r**2,r**4,r**6])
 # vector = polynomial p, real/imag centered coefficients, bounds |coeff|
 rows=[];rhs=[]
 zeros=np.zeros_like(qbasis.real)
 for phase in a:
  z=guard*phase*qbasis
  rows.append(np.column_stack([-pp,-z.real,z.imag,zeros]))
  rhs.append(-(guard*phase*value).real)
  z=guard*phase*np.eye(nb)
  rows.append(np.column_stack([np.zeros((nb,4)),z.real,-z.imag,-np.eye(nb)]))
  rhs.append(np.zeros(nb))
 # global tail r>=4.5, Taylor basis in (X-x0). J0 shell/small tail bounded by abs-weight integral
 x0=r[-1]**2
 for j,v in enumerate([[1,x0,x0**2,x0**3],[0,1,2*x0,3*x0**2],[0,0,1,3*x0],[0,0,0,1]]):
  for ph in a:
   row=np.zeros(4+3*nb)
   row[:4]=-np.array(v)
   row[4:7]=guard*ph.real*np.array(v[:3])
   row[4+nb:7+nb]=-guard*ph.imag*np.array(v[:3])
   if j==0: row[4+2*nb+3:]=np.r_[(1/k-1/hi)/abs(norm),np.ones(len(node_list))]
   rows.append(row[None,:]);rhs.append(np.array([-.02 if j==0 else 0]))
 scale=abs(G)/R
 penalty=np.r_[rad/(abs(G*norm)),node_prices]
 c=np.r_[mus*10**.1625,np.zeros(2*nb),np.r_[np.array([1e-12,5e-7,0.010]),penalty]]
 res=optimize.linprog(c,A_ub=csr_matrix(np.concatenate(rows)),b_ub=np.concatenate(rhs),bounds=[(None,None)]*(4+3*nb),method='highs')
 assert res.success,res.message
 pp=res.x[:4];qc=res.x[4:4+nb]+1j*res.x[4+nb:4+2*nb]
 def code(x): return str(round(x,7))
 out=dict(R=R,P=[code(x) for x in pp],q=[[code(z.real),code(z.imag)] for z in qc],pilot=float(scale*res.fun),maxr=float(r[-1]),panels=files,edges=list(map(int,edges)),nodes=node_list)
 print(out)
 Path(dest).write_text(json.dumps(out,indent=2))
if __name__=='__main__':
 p=ArgumentParser();p.add_argument('R',type=int);p.add_argument('dest');p.add_argument('--max-band',type=int,default=8);p.add_argument('--nodes',nargs='*',default=[]);a=p.parse_args();fit(a.R,a.dest,a.max_band,a.nodes)
