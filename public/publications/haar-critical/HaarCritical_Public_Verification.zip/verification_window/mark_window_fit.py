"""Floating pilot for spatial approximation of a sharp annulus, never a proof."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.special import j0
from numpy.polynomial.legendre import leggauss

def fit(A,B):
    h=.5+.125j
    angles=np.linspace(0,2*np.pi,64,endpoint=False)
    rad=np.r_[np.linspace(0,1,901),np.linspace(1.001,2,400)]
    pts,w=leggauss(32);v=A+(pts+1)*(B-A)/2
    q=(j0(rad[:,None]*v) @ (w*v**(-2*h-1)))*(B-A)/(2*(1/A-1/B))
    y=rad**2
    mon=np.column_stack((np.ones_like(y),y,y*y))
    mat=np.array([[1.,4,16],[0,1,8],[0,0,1]])
    lhs=[];rhs=[]
    for b in angles:
        c=np.cos(b);s=np.sin(b)
        lhs.extend([np.column_stack((-mon,-c*mon,-s*mon)),np.column_stack((-mat,c*mat,s*mat))])
        rhs.extend([-(q.real*c+q.imag*s+.001),np.array([-1.005,-.006,-.006])])
    cost=np.array([.9423646306,.3212988522,.229092239,0,0,0,0,0,0])
    r=linprog(cost,A_ub=np.vstack(lhs),b_ub=np.concatenate(rhs),bounds=[(None,None)]*9)
    assert r.success
    v=np.round(r.x,3); v[:3]+=[.004,.002,.001]
    return dict(A=A,B=B,p=[f"{t:.3f}" for t in v[:3]],center=[[f"{a:.3f}",f"{b:.3f}"] for a,b in zip(v[3:6],v[6:9])])
if __name__=='__main__':
    import sys
    print(json.dumps(fit(int(sys.argv[1]),int(sys.argv[2])),indent=2))
