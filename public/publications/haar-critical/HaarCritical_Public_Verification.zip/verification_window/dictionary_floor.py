"""A verified obstruction for the fixed collection of band tests used to center a tail.

The constructed functional annihilates the three complex jets and the
listed integrated Fourier bands. Its absolute variation can be included
in a positive measure with all four independently enclosed real moments.
"""
from pathlib import Path
import json
import sys
from flint import arb, acb, acb_mat, ctx

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'verification_depthone'))
from contour_source import R
from annulus import restore

H = acb(R('1/2'), R('1/8'))


def kernel(x, degree=300):
    if x == 0:
        return 1/(2*H)
    w = -x*x/4
    coefficient = arb(1)
    partial = acb(coefficient)/(-2*H)
    for j in range(1,degree):
        coefficient *= w/(j*j)
        partial += coefficient/(2*j-2*H)
    coefficient *= w/(degree*degree)
    ratio = abs(w)/(degree+1)**2
    assert ratio < 1
    err = (abs(coefficient)/((2*degree-1)*(1-ratio))).upper()
    mellin = acb(2)**(-2*H-1)*(-H).gamma()/(1+H).gamma()
    return mellin*acb(x)**(2*H)-partial+acb(arb(0,err),arb(0,err))


def witness(cutoff, bands):
    # Last radius 1, quadratically clustered squared radii close to 0.
    count = 3+len(bands)
    radii = [R(j)/count for j in range(count+1)]
    used = sorted({cutoff} | {k for pair in bands for k in pair})
    q = {k:[kernel(k*r) for r in radii] for k in used}
    tests = [[arb(1) for r in radii], [r*r for r in radii], [r**4 for r in radii]]
    for left,right in bands:
        # Normalizing each band by a nonzero constant leaves its null space unchanged.
        tests.append([acb(left)**(-2*H)*u-acb(right)**(-2*H)*v
                      for u,v in zip(q[left],q[right])])
    matrix = acb_mat([row[1:] for row in tests])
    # Successful Arb solve certifies a unique solution for the exact matrix.
    roots = matrix.solve(acb_mat([[-row[0]] for row in tests]))
    weights=[acb(1)]+[roots[j,0] for j in range(count)]
    total = sum(abs(t) for t in weights)
    separation = abs(sum(t*f for t,f in zip(weights,q[cutoff])))/total
    assert separation.lower() > 0
    eps = R('1/100')
    # We may subtract eps times normalized absolute weights at X <= 1.
    # Verify existence of a positive measure representing the remaining
    # four moments via a two-node positive symmetric multiplication matrix.
    moments=json.loads((HERE.parent/'verification_depthone/real_order_control.json').read_text())
    m=[restore(lo).union(restore(hi)) for lo,hi in moments['moment_dyadics']]
    reduced=[v-arb(0).union(eps) for v in m]
    a,b,c,d = reduced
    assert a > 0 and b > 0 and a*c-b*b>0 and b*d-c*c>0
    shape_floor=eps*separation
    scalar_floor=R('17/16')*shape_floor/cutoff
    return dict(cutoff=cutoff, bands=bands, weight_mass='1/100',
                precision_bits=ctx.prec,
                residual_separation_lower=separation.lower().str(16),
                shape_only_scalar_floor_lower=scalar_floor.lower().str(16),
                annihilated_complex_columns=count,
                hurwitz_minors_lower=[(a*c-b*b).lower().str(12),(b*d-c*c).lower().str(12)],
                scope='Absolute cubic shape majorant priced only by four real moments; polynomial centering degree two and the stated signed tests.')


if __name__=='__main__':
    with ctx.workprec(820):
        rows=[]
        for R0 in (8,9,12,16):
            rows.append(witness(R0, [(k,k+1) for k in range(1,8)]))
        rows.append(witness(16, [(k,k+1) for k in range(1,16)]))
        print(json.dumps(rows,indent=2))
