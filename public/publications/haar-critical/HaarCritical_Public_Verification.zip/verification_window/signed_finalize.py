"""Test exact shape margins and fixed ranks against a finite predeclared grid, then retain the smallest rigorous tail."""
from pathlib import Path
from copy import deepcopy
import sys,json,time
from flint import ctx
from signed_shapes import HERE, run
from annulus import restore
SETTINGS=[(56,16),(57,17),(58,18),(59,18),(60,19),(61,20),(62,21),(63,21),(64,22),(65,23)]
def best(name):
 start=time.monotonic()
 source=json.loads((HERE/name).read_text())
 shape_cache={};rows=[];failed=[]
 for slack in ('0.000006','0.000015','0.00004','0.00010','0.00018','0.00025','0.00040','0.00080','0.00160'):
  candidate=dict(source,slack=slack)
  try:
   first=run(candidate,shape_cache)
  except AssertionError as error:
   failed.append(dict(slack=slack,first_error=str(error)[:850]));continue
  rows.append(first);break
 if not rows:
  raise AssertionError((name,failed))
 for g,m in SETTINGS[1:]:
  rows.append(run(dict(candidate,rank_exponent=g,frequency_M=2**m),shape_cache))
 out=min(rows,key=lambda row:restore(row['tail_radius_dyadic']))
 out['candidate_file']=name
 out['failed_shape_slacks']=failed
 out['rank_search']=[dict(rank=r['rank'],M=r['frequency_M'],radius=r['tail_radius_dyadic']) for r in rows]
 out['all_settings_seconds']=time.monotonic()-start
 return out
if __name__=='__main__':
 with ctx.workprec(256):
  print(json.dumps([best(name) for name in sys.argv[1:]],indent=2))
