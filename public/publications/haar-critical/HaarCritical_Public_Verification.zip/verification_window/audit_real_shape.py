"""Validate a Bessel-polynomial positive majorant using actual real Haar source data."""
import argparse,json,sys,time
from pathlib import Path
from math import factorial
from flint import arb,acb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'verification_depthone'))
from analytic_bridge import a,constants,budget
from bessel_bridge import finite_real_moments
from contour_source import dyadic
from annulus import restore
from bridge_quad import INPUT


def certify(data):
    started=time.monotonic()
    R=a(data['R']); end=a(data['rmax'])
    h=acb(a('1/2'),a('1/8'))
    q0=acb(*map(a,data['center']))
    coeff=list(map(a,data['coeff']))
    p0,p1,p2=coeff[:3]
    bump='0.00004'; quartic='0.0001' if len(coeff)>8 else '0'
    p0+=a(bump);p1+=a('0.0000001');p2+=a(quartic)
    ks=list(map(a,data['positive_frequencies']));bs=coeff[3:]
    assert len(ks)==len(bs)
    Jmax=a('1.25')
    y=a(2); sq=y.sqrt()
    f=sq*y.bessel_j(0); fp=y.bessel_j(0)/(2*sq)-sq*y.bessel_j(1)
    # f''+[1+1/(4x²)]f=0; f'^2+[1+1/(4x²)]f² is nonincreasing.
    assert fp**2+(1+1/(4*y*y))*f*f<Jmax**2
    g=sq*y.bessel_j(1); gp=sq*y.bessel_j(0)-y.bessel_j(1)/(2*sq)
    assert (g*g+gp*gp/(1-3/(4*y*y))).sqrt()*(1+abs(2*h+2)/(2*h.real+a('3/2')))<3
    large_allow=abs(q0)+3/(end*R)**a('3/2')+sum(abs(z)*Jmax/(k*end).sqrt() for k,z in zip(ks,bs))
    assert p0+p1*end**2+p2*end**4>large_allow and p1+2*p2*end**2>=0 and p2>=0
    # Validated power series for Q_h(Rr), including its singular fractional power.
    order=int(2*int(data['R'])*data['rmax']+45)
    cf=acb(2)**(-2*h-1)*(-h).gamma()/(1+h).gamma()*acb(R)**(2*h)
    terms=[];t=arb(1)
    for j in range(order):
        terms.append(-t/(2*j-2*h))
        t*=(-R*R)/(4*(j+1)**2)
    lim=(R*end)**2/4
    ratio=lim/(order+1)**2
    assert ratio<1
    rem=(abs(t)*end**(2*order)/((2*order-2*h.real)*(1-ratio))).upper()
    assert rem<a('1e-35'),rem
    def point(r):
        p=p0+r*r*(p1+r*r*p2)+sum(v*(k*r).bessel_j(0) for k,v in zip(ks,bs))
        q=terms[-1]
        for term in reversed(terms[:-1]):
            q=q*r*r+term
        if r!=0: q+=cf*acb(r)**(2*h)
        return (p-abs(q-q0)-rem).lower()
    tiny=a('1e-8'); w=(R*tiny)**2/4
    curvatureJ=sum(abs(z)*k*k/2 for z,k in zip(bs,ks))
    small_error=abs(cf)*tiny+w/((2-2*h.real)*(1-w/4))+(curvatureJ/2+abs(p1))*tiny*tiny+abs(p2)*tiny**4
    assert point(arb(0))>small_error
    pending=[(tiny,end,point(tiny),point(end))]
    n=0; gap=arb(1)
    while pending:
        lo,hi,x,yval=pending.pop()
        assert min(x,yval)>0,(str(lo),str(hi),str(x),str(yval))
        c=abs(2*h-1)*(abs(2*h)+1)/lo**2 + R/lo + curvatureJ + 2*abs(p1)+12*abs(p2)*hi**2
        z=(min(x,yval)-c*(hi-lo)**2/8).lower()
        if z>0:
            gap=min(gap,z);n+=1
        else:
            mid=(lo+hi)/2; zv=point(mid)
            assert hi-lo>a('1e-14')
            pending.extend([(lo,mid,x,zv),(mid,hi,zv,yval)])
    raw=json.loads((HERE/'audit_real_samples.json').read_text())
    assert raw['depth']==1 and raw['s']==['1/2','0']
    rank=a(10)**raw['rank_log10']; M=a(2)**16
    _,C,nu,K,_,floor=constants(); P=4*a('387/500')
    assert rank>floor*(M+2)**(4/(1+a('1/4')**2)) and 2<=M
    mr,_,_=finite_real_moments(rank,HERE.parent/'verification_microscopic/jet_half_tight.json')
    mean=p0*mr[0]+p1*mr[1]+p2*mr[2]
    esamp=arb()
    used=[]
    files=data.get('sample_files',['audit_real_samples.json']*len(bs))
    for freq,b,name in zip(data['positive_frequencies'],bs,files,strict=True):
        sr=json.loads((HERE/name).read_text())
        assert sr['rank_log10']==raw['rank_log10'] and sr['depth']==1 and sr['s']==['1/2','0']
        row,=[v for v in sr['samples'] if v['r']==freq]
        mid=restore(row['real']);err=restore(row['limiting_error'])+restore(row['finite_discrepancy'])
        mean+=b*mid
        esamp+=abs(b)*err
        used.append(dict(k=freq,file=name,coefficient=str(b),limiting_error=row['limiting_error']))
    jet=json.loads((HERE.parent/'verification_depthone/jet_complex_precision.json').read_text())['exact_dyadic_disks']['0']
    cm=acb(restore(jet['real']),restore(jet['imag']))
    merror=restore(jet['radius'])+K*2**P/rank**nu
    pref=acb(2)**(2*h+1)*(1+h).gamma()*(-h).rgamma()
    T=pref*acb(R)**(-2*h); mid=T*q0*cm
    var=rank**a('1/400')
    errors={'shape_center_expectation':(abs(T)*var*mean).upper(),
            'real_samples_errors':(abs(T)*var*esamp).upper(),
            'complex_mass_error':(abs(T*q0)*merror).upper(),
            'continuous_bridge':(abs(pref)*K*(1+2/R)**P*M**(P-1)/((P-1)*rank**nu)).upper(),
            'finite_past_M':(abs(pref)*var*mr[0]/M).upper(),
            'limit_past_M':budget(M,arithmetic=True),
            'arithmetic':abs(mid-mid.mid()).upper()}
    radius=sum(errors.values(),arb()).upper()
    z=mid.mid()
    return dict(input=INPUT,kind='tail',R=data['R'],B=data['R'],h=['1/2','1/8'],tilt=['1/2','1/20'],
                real_sample_file='audit_real_samples.json',positive_sample_controls=used,
                finite_rank_log10=raw['rank_log10'],band_limit=65536,source_calls_for_shape=0,
                verified_shape_panels=n,min_margin=str(gap),series_rem=str(rem),
                proof_slack=[bump,'0.0000001',quartic],bits=ctx.prec,
                tail_centre_dyadic=[dyadic(z.real),dyadic(z.imag)],tail_radius_dyadic=dyadic(radius),
                tail_radius=radius.str(18),tail_center=[z.real.str(18),z.imag.str(18)],
                terms={k:dyadic(v) for k,v in errors.items()},
                term_display={k:v.str(16) for k,v in errors.items()},seconds=time.monotonic()-started)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('files',nargs='+',type=Path)
    args=parser.parse_args()
    with ctx.workprec(384):
        print(json.dumps([certify(json.loads(path.read_text())) for path in args.files],indent=2))
