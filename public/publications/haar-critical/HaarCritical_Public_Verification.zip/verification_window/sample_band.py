"""Compute and retain reusable keyhole angular samples for a depth-one shell.

This single grid returns both a sharp and a quintic tapered Mellin integral.
Band arithmetics and both sets of weights use complex/real Arb balls. At a
poorly conditioned sample we can replace its enclosure by the independent
physical-rank disk about zero. No unvalidated source is used.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor
import json
import multiprocessing
from pathlib import Path
from time import monotonic

from flint import arb, acb, ctx
from bridge_quad import INPUT, price_quadrature
from contour_source import Keyhole, R, C, dyadic
from annulus import restore


def raw_point(node):
    i,j=node
    rho=RADII[i]
    p=rho*acb(0,2*arb.pi()*j/CFG.angular).exp()
    s=SOURCE(p,p.conjugate())
    disk=(s.analytic+s.numerical).upper()
    fallback=not disk < PHYSICAL_CAP
    if fallback:
        center=(arb(),arb()); analytic=PHYSICAL_CAP; arithmetic=arb()
    else:
        center=(s.mid.real,s.mid.imag); analytic=s.analytic; arithmetic=s.numerical
    return dict(radial=i,angle=j,center=list(map(dyadic,center)),analytic=dyadic(analytic),arithmetic=dyadic(arithmetic),
                line_tail=dyadic(s.contour_tail),contour_gauss=dyadic(s.contour_quad),
                projection=dyadic(s.projection),fallback=fallback,seconds=s.elapsed)


def price_taper_radial(a,b,nrad):
    width=b-a
    choices=[]
    for j in range(5,161):
        e=R(j)/4
        left=(a+b)/2-width*(e+1/e)/4
        if not left>0: continue
        height=width*(e-1/e)/4
        # |t| on the transformed ellipse is bounded by 1/2 + (e+1/e)/4.
        t=R("1/2")+(e+1/e)/4
        size=1+10*t**3+15*t**4+6*t**5
        env=(R(10)**R("1/4"))*(height/2+height**2/4).exp()
        basic=4*R("17/16")*width*env*(arb.pi()/8).exp()/left**2
        choices.append(((basic*size*e**(-2*nrad)/(1-1/e)).upper(),j))
    return min(choices,key=lambda p:p[0])


def reduce_grid(c,rows,radial,weights,charges,taper,complement=False):
    a,b=map(R,c.band)
    h=C(("1/2","1/8"))
    pref=acb(2)**(2*h+1)*(1+h).gamma()*(-h).rgamma()
    val=acb(); ea=arb(); en=arb(); angular_means=[]
    for i,(rho,gwt) in enumerate(zip(radial,weights)):
        vals=rows[i*(c.angular//2+1):(i+1)*(c.angular//2+1)]
        av=acb(); ae=arb(); ne=arb()
        for j,row in enumerate(vals):
            assert (row['radial'],row['angle'])==(i,j)
            weight=R(1 if j in (0,c.angular//2) else 2)/c.angular
            x,y=map(restore,row['center'])
            av+=weight*acb(x,y); ae+=weight*restore(row['analytic']); ne+=weight*restore(row['arithmetic'])
        m=av.mid(); ne+=(av-m).abs_upper()
        t=(rho-a)/(b-a); wt=gwt*acb(rho)**(-2*h-1)
        if taper:
            rise=t**3*(10+t*(-15+6*t))
            wt*=rise if complement else 1-rise
        val+=wt*m; ea+=wt.abs_upper()*ae; en+=wt.abs_upper()*ne
        angular_means.append(dict(midpoint=list(map(dyadic,(m.real,m.imag))),source=dyadic(ae.upper()),arithmetic=dyadic(ne.upper())))
    val*=pref; center=val.mid()
    radial_cost,ellipse=price_taper_radial(a,b,c.radial) if taper else (charges['radial'],charges['ellipse_numerator'])
    error=dict(source=(pref.abs_upper()*ea).upper(),arithmetic=((val-center).abs_upper()+pref.abs_upper()*en).upper(),
               bridge=charges['bridge'],angular=charges['angular'],radial=radial_cost)
    total=sum(error.values(),arb()).upper()
    return dict(center=list(map(dyadic,(center.real,center.imag))),radius=dyadic(total),
                mid_display=[center.real.str(18),center.imag.str(18)],display=total.str(22),
                terms={k:dyadic(x) for k,x in error.items()},term_display={k:x.str(16) for k,x in error.items()},
                ellipse=[ellipse,4], angle_strip=[charges['strip_numerator'],charges['strip_denominator']],
                node_means=angular_means)


def main():
    global SOURCE,RADII,CFG,PHYSICAL_CAP
    p=argparse.ArgumentParser()
    p.add_argument('--band',nargs=2,required=True);p.add_argument('--radial',type=int,required=True)
    p.add_argument('--angular',type=int,required=True);p.add_argument('--bits',type=int,required=True)
    p.add_argument('--project',type=int,required=True);p.add_argument('--order',type=int,required=True)
    p.add_argument('--extent',required=True);p.add_argument('--scale',required=True)
    p.add_argument('--cpu',type=int,default=4)
    c=p.parse_args()
    assert c.angular%2==0
    CFG=c
    with ctx.workprec(c.bits):
        start=monotonic(); a,b=map(R,c.band)
        charges=price_quadrature(a,b,c.radial,c.angular)
        PHYSICAL_CAP=(R(10)**R("1/4")+charges['rank_discrepancy']).upper()
        SOURCE=Keyhole(1,('1/2','1/20'),c.extent,n=c.order,project=c.project,laguerre=c.scale)
        RADII=[]; weights=[]
        for i in range(c.radial):
            t,w=arb.legendre_p_root(c.radial,i,weight=True)
            RADII.append((a+b+(b-a)*t)/2); weights.append((b-a)*w/2)
        locs=[(i,j) for i in range(c.radial) for j in range(c.angular//2+1)]
        if c.cpu>1:
            with ProcessPoolExecutor(max_workers=c.cpu,mp_context=multiprocessing.get_context("fork")) as pool:
                rows=list(pool.map(raw_point,locs))
        else: rows=list(map(raw_point,locs))
        sharp=reduce_grid(c,rows,RADII,weights,charges,False)
        smooth=reduce_grid(c,rows,RADII,weights,charges,True)
        print(json.dumps(dict(input=INPUT,parameters=vars(c),sharp=sharp,quintic=smooth,
                samples=rows,count=len(rows),physical_cap=dyadic(PHYSICAL_CAP),fallback=sum(d['fallback'] for d in rows),seconds=monotonic()-start)))

if __name__=='__main__':
    main()
