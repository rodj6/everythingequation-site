"""Independent signed-weight audit: recompute Mellin multipliers in Arb, check shared disks by rational rectangle bounds."""
from pathlib import Path
import json
from fractions import Fraction as F
from flint import arb,acb,ctx,fmpq
BASE=Path(__file__).resolve().parent
PRE=BASE.parent/'verification_depthone'
def read(p):return json.loads(p.read_text())
def d(x):return F(int(x[0]))*F(2)**int(x[1])
def component(x):return F(str(x).strip('[]').split(' +/- ')[0])
def interval(s):
    z=s.strip('[]').split(' +/- ')
    w=F(z[0]);e=F(z[1]) if len(z)==2 else F(0)
    assert e>=0 and len(z)<=2
    return w-e,w+e
def exact_arb(x):
    a=F(x);return arb(fmpq(a.numerator,a.denominator))
def floor192(x):return F((x.numerator<<192)//x.denominator,1<<192)
def corners(s):
    a,b=interval(s[0]);c,e=interval(s[1])
    return [(x,y) for x in [a,b] for y in [c,e]]
def disk(x,c='center',r='radius'):return tuple(map(d,x[c])),d(x[r])
def mul(z,w):return (z[0]*w[0]-z[1]*w[1],z[1]*w[0]+z[0]*w[1])
def check():
    shared=read(BASE/'shared_disks.json'); ordinary=read(BASE/'final_disks.json')
    tails=read(BASE/ordinary['tail_source'])
    prefix=read(BASE/'retained_repriced.json')
    original={}
    sharp={}
    expect=['c=1','h=1/2+i/8','s=1/2+i/20']
    assert shared['input']==ordinary['input']==prefix['input']==expect
    for j,row in enumerate(prefix['bands']):
        src=read(PRE/row['file']);assert src['input']==expect
        b,t=map(int,src['parameters']['range']);assert (b,t)==(j+1,j+2)
        z,_=disk(src,'dyadic_midpoint','dyadic_radius')
        sharp[b,t]=z,d(row['radius']);original[row['file']]=((b,t),z)
    units=read(BASE/'new_bands_12.json')
    for r in units['bands']:
        b=r['left'];t=r['right'];z,e=disk(r)
        sharp[b,t]=z,e;original['new_bands_12.json#'+str(b)]=((b,t),z)
    for name in ['window_89_mean.json','window_1216_mean.json','window_1620_mean.json']:
        row=read(BASE/name);assert row['input']==expect
        b,t=map(int,row['parameters']['band'])
        sharp[b,t]=disk(row['sharp'])
    oz,oe=disk(read(BASE/'audit_origin.json'),'midpoint_dyadic','radius_dyadic')
    out={}
    h=acb(arb(1)/2,arb(1)/8)
    for t in tails:
        n=t['R']; row=shared['refined'][str(n)]; src=read(BASE/t['candidate_file'])
        assert src['R']==n and t['input']==expect
        assert len(src['edges'])-1==len(src['panels'])==len(t['signed_controls'])==len(row['bands'])
        charges={k:d(v) for k,v in t['exact_charges'].items()}; extra=d(t['tail_radius_dyadic'])-sum(charges.values());assert extra>=0
        keep=extra+sum(v for k,v in charges.items() if k!='control_source_enclosures')
        assert keep==d(row['tail_terms_kept'])
        z=tuple(x+d(y) for x,y in zip(oz,t['tail_centre_dyadic']));ee=oe+keep
        last=1
        for j,r in enumerate(row['bands']):
            a,b=r['band']; assert a==last and src['edges'][j:j+2]==[a,b];last=b
            loc=src['panels'][j]
            if loc not in original:
                tmp=read(BASE/loc); assert tmp['input']==expect
                original[loc]=(tuple(map(int,tmp['parameters']['band'])),disk(tmp['sharp'])[0])
            assert original[loc][0]==(a,b)
            old=original[loc][1]; m,e=sharp[a,b]
            beta=acb(*map(exact_arb,src['q'][3+j]))
            ratio=acb(2)*h*(acb(n)**(-2*h))*beta/((acb(a)**(-2*h))-(acb(b)**(-2*h)))
            printed=t['signed_controls'][j]['total_multiplier']
            for s,c in zip(printed,[ratio.real,ratio.imag]):
                l,u=interval(s); assert exact_arb(l)<=c and c<=exact_arb(u),(s,c)
            c=tuple(floor192(component(w)) for w in printed)
            md=tuple(x-y for x,y in zip(m,old))
            correction=mul(c,md)
            z=tuple(x+y+v for x,y,v in zip(z,m,correction))
            cp=d(r['combined_charge']);ce=d(r['midpoint_replacement_charge']);assert cp>=0 and ce>=0
            # Directly bound maxima at the four rectangle corners without using the primary complex-norm routine.
            assert cp**2>=e**2*max((1+x)**2+y*y for x,y in corners(printed))
            assert ce**2>=sum(x*x for x in md)*max((x-c[0])**2+(y-c[1])**2 for x,y in corners(printed))
            ee+=cp+ce
        assert last==n
        alias,er=disk(row); assert alias==z and er==ee
        low=d(row['modulus_lower']);rel=d(row['relative_upper'])
        assert low>0 and sum(x*x for x in z)>=(low+ee)**2 and rel*low>=ee
        out[str(n)]=dict(multiplier_rechecks=len(row['bands']),real_and_imag_trapped=True,
                          corner_charge_inequalities=True,exact_center_and_radius=True,strict_lower_modulus=True)
    return dict(source='shared_disks.json',tail_source=ordinary['tail_source'],checks=out)
if __name__=='__main__':
    with ctx.workprec(510):print(json.dumps(check(),indent=2))
