"""Check final_disks.json by alignment to a common integer grid. No assembly imports."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'verification_depthone'
def read(p):return json.loads(p.read_text())

def audit():
    final=read(HERE/'final_disks.json')
    expected=['c=1','h=1/2+i/8','s=1/2+i/20']
    assert final['input']==expected
    lower=read(HERE/'audit_origin.json')
    assert lower['input']==expected
    prefix=[(lower['midpoint_dyadic'],lower['radius_dyadic'])]
    repriced=read(HERE/'retained_repriced.json')
    assert repriced['input']==expected
    for n,row in enumerate(repriced['bands'],1):
        src=read(OLD/row['file'])
        assert src['input']==expected and list(map(int,src['parameters']['range']))==[n,n+1]
        prefix.append((src['dyadic_midpoint'],row['radius']))
    tail=read(HERE/final['tail_source'])
    rows={str(t['R']):t for t in tail}
    bands=read(HERE/'new_bands_12.json')
    assert bands['input']==expected
    for f in final['projective_bands']:
        if f['file']=='new_bands_12.json':
            b,=[row for row in bands['bands'] if row['left']==f['left'] and row['right']==f['right']]
        else:
            raw=read(HERE/f['file'])
            assert raw['input']==expected and list(map(int,raw['parameters']['band']))==[f['left'],f['right']]
            b=raw['sharp']
        f['native_center']=b['center']; f['native_radius']=b['radius']
        assert b['radius']==f['charge']
    report={}
    for cutoff in final['refined']:
        c=int(cutoff)
        t=rows[cutoff]; assert t['input']==expected
        d=prefix.copy()
        last=8
        for row in final['projective_bands']:
            if row['right']>c:break
            assert row['left']==last
            d.append((row['native_center'],row['native_radius'])); last=row['right']
        assert last==c
        d.append((t['tail_centre_dyadic'],t['tail_radius_dyadic']))
        actual=final['refined'][cutoff]
        mod=actual['modulus_lower'];rel=actual['relative_upper']
        keys=[p for z,e in d for p in (*z,e)]+actual['center']+[actual['radius'],mod,rel]
        base=min(int(key[1]) for key in keys); assert base<0
        def units(p):return int(p[0]) << (int(p[1])-base)
        scale=1 << (-base)
        x,y=[sum(units(z[i]) for z,e in d) for i in (0,1)]
        r=sum(units(e) for z,e in d)
        assert [x,y]==[units(z) for z in actual['center']]
        assert r==units(actual['radius'])
        ell=units(mod); ratio=units(rel)
        assert ell>0 and x*x+y*y>=(ell+r)**2 and r*scale<=ratio*ell
        report[cutoff]=dict(input_disk_count=len(d),common_binary_exponent=base,
                            integer_center_equality=True,integer_radius_equality=True,
                            integer_modulus_and_relative_inequalities=True)
    assert final['best']==final['refined'][str(final['best']['cutoff'])]
    return dict(checked='final_disks.json',compared_against=final['tail_source'],rows=report)
if __name__=='__main__':print(json.dumps(audit(),indent=2))
