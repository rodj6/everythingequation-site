"""Optional floating LP shortlist for real-transform shape certificates."""
import json, sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import j0, gamma
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
def delta(a):
    return np.inf if int(a[1]) > 700 else int(a[0])*2.**a[1]
def fit(R,rmax=5,expanded=False):
    names=['audit_real_samples.json']+(['audit_real_samples_expanded.json'] if expanded else [])
    lookup={}
    for name in names:
        raw=json.loads((HERE/name).read_text())
        for a in raw['samples']:
            k=a['r'];e=delta(a['limiting_error'])
            if e<0.2 and (k not in lookup or e<delta(lookup[k]['limiting_error'])):
                lookup[k]=dict(file=name,**a)
    samples=[lookup[k] for k in sorted(lookup)]
    r=np.unique(np.r_[np.linspace(0,.4,650),np.linspace(.4,2,1200),np.linspace(2,rmax,600)])
    u=np.array([a['r'] for a in samples])
    J=j0(r[:,None]*u[None,:]); m=len(u)
    h=.5+.125j; C=2**(-2*h-1)*gamma(-h)/gamma(1+h)
    x0=1e-4
    z0=C*x0**(2*h)+1/(2*h)+x0*x0/4/(2-2*h)
    ode=solve_ivp(lambda t,y:(2*h*y-j0(t))/t,[x0,rmax*R],[z0],rtol=3e-12,atol=3e-13,dense_output=True)
    X=r*r
    y=ode.sol(R*r[1:])[0]
    y=np.r_[1/(2*h),y]
    # P=p0+p1*x+p2*x^2 + sum b_j J0(k_j r);
    # use signed centre q0 so spatial uniform component can be paid exactly.
    pbase=np.c_[np.ones_like(r),X,X*X,J]
    # unknown p(3+m), |b| (m), Re q0, Im q0
    rows=[];rhs=[]
    for theta in np.linspace(0,2*np.pi,16,endpoint=False):
        phase=np.exp(1j*theta)/np.cos(np.pi/16)
        rows.append(np.c_[-pbase,np.zeros((len(r),m)),np.full(len(r),-phase.real),np.full(len(r),phase.imag)])
        rhs.append(-(y*phase).real)
    for j in range(m):
        for sign in (-1,1):
            v=np.zeros(3+2*m+2);v[3+j]=sign;v[3+m+j]=-1
            rows.append(v[None,:]);rhs.append(np.array([0]))
    # To the right use |J0|<=1 or the improved energy bound <1.25/sqrt(f*rmax).
    # Final Arb proof checks this using a direct Bessel energy inequality.
    for theta in np.linspace(0,2*np.pi,16,endpoint=False):
        phase=np.exp(1j*theta)/np.cos(np.pi/16)
        v=np.r_[[-1,-rmax**2,-rmax**4],np.zeros(m),1.25/np.sqrt(u*rmax),phase.real,-phase.imag]
        rows.append(v[None,:]);rhs.append(np.array([-3/(R*rmax)**1.5]))
    v=np.r_[[0,-1,-2*rmax*rmax],np.zeros(2*m+2)];rows.append(v[None,:]);rhs.append(np.array([0]))
    mu=np.array([delta(a['real']) for a in samples])
    eps=np.array([delta(a['limiting_error']) for a in samples])
    cost=np.r_[[.9423646306,.3212988522,.229092239],mu,eps,[0,0]]
    bu=[(None,None),(None,None),(1e-7,None)]+[(None,None)]*m+[(0,None)]*m+[(None,None)]*2
    opt=linprog(cost,A_ub=np.vstack(rows),b_ub=np.concatenate(rhs),bounds=bu,method='highs')
    assert opt.success,opt.message
    p=opt.x[:3+m]
    return dict(R=R,positive_frequencies=u.tolist(),sample_files=[v['file'] for v in samples],coeff=[f'{x:.10f}' for x in p],
                center=[f'{x:.10f}' for x in opt.x[-2:]],rmax=rmax,
                predicted_shape=opt.fun*1.0625*10**.14/R)
if __name__=='__main__':
    result=fit(int(sys.argv[1]),expanded='--expanded' in sys.argv[2:])
    print(json.dumps(result,indent=2))
