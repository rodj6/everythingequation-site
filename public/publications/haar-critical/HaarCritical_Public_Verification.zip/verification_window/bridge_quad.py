"""Validated quadrature on a positive depth-one band via a single Haar rank."""
import json
import sys
from pathlib import Path
from flint import arb, ctx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "verification_depthone"))
from analytic_bridge import constants
from contour_source import R, dyadic
from annulus import restore

INPUT = ["c=1", "h=1/2+i/8", "s=1/2+i/20"]
RECEIPTS = [
    "annulus_1_2_b_reprice.json", "annulus_2_3_b_reprice.json",
    "annulus_3_4_b_reprice.json", "panel45_reprice.json",
    "panel56_reprice.json", "panel67_reprice.json", "panel78_reprice.json",
]


def price_quadrature(left, right, nrad, nang):
    """All three charges include the Mellin modulus. No limiting strip needed."""
    a, b = R(left), R(right)
    width = b-a
    assert a > 0 and width > 0 and nrad >= 1 and nang >= 2
    rank = R(10)**100
    _, constant, decay, telescope, _, _ = constants()
    assert 2*constant*(2+b)**4/rank < 2*(2*rank)**R("1/16")
    delta = telescope*(2+b)**(4*R("387/500"))/rank**decay
    mass = rank**R("1/400")
    mellin = R("17/16")
    weight_sum = R(0)
    for index in range(nrad):
        node, weight = arb.legendre_p_root(nrad, index, weight=True)
        radius = (a+b+width*node)/2
        weight_sum += width*weight/(2*radius**2)
    bridge = (mellin*delta*(1/a-1/b+weight_sum)).upper()

    # Finite-rank exponential moments on the whole translated plane.
    def envelope(depth):
        return mass*(depth/2+depth**2/4).exp()

    alias_options = []
    for step in range(1, 81):
        shift = R(step)/20
        strip_bound = envelope(b*shift.sinh())
        price = 2*mellin*weight_sum*strip_bound/(nang*shift).expm1()
        alias_options.append((price.upper(), step))
    angular, best_step = min(alias_options, key=lambda entry: entry[0])

    radial_options = []
    for numerator in range(5, 161):
        parameter = R(numerator)/4
        leftmost = (a+b)/2-width*(parameter+1/parameter)/4
        if not leftmost > 0:
            continue
        height = width*(parameter-1/parameter)/4
        # Positive real part gives |arg z| <= pi/2.
        bound = envelope(height)*(arb.pi()/8).exp()/leftmost**2
        price = 4*mellin*width*bound*parameter**(-2*nrad)/(1-1/parameter)
        radial_options.append((price.upper(), numerator))
    if not radial_options:
        raise ValueError("no admissible ellipse on the preselected grid")
    radial, best_parameter = min(radial_options, key=lambda entry: entry[0])
    return dict(radial=radial, angular=angular, bridge=bridge,
                ellipse_numerator=best_parameter, ellipse_denominator=4,
                strip_numerator=best_step, strip_denominator=20,
                rank_exponent=100, rank_discrepancy=delta.upper())


def main():
    directory = ROOT / "verification_depthone"
    origin = json.loads((ROOT/"verification_window"/"audit_origin.json").read_text())
    assert origin["input"] == INPUT
    total = restore(origin["radius_dyadic"])
    cx, cy = map(restore, origin["midpoint_dyadic"])
    rows = []
    for index, name in enumerate(RECEIPTS, start=1):
        old = json.loads((directory/name).read_text())
        assert old["input"] == INPUT
        p = old["parameters"]
        assert tuple(map(int, p["range"])) == (index, index+1)
        cx += restore(old["dyadic_midpoint"][0])
        cy += restore(old["dyadic_midpoint"][1])
        price = price_quadrature(*p["range"], p["radial"], p["angular"])
        hs = arb(old["breakdown"]["source"]).upper()
        arithmetic = arb(old["breakdown"]["arithmetic"]).upper()
        radius = (hs+arithmetic+price["angular"]+price["radial"]+price["bridge"]).upper()
        assert radius < restore(old["dyadic_radius"])
        total += radius
        rows.append(dict(file=name, inherited_radius=old["dyadic_radius"],
                         radius=dyadic(radius), source=dyadic(hs),
                         arithmetic=dyadic(arithmetic),
                         quadrature={k:(dyadic(v) if isinstance(v,arb) else v)
                                     for k,v in price.items()}))
    m1, m2 = cx.mid(), cy.mid()
    total = (total+(cx-m1).abs_upper()+(cy-m2).abs_upper()).upper()
    return dict(input=INPUT, cutoff=8, comparison_rank="10^100",
                center=[dyadic(m1),dyadic(m2)], radius=dyadic(total),
                radius_display=total.str(22), bands=rows,
                origin_file="verification_window/audit_origin.json", new_source_calls=0)


if __name__ == "__main__":
    with ctx.workprec(240):
        print(json.dumps(main(),indent=2))
