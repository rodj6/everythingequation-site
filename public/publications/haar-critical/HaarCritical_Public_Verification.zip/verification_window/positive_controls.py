"""Independent rational readouts for two positive depth-one controls.

Run from any directory with Python 3.8+.  The noninteger check starts from
the inherited outward real source moments; it does not recompute the jets.
"""
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import factorial, isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BITS = 120

def value(item):
    return Q(int(item[0])) * Q(2) ** item[1]

def dyadic_bounds(q, bits=BITS):
    scale = 1 << bits
    num = q.numerator * scale
    den = q.denominator
    return [[str(num // den), -bits], [str(-(-num // den)), -bits]]

def upper(q):
    return dyadic_bounds(q)[1]

def lower_sqrt(q):
    scale = 1 << BITS
    n = isqrt((q.numerator * scale**2) // q.denominator)
    r = Q(n, scale)
    assert r*r <= q < (r + Q(1, scale))**2
    return [str(n), -BITS]

def mul(f, g):
    ans = [Q(0)] * (len(f) + len(g) - 1)
    for j, v in enumerate(f):
        for k, w in enumerate(g):
            ans[j + k] += v*w
    return ans

def cited(f):
    return {"file": str(f.relative_to(ROOT)), "sha256": sha256(f.read_bytes()).hexdigest()}

def schur():
    # Integral of t^2 exp(-t) on [0,1].  Diminishing alternating terms
    # bound the signed truncation. A separate exponential sum evaluates 2-5/e.
    precision_order = 63
    degree = precision_order
    il = sum(Q((-1)**n, factorial(n)*(3+n)) for n in range(degree+1))
    iu = il + Q(1, factorial(degree+1)*(4+degree))
    el = sum(Q((-1)**n, factorial(n)) for n in range(degree+1))
    eu = el + Q(1, factorial(degree+1))
    lo, hi = max(il, 2-5*eu), min(iu, 2-5*el)
    assert lo <= hi
    src = ROOT / 'verification_depthone/independent_controls.jsonl'
    receipts = [json.loads(x) for x in src.read_text().splitlines()]
    z = next(x for x in receipts if 'integer_schur' in x)['exact_dyadic_disks']['1']
    m, im, r = (value(z[k]) for k in ('real', 'imag', 'radius'))
    assert im == 0 and max(abs(lo-m), abs(hi-m)) < r
    return {"input": {"c": 1, "h": 1, "s": 1},
            "exact_value": "2 - 5/e", "max_series_degree": degree+1,
            "integral_interval_dyadic": [dyadic_bounds(lo)[0], upper(hi)],
            "inherited_fredholm_disk_contains_entire_interval": True,
            "source": cited(src)}

def real_half():
    src = ROOT / 'verification_depthone/real_order_control.json'
    old = json.loads(src.read_text())
    moment = [[value(k) for k in row] for row in old["moment_dyadics"]]
    a, b = Q(253, 500), Q(271, 200)
    d = 2*a*b*(a+b)**3
    polynomial = [a*a*b*b*(a*a+3*a*b+b*b)/d,
                  (a**4+3*a**3*b+7*a*a*b*b+3*a*b**3+b**4)/d,
                  -(2*a*a+a*b+2*b*b)/d, 1/d]
    rhs = mul(mul(mul([-a, 1], [-a, 1]), mul([-b, 1], [-b, 1])),
              [(a*a+3*a*b+b*b)/d, 2*(a+b)/d, 1/d])
    assert rhs == [polynomial[0], -1, polynomial[1], 0, polynomial[2], 0, polynomial[3]]
    hi = sum(max(co*lo, co*up) for co, (lo, up) in zip(polynomial, moment))
    lo_dyad = lower_sqrt(moment[1][0]**3/moment[2][1])
    hi_dyad = upper(hi)
    assert value(lo_dyad) > value(old['exact_interval'][0])
    assert value(hi_dyad) < value(old['exact_interval'][1])
    return {"input": {"c": 1, "h": "1/2", "s": "1/2"},
            "source": cited(src),
            "interval_dyadic": [lo_dyad, hi_dyad],
            "hermite_knots_sqrt_variable": [str(a), str(b)],
            "coefficients_of_cubic_in_x": list(map(str, polynomial)),
            "exact_rational_upper_bound": str(hi),
            "display_outward": ["0.38050322365532", "0.51985705002601"]}

if __name__ == '__main__':
    a = real_half()
    assert Q(a['display_outward'][0]) < value(a['interval_dyadic'][0])
    assert Q(a['display_outward'][1]) > value(a['interval_dyadic'][1])
    print(json.dumps({"arithmetic": "Python integers and fractions; dyadic denominator 2^120",
                      "integer_diagonal": schur(), "positive_noninteger_diagonal": a},
                     indent=2))
