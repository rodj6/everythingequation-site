"""Independent window comparison and outward full scalar disks at depth one."""
import json
from pathlib import Path
from time import monotonic
from flint import acb,arb,ctx
from mark_shapes import a,constants,exact,dyadic,HERE,BASE

def read(name):return json.loads((HERE/name).read_text())
def disk(v,center,radius):
    return acb(*(dyadic(x) for x in v[center])),dyadic(v[radius])

def save(z,e):
    mid=z.mid(); rad=(e+abs(z-mid)).upper()
    low=(abs(mid).lower()-rad).lower()
    return dict(center=[exact(mid.real),exact(mid.imag)],radius=exact(rad),
                center_display=[mid.real.str(20),mid.imag.str(20)],radius_display=rad.str(20),
                modulus_lower=exact(low) if low>0 else None,
                relative_upper=exact((rad/low).upper()) if low>0 else None)

def run():
    st=monotonic()
    retained=disk(read("retained_repriced.json"),"center","radius")
    old=json.loads((BASE/"complete_R8_repriced_centered.json").read_text())
    oldradius=dyadic(old["radius_dyadic"])
    accrued=read("new_bands_12.json")["bands"]
    tails={t["B"]:disk(t,"tail_centre_dyadic","tail_radius_dyadic") for t in read("mark_tails_cubic.json")}
    win={t["B"]:disk(t,"tail_centre_dyadic","tail_radius_dyadic") for t in read("mark_windows.json")}
    receipts=[]
    for B in (9,10,12):
        z,e=acb(0),arb(0)
        for t in accrued:
            if t["right"]<=B:
                q,err=disk(t,"center","radius");z+=q;e+=err
        w,ew=win[B];tail,et=tails[B]
        gap=abs(z-w).upper()
        assert gap<ew+e
        receipts.append(dict(end=B,frequency=save(z,e),mark=save(w,ew),center_distance_upper=exact(gap),
          spatial_scalar=save(retained[0]+w+tail,retained[1]+ew+et),
          frequency_scalar=save(retained[0]+z+tail,retained[1]+e+et)))
    # Quintic window chi=1-10t^3+15t^4-6t^5; complement on [8,9] has mass 1/2.
    taper=read("window_89_taper.json")
    w,ew=disk(taper["quintic"],"center","radius"); sharp,es=disk(taper["sharp"],"center","radius")
    _,_,q,L,_,Dmin=constants()
    N=arb(10)**48;R=arb(9)
    assert N>Dmin*(R+2)**(4/(1+a("1/4")**2))
    discrepancy=L*(2+R)**(4*a("387/500"))/N**q
    bound=N**a("1/400")+discrepancy
    leakage=(a("17/16")*bound/128).upper()
    T,eT=tails[9]
    full=save(retained[0]+w+T,retained[1]+ew+eT+leakage)
    assert dyadic(full["radius"])<oldradius
    # Integrating the complementary taper as sharp minus smooth costs es+ew when
    # isolated. In the assembled scalar the same computed w cancels exactly.
    comp=save(T+sharp-w,eT+es+ew)
    recovered=save(retained[0]+sharp+T,retained[1]+es+eT)
    return dict(input=["c=1","h=1/2+i/8","s=1/2+i/20"],mark_window_checks=receipts,
      quintic=dict(window=save(w,ew),physical_rank="10^48",finite_uniform_discrepancy=exact(discrepancy.upper()),
      leakage_bound=exact(leakage),leakage_display=leakage.str(19),complete_with_absolute_leakage=full,
      signed_complement=comp,complete_after_exact_compensation=recovered),seconds=monotonic()-st)
if __name__=="__main__":
    with ctx.workprec(320):print(json.dumps(run(),indent=2))
