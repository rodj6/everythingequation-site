"""Independent special-function verification of the joint signed shell / real Bessel envelope."""
import hashlib
import json
from time import perf_counter
from flint import acb,arb,ctx
from mark_shapes import a,exact,HERE,shift,polyval

def verify(data):
    start=perf_counter()
    R=a(data["R"]);right=a(data["maxr"]);h=acb(a("1/2"),a("1/8"))
    p=list(map(a,data['P']));p[0]+=a(data.get('slack','0.00025'));p[1]+=a("1e-7")
    p=p+[arb(0)]*(3-len(p))
    q=[acb(*map(a,row)) for row in data['q'][:3]]
    beta=[acb(*map(a,row)) for row in data['q'][3:3+len(data['panels'])]]
    nodal=[acb(*map(a,row)) for row in data['q'][3+len(beta):]]
    omega=[]
    for fn,i in data.get('nodes',[]):
        cfg=json.loads((HERE/fn).read_text())['parameters']
        l,u=map(a,cfg['band'])
        omega.append((l+u+(u-l)*arb.legendre_p_root(cfg['radial'],i))/2)
    assert len(omega)==len(nodal)
    ks=[a(row['k']) for row in data['real_controls']];bs=[a(row['co']) for row in data['real_controls']]
    edges=list(map(int,data['edges'])); assert len(edges)==len(beta)+1
    powers=[acb(k)**(-2*h) for k in edges]
    ak=[(l-u)/(2*h) for l,u in zip(powers,powers[1:])]
    mass=[(1/a(l)-1/a(u))/abs(z) for l,u,z in zip(edges,edges[1:],ak)]
    # Precombine Q_h(k r) coefficients only; no integer series from the primary check.
    weights={int(data['R']):acb(1)}
    for l,u,pl,pu,b,d in zip(edges,edges[1:],powers,powers[1:],beta,ak):
        weights[l]=weights.get(l,acb(0))-b*pl/d
        weights[u]=weights.get(u,acb(0))+b*pu/d
    weights={k:v for k,v in weights.items() if not v.is_zero()}
    C=acb(2)**(-2*h-1)*(-h).gamma()/(1+h).gamma()
    def val(k,r):
        x=k*r
        return C*acb(x)**(2*h)+acb(-x*x/4).hypgeom([-h],[acb(1),1-h])/(2*h)
    x=arb(2);sq=x.sqrt();j0=x.bessel_j(0);j1=x.bessel_j(1)
    jmax=((j0/(2*sq)-sq*j1)**2+(1+1/(4*x*x))*(sq*j0)**2).sqrt().upper()
    qmax=((sq*j1)**2+(sq*j0-j1/(2*sq))**2/(1-3/(4*x*x))).sqrt().upper()*(1+abs(2*h+2)/(2*h.real+a('3/2')))
    l0=a("1e-6");w=(R*l0)**2/4
    assert all(k*right>=2 for k in ks+edges)
    S=sum(abs(b)*mass_i*k2*k2/2 for b,mass_i,k2 in zip(beta,mass,edges[1:]))
    J=sum(abs(b)*k*k/2 for b,k in zip(bs,ks))
    U=sum(abs(b)*k*k/2 for b,k in zip(nodal,omega))
    origin=P0=(p[0]+sum(bs)-abs(1/(2*h)-sum(beta)-sum(nodal)-q[0])).lower()
    origin-=abs(C)*R*l0+w/((2-2*h.real)*(1-w/4))+(S+J+U)*l0*l0/2
    origin-=sum(abs(z)*l0**(2*j) for pp in (p,q) for j,z in enumerate(pp) if j)
    assert origin>0
    ps=shift(p,right**2);qs=shift(q,right**2)
    ray=ps[0]-abs(qs[0])-qmax/(R*right)**a("3/2")
    ray-=sum(abs(b)*jmax/(k*right).sqrt() for b,k in zip(bs,ks))
    ray-=sum(abs(b)*mass_i*min(arb(1),jmax/(k*right).sqrt()) for b,mass_i,k in zip(beta,mass,edges))
    ray-=sum(abs(b) for b in nodal)
    assert ray>0
    for j in range(1,max(len(qs),len(ps))):
        assert (ps[j] if j<len(ps) else arb(0))>=(abs(qs[j]) if j<len(qs) else arb(0))
    intervals=[(l0,right)];mins=[]
    while intervals:
        l,u=intervals.pop();m=(l+u)/2;d=(u-l)/2
        y={k:val(k,m) for k in weights}
        V=sum(v*y[k] for k,v in weights.items())-polyval(m*m,q)
        V-=sum(b*(k*m).bessel_j(0) for b,k in zip(nodal,omega))
        V1=(2*h*sum(v*y[k] for k,v in weights.items())-sum(v*(k*m).bessel_j(0) for k,v in weights.items()))/m
        V1+=sum(b*k*(k*m).bessel_j(1) for b,k in zip(nodal,omega))
        V1-=sum(2*j*z*m**(2*j-1) for j,z in enumerate(q) if j)
        P=polyval(m*m,p)+sum(b*(k*m).bessel_j(0) for b,k in zip(bs,ks))
        P1=sum(2*j*z*m**(2*j-1) for j,z in enumerate(p) if j)-sum(b*k*(k*m).bessel_j(1) for b,k in zip(bs,ks))
        H=S+J+U+abs(2*h-1)*(abs(2*h)+1)/l**2+R/l
        H+=sum(2*j*(2*j-1)*abs(z)*u**(2*j-2) for pp in (p,q) for j,z in enumerate(pp) if j)
        if data.get("fit_affine_endpoints"):
            # A real affine function minus the norm of a complex affine
            # function is concave. Its minimum on [-d,d] is at an endpoint.
            diff=(min((P+P1*d-abs(V+V1*d)).lower(),
                      (P-P1*d-abs(V-V1*d)).lower())-H*d*d/2).lower()
        else:
            diff=(P-abs(V)-(abs(P1)+abs(V1))*d-H*d*d/2).lower()
        if diff>0:mins.append(diff)
        else:
            assert u-l>a("1e-13")
            intervals.extend([(l,m),(m,u)])
    return dict(R=data['R'],candidate=data['panels'],source_nodes=data.get('nodes',[]),origin=exact(origin.lower()),exterior=exact(ray.lower()),
                inner_panels=len(mins),minimum_margin=exact(min(mins)),bits=ctx.prec,seconds=perf_counter()-start)
def verify_pinned(filename, affine=False):
    snap=HERE/"mark_crosscheck_inputs"
    path=snap/filename
    pinned=json.loads((snap/"SHA256.json").read_text())[filename]
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==pinned
    candidate=json.loads(data)
    if filename.startswith("signed_best"):
        cfg=(snap/"joint_final_settings.json").read_bytes()
        assert hashlib.sha256(cfg).hexdigest()==json.loads((snap/"SHA256.json").read_text())["joint_final_settings.json"]
        settings=json.loads(cfg)[filename]
        assert a(settings["p1_slack"]).contains(a("1e-7"))
        candidate["slack"]=settings["p0_slack"]
        candidate["fit_affine_endpoints"]=affine
    result=verify(candidate)
    result["p0_slack"]=candidate.get("slack","0.00025")
    result["p1_slack"]="0.0000001"
    result["affine_endpoint_bound"]=affine
    return dict(input_file="mark_crosscheck_inputs/"+filename,sha256=pinned,**result)

if __name__=='__main__':
    import argparse
    opt=argparse.ArgumentParser()
    opt.add_argument('--affine',action='store_true')
    opt.add_argument('files',nargs='+')
    args=opt.parse_args()
    with ctx.workprec(320):
        print(json.dumps([verify_pinned(f,args.affine) for f in args.files],indent=2))
