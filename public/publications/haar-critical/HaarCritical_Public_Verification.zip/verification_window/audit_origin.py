"""Outward repricing of the depth-one origin quadrature via finite-rank subtraction."""
import json
import sys
from pathlib import Path

from flint import arb, ctx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'verification_depthone'))
from analytic_bridge import constants
from annulus import boundD, restore
from contour_source import R, C, dyadic
from origin import weights


def price():
    old = json.loads((ROOT/'verification_depthone/origin_refined.json').read_text())
    expected = ["c=1", "h=1/2+i/8", "s=1/2+i/20"]
    assert old['input'] == expected
    n, nang = (old['parameters'][k] for k in ('radial', 'angular'))
    h = C(('1/2','1/8'))
    rank = R(10)**100
    _, constant, q, telescope, _, _ = constants()
    assert 2*constant*3**4/rank <= 2*(2*rank)**R('1/16')
    delta = (telescope*R(3)**(4*R('387/500'))/rank**q).upper()
    mass = rank**R('1/400')
    mellin = R('17/16')
    def env(b):
        return mass*(b/2+b*b/4).exp()
    even_max = boundD(R('1/2'),R('1/2'))+env(R('1/2'))
    # Cauchy on |z|=1/2, even powers only, followed by |z|<=1/4.
    curv = (R(16)*even_max/3).upper()
    cut = R(2)**-81
    integral_bridge = curv*cut+2*delta*(1/cut-1)
    angles = [arb.pi()*(2*j+1)/(2*n) for j in range(n)]
    radii = [(1+t.cos())/2 for t in angles]
    ww = [abs(w)/r**2 for w,r in zip(weights(n,h,angles),radii)]
    sampled_bridge = 2*delta*sum(ww,arb())
    # The finite-part mass -mu0/(2h) occurs once in the exact and the
    # quadrature expression. Its existing error remains in the jet charge.
    radial_prices = []
    for t in range(2,55):
        T = R(t)
        minmod = (T+1/T-2)/4
        height = (T-1/T)/4
        Xi = (env(height)+mass)/minmod**2
        # Sup-norm interpolation error after Chebyshev aliasing.
        err = 4*Xi*T**(-n)/(1-1/T)
        radial_prices.append((err.upper(),t))
    radial, best_ellipse = min(radial_prices,key=lambda pair:pair[0])
    alias_errors = []
    for rr, w in zip(radii,ww):
        candidates = []
        for step in range(1,201):
            strip = R(step)/20
            price = 2*env(rr*strip.sinh())/(nang*strip).expm1()
            candidates.append(price.upper())
        alias_errors.append(min(candidates)*w)
    angular = sum(alias_errors,arb())
    terms = {k:arb(old['error_breakdown'][k]).upper()
             for k in ('source','arithmetic','jet')}
    terms.update(radial=(mellin*radial).upper(),angular=(mellin*angular).upper(),
                 integral_bridge=(mellin*integral_bridge).upper(),
                 samples_bridge=(mellin*sampled_bridge).upper())
    result = sum(terms.values(),arb()).upper()
    assert result < restore(old['radius_dyadic'])
    return dict(input=expected, origin='verification_depthone/origin_refined.json',
                comparison_rank='10^100', physical_discrepancy=dyadic(delta),
                origin_lipschitz_in_squared_radius=dyadic(curv),
                small_cutoff=dyadic(cut), ellipse_parameter=best_ellipse,
                midpoint_dyadic=old['midpoint_dyadic'],radius_dyadic=dyadic(result),
                radius_display=result.str(22), source_calls=0,
                terms={k:dyadic(v) for k,v in terms.items()},
                terms_display={k:v.str(14) for k,v in terms.items()})

if __name__ == '__main__':
    with ctx.workprec(240):
        print(json.dumps(price(),indent=2))
