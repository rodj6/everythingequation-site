"""Validate signed shell-control Bessel-tail enclosures at the exact depth-one tuple.

Usage from project root: python verification_window/signed_shapes.py signed_candidate10.json
All assertions and all error charges use Arb. The LP is only a proposal generator.
"""
from pathlib import Path
import json, sys, argparse, time
from math import factorial, comb
from flint import arb, acb, ctx
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/'verification_depthone';PRE=ROOT/'verification_microscopic'
sys.path.insert(0,str(OLD))
from analytic_bridge import a, constants, budget
from bessel_bridge import finite_real_moments
from annulus import restore
from contour_source import dyadic
from bridge_quad import INPUT

def horner(x,coeff):
 y=coeff[-1]
 for v in reversed(coeff[:-1]):
  y=y*x+v
 return y

def shifted(poly,x):
 return [sum(comb(k,j)*poly[k]*x**(k-j) for k in range(j,len(poly))) for j in range(len(poly))]

def verify_shape(R,h,p,q,beta,Ak,edges,point_co,omega,real_k,real_c,rmax):
 nr=250
 end=a(rmax)
 k=edges[:-1]; highs=edges[1:]
 weights=[abs(v)*(1/a(j)-1/a(j2))/abs(w) for v,j,j2,w in zip(beta,k,highs,Ak)]
 # Global beyond end: compare the Taylor coefficients around r²=end².
 # Shell/control variations follow |J0|<=1. For Q use the proved Bessel energy estimate.
 x=arb(2); sq=x.sqrt()
 f=sq*x.bessel_j(1);fp=sq*x.bessel_j(0)-x.bessel_j(1)/(2*sq)
 assert (f*f+fp*fp/(1-3/(4*x*x))).sqrt()*(1+abs(2*h+2)/(2*h.real+a('3/2')))<3
 f=sq*x.bessel_j(0); fp=x.bessel_j(0)/(2*sq)-sq*x.bessel_j(1)
 assert fp**2+(1+1/(4*x*x))*f*f<a('1.25')**2
 pS=shifted(p,end**2);qS=shifted(q,end**2)
 for j in range(len(pS)):
  req=abs(qS[j]) if j<len(qS) else arb(0)
  if j==0:
   req+=3/(R*end)**a('3/2')+sum(w*min(a(1),a('1.25')/(k0*end).sqrt()) for w,k0 in zip(weights,k))
   req+=sum(abs(z)*a('1.25')/(freq*end).sqrt() for z,freq in zip(real_c,real_k))
   req+=sum(abs(z) for z in point_co)
  assert pS[j]>=req,(j,pS[j],req)
 # Precombine entire coefficients of Q and all shell Bessel transforms.
 rk=[acb(j)**(-2*h) for j in edges]
 cur=rk[:]; CR=(acb(2)**(-2*h-1)*(-h).gamma()/(h+1).gamma())*acb(R)**(2*h)
 rp=arb(1); factor=arb(1);coeff=[]; om=[arb(1)]*len(point_co)
 for j in range(nr):
  tmp=rp+sum(w*(z1-z0)/n for w,z0,z1,n in zip(beta,cur,cur[1:],Ak))
  coeff.append(-factor*(tmp/(2*j-2*h)+sum(c*v for c,v in zip(point_co,om))))
  om=[v*f*f for v,f in zip(om,omega)]
  rp*=R*R
  cur=[z*d*d for z,d in zip(cur,edges)]
  factor/=(-4*(j+1)**2)
 for j,z in enumerate(q): coeff[j]-=z
 w0=(end*max([R,a(edges[-1])]+omega))**2/4
 rem=w0**nr/arb(factorial(nr))**2/(1-w0/(nr+1)**2)*(1/(2*nr-2*h.real)+sum(weights)+sum(abs(z) for z in point_co))
 assert rem<a('1e-70'),rem
 def endpoint(t):
  val=horner(t*t,coeff)
  if t!=0: val+=CR*acb(t)**(2*h)
  return (horner(t*t,p)+sum(z*(freq*t).bessel_j(0) for z,freq in zip(real_c,real_k))-abs(val)-rem).lower()
 # Interpolate between two verified endpoint values; |X-linear interpolation|<=||X''||*width²/8.
 # Bessel J0'' at real argument bounded by 1/2 from its angular average.
 b2=sum(v*j2**2/2 for v,j2 in zip(weights,highs))+sum(abs(c)*v*v/2 for c,v in zip(point_co,omega))+sum(abs(z)*freq**2/2 for z,freq in zip(real_c,real_k))
 # For r<=origin, Q differs from Q(0) by direct series (19.D4).
 ori=a('1e-7')
 orig=endpoint(arb(0))
 w=(R*ori)**2/4
 near=abs(CR)*ori+w/((2-2*h.real)*(1-w/4))
 # J0'(t) <= t/2, by its angular average.
 near+=b2*ori**2/2+sum(abs(v)*ori**(2*j) for z in (q,p) for j,v in enumerate(z) if j>0)
 assert orig>near,(orig,near)
 le=endpoint(ori);ri=endpoint(end)
 st=[(ori,end,le,ri)];count=0;small=a(1000)
 while st:
  lo,hi,l,u=st.pop()
  assert min(l,u)>0,(str(lo),str(hi),str(l),str(u))
  curvature=abs(2*h-1)*(abs(2*h)+1)/lo**2+R/lo+b2
  # Local polynomial second derivatives, including the majorant.
  curvature+=sum(2*j*(2*j-1)*abs(z[j])*hi**(2*j-2) for z in (q,p) for j in range(1,len(z)))
  delta=(min(l,u)-curvature*(hi-lo)**2/8).lower()
  if delta>0:
   count+=1;small=min(small,delta)
  else:
   assert hi-lo>a('1e-14')
   mid=(lo+hi)/2;val=endpoint(mid)
   st.extend([(lo,mid,l,val),(mid,hi,val,u)])
 return count,small,rem

def node_disk(filename,index):
 tab=json.loads((HERE/filename).read_text());assert tab['input']==INPUT
 lo,hi=map(a,tab['parameters']['band']); n=tab['parameters']['radial'];m=tab['parameters']['angular']
 rho=(lo+hi+(hi-lo)*arb.legendre_p_root(n,index))/2
 row=tab['sharp']['node_means'][index]
 mid=acb(*(restore(z) for z in row['midpoint']))
 source=restore(row['source'])+restore(row['arithmetic'])
 # Compare nodes and true circular average separately to rank 10^100.
 _,_,nu,K,_,n0=constants()
 rank=a(10)**100; assert rank>n0*(2+rho)**(4/(1+a('1/4')**2))
 alias=[]
 for j in range(1,51):
  t=a(j)/50;b=rho*t.sinh()
  env=rank**a('1/400')*(b/2+b*b/4).exp()
  alias.append((2*env/(m*t).expm1()).upper())
 cost=source+min(alias)+2*K*(2+rho)**(4*a('387/500'))/rank**nu
 return rho,mid,cost.upper()

def real_m3(N,C):
 # Third divided difference in u=r^2, on u/t^2=0,1,4,9.
 # For both measures the cosine Taylor integral remainder is bounded by the absolute eighth moment.
 tab=json.loads((OLD/'real_order_control.json').read_text())
 row=tab['moment_dyadics'][3]
 lim=restore(row[0]).union(restore(row[1]))
 u=[0,1,4,9]; w=[]
 for i,f in enumerate(u):
  v=arb(1)
  for j,g in enumerate(u):
   if i!=j: v/=f-g
  w.append(v)
 assert all(sum(v*g**l for v,g in zip(w,u)).contains(1 if l==3 else 0) for l in range(4))
 Mc=a(4)**4*factorial(4)**2*a(6).exp()/a(4)**8
 es=[]
 for den in (100,150,200,250,300,400,500,1000,10000):
  t=1/a(den)
  es.append((2304*sum(abs(v)*(C*(2+3*t)**4/N+2*Mc*t**8*g**4/(4**4*factorial(4)**2)) for v,g in zip(w,u))/t**6).upper())
 e=min(es)
 return lim+arb(0,e.upper())

def first_moments(N,mom):
 # Direct transfer of m0,m1 with an inexpensive t chosen by inspection of the two terms.
 # Limiting complex m2 comes from an inherited exact jet; sixth order uses its proven Cauchy bound.
 _,C,nu,K,_,n0=constants()
 t=a('1/1000')
 delta=K*(2+t)**(4*a('387/500'))/N**nu
 precise=json.loads((PRE/'jet_complex_precision.json').read_text())['exact_dyadic_disks']
 wide=json.loads((PRE/'jet_complex_reference.json').read_text())['exact_dyadic_disks']
 def disk(row): return acb(restore(row['real']),restore(row['imag'])),restore(row['radius'])
 vals=[disk(precise[str(j)]) for j in range(2)]
 z2,e2=disk(wide['2'])
 realmom,_,m3=mom
 var=N**a('1/400')
 cost=8*delta/t**2+(abs(z2)+e2+var*realmom[2])*t**2/16+4*(a(128000)+var*m3/2304)*t**4
 return [vals[0][0],vals[1][0],z2],[vals[0][1]+delta,vals[1][1]+cost,e2] # third jet unused; enforced by run

def run(data,shape_cache=None):
 start=time.monotonic()
 h=acb(a('1/2'),a('1/8')); R=a(data['R'])
 p=[a(z) for z in data['P']]
 real_data=data.get('real_controls',[])
 slack=data.get('slack','0.00025' if real_data else '0.0008')
 p[0]+=a(slack)
 if real_data:p[1]+=a('0.0000001')
 real_k=[a(row['k']) for row in real_data];real_c=[a(row['co']) for row in real_data]
 if len(p)==4:
  if p[3]==0: p=p[:3]
 q=[acb(a(x),a(y)) for x,y in data['q'][:3]]

 b_all=[acb(a(x),a(y)) for x,y in data['q'][3:]]
 beta=b_all[:len(data['panels'])];point_co=b_all[len(beta):]
 nodedata=[node_disk(fn,i) for fn,i in data.get('nodes',[])]
 assert len(point_co)==len(nodedata)
 omega=[row[0] for row in nodedata]
 edges=data.get("edges",list(range(1,len(beta)+2)))
 assert len(edges)==len(beta)+1
 Ak=[(acb(i)**(-2*h)-acb(j)**(-2*h))/(2*h) for i,j in zip(edges,edges[1:])]
 shape_key=json.dumps({k:v for k,v in data.items() if k not in ('rank_exponent','frequency_M')},sort_keys=True)
 if shape_cache is None: shape_cache={}
 if shape_key not in shape_cache:
  shape_cache[shape_key]=verify_shape(R,h,p,q,beta,Ak,edges,point_co,omega,real_k,real_c,data['maxr'])
 panels,margin,ser=shape_cache[shape_key]
 rep=json.loads((HERE/'retained_repriced.json').read_text())
 files=data['panels']; assert len(beta)==len(files)
 bands={v['file']:v['radius'] for v in rep['bands']}
 D=[];err=[]
 for lo,hi,f in zip(edges,edges[1:],files):
  if '#' in f:
   fn,ix=f.split('#')
   raw=json.loads((HERE/fn).read_text()); assert raw['input']==INPUT
   row=next(r for r in raw['bands'] if r['left']==int(ix))
   assert [row['left'],row['right']]==[lo,hi]
   center=row['center']; rad=row['radius']
  elif f in bands:
   raw=json.loads((OLD/f).read_text());assert raw['input']==INPUT
   assert list(map(int,raw['parameters']['range']))==[lo,hi]
   center=raw['dyadic_midpoint'];rad=bands[f]
  else:
   raw=json.loads((HERE/f).read_text());assert raw['input']==INPUT
   assert list(map(int,raw['parameters']['band']))==[lo,hi]
   center=raw['sharp']['center'];rad=raw['sharp']['radius']
  D.append(acb(*(restore(z) for z in center)));err.append(restore(rad))
 kappa=acb(2)**(2*h+1)*(1+h).gamma()*(-h).rgamma();T=kappa*acb(R)**(-2*h)
 # A *single* rank is used for every transferred term. Compare on actual real frequencies there.
 rank_exponent=data.get('rank_exponent',56);assert rank_exponent>=56
 N=a(10)**rank_exponent;M=a(data.get('frequency_M',65536))
 _,C,nu,K,_,n0=constants();P=4*a('387/500')
 assert N>n0*(M+2)**(4/(1+a('1/4')**2))
 recompute=finite_real_moments(N,PRE/'jet_half_tight.json')
 mr,_,_=recompute;mc,ec=first_moments(N,recompute)
 if q[2]!=0:
  from mark_shapes import complex_jets
  mc2,ec2,_=complex_jets(N);ec[2]=ec2[2];mc[2]=mc2[2]
 if len(p)==4: mr.append(real_m3(N,C))
 var=N**a('1/400')
 # Source shell receipts already include kappa. The normalized mark-observable is D/(kappa*A).
 z=T*sum(co*m for co,m in zip(q,mc))
 z+=sum(T*co*dk/(kappa*ak) for co,dk,ak in zip(beta,D,Ak))
 z+=T*sum(c*row[1] for c,row in zip(point_co,nodedata))
 mean=sum(v*m for v,m in zip(p,mr)); rp_err=arb()
 for row,co in zip(real_data,real_c):
  sample=json.loads((HERE/row['file']).read_text())
  assert sample['s']==['1/2','0'] and sample['depth']==1 and sample['rank_log10']<=rank_exponent
  datum,=[pt for pt in sample['samples'] if pt['r']==row['k']]
  mean+=co*restore(datum['real'])
  eold=restore(datum['finite_discrepancy'])
  assert sample['rank_log10']<=rank_exponent
  rp_err+=abs(co)*(restore(datum['limiting_error'])+eold*a(10)**(sample['rank_log10']-rank_exponent))
 raw_shape=(abs(T)*var*mean).upper()
 charges={'shape':raw_shape,'complex_jet':(abs(T)*sum(abs(co)*v for co,v in zip(q,ec))).upper(),
          'control_source_enclosures':sum(abs(T*co/(kappa*ak))*er for co,ak,er in zip(beta,Ak,err)).upper(),
          'control_to_finite':sum(abs(T*co/ak)*(1/a(i)-1/a(j))*K*(j+2)**P/N**nu for i,j,co,ak in zip(edges,edges[1:],beta,Ak)).upper(),
          'main_band_bridge':(abs(kappa)*K*(1+2/R)**P*M**(P-1)/((P-1)*N**nu)).upper(),
          'finite_past_M':(abs(kappa)*var*mr[0]/M).upper(),'limit_past_M':budget(M,arithmetic=True),
          'rounding':(z-z.mid()).abs_upper()}
 charges['matched_positive_source_errors']=(abs(T)*var*rp_err).upper()
 charges['node_enclosures']=(abs(T)*sum(abs(c)*row[2] for c,row in zip(point_co,nodedata))).upper()
 charges['node_to_finite']=(abs(T)*sum(abs(c)*K*(2+row[0])**P/N**nu for c,row in zip(point_co,nodedata))).upper()
 total=sum(charges.values(),arb(0)).upper(); z=z.mid()
 return dict(input=INPUT,R=data['R'],h=['1/2','1/8'],tilt=['1/2','1/20'],rank='10^'+str(rank_exponent),frequency_M=int(M.unique_fmpz()),control_files=files,
  signed_controls=[{'coefficient':[str(co.real),str(co.imag)],'total_multiplier':[str((T*co/(kappa*ak)).real),str((T*co/(kappa*ak)).imag)]} for co,ak in zip(beta,Ak)],
  shape_slack=slack,quadratic_slack=('0.0000001' if real_data else '0'),real_controls=real_data,shape_panels=panels,min_verified_margin=str(margin),series_error_bound=str(ser),tail_centre_dyadic=[dyadic(z.real),dyadic(z.imag)],
  tail_radius_dyadic=dyadic(total),tail_center=[z.real.str(18),z.imag.str(18)],tail_radius=total.str(18),
  radius_breakdown={j:v.str(15) for j,v in charges.items()},exact_charges={j:dyadic(v.upper()) for j,v in charges.items()},
  runtime_seconds=time.monotonic()-start,bits=ctx.prec)
if __name__=='__main__':
 with ctx.workprec(256):
  print(json.dumps([run(json.loads((HERE/f).read_text())) for f in sys.argv[1:]],indent=2))
