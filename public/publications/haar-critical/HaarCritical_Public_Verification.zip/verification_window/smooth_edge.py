"""Cost of replacing a measured sharp band by a symmetric C-infinity edge."""
from pathlib import Path
import json
import sys
from flint import arb, acb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'verification_depthone'))
from analytic_bridge import a,constants
from contour_source import dyadic

def edge(B,eps):
    # This rank is only used for the real-frequency comparison and a first derivative.
    N=a(10)**100
    A=a(B)-eps
    _,C,nu,L,_,_=constants()
    M=a(B)+eps
    assert A>=8 and 2*C*(2+M)**4/N<2*(2*N)**a('1/16')
    delta=L*(2+M)**(4*a('387/500'))/N**nu
    mass=N**a('1/400')
    # For a real projection X, E[X^2] <= E[e^X+e^(-X)-2] <= 2e^(3/4).
    projected_first=(2*a('3/4').exp()).sqrt()
    exponent=abs(acb(2,a('1/4')))
    Lfinite=mass*(exponent/A**3+projected_first/A**2)
    # With a symmetric probability mollifier supported in [-eps,eps],
    # the first absolute moment of the integrated step discrepancy is <= eps^2/2.
    error=(a('17/16')*(Lfinite*eps**2/2+delta*eps/A**2)).upper()
    return dict(B=B,epsilon=eps.str(8),one_edge=dyadic(error),
                one_edge_upper=error.str(18),extra_if_priced_twice=(2*error).upper().str(18))

if __name__=='__main__':
    with ctx.workprec(160):
        print(json.dumps([edge(B,a(e)) for B in (9,10,12,16) for e in ('1/8','1/32','1/128')],indent=2))
