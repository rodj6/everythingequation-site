"""Repeat the order-three positive Fredholm jet with a larger bidisk and projection.

Independent finite-rank transfer and signed-window proofs use the inherited
jets. This is a tighter numerical check of the limiting real radial moments.
"""
import json
import sys
from pathlib import Path
from time import perf_counter

from flint import ctx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'verification_depthone'))
from real_order_control import jets
from contour_source import Keyhole, R, dyadic

if __name__ == '__main__':
    with ctx.workprec(160):
        start=perf_counter()
        operator=Keyhole(1,'1/2','48',n=34,project=132,laguerre='2')
        mm,meta=jets(operator,3,R('1/2'))
        record=dict(inputs=dict(depth=1,s='1/2',bidisk='1/2',degree=3,extent=48,
                                gauss=34,project=132,laguerre='2',bits=160),
                    moment_dyadics=[[dyadic(z.lower()),dyadic(z.upper())] for z in mm],
                    enclosures=[str(z) for z in mm],bounds=meta,seconds=perf_counter()-start)
        print(json.dumps(record,indent=2))
