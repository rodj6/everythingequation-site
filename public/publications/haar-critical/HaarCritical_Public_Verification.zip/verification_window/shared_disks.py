"""Exact rational complex disk assembly with a single copy of each measured annulus."""
from fractions import Fraction as F
from pathlib import Path
import json
from audit_assembly import EXPECTED, OLD, PRE, binary, disk, summarize, encode
from final_disks import HERE, read, priced_bands, tail_rows
BINARY=1<<192

def upper_sqrt(d):
    from math import isqrt
    t=isqrt((d.numerator*BINARY**2)//d.denominator)
    return F(t+1,BINARY)

def upper_abs(z):
    return upper_sqrt(sum(c*c for c in z))
def plus(a,b):
    return (a[0]+b[0],a[1]+b[1])
def minus(a,b):
    return (a[0]-b[0],a[1]-b[1])
def product(a,b):
    return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def parse(s):
    text=s.strip('[]')
    pair=text.split(' +/- ')
    val=F(pair[0]);rad=F(pair[1]) if len(pair)>1 else F(0)
    scaled=val*BINARY
    point=F(scaled.numerator//scaled.denominator,BINARY)
    return point,rad+abs(point-val)
def ceiling_dyadic(x):
    return F(-((-x.numerator*BINARY)//x.denominator),BINARY)
def verify(end,row,all_bands,oldwidth):
    src=read(row['candidate_file'])
    assert src['R']==row['R']==end and row['input']==EXPECTED and not src.get('nodes')
    charges={k:binary(z) for k,z in row['exact_charges'].items()}
    old_error=binary(row['tail_radius_dyadic'])
    assert old_error>=sum(charges.values())
    # All of the original complement charges except the separately charged
    # uncertainty of the signed panel tests stay in the enclosure.
    keep=old_error-charges['control_source_enclosures']
    center,origin=disk(read('audit_origin.json'),'midpoint_dyadic','radius_dyadic')
    center=plus(center,tuple(map(binary,row['tail_centre_dyadic'])))
    combined=F(0); center_err=F(0); details=[]
    for j,(a,b,location,coef) in enumerate(zip(src['edges'],src['edges'][1:],src['panels'],row['signed_controls'])):
        assert (a,b) in all_bands
        newmid,er=all_bands[a,b]
        if location in OLD:
            actual=json.loads((PRE/location).read_text())
            assert list(map(int,actual['parameters']['range']))==[a,b]
            oldmid,older=disk(actual,'dyadic_midpoint','dyadic_radius')
        elif '#' in location:
            file,k=location.split('#')
            rec=next(v for v in read(file)['bands'] if v['left']==int(k))
            assert (rec['left'],rec['right'])==(a,b)
            oldmid,older=disk(rec,'center','radius')
        else:
            rec=read(location)
            assert list(map(int,rec['parameters']['band']))==[a,b]
            oldmid,older=disk(rec['sharp'],'center','radius')
        assert len(coef['total_multiplier'])==2
        cx,cy=map(parse,coef['total_multiplier'])
        w=(cx[0],cy[0]); ew=cx[1]+cy[1]
        displacement=minus(newmid,oldmid)
        center=plus(plus(center,newmid),product(w,displacement))
        pe=ceiling_dyadic((upper_abs(plus((1,0),w))+ew)*er)
        ce=ceiling_dyadic(ew*upper_abs(displacement))
        combined+=pe;center_err+=ce
        details.append(dict(band=[a,b],combined_charge=encode(pe),midpoint_replacement_charge=encode(ce)))
    assert list(zip(src['edges'],src['edges'][1:]))==[(a,b) for a,b in all_bands if b<=end]
    radius=keep+origin+combined+center_err
    assert radius<oldwidth
    out=summarize((center,radius))
    out.update(cutoff=end,tail_terms_kept=encode(keep),origin_charge=encode(origin),
               combined_band_charge=encode(combined),coefficient_rounding=encode(center_err),
               improvement_over_separate=encode(oldwidth-radius),bands=details)
    return out
def main():
    retained=read('retained_repriced.json')
    fresh=priced_bands();bands={}
    for j,(name,row) in enumerate(zip(OLD,retained['bands']),1):
        raw=json.loads((PRE/name).read_text())
        bands[j,j+1]=(tuple(map(binary,raw['dyadic_midpoint'])),binary(row['radius']))
    for a,b,_,d in fresh: bands[a,b]=d
    old=read('final_disks.json')
    ts=tail_rows(old['tail_source'])
    results={str(k):verify(k,row,bands,binary(old['refined'][str(k)]['radius'])) for k,row in ts.items()}
    best=min(results.values(),key=lambda r:binary(r['radius']))
    return dict(input=EXPECTED,refined=results,best=best,
       published_improvement=encode(binary(old['opening']['radius'])-binary(best['radius'])),
       matched_R8_improvement=encode(binary(results['8']['radius'])-binary(best['radius'])))
if __name__=='__main__':
    print(json.dumps(main(),indent=2))
