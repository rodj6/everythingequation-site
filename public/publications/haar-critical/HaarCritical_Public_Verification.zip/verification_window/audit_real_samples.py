"""Real-tilt signed Fourier constraints for the positive shape majorant."""
from concurrent.futures import ProcessPoolExecutor
import multiprocessing, json, sys, time
from pathlib import Path
from flint import arb, acb, ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'verification_depthone'))
from contour_source import Keyhole,R,dyadic
from annulus import restore
from analytic_bridge import constants

def point(args):
    n,k,r=args
    p = R(r)*acb(0,2*arb.pi()*k/n).exp()
    v=G(p,p.conjugate())
    err=(v.analytic+v.numerical).upper()
    if GAMMA_CAP and err>1:
        return dict(j=k,z=dyadic(arb()),radius=dyadic(arb(1)),mass_fallback=True)
    return dict(j=k,z=dyadic(v.mid.real),radius=dyadic(err),mass_fallback=False)

def main():
    global G,GAMMA_CAP
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--radii',nargs='+',type=int,default=[2,4,6,8,10,12])
    ap.add_argument('--rank',type=int,default=56)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--expanded',action='store_true')
    args=ap.parse_args()
    GAMMA_CAP=args.expanded
    bits=260 if args.expanded else 190
    with ctx.workprec(bits):
        if args.expanded:
            extent,order,projection,scale=(77,85,175,'1.45')
        else:
            extent,order,projection,scale=(42,46,85,'1')
        G=Keyhole(1,('1/2','0'),extent,n=order,project=projection,laguerre=scale)
        rank=R(10)**args.rank
        _,creal,_,_,_,_=constants()
        out=[]
        with ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context('fork')) as pool:
            for r in args.radii:
                start=time.monotonic()
                n=(48 if r<=8 else 64) if args.expanded else (40 if r<=8 else 56)
                pp=list(pool.map(point,[(n,k,r) for k in range(n//4+1 if args.expanded else n//2+1)]))
                z=arb(); sep=arb()
                for k,v in enumerate(pp):
                    if args.expanded:
                        w=R(2 if k in (0,n//4) else 4)/n
                    else:
                        w=R(1 if k in (0,n//2) else 2)/n
                    z+=w*restore(v['z']);sep+=w*restore(v['radius'])
                # Use A(b) for the *real* limiting tilt, by compact source convergence
                # and the real finite-rank Gaussian bound with no N^{v²} factor.
                cand=[]
                for t in range(1,151):
                    strip=R(t)/40
                    b=r*strip.sinh()
                    cand.append(2*(b/2+b*b/4).exp()/(n*strip).expm1())
                alias=min(x.upper() for x in cand)
                err=(alias+sep+abs(z-z.mid())).upper()
                rankerr=(creal*(2+r)**4/rank).upper()
                out.append(dict(r=r,angular=n,minimum_calls=len(pp),real=dyadic(z.mid()),limiting_error=dyadic(err),
                                finite_discrepancy=dyadic(rankerr),alias=dyadic(alias),source=dyadic(sep.upper()),
                                seconds=time.monotonic()-start,point_receipts=pp))
        print(json.dumps(dict(depth=1,s=['1/2','0'],rank_log10=args.rank,order=order,projection=projection,quarter_symmetric=args.expanded,
                              extent=extent,scale=scale,bits=bits,samples=out),indent=2))
if __name__=='__main__': main()
