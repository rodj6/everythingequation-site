"""Outward scalar window and complement budgets at the exact depth-one tuple.

Run from any directory: python mark_shapes.py (Python-FLINT 0.9).
The candidates are decimal rationals; none of the floating searches are trusted.
"""
import json
import sys
from math import comb
from pathlib import Path
from time import monotonic

from flint import acb, arb, ctx

HERE=Path(__file__).resolve().parent
BASE=HERE.parent / "verification_depthone"
sys.path.insert(0,str(BASE))
from analytic_bridge import a, constants, budget
from bessel_bridge import finite_real_moments, dyadic
from centred_bessel import q_bessel, poly_product, shift
from fractions import Fraction

def exact(x):
    m,e=x.man_exp()
    return [str(m),int(e)]

def polyval(x,p):
    v=p[-1]
    for t in p[-2::-1]:
        v=v*x+t
    return v

def read_fit(name):
    f=json.loads((HERE / name).read_text(),parse_float=str)
    # All candidates are explicitly rounded to decimal rationals on a .001 grid.
    def milli(x):
        return a(Fraction(round(1000*Fraction(str(x))),1000))
    return [milli(x) for x in f["p"]], [acb(milli(x),milli(y)) for x,y in f["center"]]

def kernel(kind,h,A,B):
    if kind=="tail":
        scale=acb(B)**(-2*h)
        def f(r):
            v,e,_=q_bessel(B*r,h)
            return v,e
        def lip(lo,hi):
            if B*hi<1:
                C=acb(2)**(-2*h-1)*(-h).gamma()/(h+1).gamma()
                return B*abs(2*h*C)+B**2*hi/(2*(1-(B*hi)**2/16))
            return (abs(2*h)+1)/lo
        def small(lim):
            x=B*lim
            w=x**2/4
            _,_,C=q_bessel(x,h)
            return C*x+w/((2-2*h.real)*(1-w/4))
        return scale,f,lip,1/(2*h),small,3/(2*B)**a("3/2")
    diff=1/A-1/B
    a1=acb(A)**(-2*h)/diff
    a2=acb(B)**(-2*h)/diff
    def f(r):
        v1,e1,_=q_bessel(A*r,h)
        v2,e2,_=q_bessel(B*r,h)
        return a1*v1-a2*v2,abs(a1)*e1+abs(a2)*e2
    def lip(lo,hi):
        return (B/A).log()/diff
    def small(lim):
        return (B*lim)**2/4
    return diff,f,lip,(a1-a2)/(2*h),small,arb(1)

def certify(kind,h,A,B,p,q):
    scale,f,lip,val0,small,big=kernel(kind,h,A,B)
    left=a("1/20000");right=arb(2)
    # From the checked Bessel energy in centred_bessel.tex.
    x=arb(2); j0=x.bessel_j(0); j1=x.bessel_j(1)
    C=(2*j1**2+(x.sqrt()*j0-j1/(2*x.sqrt()))**2/(1-3/(4*x*x))).sqrt()
    assert C*(1+abs(2*h+2)/(2*h.real+a("3/2")))<3
    pp=p[:];pp[0]-=big
    pp=shift(pp,4);qq=shift(q,4)
    sq=poly_product(pp,pp);rsq=poly_product(qq,[z.conjugate() for z in qq])
    assert all(z>0 for z in pp)
    assert all(z-w.real>0 for z,w in zip(sq,rsq)), list(zip(sq,rsq))
    origin_gap=(polyval(arb(0).union(left**2),p)-abs(val0-q[0])-small(left)
                -sum(abs(z)*left**(2*j) for j,z in enumerate(q) if j)).lower()
    assert origin_gap>0, (str(B),str(origin_gap))
    stack=[(left,right)]
    margins=[]
    while stack:
        lo,hi=stack.pop()
        mid=(lo+hi)/2
        v,err=f(mid)
        L=lip(lo,hi)+sum((2*j)*abs(z)*hi**(2*j-1) for j,z in enumerate(q) if j)
        full=polyval(lo.union(hi)**2,p)
        gap=(full-abs(v-polyval(mid**2,q))-err-(hi-lo)*L/2).lower()
        if gap>0:
            margins.append(gap)
        else:
            assert hi-lo > a("1/2000000"), (str(B),str(lo),str(hi),str(gap))
            stack.extend([(lo,mid),(mid,hi)])
    return scale,len(margins),min(margins),origin_gap

def complex_jets(N):
    # Finite differences of the two radial transforms at 0,t,2t.
    # All identities and constants are from centred_bessel.tex; the fourth
    # coefficient is eliminated in the first derivative-free stencil below.
    _,_,q,K,_,dmin=constants()
    _,_,m3=finite_real_moments(N,HERE.parent/"verification_microscopic/jet_half_tight.json")
    Cfin=N**a("1/400")*m3/2304
    # Equation (19.D3) on the complex radial 1/2 disk.
    b=a("1/2"); g=a("127/500"); pi=arb.pi()
    kk=(pi/20).exp();jj=(pi/20).sinh()/pi
    cc=arb(4).log()/2+3+(2*pi/3).sqrt()
    bound=(b/2+b*b/4+b.exp()/(1-g)*(2*kk*b.exp()*jj*(arb(804).log()+cc)+4*kk**2/10000)).exp()
    assert bound < 1000
    e0=K*(2+a("1/10"))**(4*a("387/500"))/N**q
    # Any positive t permitted. This choice approximately balances the terms.
    t=(e0/(128000+Cfin))**a("1/6")
    assert 2*t<a("1/10") and N>dmin*(2+2*t)**(4/(1+a("1/4")**2))
    ef=K*(2+2*t)**(4*a("387/500"))/N**q
    csum=128000+Cfin
    err2=(arb(16)/3)*(10*ef/t**4+68*csum*t**2)
    # 16*(Phi(t)-Phi(0))-(Phi(2t)-Phi(0)) eliminates m2;
    # quadratic coefficient -3*m1*t², absolute fourth terms cancel.
    err1=(32*ef+80*csum*t**6)/(3*t**2)
    rows=json.loads((HERE.parent/"verification_microscopic/jet_complex_reference.json").read_text())["exact_dyadic_disks"]
    tight=json.loads((BASE/"jet_complex_precision.json").read_text())["exact_dyadic_disks"]
    rows.update(tight)
    m=[]; e=[]
    for j,efin in enumerate((ef,err1,err2)):
        row=rows[str(j)]
        m.append(acb(dyadic(row["real"]),dyadic(row["imag"])))
        e.append(dyadic(row["radius"])+efin)
    return m,e,t

def real_third(N):
    # F_N(3t)-6F_N(2t)+15F_N(t)-10F_N(0) annihilates 1,r^2,r^4.
    # Source difference costs 32e and the degree-six coefficient is -360/2304.
    t=a("1/10000")
    M4=(arb(6).exp()*256*576/4**8).upper()
    _,C,_,_,_,_=constants()
    e=C*(2+3*t)**4/N
    err=arb(2304)/360*(32*e/t**6+2*M4*8112*t**2/147456)
    r=json.loads((BASE/"real_order_control.json").read_text())["moment_dyadics"][3]
    return dyadic(r[0]).union(dyadic(r[1]))+arb(0,err.upper())

def enclose(kind, lo, hi, ranklog, M, extra, cubic=False):
    start=monotonic(); h=acb(a(".5"),a(".125"));A=a(lo); B=a(hi)
    fname=("mark_fit_"+str(hi)+".json") if kind=="tail" else ("mark_fit_win_"+str(lo)+"_"+str(hi)+".json")
    if cubic:
        assert kind=="tail"
        fname="mark_cubic_fit_"+str(hi)+".json"
    p,q=read_fit(fname)
    p[0]+=a(extra)
    scale,panels,gap,og=certify(kind,h,A,B,p,q)
    N=arb(10)**ranklog;M=a(M)
    _,_,nu,K,_,dmin=constants()
    band_max=M if kind=="tail" else B
    assert N>dmin*(2+band_max)**(4/(1+a("1/4")**2))
    e=K*(2+band_max)**(4*a("387/500"))/N**nu
    real,_,_=finite_real_moments(N,HERE.parent/"verification_microscopic/jet_half_tight.json")
    if cubic:
        real.append(real_third(N))
    comp,erms,t=complex_jets(N)
    pref=acb(2)**(2*h+1)*(1+h).gamma()*(-h).rgamma()
    mid=pref*scale*sum(zj*mj for zj,mj in zip(q,comp))
    factor=abs(pref*scale);loss=N**a("1/400")
    terms={"complex_jets":factor*sum(abs(zj)*ej for zj,ej in zip(q,erms)),
           "positive_shape":factor*loss*sum(pj*mj for pj,mj in zip(p,real))}
    if kind=="tail":
        terms.update(finite_past_M=abs(pref)*loss*real[0]/M, limit_past_M=budget(M,arithmetic=True),
                     band_bridge=abs(pref)*e*(1/B-1/M))
    else:
        terms["band_bridge"]=abs(pref)*e*(1/A-1/B)
    mid0=mid.mid();terms["arithmetic"]=abs(mid-mid0)
    radius=sum(v.upper() for v in terms.values()).upper()
    return dict(kind=kind,R=hi,A=lo,B=hi,h=["1/2","1/8"],tilt=["1/2","1/20"],
                candidate=fname,constant_bump=extra,comparison_rank_log10=ranklog,
                M=int(M.unique_fmpz()),real_comparison_loss=loss.str(12),complex_moment_step=t.str(12),
                checked_panels=panels,minimum_margin=gap.str(12),origin_margin=og.str(12),
                tail_centre_dyadic=[exact(mid0.real),exact(mid0.imag)],tail_radius_dyadic=exact(radius),
                tail_center=[mid0.real.str(18),mid0.imag.str(18)],tail_radius=radius.str(18),
                terms={k:v.upper().str(18) for k,v in terms.items()},seconds=monotonic()-start)

if __name__=="__main__":
    import argparse
    par=argparse.ArgumentParser()
    par.add_argument("--cubic",action="store_true")
    par.add_argument("--kind",choices=("tail","window"),default="tail")
    par.add_argument("--A",type=int,default=8)
    par.add_argument("--B",type=int,nargs="+",default=[8,9,10,11,12])
    par.add_argument("--ranklog",type=int,default=66)
    par.add_argument("--M",type=int,default=131072)
    par.add_argument("--bump",default="0.004")
    par.add_argument("--output",type=Path)
    args=par.parse_args()
    with ctx.workprec(160):
        rows=[enclose(args.kind,args.A,n,args.ranklog,args.M,args.bump,args.cubic) for n in args.B]
    txt=json.dumps(rows,indent=2)+"\n"
    if args.output: args.output.write_text(txt)
    else: print(txt)
