"""Independent exact-rational assembly and loss attribution; no Arb or source imports."""
import argparse
import json
from fractions import Fraction as F
from math import isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRE = HERE.parent / 'verification_depthone'
EXPECTED = ['c=1','h=1/2+i/8','s=1/2+i/20']
OLD = ['annulus_1_2_b_reprice.json','annulus_2_3_b_reprice.json',
       'annulus_3_4_b_reprice.json', 'panel45_reprice.json','panel56_reprice.json',
       'panel67_reprice.json','panel78_reprice.json']
ZERO = ((F(0),F(0)),F(0))

def read(path):
    return json.loads(path.read_text())

def binary(v):
    m,e = v
    return int(m)*F(2)**int(e)

def encode(x):
    exponent = x.denominator.bit_length()-1
    assert x.denominator==2**exponent
    return [str(x.numerator),-exponent]

def disk(row, c, e):
    xy=tuple(map(binary,row[c]))
    rad=binary(row[e])
    assert len(xy)==2 and rad>=0
    return xy,rad

def add(*disks):
    return (tuple(sum((p[0][i] for p in disks),F(0)) for i in (0,1)),
            sum((p[1] for p in disks),F(0)))

def contains(big,small):
    gap=big[1]-small[1]
    return gap>=0 and gap**2>=sum((x-y)**2 for x,y in zip(big[0],small[0]))

def floor_sqrt(z, digits=128):
    return F(isqrt((z.numerator << (2*digits))//z.denominator),1<<digits)

def ceil_dyadic(x,digits=128):
    return F(-((-x.numerator << digits)//x.denominator),1<<digits)

def summarize(d):
    center,r=d
    center_lower=floor_sqrt(sum(t*t for t in center))
    lower=center_lower-r
    assert lower>0 and sum(x*x for x in center)>=(lower+r)**2
    relative=ceil_dyadic(r/lower)
    assert relative*lower>=r
    return dict(center=[encode(t) for t in center],radius=encode(r),
                center_modulus_lower=encode(center_lower),modulus_lower=encode(lower),
                relative_upper=encode(relative))

def verify_base():
    o=read(PRE/'origin_refined.json')
    assert o['input']==EXPECTED
    oldbands=[disk(o,'midpoint_dyadic','radius_dyadic')]
    centers=[]
    for j,f in enumerate(OLD,1):
        r=read(PRE/f)
        assert r['input']==EXPECTED and list(map(int,r['parameters']['range']))==[j,j+1]
        oldbands.append(disk(r,'dyadic_midpoint','dyadic_radius'))
        centers.append(oldbands[-1][0])
    oldtails=read(PRE/'centred_bessel_all.json')
    t,=[row for row in oldtails if row['R']==8]
    assert t['h']==['1/2','1/8'] and t['tilt']==['1/2','1/20']
    oldtail=disk(t,'tail_centre_dyadic','tail_radius_dyadic')
    orig=read(PRE/'complete_R8_repriced_centered.json')
    assert orig['input']==EXPECTED
    oldpublished=disk(orig,'midpoint_dyadic','radius_dyadic')
    assert contains(oldpublished,add(*oldbands,oldtail))
    reprice=read(HERE/'retained_repriced.json')
    assert reprice['input']==EXPECTED and reprice['cutoff']==8
    neworigin=read(HERE/'audit_origin.json')
    assert neworigin['input']==EXPECTED and neworigin['midpoint_dyadic']==o['midpoint_dyadic']
    starting=disk(neworigin,'midpoint_dyadic','radius_dyadic')
    assert starting[1]>=sum(map(binary,neworigin['terms'].values()),F(0))
    new=[starting]
    for rr,oo,xy,name in zip(reprice['bands'],oldbands[1:],centers,OLD,strict=True):
        assert rr['file']==name and binary(rr['inherited_radius'])==oo[1]
        er=binary(rr['radius'])
        charged=(binary(rr['source'])+binary(rr['arithmetic'])+
                 sum(binary(rr['quadrature'][k]) for k in ('angular','radial','bridge')))
        assert oo[1]>er>=charged
        new.append((xy,er))
    return oldpublished,add(*new),oldtail

def audit(tails_path,bands_path,extra=()):
    old,retained,oldtail=verify_base()
    priced=read(bands_path)
    assert priced['input']==EXPECTED
    for fname in extra:
        ext=read(fname)
        assert ext['input']==EXPECTED
        left,right=map(int,ext['parameters']['band'])
        assert left<right
        priced['bands'].append(dict(left=left,right=right,**ext['sharp']))
    rows=read(tails_path)
    tails={}
    for row in rows:
        if row.get('kind')!='tail': continue
        assert row['h']==['1/2','1/8'] and row['tilt']==['1/2','1/20']
        assert row['B']==row['R']
        assert row['R'] not in tails
        tails[row['R']]=disk(row,'tail_centre_dyadic','tail_radius_dyadic')
    unchanged_tail=add(retained,oldtail)
    output={'opening_published':summarize(old),'repriced_retained':summarize(retained)
            if sum(t*t for t in retained[0])>retained[1]**2 else {},
            'unchanged_tail_after_repricing':summarize(unchanged_tail),'cutoffs':{}}
    r=8
    base=retained
    if r in tails:
        output['cutoffs'][str(r)]=summarize(add(base,tails[r]))
    for row in priced['bands']:
        assert row['left']==r and row['right']>r
        r=row['right']
        item=disk(row,'center','radius')
        assert item[1]>=sum(map(binary,row['terms'].values()),F(0))
        base=add(base,item)
        if r in tails:
            result=add(base,tails[r])
            s=summarize(result)
            s['radius_improvement_over_published']=encode(old[1]-result[1])
            s['radius_improvement_over_same_method_at_8']=encode(
                retained[1]+tails[8][1]-result[1]) if 8 in tails else None
            output['cutoffs'][str(r)]=s
    return output

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--tails',type=Path,default=HERE/'mark_tails.json')
    parser.add_argument('--bands',type=Path,default=HERE/'new_bands_12.json')
    parser.add_argument('--extra',nargs='*',type=Path,default=[])
    args=parser.parse_args()
    print(json.dumps(audit(args.tails,args.bands,args.extra),indent=2))
