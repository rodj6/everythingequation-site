"""Positive-atomic dual witnesses for the measured real-Bessel envelope.

SciPy proposes radii. Arb subsequently solves the exact system for all
moments in the stated intervals and must verify strictly positive weights.
"""
import json
from argparse import ArgumentParser
from pathlib import Path
import sys
import numpy as np
from scipy.special import j0
from scipy.optimize import linprog
from flint import acb, arb, acb_mat, arb_mat, ctx
from dictionary_floor import kernel, H, R, restore, HERE
from bessel_bridge import finite_real_moments
from analytic_bridge import constants

def inputs(freqs, file, refined=False):
    n=arb(10)**56
    _,C,_,_,_,_=constants()
    m=list(finite_real_moments(n,HERE.parent/'verification_microscopic/jet_half_tight.json')[0])
    f=json.loads((HERE/'fixed_feature_floor.json').read_text())["matched_m3_interval"]
    m.append(restore(f[0]).union(restore(f[1])))
    observations=[row for part in file.split(',') for row in json.loads((HERE/part).read_text())['samples']]
    if refined:
        m=[restore(z['finite_dyadic'][0]).union(restore(z['finite_dyadic'][1])) for z in json.loads((HERE/'refined_real_moments.json').read_text())['finite_moments']]
    for k in freqs:
        row=min((x for x in observations if x["r"]==k),key=lambda x: restore(x["limiting_error"]))
        z=restore(row["real"]); err=restore(row["limiting_error"])+C*(2+k)**4/n
        m.append(z+arb(0,err.upper()))
    return m

def witness(B,freqs,source,controls,eps_str,step,seed_count,midpoints,corners,refined):
    eps=R(eps_str)
    rank=3+len(controls)
    # stably spaced small-radius atoms; X grows quadratically near 0.
    radii=[R(j)/rank for j in range(rank+1)]
    edges=sorted({B}|{u for band in controls for u in band})
    q={k:[kernel(k*r) for r in radii] for k in edges}
    tests=[[arb(1) for r in radii],[r*r for r in radii],[r**4 for r in radii]]
    for left,right in controls:
        tests.append([acb(left)**(-2*H)*u-acb(right)**(-2*H)*v for u,v in zip(q[left],q[right])])
    roots=acb_mat([r[1:] for r in tests]).solve(acb_mat([[-r[0]] for r in tests]))
    v=[acb(1)]+[roots[j,0] for j in range(rank)]
    l1=sum(abs(z) for z in v)
    density=[eps*abs(z)/l1 for z in v]
    def features(r):
        return [arb(1),r*r,r**4,r**6]+[(k*r).bessel_j(0) for k in freqs]
    fg=[features(r) for r in radii]
    actual=inputs(freqs,source,refined)
    if midpoints:
        actual=[z.mid() for z in actual]
    if corners is not None:
        for i,sgn in corners:
            actual[i] = actual[i].lower() if sgn==0 else actual[i].upper()
    y=[m-sum(x*f[i] for f,x in zip(fg,density)) for i,m in enumerate(actual)]
    # Search for a well-conditioned positive basis in the residual moment cone.
    nfeatures=len(y)
    grid=np.arange(0,3*step+1)/step
    matrix=np.array([grid**(2*j) for j in range(4)]+[j0(k*grid) for k in freqs])
    target=np.array([float(z.mid()) for z in y]); width=np.array([float(z.rad()) for z in y])
    for seed in range(seed_count):
        cost=np.random.default_rng(seed).uniform(size=len(grid))
        fit=linprog(cost,A_eq=matrix,b_eq=target,bounds=(0,None),method='highs')
        if not fit.success:
            continue
        ix=np.where(fit.x>1e-9)[0]
        if len(ix)!=nfeatures:
            continue
        try:
            uncertainty=np.abs(np.linalg.inv(matrix[:,ix]))@width
        except np.linalg.LinAlgError:
            continue
        if np.min(fit.x[ix]-uncertainty)<=0:
            continue
        candidate=[features(R(int(j))/step) for j in ix]
        inverse = arb_mat([list(row) for row in zip(*candidate)]).inv()
        solution = inverse*arb_mat([[z] for z in y])
        masses=[solution[j,0] for j in range(nfeatures)]
        if not all(z>0 for z in masses):
            continue
        price=(R('17/16')/B*eps*abs(sum(t*f for t,f in zip(v,q[B])))/l1).lower()
        assert price>0
        return dict(R=B,positive_frequencies=freqs,raw_positive_file=source,
            controls=controls,comparison_rank='10^56',precision=ctx.prec,origin_atoms=rank+1,
            positive_mass=eps_str,remainder_atoms_numerators=ix.tolist(),
            remainder_atoms_denominator=step,minimum_remainder_mass=min(masses).lower().str(16),
            scalar_shape_lower=price.str(18),proposal_seed=seed,
            moment_scope=('midpoints of supplied independent moment enclosures' if midpoints else 'all moments in supplied intervals'),
            interpretation='Lower bound even with unit variation cost, the stated real moment information. Additional signed/positive features change the class.')
    return dict(R=B,positive_frequencies=freqs,raw_positive_file=source,positive_mass=eps_str,status='No uniformly positive basis certified by this search',seeds=seed_count)

if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--source',default='audit_real_samples.json');p.add_argument('--freqs',nargs='+',type=int,default=[2,4,6,8,10])
    p.add_argument('--R',type=int,default=20);p.add_argument('--upper',type=int,default=20)
    p.add_argument('--eps',default='1/1000');p.add_argument('--step',type=int,default=80)
    p.add_argument('--refined',action='store_true');p.add_argument('--split',nargs='*',type=int);p.add_argument('--midpoints',action='store_true');p.add_argument('--seeds',type=int,default=250)
    args=p.parse_args()
    with ctx.workprec(960):
        from itertools import product
        def run(corner):
            return witness(args.R,args.freqs,args.source,[(k,k+1) for k in range(1,args.upper)],args.eps,args.step,args.seeds,args.midpoints,corner,args.refined)
        if args.split:
            out={'split_indices':args.split,'corners':[run(list(zip(args.split,z))) for z in product((0,1),repeat=len(args.split))]}
            out['all_corners_certified']=all('scalar_shape_lower' in row for row in out['corners'])
        else:
            out=run(None)
        print(json.dumps(out,indent=2))
