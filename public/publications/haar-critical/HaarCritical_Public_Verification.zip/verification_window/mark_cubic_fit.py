"""Optional floating search; all coefficients are rechecked independently in Arb."""
from pathlib import Path
import sys,json
from math import comb
import numpy as np
from scipy.optimize import linprog
from scipy.special import j0, gamma
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'verification_depthone'))
from fit_centered import Q
from numpy.polynomial.legendre import leggauss
def fit(B):
    deg=3; angles=np.linspace(0,2*np.pi,48,endpoint=False)
    rad=np.r_[np.linspace(.000001,1,1201),np.linspace(1.001,2,500)]
    y=rad**2
    M=np.column_stack([y**j for j in range(4)]); X=M[:,:3]
    # Evaluate flat Q via integration of Q' along the real axis in floating pilot.
    from scipy.integrate import solve_ivp
    h=.5+.125j
    x0=1e-6
    init=complex(Q(np.array([x0]))[0])
    ode=solve_ivp(lambda x,y:(2*h*y-j0(x))/x,[x0,2*B],[init],
                  rtol=1e-11,atol=1e-13,dense_output=True)
    val=ode.sol(B*rad)[0]
    mat=np.array([[comb(k,i)*4**(k-i) if k>=i else 0 for k in range(4)] for i in range(4)])
    lhs=[];rhs=[]
    for b in angles:
        c=np.cos(b);s=np.sin(b)
        lhs.extend([np.column_stack((-M,-c*X,-s*X)),np.column_stack((-mat,c*mat[:,:3],s*mat[:,:3]))])
        rhs.extend([-(val.real*c+val.imag*s+.001),np.array([-float(3/(2*B)**1.5)-.003,-.005,-.005,-.001])])
    cost=np.array([.9423646306,.3212988522,.229092239,.328,0,0,0,0,0,0])
    r=linprog(cost,A_ub=np.vstack(lhs),b_ub=np.concatenate(rhs),bounds=[(None,None)]*10)
    assert r.success
    v=np.round(r.x,3);v[:4]+=[.005,.003,.001,.001]
    return dict(B=B,p=[f"{x:.3f}" for x in v[:4]],center=[[f"{a:.3f}",f"{b:.3f}"] for a,b in zip(v[4:7],v[7:10])])
if __name__=='__main__':print(json.dumps(fit(int(sys.argv[1])),indent=2))
