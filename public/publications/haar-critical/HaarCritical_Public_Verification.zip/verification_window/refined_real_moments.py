"""Higher-order real-frequency comparison of the matched depth-one radial moments."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json
import sys
from flint import arb, ctx

HERE = Path(__file__).resolve().parent
DEPTH = HERE.parent/'verification_depthone'
sys.path.insert(0, str(DEPTH))
from analytic_bridge import a, constants
from bessel_bridge import dyadic as restore
from contour_source import dyadic

def lagrange(nodes, index):
    coeff=[Q(1)]
    for k, node in enumerate(nodes):
        if k==index:
            continue
        den=nodes[index]-node
        new=[Q(0)]*(len(coeff)+1)
        for j,c in enumerate(coeff):
            new[j+1]+=c/den
            new[j]-=c*node/den
        coeff=new
    return coeff

def run():
    n=12
    nodes=[j*j for j in range(n+1)]
    t=a('1/10')
    u=arb(7)
    rank=arb(10)**56
    _,C,_,_,_,_=constants()
    table = json.loads((DEPTH/'real_order_control.json').read_text())['moment_dyadics']
    tighter = json.loads((HERE.parent/'verification_microscopic/jet_half_tight.json').read_text())['exact_dyadic_disks']
    lag=[lagrange(nodes,j) for j in range(n+1)]
    rows=[]
    for j in range(4):
        ell=[c[j] for c in lag]
        assert all(sum(w*x**l for w,x in zip(ell,nodes))==int(l==j) for l in range(n+1))
        pre=arb(4)**j*factorial(j)**2/t**(2*j)
        e_src=arb(0);e_rem=arb(0)
        for k,w in enumerate(ell):
            z=abs(a(w)); rho=k*t
            e_src+=z*C*(2+rho)**4/rank
            e_rem+=z*2*(u/2+u*u/4).exp()*(rho/u)**(2*n+2)
        diff=(pre*(e_src+e_rem)).upper()
        if j==0:
            # Source at the origin. The positive mark moment is the Fourier mass.
            diff=(C*16/rank).upper()
        row=table[j]
        lim=restore(row[0]).union(restore(row[1]))
        if j<3:
            z=tighter[str(j)]
            m=restore(z['real'])
            e=restore(z['radius'])
            lim=lim.intersection(m+arb(0,e))
        # Preserve the original dyadic endpoints outwardly: arb.radius uses fewer bits.
        lower=(lim.lower()-diff).lower(); upper=(lim.upper()+diff).upper()
        rows.append(dict(degree=j,finite_dyadic=[dyadic(lower),dyadic(upper)],
                         finite_display=[lower.str(15),upper.str(15)],
                         transfer_upper=dyadic(diff),transfer_display=diff.str(12),
                         source_discrepancy_upper=dyadic((pre*e_src).upper()),
                         taylor_remainder_upper=dyadic((pre*e_rem).upper())))
    return dict(rank='10^56',depth='1',real_tilt='1/2',nodes='k²: k = 0,…,12',
                limiting_sources=['verification_depthone/real_order_control.json','verification_microscopic/jet_half_tight.json'],
                radial_step='1/10',positive_exponential_parameter='7',input_jet_degree=12,
                precision_bits=ctx.prec,finite_moments=rows)

if __name__=='__main__':
    with ctx.workprec(192):
        print(json.dumps(run(),indent=2))
