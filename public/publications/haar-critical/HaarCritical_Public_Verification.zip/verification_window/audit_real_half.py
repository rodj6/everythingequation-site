"""Independent spatial interval for F(1;1/2,1/2) using the real Bessel probes."""
import json,sys,math,argparse
from pathlib import Path
from flint import arb,ctx
from audit_real_fit import delta
from audit_real_shape import a,restore,dyadic

HERE=Path(__file__).resolve().parent

def search(sgn,samples):
    import numpy as np
    from scipy.special import j0
    from scipy.optimize import linprog
    r=np.unique(np.r_[np.linspace(0,.5,251),np.linspace(.5,2,751),np.linspace(2,5,501)])
    k=np.array([s['r'] for s in samples])
    b=np.c_[np.ones_like(r),r*r,r**4,j0(r[:,None]*k[None,:])]
    m=len(k); xx=np.c_[-b,np.zeros((len(r),m))]
    t=np.array([5.**(4-j)*math.comb(4,j) for j in range(5)])
    rows=[xx];rhs=[-sgn*r]
    for j in range(m):
        for sign in (-1,1):
            now=np.zeros(3+2*m);now[3+j]=sign;now[3+m+j]=-1
            rows.append(now[None,:]);rhs.append(np.array([0]))
    for i in range(5):
        v=np.zeros(3+2*m)
        v[:3]=[-int(i==0),-(25 if i==0 else 10 if i==1 else 1 if i==2 else 0),-t[i]]
        if i==0:v[3+m:]=1.25/np.sqrt(5*k)
        rows.append(v[None,:]);rhs.append(np.array([-sgn*(5 if i==0 else 1 if i==1 else 0)]))
    cost=np.r_[[.9423646306,.3212988522,.229092239],np.array([delta(s['real']) for s in samples]),np.array([delta(s['limiting_error']) for s in samples])]
    opt=linprog(cost,A_ub=np.vstack(rows),b_ub=np.concatenate(rhs),bounds=[(None,None)]*(3+m)+[(0,None)]*m,method='highs')
    assert opt.success
    return [str(round(z,10)) for z in opt.x[:3+m]]

def one(sgn,samples,coeff):
    # The two fixed slack polynomials put the exterior coefficient inequalities strictly inside their cone.
    p0,p1,p2=map(a,coeff[:3]);bump='.00002' if len(samples)>5 else '.000005'; extra='.0003' if len(samples)>5 else '1e-9';p0+=a(bump);p1+=a('1e-8');p2+=a(extra)
    ks=[a(s['r']) for s in samples];bs=list(map(a,coeff[3:]))
    end=a(5);sig=a(sgn)
    for i in range(5):
        p=(p0 if i==0 else 0)+(p1*math.comb(2,i)*end**(2-i) if i<=2 else 0)+p2*math.comb(4,i)*end**(4-i)
        cut=(sig*end if i==0 else sig if i==1 else 0)
        if i==0:cut+=sum(abs(b)*a('1.25')/(k*end).sqrt() for b,k in zip(bs,ks))
        assert p>cut
    def residual(r):
        return (p0+p1*r*r+p2*r**4-sig*r+sum(b*(k*r).bessel_j(0) for b,k in zip(bs,ks))).lower()
    curvature=2*abs(p1)+12*end**2*abs(p2)+sum(abs(b)*k*k/2 for b,k in zip(bs,ks))
    l=arb(); rr=end; stack=[(l,rr,residual(l),residual(rr))];count=0
    while stack:
        l,rr,v,w=stack.pop()
        assert min(v,w)>0,(l,rr,v,w)
        if min(v,w)>curvature*(rr-l)**2/8: count+=1
        else:
            z=(l+rr)/2;zz=residual(z)
            stack.extend([(l,z,v,zz),(z,rr,zz,w)])
    jets=json.load((HERE.parent/'verification_microscopic/jet_half_tight.json').open())['exact_dyadic_disks']
    z=arb()
    for p,j in zip((p0,p1,p2),range(3)):
        row=jets[str(j)]
        z+=p*restore(row['real'])+abs(p)*restore(row['radius'])
    for b,s in zip(bs,samples):
        z+=b*restore(s['real'])+abs(b)*restore(s['limiting_error'])
    return z.upper(),dict(sign=sgn,candidates=coeff,slack=[bump,'1e-8',extra],panels=count,upper=dyadic(z.upper()))

def main():
    p=argparse.ArgumentParser();p.add_argument('--expanded',action='store_true');p.add_argument('--saved',type=Path);a0=p.parse_args()
    results={};names=['audit_real_samples.json']+(['audit_real_samples_expanded.json'] if a0.expanded else [])
    for name in names:
        rows=json.load((HERE/name).open())['samples']
        for s in rows:
            kk=s['r'];e=delta(s['limiting_error'])
            if e<.2 and (kk not in results or e<delta(results[kk]['limiting_error'])):results[kk]=s
    samples=[results[k] for k in sorted(results)]
    with ctx.workprec(200):
        if a0.saved:
            saved=json.loads(a0.saved.read_text());assert saved['frequencies']==[q['r'] for q in samples]
            fixed={q['sign']:q['candidates'] for q in saved['checks']}
        else:
            fixed={sgn:search(sgn,samples) for sgn in (-1,1)}
        hi,checkup=one(1,samples,fixed[1])
        abslo,checklo=one(-1,samples,fixed[-1])
        lo=-abslo
        assert lo>a('0.38050322141498') and hi<a('0.52417857090888') and lo<hi
        print(json.dumps(dict(input=['c=1','h=1/2','s=1/2'],frequencies=[s['r'] for s in samples],
                              receipts=names,lower=dyadic(lo),upper=dyadic(hi),
                              interval=[lo.str(18),hi.str(18)],checks=[checklo,checkup]),indent=2))
if __name__=='__main__':main()
