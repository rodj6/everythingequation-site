"""Dual lower bound for the signed-shell/degree-two positive-majorant method.

Input: four matched real moments at N=10^56 (third transferred below); seven exact annular
test functions; fixed c,h,s. All solves and inequalities use Arb enclosures.
"""
from fractions import Fraction
from pathlib import Path
import json
import sys
from math import factorial
from flint import acb, acb_mat, arb, ctx

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT/'verification_depthone'))
from analytic_bridge import a, constants
from bessel_bridge import finite_real_moments, dyadic as restore
from contour_source import dyadic

def q_value(x, h):
    if x.is_zero():
        return 1/(2*h)
    nn = 240
    rat = -x*x/4
    coeff = arb(1)
    s = acb(0)
    for j in range(nn):
        s += coeff/(2*j-2*h)
        coeff *= rat/(j+1)**2
    ratio = abs(rat)/(nn+1)**2
    assert ratio < 1
    err = (abs(coeff)/((2*nn-2*h.real)*(1-ratio))).upper()
    val = acb(2)**(-2*h-1)*(-h).gamma()/(1+h).gamma()*acb(x)**(2*h)-s
    return val + acb(arb(0,err),arb(0,err))

def shell(j, X, h):
    l, r = acb(j), acb(j+1)
    al, ar = l**(-2*h), r**(-2*h)
    norm = (al-ar)/(2*h)
    N = 300 if j > 7 or X > 18 else 150
    v = arb(1)
    z = acb(0)
    for n in range(N):
        z += v*(ar-al)/(2*n-2*h)
        ar *= (j+1)**2
        al *= j*j
        v *= -X/(4*(n+1)**2)
    w = X*(j+1)**2/4
    ratio = w/(N+1)**2
    assert ratio < 1
    err = (w**N/arb(factorial(N))**2/(1-ratio)*
           (1/arb(j)-1/arb(j+1))/abs(norm)).upper()
    return z/norm + acb(arb(0,err),arb(0,err))

def solve_witness(nodes, real, h):
    x = list(map(a,nodes))
    n = len(x)
    assert n >= 5 and x[0] == 0
    # Include ALL complex quadratics as well as the seven complex shell tests.
    columns = [[arb(1), xx, xx*xx]+[shell(j,xx,h) for j in range(1,n-3)] for xx in x]
    matrix = acb_mat(n-1,n-1,[columns[j][k] for k in range(n-1) for j in range(1,n)])
    rhs = acb_mat(n-1,1,[-z for z in columns[0]])
    vector = [acb(1)]+matrix.solve(rhs).entries()
    assert all(z.is_finite() for z in vector)
    absolute = [abs(z).upper() for z in vector]
    costs = [sum(w*xx**j for xx,w in zip(x,absolute)) for j in range(4)]
    # Positive definite H0 and H1 realize the remaining four moments by positive quadrature.
    def feasible(tau):
        z = [mj-tau*c for mj,c in zip(real,costs)]
        return (min(z)>0 and z[0]*z[2]-z[1]**2>0 and z[1]*z[3]-z[2]**2>0)
    low, high = 0, 2**40
    while high-low>1:
        mid = (high+low)//2
        if feasible(arb(mid)/2**40):
            low = mid
        else:
            high = mid
    tau = arb(low)/2**40
    assert low and feasible(tau)
    return vector,tau

def run():
    h=acb(a('1/2'),a('1/8'))
    N=arb(10)**56
    mom,_,_=finite_real_moments(N,ROOT/'verification_microscopic/jet_half_tight.json')
    # Matched finite m3 from the third central difference as in mark_shapes.real_third,
    # choosing t from the two proven error terms at this specific bridge rank.
    _,C,_,_,_,_=constants()
    t=a('1/250')
    m4=(arb(6).exp()*256*576/4**8).upper()
    e=C*(2+3*t)**4/N
    err=arb(2304)/360*(32*e/t**6+2*m4*8112*t**2/147456)
    m3=json.loads((ROOT/'verification_depthone/real_order_control.json').read_text())["moment_dyadics"][3]
    mom.append(restore(m3[0]).union(restore(m3[1]))+arb(0,err.upper()))
    assert mom[3].lower()>a('0.31') and mom[3].upper()<a('0.35')
    groups=[
        ['0','.01','.08','.2','.5','1','2','4','6','9','12'],
        ['0','.04','.15','.35','.7','1.3','2.5','4','6','9','12'],
        ['0','.03','.12','.35','.7','1.3','2','3','4','6','9'],
        ['0','.08','.20','.45','.8','1.3','2.0','3.0','4.0','6.0','9.0'],
        ['0','.10','.30','.70','1.20','1.9','3','4.5','7','10','13'],
        ['0','.04','.20','.60','1.20','2.0','3','5','8','12','18'],
        ['0','.02','.10','.30','.75','1.5','2.2','3','5','8','12'],
    ]
    rs=[8,9,10,11,12,13,14,15,16,17,18,20,24,32]
    best={}
    limiting=[]
    for nodes in groups:
        x=list(map(a,nodes))
        vector,tau=solve_witness(nodes,mom,h)
        masses=[abs(z).upper() for z in vector]
        D=sum(3*m/xx**a('3/4') for xx,m in zip(x[1:],masses[1:]))
        # From |Q_h(R sqrt(x))|<=3 (R sqrt(x))^-3/2 on positive nodes.
        threshold=2
        while not (threshold*x[1].sqrt()>=2 and
                   D/arb(threshold)**a('3/2')<abs(1/(2*h))/2):
            threshold*=2
        const=(a('17/16')*N**a('1/400')*tau*abs(1/(2*h))/2).lower()
        limiting.append((const,nodes,str(tau),threshold))
        for R in rs:
            z=sum(v*q_value(arb(R)*xx.sqrt(),h) for xx,v in zip(x,vector))
            floor=(a('17/16')*N**a('1/400')/R*tau*abs(z)).lower()
            if R not in best or floor>best[R][0]:
                best[R]=(floor,nodes,str(tau))
    base_const,base_nodes,base_tau,r0=max(limiting,key=lambda e:e[0])
    extended=[]
    for bands,cut,end in [(15,16,Fraction(12,5)),(19,20,Fraction(5,2))]:
        with ctx.workprec(1024):
            count=bands+3
            nodes=[str((end*j/count)**2) for j in range(count+1)]
            x=list(map(a,nodes))
            vector,tau=solve_witness(nodes,mom,h)
            z=sum(v*q_value(arb(cut)*xx.sqrt(),h) for xx,v in zip(x,vector))
            floor=(a('17/16')*N**a('1/400')*tau*abs(z)/cut).lower()
            D=sum(3*abs(v).upper()/xx**a('3/4') for xx,v in zip(x[1:],vector[1:]))
            threshold=2
            while not (threshold*x[1].sqrt()>=2 and D/arb(threshold)**a('3/2')<abs(1/(2*h))/2):
                threshold*=2
            coeff=(a('17/16')*N**a('1/400')*tau*abs(1/(2*h))/2).lower()
            extended.append(dict(bands=bands,cutoff=cut,positive_radii="j * (%s) / %d"%(end,count),
                                 tau_dyadic=dyadic(tau),precision_bits=ctx.prec,
                                 floor=dyadic(floor), floor_display=floor.str(14),
                                 asymptotic_threshold=threshold, asymptotic_coefficient_lower=dyadic(coeff),
                                 asymptotic_coefficient_display=coeff.str(14)))
    return dict(extended_features=extended,input=["c=1","h=1/2+i/8","s=1/2+i/20","comparison N=10^56"],
                precision_bits=ctx.prec, matched_m3_interval=[dyadic(mom[3].lower()),dyadic(mom[3].upper())], step_m3='1/250', exact_features=['1','X','X^2','normalized complex B_j for j=1..7'],
                restriction='Any pointwise global cubic majorant priced against real m0,m1,m2,m3; this is not a lower bound on the actual complex tail.',
                lower_shape_charge={R:{"dyadic_lower":dyadic(v),"display":v.str(10),"nodes":n,"tau":t}
                                    for R,(v,n,t) in best.items()},
                all_large_R={"lower_bound_form":"coefficient / R","coefficient_dyadic_lower":dyadic(base_const),
                             "coefficient_display":base_const.str(12),"threshold":r0,"nodes":base_nodes,"tau":base_tau})

if __name__ == '__main__':
    with ctx.workprec(384):
        print(json.dumps(run(),indent=2))
