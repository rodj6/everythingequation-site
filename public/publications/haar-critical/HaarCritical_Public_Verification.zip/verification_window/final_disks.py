"""Exact assembly of this edition's disks and attribution of changes in radius."""
from pathlib import Path
import json
from fractions import Fraction
from math import isqrt
from audit_assembly import verify_base, EXPECTED
from audit_assembly import disk, add, binary, encode, summarize

HERE=Path(__file__).resolve().parent
def read(name):
    return json.loads((HERE/name).read_text())
def priced_bands():
    fresh=read('new_bands_12.json')
    assert fresh['input']==EXPECTED
    unit={r['left']:r for r in fresh['bands']}
    schedule=[]
    for lo in (8,9,10,11,12,16):
        if lo in (8,12,16):
            file={8:'window_89_mean.json',12:'window_1216_mean.json',16:'window_1620_mean.json'}[lo]
            raw=read(file)
            a,b=map(int,raw['parameters']['band'])
            assert raw['input']==EXPECTED and a==lo
            row=raw['sharp']
        else:
            file='new_bands_12.json'
            row=unit[lo]; a=row['left'];b=row['right']
        val=disk(row,'center','radius')
        assert val[1]>=sum(map(binary,row['terms'].values()))
        schedule.append((a,b,file,val))
    return schedule

def tail_rows(name):
    out={}
    for row in read(name):
        assert row['input']==EXPECTED and row['h']==['1/2','1/8'] and row['tilt']==['1/2','1/20']
        out[row['R']]=row
    return out

def produce():
    old,retained,oldtail=verify_base()
    schedule=priced_bands()
    tails_file='joint_refined_tails.json'
    tails=tail_rows(tails_file)
    baseline_set={}
    for end in (8,12,16,20):
        raw=read(f'signed_joint{end}_tail.json')[0]
        assert raw['R']==end and raw['input']==EXPECTED
        baseline_set[end]=raw
    stages={8:retained}
    sources=[]
    for a,b,file,d in schedule:
        stages[b]=add(stages[a],d)
        sources.append(dict(left=a,right=b,file=file,charge=encode(d[1])))
    def result(end,data):
        tail=disk(data,'tail_centre_dyadic','tail_radius_dyadic')
        total=add(stages[end],tail)
        row=summarize(total)
        row.update(cutoff=end,retained_charge=encode(stages[end][1]),tail_charge=encode(tail[1]),
                   tail_midpoint=[encode(z) for z in tail[0]],tail_ledger=data.get('exact_charges',data.get('terms')),
                   comparison_rank=data.get('rank'),M=data.get('frequency_M'))
        return row,total
    matched={};for_table={}
    for end in (8,12,16,20):
        r,_=result(end,baseline_set[end])
        matched[str(end)]=r
    for end,data in sorted(tails.items()):
        r,total=result(end,data)
        for_table[str(end)]=r
    best=min(for_table.values(),key=lambda r:binary(r['radius']))
    assert binary(best['radius'])<old[1]
    delta=old[1]-binary(best['radius'])
    local=binary(for_table['8']['radius'])-binary(best['radius'])
    return dict(input=EXPECTED, unit='absolute complex disk radius',
        opening=summarize(old), opening_retained_repriced=summarize(add(retained,oldtail)),
        projective_bands=sources, matched_five_positive_probes=matched,
        tail_source=tails_file, refined=for_table, best=best,
        improvement_over_published=encode(delta),
        improvement_over_refined_R8=encode(local),
        checks='Exact rational sums, strictly positive |center|-E by integer-square-root bound. Interval charges permit reuse of shared data by triangle inequality.')
if __name__=='__main__':
    print(json.dumps(produce(),indent=2))
