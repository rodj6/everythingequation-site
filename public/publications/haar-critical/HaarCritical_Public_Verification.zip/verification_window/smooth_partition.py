"""Recombine both directly sampled quintic weights on saved real nodes."""
import argparse
from pathlib import Path
import json
from flint import acb, arb, ctx
from sample_band import reduce_grid
from bridge_quad import INPUT, price_quadrature, R
from contour_source import dyadic
from annulus import restore


def cm(d):
    return acb(*(restore(x) for x in d['center']))


def execute(path):
    raw=json.loads(Path(path).read_text())
    c=argparse.Namespace(**raw['parameters'])
    assert raw['input']==INPUT
    with ctx.workprec(c.bits):
        a,b=map(R,c.band)
        radii=[]; weights=[]
        for i in range(c.radial):
            t,w=arb.legendre_p_root(c.radial,i,weight=True)
            radii.append((a+b+(b-a)*t)/2); weights.append((b-a)*w/2)
        prices=price_quadrature(a,b,c.radial,c.angular)
        def read(mode): return reduce_grid(c,raw['samples'],radii,weights,prices,mode>0,mode==2)
        hard,drop,rise=map(read,range(3))
        for out,key in [(hard,'sharp'),(drop,'quintic')]:
            assert cm(out)==cm(raw[key])
            assert restore(out['radius'])==restore(raw[key]['radius'])
        delta=(cm(hard)-cm(drop)-cm(rise)).abs_upper()
        error_sum=restore(drop['terms']['arithmetic'])+restore(rise['terms']['arithmetic'])+restore(hard['terms']['arithmetic'])
        assert delta < error_sum
        cap=restore(raw['physical_cap'])
        positive_loss=(R('17/16')*cap*(b-a)/(2*a*a)).upper()
        assert restore(rise['radius'])+cm(rise).abs_upper() < positive_loss
        for d in (hard,drop,rise): del d['node_means']
        return dict(input=INPUT,from_file=Path(path).name,method='one shared node grid and three separately enclosed weights',hard=hard,
                    falling=drop,rising=rise,original_source_calls=raw['count'],new_source_calls=0,
                    cap_only_rising_modulus=dyadic(positive_loss),signed_rising_modulus=dyadic((cm(rise).abs_upper()+restore(rise['radius'])).upper()),
                    recombined_center_difference=dyadic(delta),permitted_arithmetic_difference=dyadic(error_sum.upper()),
                    separate_window_radii_sum=dyadic((restore(drop['radius'])+restore(rise['radius'])).upper()))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('receipt')
    args=p.parse_args()
    print(json.dumps(execute(args.receipt),indent=2))
