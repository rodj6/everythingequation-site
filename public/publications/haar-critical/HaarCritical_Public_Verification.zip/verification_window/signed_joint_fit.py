"""Diagnostic only: propose a joint signed-control/positive-majorant certificate."""
from pathlib import Path
import sys,json,argparse
import numpy as np
from scipy import special,optimize,integrate,sparse
from signed_fit import nums,H,G
HERE=Path(__file__).resolve().parent
def dz(x): return int(x[0])*2.**x[1] if x[1]<700 else float('inf')
def fit(R,maxb,real_files,polish=False,extra=(),iteration=0):
 mus,rad,panels,edges=nums(maxb)
 rmax=5.
 r=np.unique(np.r_[0,np.linspace(.00005,.25,320),np.linspace(.25,2.25,550),np.linspace(2.25,rmax,420),extra])
 X=r*r; pp=np.c_[np.ones_like(r),X,X**2]
 lo,hi=edges[:-1],edges[1:]
 z,w=special.roots_legendre(55)
 rho=lo[:,None]+(hi-lo)[:,None]*(z+1)/2
 A=(lo**(-2*H)-hi**(-2*H))/(2*H)
 W=(hi-lo)[:,None]*w/2*rho**(-2*H-1)/A[:,None]
 B=np.einsum('kj,nkj->nk',W,special.j0(r[:,None,None]*rho[None,:,:]))
 # A constant plus observed signed shells; allowing a linear signed polynomial adds one degree.
 qb=np.c_[np.ones_like(r),X,B]; m=qb.shape[1]
 samples={}
 for file in real_files:
  tab=json.loads((HERE/file).read_text())
  for row in tab['samples']:
   k=row['r']; eps=dz(row['limiting_error'])+dz(row['finite_discrepancy'])
   if eps>0.025: continue
   if k not in samples or eps<samples[k][1]: samples[k]=(dz(row['real']),eps,file)
 ks=sorted(samples);f=np.array(ks)
 J=special.j0(r[:,None]*f[None,:]);bp=np.c_[pp,J]
 ell=len(f);l=3+ell; dim=l+ell+3*m
 var=10**.14;mu=np.array([samples[k][0] for k in ks]);er=np.array([samples[k][1] for k in ks])
 y=np.empty(len(r),dtype=complex);y[0]=1/(2*H);x=R*r[1:];C=2**(-2*H-1)*special.gamma(-H)/special.gamma(H+1)
 z0=C*x[0]**(2*H)+1/(2*H)+x[0]**2/4/(2-2*H)
 ode=integrate.solve_ivp(lambda t,v:(2*H*v-special.j0(t))/t,[x[0],x[-1]],[z0],dense_output=True,rtol=1e-11,atol=1e-13)
 y[1:]=ode.sol(x)[0]
 # [polynomial/real Bessel, absolute real coeffs, real+imag signed coefficients, absolute signed coeffs]
 rows=[];rhs=[]; guard=1/np.cos(np.pi/16);i0=l+ell
 for ph in np.exp(2j*np.pi*np.arange(16)/16)*guard:
  v=ph*qb
  rows.append(np.c_[-bp,np.zeros((len(r),ell)),-v.real,v.imag,np.zeros((len(r),m))]);rhs.extend(-(ph*y).real)
  v=ph*np.eye(m)
  rows.append(np.c_[np.zeros((m,i0)),v.real,-v.imag,-np.eye(m)]);rhs.extend(np.zeros(m))
  v0=rmax*rmax
  for j,pv in enumerate(([1,v0,v0**2],[0,1,2*v0],[0,0,1])):
   row=np.zeros(dim);row[:3]=-np.array(pv)
   row[i0:i0+2]=ph.real*np.array(pv[:2]);row[i0+m:i0+m+2]=-ph.imag*np.array(pv[:2])
   if j==0:
    row[l:i0]=1.25/np.sqrt(f*rmax)
    row[i0+2*m+2:]=1.25/np.sqrt(lo*rmax)*(1/lo-1/hi)/abs(A)
   rows.append(row[None,:]);rhs.append(-3/(R*rmax)**1.5 if j==0 else 0)
 for sign in (-1,1):
  v=np.zeros((ell,dim));v[:,3:l]=sign*np.eye(ell);v[:,l:i0]=-np.eye(ell);rows.append(v);rhs.extend(np.zeros(ell))
 cost=np.r_[mus[:3]*var,mu*var,er*var,np.zeros(2*m),1e-12,3e-6,rad/abs(G*A)]
 res=optimize.linprog(cost,A_ub=sparse.csr_matrix(np.vstack(rows)),b_ub=np.array(rhs),bounds=[(None,None)]*dim,method='highs')
 assert res.success,res.message
 u=res.x
 code=lambda a: f'{a:.10f}'
 val=u[i0:i0+m]+1j*u[i0+m:i0+2*m];val=np.r_[val[:2],0j,val[2:]]
 if polish and iteration<5:
  # Cutting-plane search at the actual complex modulus: only candidate
  # violations matter. The independent Arb verifier then covers all r.
  rr=np.unique(np.r_[0,np.geomspace(.00005,.05,260),np.linspace(.05,rmax,14000)])
  yy=np.r_[1/(2*H),ode.sol(R*rr[1:])[0]]
  qs=val[0]+val[1]*rr**2
  for wi,rhos,ws in zip(val[3:],rho,W):
   if abs(wi)>1e-14: qs+=wi*(special.j0(rr[:,None]*rhos[None,:])@ws)
  maj=u[0]+u[1]*rr**2+u[2]*rr**4+special.j0(rr[:,None]*f[None,:])@u[3:l]
  d=maj-abs(yy-qs)
  bad=np.flatnonzero((d[1:-1]<d[:-2])&(d[1:-1]<=d[2:])&(d[1:-1]<-2e-6))+1
  if len(bad): return fit(R,maxb,real_files,True,np.unique(np.r_[extra,rr[bad]]),iteration+1)
 return dict(R=R,maxr=rmax,P=list(map(code,u[:3])),q=[[code(v.real),code(v.imag)] for v in val],panels=panels,edges=edges.tolist(),
    pilot_extra_grid=list(map(float,extra)),pilot_polish_iterations=iteration,real_controls=[dict(k=k,file=samples[k][2],co=code(n)) for k,n in zip(ks,u[3:l])],pilot=float(abs(G)*res.fun/R))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('R',type=int);p.add_argument('--max-band',type=int,required=True);p.add_argument('--real-files',nargs='+',default=['audit_real_samples.json']);p.add_argument('--polish',action='store_true');a=p.parse_args()
 print(json.dumps(fit(a.R,a.max_band,a.real_files,a.polish),indent=2))
