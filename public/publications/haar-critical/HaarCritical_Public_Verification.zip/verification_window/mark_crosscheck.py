"""Independent midpoint/hypergeometric proof of the pure real-probe spatial bound."""
import hashlib
import json
from pathlib import Path
from time import perf_counter
from flint import acb,arb,ctx
from mark_shapes import a,exact,HERE

def verify(data):
    start=perf_counter()
    R=a(data["R"])
    h=acb(a("1/2"),a("1/8"))
    p0,p1,p2,*bs=map(a,data["coeff"])
    ks=list(map(a,data["positive_frequencies"]))
    assert len(bs)==len(ks)
    p0+=a("4e-5");p1+=a("1e-7")
    q=acb(*map(a,data["center"]))
    C=acb(2)**(-2*h-1)*(-h).gamma()/(1+h).gamma()
    def P(r):
        return p0+p1*r*r+p2*r**4+sum(b*(k*r).bessel_j(0) for b,k in zip(bs,ks))
    def Q(r):
        if r==0: return 1/(2*h)
        x=R*r
        return C*acb(x)**(2*h)+acb(-x*x/4).hypgeom([-h],[acb(1),1-h])/(2*h)
    left=a("1/1000000");right=a(data['rmax'])
    w=(left*R)**2/4
    origin=(P(arb(0))-abs(Q(arb(0))-q)-abs(C)*left*R-w/((2-2*h.real)*(1-w/4))
            -(abs(p1)+sum(abs(b)*k*k/4 for b,k in zip(bs,ks)))*left**2-abs(p2)*left**4).lower()
    assert origin>0
    jmax=arb(1)
    x=arb(2);z=x.sqrt()*x.bessel_j(0);dz=x.bessel_j(0)/(2*x.sqrt())-x.sqrt()*x.bessel_j(1)
    # Use exact energy rather than the rounded 5/4 in the principal certificate.
    jmax=(dz**2+(1+1/(4*x*x))*z**2).sqrt().upper()
    assert all(k*right>=2 for k in ks)
    g=x.sqrt()*x.bessel_j(1);gp=x.sqrt()*x.bessel_j(0)-x.bessel_j(1)/(2*x.sqrt())
    qmax=((g*g+gp**2/(1-3/(4*x*x))).sqrt()*(1+abs(2*h+2)/(2*h.real+a("3/2")))).upper()
    ray=p0+p1*right**2+p2*right**4-abs(q)-qmax/(R*right)**a("3/2")
    ray-=sum(abs(b)*jmax/(k*right).sqrt() for b,k in zip(bs,ks))
    assert ray>0 and p2>=0 and p1+2*p2*right**2>=0
    JB=sum(abs(b)*k**2/2 for b,k in zip(bs,ks));count=0
    stack=[(left,right)];gaps=[]
    while stack:
        l,u=stack.pop();m=(l+u)/2;d=(u-l)/2;v=Q(m)
        # Independent first derivative Taylor enclosure at the midpoint.
        Q1=(2*h*v-(R*m).bessel_j(0))/m
        P1=2*p1*m+4*p2*m**3-sum(b*k*(k*m).bessel_j(1) for b,k in zip(bs,ks))
        second=abs(2*h-1)*(abs(2*h)+1)/l**2+R/l+2*abs(p1)+12*abs(p2)*u**2+JB
        gap=(P(m)-abs(v-q)-(abs(Q1)+abs(P1))*d-second*d*d/2).lower()
        if gap>0:
            count+=1;gaps.append(gap)
        else:
            assert u-l>a("1e-14"),(str(m),str(gap))
            stack.extend([(l,m),(m,u)])
    return dict(R=int(data["R"]),origin_lower=exact(origin),exterior_lower=exact(ray.lower()),
                finite_intervals=count,min_gap=exact(min(gaps)),precision=ctx.prec,
                seconds=perf_counter()-start,identity="Q=C*x^(2h)+hypgeom([-h];[1,1-h];-x^2/4)/(2h)")
def verify_pinned(filename):
    snap=HERE/"mark_crosscheck_inputs"
    path=snap/filename
    pinned=json.loads((snap/"SHA256.json").read_text())[filename]
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==pinned
    result=verify(json.loads(data))
    return dict(input_file="mark_crosscheck_inputs/"+filename,sha256=pinned,**result)

if __name__=="__main__":
    import sys
    with ctx.workprec(320):
        print(json.dumps([verify_pinned(p) for p in sys.argv[1:]],indent=2))
