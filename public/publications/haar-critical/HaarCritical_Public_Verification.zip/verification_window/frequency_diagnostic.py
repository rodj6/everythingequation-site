"""Finite Haar and Hardy-compression comparisons of the new signed shell (floating)."""
import argparse
import json
import sys
from pathlib import Path
from time import monotonic

import numpy as np
from scipy.special import gamma,roots_legendre
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'verification_depthone'))
from scalar_diagnostic import Finite, Exterior, quadrature


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['finite','exterior'],required=True)
    ap.add_argument('--size',type=int,required=True)
    ap.add_argument('--order',type=int,default=8)
    ap.add_argument('--angles',type=int,default=32)
    a=ap.parse_args()
    h=.5+.125j; s=.5+.05j
    pref=2**(2*h+1)*gamma(1+h)/gamma(-h)
    nodes,weights=roots_legendre(a.order)
    fn=Finite(1,s,a.size,8192) if a.mode=='finite' else Exterior(1,s,a.size,8192,120)
    with threadpool_limits(limits=1):
        for lo,hi in [(8,9),(9,10),(10,11),(11,12),(12,16),(16,20)]:
            start=monotonic()
            rho=(lo+hi+(hi-lo)*nodes)/2
            A=quadrature(rho,fn,a.angles)
            z=pref*(hi-lo)/2*(weights@(rho**(-2*h-1)*A))
            print(json.dumps(dict(input=['c=1','h=1/2+i/8','s=1/2+i/20'],status='floating diagnostic',band=[lo,hi],
                  real=z.real,imag=z.imag,parameters=vars(a),seconds=monotonic()-start)),flush=True)
if __name__=='__main__': main()
