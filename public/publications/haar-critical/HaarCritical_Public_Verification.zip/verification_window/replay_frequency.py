"""Replay fresh physical nodes to a new directory without touching archived receipts.

Example from the source root:
  python verification_window/replay_frequency.py replay-output --through 16
Add --pilots for the frequency and conditioning controls, or --through 20
to include the largest projective determinant run. Printed timing fields
depend on the machine. The interval coordinates are the comparison data.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
INHERITED=HERE.parent/'verification_depthone'


def run(script, args, target):
    print('Running',script.name,'->',target,flush=True)
    with target.open('w') as out:
        subprocess.run([sys.executable,str(script),*map(str,args)],stdout=out,check=True)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('directory',type=Path);p.add_argument('--through',type=int,choices=[9,10,12,16,20],default=16)
    p.add_argument('--pilots',action='store_true');p.add_argument('--workers',type=int)
    options=p.parse_args(); d=options.directory.resolve()
    if d==HERE: raise ValueError('Use a separate output directory.')
    d.mkdir(parents=True,exist_ok=True)
    if options.pilots:
        for saved in sorted(HERE.glob('keyhole_pilot_*.jsonl')):
            c=json.loads(saved.read_text().splitlines()[0])['config']
            args=[]
            for k in ['c','angle','n','bits','extent','project','laguerre']:
                args.extend(('--'+k,c[k]))
            args.extend(('--s',*c['s'],'--sample',*c['sample']))
            run(INHERITED/'contour_source.py',args,d/saved.name)
    bands=[]
    for left in range(8,min(options.through,12)):
        name='window_'+str(left)+str(left+1)+'_raw.json'
        c=json.loads((HERE/name).read_text())['parameters']; c['cpu']=options.workers or c['cpu']
        args=['--range',*c['range']]
        for k in ['order','radial','angular','project','bits','extent','scale','cpu']: args+=['--'+k,c[k]]
        run(INHERITED/'annulus.py',args,d/name); bands.append(d/name)
    run(HERE/'price_new_bands.py',bands,d/'new_bands.json')
    for name in ['window_89_taper.json','window_1216.json','window_1620.json']:
        if name=='window_1216.json' and options.through<16: continue
        if name=='window_1620.json' and options.through<20: continue
        c=json.loads((HERE/name).read_text())['parameters']; c['cpu']=options.workers or c['cpu']
        args=['--band',*c['band']]
        for k in ['order','radial','angular','project','bits','extent','scale','cpu']: args+=['--'+k,c[k]]
        run(HERE/'sample_band.py',args,d/name)
        prefix=Path(name).stem
        run(HERE/'smooth_partition.py',[d/name],d/(prefix+'_split.json'))
        run(HERE/'price_mean_angles.py',[d/name],d/(prefix+'_mean.json'))

if __name__=='__main__':
    main()
