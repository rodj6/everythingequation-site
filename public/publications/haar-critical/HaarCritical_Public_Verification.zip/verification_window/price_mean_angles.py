"""Price real-node angular quadrature using contour L¹ rather than sup norms."""
import argparse
import json
from pathlib import Path
from flint import arb, ctx
from bridge_quad import INPUT, price_quadrature, R
from contour_source import dyadic
from annulus import restore


def cost(a,b,n,k,kind):
    mass=R(10)**R('1/4')
    total=arb()
    choices=[]
    for j in range(n):
        x,w=arb.legendre_p_root(n,j,weight=True)
        r=(a+b+(b-a)*x)/2; t=(1+x)/2
        rise=t**3*(10+t*(-15+6*t))
        factor={'sharp':R(1),'falling':1-rise,'rising':rise}[kind]
        wt=(b-a)*w/(2*r*r)*factor
        bids=[]
        for l in range(1,121):
            sigma=R(l)/40
            u=r*sigma.sinh()
            # The mean over each translated angular contour is bounded
            # by exp(b²/4) I0(z b/2), with I0(z b/2)<=I0(b/2).
            mean=mass*(u*u/4).exp()*(u/2).bessel_i(0)
            if not mean.is_finite(): continue
            charge=(2*R('17/16')*wt*mean/(k*sigma).expm1()).upper()
            bids.append((charge,l))
        best,shift=min(bids,key=lambda p:p[0])
        total+=best; choices.append(shift)
    return total.upper(),choices


def price(raw,rx,weight):
    c=raw['parameters']
    a,b=map(R,c['band'])
    exact,idx=cost(a,b,c['radial'],c['angular'],weight)
    copy=rx.copy()
    terms={k:restore(v) for k,v in copy['terms'].items()}
    assert exact<=terms['angular']
    copy['old_angular']=copy['terms']['angular']; copy['old_radius']=copy['radius']
    terms['angular']=exact
    e=sum(terms.values(),arb()).upper()
    copy.update(terms={k:dyadic(v) for k,v in terms.items()},
                term_display={k:v.str(18) for k,v in terms.items()},radius=dyadic(e),display=e.str(22),
                shifts_numerator=idx,shifts_denominator=40)
    copy.pop('node_means',None)
    return copy


def main():
    p=argparse.ArgumentParser()
    p.add_argument('receipt'); args=p.parse_args()
    raw=json.loads(Path(args.receipt).read_text())
    assert raw['input']==INPUT
    with ctx.workprec(320):
        out={k:price(raw,raw[orig],k) for k,orig in [('sharp','sharp'),('falling','quintic')]}
        out.update(input=INPUT,source=Path(args.receipt).name,parameters=raw['parameters'],count=raw['count'],seconds=raw['seconds'],fallback=raw['fallback'])
        print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
