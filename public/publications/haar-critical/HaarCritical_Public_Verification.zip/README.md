# HaarCritical public verification

Jeremy Rodgers, *Planar Formulas and Microscopic Asymptotics for Derivative Moments of Haar Unitary Characteristic Polynomials*.
Reserved DOI: https://doi.org/10.5281/zenodo.24451371
Website: https://everythingequation.com/
The DOI is reserved; this package makes no publication-status assertion.

## Check the saved evidence

Run from this extracted directory with Python 3.11+ (tested CPython 3.12.14).
No pip dependencies are needed. Node.js is required only for --theorem
(tested Node.js v26.13.1).

    python -X utf8 smoke_test.py
    python -X utf8 smoke_test.py --theorem

Both commands verify every checksum. The four Python checks recombine saved
dyadics and compare parsed JSON exactly against final_disks.json,
shared_disks.json, audit_final_integers.json and positive_controls.json.
Relative file-path separators are normalized for Windows/POSIX comparison;
all arithmetic and hash fields must match exactly. These checks do not
evaluate fresh source determinants. The --theorem option reruns
the standalone Theorem 23.1A two-prime and exact-rational consistency checks
in a temporary directory, without modifying the saved receipt; timestamp and
runtime fields are excluded when comparing its mathematical results. Finite checks
are not a proof of the all-rank theorem; the proof is in the manuscript.

## Optional numerical regeneration

The numerical programs and their recorded inputs/outputs are retained under
verification_new/, verification_microscopic/, verification_depthone/, and
verification_window/. Directory relationships must be preserved. Scripts
with no arguments can overwrite receipts: use a separate copy for experiments.
The manifest identifies the supplied expected outputs, not new calculations.

The optional requirements-regeneration.txt pins an environment recipe. Only
python-flint 0.9.0 is the inherited required Arb binding version; the other
pins are a proposed reproducible pilot environment, not a claim about the
original environment or a tested cold regeneration. Legacy ctypes programs
in verification_new/inherited_harmonic additionally require system GMP and
MPFI and MPFR shared libraries; no third-party binaries are distributed here.

Example fresh source replay from a disposable copy on a supported environment:

    python -m pip install -r requirements-regeneration.txt
    python verification_window/replay_frequency.py replay-output --through 20 --pilots

This is expensive source quadrature, distinct from smoke_test.py. It was not
executed in this production pass. There is no claim of cold regeneration.
The manuscript states the exact hypotheses and limitations of individual
receipts. Diagnostic floating computations are not rigorous certificates.

## Public contents and changes

PUBLIC_FILES.txt is the explicit archive file list. SHA256SUMS.txt hashes all
other archive files. The archive contains text-only programs and numerical
data; no PDF, binary, nested archive, private review, prompt, chat, credential,
contact list, original-source archive or working-directory snapshot is included.
The historical source-preservation checker check_edition.py and its receipt
edition_comparison.json are excluded because they require private production
archives and are not numerical verification. Build-only receipts are excluded.
One script-comment example was changed from an absolute temporary path to
the relative name replay-output. Numerical programs and data are otherwise
unchanged. The new theorem's internal proof audit is not distributed.
