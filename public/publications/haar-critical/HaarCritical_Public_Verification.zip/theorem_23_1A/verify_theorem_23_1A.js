// Standalone independent verification script for Theorem 23.1A
// (Universal polynomial scalar readout through all normal-jet resonances, N >= 3).
// NOTE: Finite-field and rational specializations are consistency checks, NOT a proof
// of the all-rank theorem (which is proved conceptually in Theorem 23.1A).
//
// Checks executed:
//  1. Validation against 3 published exact rational manuscript checkpoints (N=3, 4, 5).
//  2. Two-prime verification (P1 = 1000003, P2 = 1000033) for N = 3, 4, 5, 6 at z = 7/19, s = -41/13
//     and a second regular radius z = 11/25, s = -17/7 for N = 3, 4, 5:
//       - Exact vanishing of Res_{rho=r}(Q_{N,z}) on ALL d coordinates for every r = 1..D
//       - Nonvanishing of pre-contraction residue Res(w_r)
//       - Exact PDE compatibility of residue jets at every degree k > r
//       - Global polynomiality in h (deg <= D) tested at 3 held-out points
//       - Global polynomiality in s (deg <= D + H + H_+) for N = 3, 4, 5
//  3. Failure profile of Theorem 23.1's zero-injection shortcut at N = 5 (r = 1..8).
//  4. Independent resonant specialization at N = 5, z = 2/7, s = -3 (nu = -2), h = 2, 3, 4
//     (unsolved resonances rho = 1, 2, 3) against direct U(5) Weyl/Toeplitz determinants,
//     plus an exact arbitrary-precision BigInt rational computation of U_2(10/7; 2/7) (rho = 1).

const fs = require('fs');
const path = require('path');

function makeField(P) {
  const mod = (x) => ((x % P) + P) % P;
  const add = (a, b) => { const c = a + b; return c >= P ? c - P : c; };
  const sub = (a, b) => { const c = a - b; return c < 0 ? c + P : c; };
  const mul = (a, b) => (a * b) % P;
  const pow = (a, e) => {
    let r = 1, b = mod(a), k = e;
    while (k > 0) { if (k & 1) r = (r * b) % P; b = (b * b) % P; k = Math.floor(k / 2); }
    return r;
  };
  const inv = (a) => { const x = mod(a); if (x === 0) throw new Error('div0'); return pow(x, P - 2); };
  const div = (a, b) => (mod(a) * inv(b)) % P;
  const frac = (num, den = 1) => div(Number(BigInt(num) % BigInt(P)), Number(BigInt(den) % BigInt(P)));
  return { P, mod, add, sub, mul, pow, inv, div, frac };
}

function matInv(A, F) {
  const n = A.length, P = F.P;
  const M = Array.from({ length: n }, (_, i) => {
    const row = new Float64Array(2 * n);
    for (let j = 0; j < n; j++) row[j] = F.mod(A[i][j]);
    row[n + i] = 1;
    return row;
  });
  for (let col = 0; col < n; col++) {
    let piv = -1;
    for (let r = col; r < n; r++) if (M[r][col] !== 0) { piv = r; break; }
    if (piv === -1) throw new Error('singular');
    if (piv !== col) { const t = M[col]; M[col] = M[piv]; M[piv] = t; }
    const invP = F.inv(M[col][col]);
    const prow = M[col];
    for (let j = col; j < 2 * n; j++) prow[j] = (prow[j] * invP) % P;
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const f = M[r][col];
      if (f === 0) continue;
      const rrow = M[r];
      for (let j = col; j < 2 * n; j++) { let v = (rrow[j] - f * prow[j]) % P; rrow[j] = v < 0 ? v + P : v; }
    }
  }
  return M.map(row => Array.from(row.slice(n)));
}

function matMul(A, B, F) {
  const m = A.length, k = B.length, n = B[0].length, P = F.P;
  const C = Array.from({ length: m }, () => new Float64Array(n));
  for (let i = 0; i < m; i++) {
    const Ai = A[i], Ci = C[i];
    for (let t = 0; t < k; t++) {
      const a = Ai[t]; if (a === 0) continue;
      const Bt = B[t];
      for (let j = 0; j < n; j++) Ci[j] += a * Bt[j];
    }
    for (let j = 0; j < n; j++) Ci[j] = Ci[j] % P;
  }
  return C;
}

function genTuples(N) {
  const tuples = [], cur = new Array(N);
  (function rec(pos, minVal) {
    if (pos === N) { tuples.push(cur.slice()); return; }
    for (let v = minVal; v <= 2; v++) { cur[pos] = v; rec(pos + 1, v); }
  })(0, -1);
  const idxMap = new Map();
  tuples.forEach((t, i) => idxMap.set(t.join(','), i));
  return { tuples, idxMap };
}

function singleModeMats(z, nu, F) {
  const a0z = F.mul(F.add(1, F.mul(z, z)), F.inv(z));
  const z4 = () => Array.from({ length: 4 }, () => [0, 0, 0, 0]);
  const Ap0 = z4(), Apt = z4(), Apu = z4(), Am0 = z4(), Amt = z4(), Amu = z4();
  Apt[0][1] = 1; Apt[1][2] = 1; Apt[2][3] = 1;
  Apt[3][3] = a0z; Ap0[3][3] = F.sub(0, F.add(2, nu));
  Apt[3][2] = F.mod(-1); Apu[3][2] = 1; Ap0[3][2] = a0z;
  Apu[3][1] = F.sub(0, a0z); Ap0[3][1] = nu; Apu[3][0] = 1;
  Amu[1][0] = 1; Amu[2][1] = 1; Amu[3][2] = 1;
  Amt[0][3] = 1; Amt[0][2] = F.sub(0, a0z); Am0[0][2] = F.add(1, nu);
  Amt[0][1] = 1; Amu[0][1] = F.mod(-1);
  Amu[0][0] = a0z; Am0[0][0] = F.sub(0, F.add(nu, 1));
  return { Ap0, Apt, Apu, Am0, Amt, Amu };
}

function liftMat(M4, tuples, idxMap, F) {
  const d = tuples.length, N = tuples[0].length;
  const out = Array.from({ length: d }, () => new Float64Array(d));
  for (let row = 0; row < d; row++) {
    const tup = tuples[row], counts = [0, 0, 0, 0];
    for (let k = 0; k < N; k++) counts[tup[k] + 1]++;
    for (let from = 0; from < 4; from++) {
      const c = counts[from]; if (c === 0) continue;
      for (let to = 0; to < 4; to++) {
        const val = M4[from][to]; if (val === 0) continue;
        const nt = tup.slice(); nt[nt.indexOf(from - 1)] = to - 1; nt.sort((a, b) => a - b);
        const col = idxMap.get(nt.join(','));
        out[row][col] = F.add(out[row][col], F.mul(c, val));
      }
    }
  }
  return out;
}

function buildBaseSystem(N, z, F) {
  const { tuples, idxMap } = genTuples(N);
  const d = tuples.length;
  const { Apt, Apu, Amt, Amu } = singleModeMats(z, 0, F);
  const L_Apt = liftMat(Apt, tuples, idxMap, F), L_Apu = liftMat(Apu, tuples, idxMap, F);
  const L_Amt = liftMat(Amt, tuples, idxMap, F), L_Amu = liftMat(Amu, tuples, idxMap, F);
  const Nz = F.mul(N, z);
  const L = Array.from({ length: 2 * d }, () => new Float64Array(2 * d));
  for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) {
    L[i][j] = F.sub(i === j ? Nz : 0, L_Apt[i][j]);
    L[i][d + j] = F.sub(0, L_Apu[i][j]);
    L[d + i][j] = F.sub(0, L_Amt[i][j]);
    L[d + i][d + j] = F.sub(i === j ? Nz : 0, L_Amu[i][j]);
  }
  const invZ = F.inv(z);
  const Ea = new Float64Array(d), Eb = new Float64Array(d);
  for (let i = 0; i < d; i++) {
    const sum = tuples[i].reduce((a, b) => a + b, 0);
    Ea[i] = sum >= 0 ? F.pow(z, sum) : F.pow(invZ, -sum);
    Eb[i] = sum >= 0 ? F.pow(invZ, sum) : F.pow(z, -sum);
  }
  const J = L.map(r => Float64Array.from(r));
  const invEa0 = F.inv(Ea[0]), invEb0 = F.inv(Eb[0]);
  for (let i = 0; i < d; i++) {
    J[i][0] = F.add(J[i][0], F.mul(Ea[i], invEa0));
    J[d + i][d] = F.add(J[d + i][d], F.mul(Eb[i], invEb0));
  }
  const Jinv = matInv(J, F);
  const row0 = Jinv[0].map(x => F.mul(x, invEa0)), rowd = Jinv[d].map(x => F.mul(x, invEb0));
  const Pi = Array.from({ length: 2 * d }, (_, r) => {
    const out = new Float64Array(2 * d);
    if (r < d) for (let j = 0; j < 2 * d; j++) out[j] = F.mul(Ea[r], row0[j]);
    else for (let j = 0; j < 2 * d; j++) out[j] = F.mul(Eb[r - d], rowd[j]);
    return out;
  });
  const ImPi = Array.from({ length: 2 * d }, (_, i) => {
    const row = new Float64Array(2 * d);
    for (let j = 0; j < 2 * d; j++) row[j] = F.sub(i === j ? 1 : 0, Pi[i][j]);
    return row;
  });
  const S0 = matMul(ImPi, matMul(Jinv, ImPi, F), F);
  const invDetE = F.inv(F.sub(F.mul(Ea[0], Eb[d - 1]), F.mul(Eb[0], Ea[d - 1])));
  const piE = (y0, y1) => [
    F.mul(invDetE, F.sub(F.mul(Eb[d - 1], y0), F.mul(Eb[0], y1))),
    F.mul(invDetE, F.sub(F.mul(Ea[0], y1), F.mul(Ea[d - 1], y0)))
  ];
  return { N, z, d, tuples, idxMap, L, S0, Pi, Ea, Eb, piE };
}

function buildG(base, g, nu, F) {
  const { d, tuples, idxMap, z } = base;
  const { Ap0, Am0 } = singleModeMats(z, nu, F);
  const L_Ap0 = liftMat(Ap0, tuples, idxMap, F), L_Am0 = liftMat(Am0, tuples, idxMap, F);
  const G = Array.from({ length: 2 * d }, () => new Float64Array(d));
  for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) {
    G[i][j] = F.sub(i === j ? g : 0, L_Ap0[i][j]);
    G[d + i][j] = F.sub(i === j ? g : 0, L_Am0[i][j]);
  }
  return G;
}

function buildDetPoly(base, nu, F) {
  const { N, z, d, idxMap } = base;
  const H = Math.floor((N - 1) * (N - 1) / 4), D = 2 * H;
  const a0z = F.mul(F.add(1, F.mul(z, z)), F.inv(z));
  const pAdd = (p1, p2) => {
    const out = new Map(p1);
    for (const [k, v] of p2) { const nv = F.add(out.get(k) || 0, v); if (nv === 0) out.delete(k); else out.set(k, nv); }
    return out;
  };
  const pShift = (p, dt, du) => {
    const out = new Map();
    for (const [k, v] of p) { const [i, j] = k.split(',').map(Number); out.set(`${i + dt},${j + du}`, v); }
    return out;
  };
  const pMul = (p1, p2) => {
    const out = new Map();
    for (const [k1, v1] of p1) {
      const [i1, j1] = k1.split(',').map(Number);
      for (const [k2, v2] of p2) {
        const [i2, j2] = k2.split(',').map(Number);
        const key = `${i1 + i2},${j1 + j2}`, nv = F.add(out.get(key) || 0, F.mul(v1, v2));
        if (nv === 0) out.delete(key); else out.set(key, nv);
      }
    }
    return out;
  };
  const R = new Map(), ePlus = m => m > 2 ? m - 2 : 0, eMinus = m => m < -1 ? -1 - m : 0;
  for (let m = -1; m <= 2; m++) { const a = [new Map(), new Map(), new Map(), new Map()]; a[m + 1].set('0,0', 1); R.set(m, a); }
  for (let m = 3; m <= N - 1; m++) {
    const arr = [new Map(), new Map(), new Map(), new Map()];
    const addT = (q, pf) => { const Rq = R.get(q); for (let r = 0; r < 4; r++) if (Rq[r].size) arr[r] = pAdd(arr[r], pMul(pf, pShift(Rq[r], (m - 3) - ePlus(q), 0))); };
    addT(m - 1, new Map([['1,0', a0z], ['0,0', F.sub(0, F.add(m - 1, nu))]]));
    addT(m - 2, new Map([['0,0', F.mul(m - 2, a0z)], ['0,1', 1], ['1,0', F.mod(-1)]]));
    addT(m - 3, new Map([['0,1', F.sub(0, a0z)], ['0,0', F.sub(F.add(nu, 3), m)]]));
    addT(m - 4, new Map([['0,1', 1]]));
    R.set(m, arr);
  }
  for (let m = -2; m >= -(N - 1); m--) {
    const arr = [new Map(), new Map(), new Map(), new Map()];
    const addT = (q, pf) => { const Rq = R.get(q); for (let r = 0; r < 4; r++) if (Rq[r].size) arr[r] = pAdd(arr[r], pMul(pf, pShift(Rq[r], 0, (-2 - m) - eMinus(q)))); };
    addT(m + 4, new Map([['1,0', 1]]));
    addT(m + 3, new Map([['1,0', F.sub(0, a0z)], ['0,0', F.add(F.mod(m + 3), nu)]]));
    addT(m + 2, new Map([['0,0', F.sub(0, F.mul(F.mod(m + 2), a0z))], ['0,1', F.mod(-1)], ['1,0', 1]]));
    addT(m + 1, new Map([['0,1', a0z], ['0,0', F.sub(0, F.sub(F.sub(nu, 1), F.mod(m)))]]));
    R.set(m, arr);
  }
  const out = new Map();
  const cols = Array.from({ length: N }, (_, i) => i);
  (function permute(start, sign) {
    if (start === N) {
      let ep = 0, em = 0; const disps = new Array(N);
      for (let i = 0; i < N; i++) { disps[i] = i - cols[i]; ep += ePlus(disps[i]); em += eMinus(disps[i]); }
      let prod = new Map([['0,0,0,0', new Map([[`${H - ep},${H - em}`, sign === 1 ? 1 : F.mod(-1)]])]]);
      for (let i = 0; i < N; i++) {
        const Ri = R.get(disps[i]), next = new Map();
        for (const [ck, cp] of prod) {
          const cnt = ck.split(',').map(Number);
          for (let r = 0; r < 4; r++) {
            if (!Ri[r].size) continue;
            cnt[r]++; const nk = cnt.join(','); cnt[r]--;
            const mp = pMul(cp, Ri[r]); if (!mp.size) continue;
            next.set(nk, next.has(nk) ? pAdd(next.get(nk), mp) : mp);
          }
        }
        prod = next;
      }
      for (const [ck, cp] of prod) {
        const cnt = ck.split(',').map(Number), tup = [];
        for (let r = 0; r < 4; r++) for (let c = 0; c < cnt[r]; c++) tup.push(r - 1);
        const tidx = idxMap.get(tup.join(','));
        for (const [ij, val] of cp) {
          let vec = out.get(ij); if (!vec) { vec = new Float64Array(d); out.set(ij, vec); }
          vec[tidx] = F.add(vec[tidx], val);
        }
      }
      return;
    }
    for (let i = start; i < N; i++) {
      [cols[start], cols[i]] = [cols[i], cols[start]];
      permute(start + 1, i === start ? sign : -sign);
      [cols[start], cols[i]] = [cols[i], cols[start]];
    }
  })(0, 1);
  return { H, D, detPoly: out };
}

function computeRow(base, detData, h, s, F, useShortcut) {
  const { N, d, S0, Pi, Ea, Eb, piE } = base;
  const { H, D, detPoly } = detData;
  const g = F.add(h, H), nu = F.sub(F.sub(0, N), s), rho = F.add(g, F.mul(N, F.add(1, nu)));
  const G = buildG(base, g, nu, F);
  const Id = Array.from({ length: d }, (_, i) => { const r = new Float64Array(d); r[i] = 1; return r; });
  let w = null;
  if (!useShortcut) {
    const Rmul = (M2d) => { const out = Array.from({ length: d }, () => new Float64Array(d)); for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) out[i][j] = F.add(M2d[i][j], M2d[d + i][j]); return out; };
    const B = Rmul(matMul(Pi, G, F)), Bm = [];
    let cur = matMul(S0, G, F);
    for (let m = 0; m < D; m++) { const rm = Rmul(cur); Bm.push(m % 2 === 0 ? rm : rm.map(r => r.map(x => F.sub(0, x)))); if (m + 1 < D) cur = matMul(S0, cur, F); }
    w = [Id];
    for (let k = 1; k <= D; k++) {
      const rhs = Array.from({ length: d }, () => new Float64Array(d));
      for (let m = 0; m < k; m++) { const prod = matMul(Bm[m], w[k - 1 - m], F); for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) rhs[i][j] = F.add(rhs[i][j], prod[i][j]); }
      const invK = F.inv(k), cB = F.mul(invK, F.inv(F.sub(k, rho))), Brhs = matMul(B, rhs, F);
      w.push(Array.from({ length: d }, (_, i) => { const row = new Float64Array(d); for (let j = 0; j < d; j++) row[j] = F.add(F.mul(invK, rhs[i][j]), F.mul(cB, Brhs[i][j])); return row; }));
    }
  }
  const X = new Map([['0,0', Id]]);
  let fact = 1;
  for (let k = 1; k <= D; k++) {
    fact = F.mul(fact, k);
    const U = new Array(k + 1), V = new Array(k);
    for (let i = 0; i <= k - 1; i++) {
      const j = k - 1 - i, Xij = X.get(`${i},${j}`), GX = matMul(G, Xij, F);
      if (i > 0) for (let r = 0; r < d; r++) for (let c = 0; c < d; c++) GX[r][c] = F.sub(GX[r][c], F.mul(i, Xij[r][c]));
      if (j > 0) for (let r = 0; r < d; r++) for (let c = 0; c < d; c++) GX[d + r][c] = F.sub(GX[d + r][c], F.mul(j, Xij[r][c]));
      const sol = matMul(S0, GX, F);
      U[i + 1] = sol.slice(0, d); V[i] = sol.slice(d, 2 * d);
    }
    for (let i = 1; i < k; i++) {
      const Xik = U[i].map(r => Float64Array.from(r));
      for (let col = 0; col < d; col++) {
        const [alpha] = piE(F.sub(V[i][0][col], U[i][0][col]), F.sub(V[i][d - 1][col], U[i][d - 1][col]));
        for (let r = 0; r < d; r++) Xik[r][col] = F.add(Xik[r][col], F.mul(alpha, Ea[r]));
      }
      X.set(`${i},${k - i}`, Xik);
    }
    if (useShortcut) { X.set(`${k},0`, U[k]); X.set(`0,${k}`, V[0]); }
    else {
      const Xk0 = U[k].map(r => Float64Array.from(r)), X0k = V[0].map(r => Float64Array.from(r));
      const binom = [1]; for (let i = 1; i <= k; i++) binom.push(F.div(F.mul(binom[i - 1], k - i + 1), i));
      for (let col = 0; col < d; col++) {
        let r0 = F.sub(F.sub(F.mul(fact, w[k][0][col]), U[k][0][col]), V[0][0][col]);
        let r1 = F.sub(F.sub(F.mul(fact, w[k][d - 1][col]), U[k][d - 1][col]), V[0][d - 1][col]);
        for (let i = 1; i < k; i++) { const Xi = X.get(`${i},${k - i}`); r0 = F.sub(r0, F.mul(binom[i], Xi[0][col])); r1 = F.sub(r1, F.mul(binom[i], Xi[d - 1][col])); }
        const [ck, dk] = piE(r0, r1);
        for (let r = 0; r < d; r++) { Xk0[r][col] = F.add(Xk0[r][col], F.mul(ck, Ea[r])); X0k[r][col] = F.add(X0k[r][col], F.mul(dk, Eb[r])); }
      }
      X.set(`${k},0`, Xk0); X.set(`0,${k}`, X0k);
    }
  }
  const Q = new Float64Array(d);
  for (const [ij, pvec] of detPoly) {
    const [ti, uj] = ij.split(',').map(Number), Xij = X.get(ij), sgn = ((ti + uj) % 2 === 0) ? 1 : F.mod(-1);
    for (let r = 0; r < d; r++) {
      const pr = F.mul(sgn, pvec[r]); if (pr === 0) continue;
      const Xr = Xij[r];
      for (let c = 0; c < d; c++) Q[c] = (Q[c] + pr * Xr[c]) % F.P;
    }
  }
  return Q;
}

function computeExactResidue(base, detData, r, s, F) {
  const { N, d, S0, Pi, Ea, Eb, piE } = base;
  const { D, detPoly } = detData;
  const nu = F.sub(F.sub(0, N), s), g = F.sub(r, F.mul(N, F.add(1, nu)));
  const G = buildG(base, g, nu, F);
  const Rmul = (M2d) => { const out = Array.from({ length: d }, () => new Float64Array(d)); for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) out[i][j] = F.add(M2d[i][j], M2d[d + i][j]); return out; };
  const B = Rmul(matMul(Pi, G, F)), Bm = [];
  let cur = matMul(S0, G, F);
  for (let m = 0; m < D; m++) { const rm = Rmul(cur); Bm.push(m % 2 === 0 ? rm : rm.map(row => row.map(x => F.sub(0, x)))); if (m + 1 < D) cur = matMul(S0, cur, F); }
  const Id = Array.from({ length: d }, (_, i) => { const row = new Float64Array(d); row[i] = 1; return row; });
  const wReg = [Id];
  for (let k = 1; k < r; k++) {
    const rhs = Array.from({ length: d }, () => new Float64Array(d));
    for (let m = 0; m < k; m++) { const prod = matMul(Bm[m], wReg[k - 1 - m], F); for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) rhs[i][j] = F.add(rhs[i][j], prod[i][j]); }
    const invK = F.inv(k), cB = F.mul(invK, F.inv(F.sub(k, r))), Brhs = matMul(B, rhs, F);
    wReg.push(Array.from({ length: d }, (_, i) => { const row = new Float64Array(d); for (let j = 0; j < d; j++) row[j] = F.add(F.mul(invK, rhs[i][j]), F.mul(cB, Brhs[i][j])); return row; }));
  }
  const rhsR = Array.from({ length: d }, () => new Float64Array(d));
  for (let m = 0; m < r; m++) { const prod = matMul(Bm[m], wReg[r - 1 - m], F); for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) rhsR[i][j] = F.add(rhsR[i][j], prod[i][j]); }
  const negInvR = F.sub(0, F.inv(r));
  const resWr = matMul(B, rhsR, F).map(row => row.map(x => F.mul(negInvR, x)));
  const resWrNonzero = resWr.some(row => row.some(x => x !== 0));
  let decompExact = true;
  for (let col = 0; col < d; col++) {
    const [a, b] = piE(resWr[0][col], resWr[d - 1][col]);
    for (let i = 0; i < d; i++) if (F.add(F.mul(a, Ea[i]), F.mul(b, Eb[i])) !== resWr[i][col]) decompExact = false;
  }
  let factR = 1; for (let k = 1; k <= r; k++) factR = F.mul(factR, k);
  const resW2 = new Array(D + 1).fill(null);
  resW2[r] = Array.from({ length: d }, (_, i) => Float64Array.from([Ea[i], Eb[i]]));
  for (let k = r + 1; k <= D; k++) {
    const rhs = Array.from({ length: d }, () => new Float64Array(2));
    for (let m = 0; m <= k - 1 - r; m++) { const prod = matMul(Bm[m], resW2[k - 1 - m], F); for (let i = 0; i < d; i++) for (let c = 0; c < 2; c++) rhs[i][c] = F.add(rhs[i][c], prod[i][c]); }
    const invK = F.inv(k), cB = F.mul(invK, F.inv(F.sub(k, r))), Brhs = matMul(B, rhs, F);
    resW2[k] = Array.from({ length: d }, (_, i) => Float64Array.from([
      F.add(F.mul(invK, rhs[i][0]), F.mul(cB, Brhs[i][0])),
      F.add(F.mul(invK, rhs[i][1]), F.mul(cB, Brhs[i][1]))
    ]));
  }
  const resX = new Map();
  resX.set(`${r},0`, Array.from({ length: d }, (_, i) => Float64Array.from([F.mul(factR, Ea[i]), 0])));
  resX.set(`0,${r}`, Array.from({ length: d }, (_, i) => Float64Array.from([0, F.mul(factR, Eb[i])])));
  for (let i = 1; i < r; i++) resX.set(`${i},${r - i}`, Array.from({ length: d }, () => new Float64Array(2)));
  let compatExact = true, fact = factR;
  for (let k = r + 1; k <= D; k++) {
    fact = F.mul(fact, k);
    const U = new Array(k + 1), V = new Array(k);
    for (let i = 0; i <= k - 1; i++) {
      const j = k - 1 - i, Xij = resX.get(`${i},${j}`), GX = matMul(G, Xij, F);
      if (i > 0) for (let rr = 0; rr < d; rr++) for (let c = 0; c < 2; c++) GX[rr][c] = F.sub(GX[rr][c], F.mul(i, Xij[rr][c]));
      if (j > 0) for (let rr = 0; rr < d; rr++) for (let c = 0; c < 2; c++) GX[d + rr][c] = F.sub(GX[d + rr][c], F.mul(j, Xij[rr][c]));
      const PiRhs = matMul(Pi, GX, F);
      for (let rr = 0; rr < 2 * d; rr++) for (let c = 0; c < 2; c++) if (PiRhs[rr][c] !== 0) compatExact = false;
      const sol = matMul(S0, GX, F); U[i + 1] = sol.slice(0, d); V[i] = sol.slice(d, 2 * d);
    }
    for (let i = 1; i < k; i++) {
      const Xik = U[i].map(row => Float64Array.from(row));
      for (let col = 0; col < 2; col++) {
        const [alpha, negBeta] = piE(F.sub(V[i][0][col], U[i][0][col]), F.sub(V[i][d - 1][col], U[i][d - 1][col]));
        for (let rr = 0; rr < d; rr++) { Xik[rr][col] = F.add(Xik[rr][col], F.mul(alpha, Ea[rr])); if (Xik[rr][col] !== F.sub(V[i][rr][col], F.mul(negBeta, Eb[rr]))) compatExact = false; }
      }
      resX.set(`${i},${k - i}`, Xik);
    }
    const Xk0 = U[k].map(row => Float64Array.from(row)), X0k = V[0].map(row => Float64Array.from(row));
    const binom = [1]; for (let i = 1; i <= k; i++) binom.push(F.div(F.mul(binom[i - 1], k - i + 1), i));
    for (let col = 0; col < 2; col++) {
      let r0 = F.sub(F.sub(F.mul(fact, resW2[k][0][col]), U[k][0][col]), V[0][0][col]);
      let r1 = F.sub(F.sub(F.mul(fact, resW2[k][d - 1][col]), U[k][d - 1][col]), V[0][d - 1][col]);
      for (let i = 1; i < k; i++) { const Xi = resX.get(`${i},${k - i}`); r0 = F.sub(r0, F.mul(binom[i], Xi[0][col])); r1 = F.sub(r1, F.mul(binom[i], Xi[d - 1][col])); }
      const [ck, dk] = piE(r0, r1);
      for (let rr = 0; rr < d; rr++) {
        let fullRem = F.sub(F.sub(F.mul(fact, resW2[k][rr][col]), U[k][rr][col]), V[0][rr][col]);
        for (let i = 1; i < k; i++) fullRem = F.sub(fullRem, F.mul(binom[i], resX.get(`${i},${k - i}`)[rr][col]));
        if (F.add(F.mul(ck, Ea[rr]), F.mul(dk, Eb[rr])) !== fullRem) compatExact = false;
        Xk0[rr][col] = F.add(Xk0[rr][col], F.mul(ck, Ea[rr])); X0k[rr][col] = F.add(X0k[rr][col], F.mul(dk, Eb[rr]));
      }
    }
    resX.set(`${k},0`, Xk0); resX.set(`0,${k}`, X0k);
  }
  const resQ2 = [0, 0];
  for (const [ij, pvec] of detPoly) {
    const [ti, uj] = ij.split(',').map(Number); if (ti + uj < r) continue;
    const Xij = resX.get(ij), sgn = ((ti + uj) % 2 === 0) ? 1 : F.mod(-1);
    for (let rr = 0; rr < d; rr++) { const pr = F.mul(sgn, pvec[rr]); if (pr === 0) continue; resQ2[0] = (resQ2[0] + pr * Xij[rr][0]) % F.P; resQ2[1] = (resQ2[1] + pr * Xij[rr][1]) % F.P; }
  }
  return { allZero: resQ2[0] === 0 && resQ2[1] === 0 && decompExact, resWrNonzero, compatExact };
}

function testShortcutInjection(base, detData, r, h, s, F) {
  const { N, d, S0, Ea, Eb, piE } = base;
  const { H, D, detPoly } = detData;
  const g = F.add(h, H), nu = F.sub(F.sub(0, N), s), G = buildG(base, g, nu, F);
  const X = new Map();
  X.set(`${r},0`, Array.from({ length: d }, (_, i) => Float64Array.from([Ea[i], 0])));
  X.set(`0,${r}`, Array.from({ length: d }, (_, i) => Float64Array.from([0, Eb[i]])));
  for (let i = 1; i < r; i++) X.set(`${i},${r - i}`, Array.from({ length: d }, () => new Float64Array(2)));
  for (let k = r + 1; k <= D; k++) {
    const U = new Array(k + 1), V = new Array(k);
    for (let i = 0; i <= k - 1; i++) {
      const j = k - 1 - i, Xij = X.get(`${i},${j}`), GX = matMul(G, Xij, F);
      if (i > 0) for (let rr = 0; rr < d; rr++) for (let c = 0; c < 2; c++) GX[rr][c] = F.sub(GX[rr][c], F.mul(i, Xij[rr][c]));
      if (j > 0) for (let rr = 0; rr < d; rr++) for (let c = 0; c < 2; c++) GX[d + rr][c] = F.sub(GX[d + rr][c], F.mul(j, Xij[rr][c]));
      const sol = matMul(S0, GX, F); U[i + 1] = sol.slice(0, d); V[i] = sol.slice(d, 2 * d);
    }
    for (let i = 1; i < k; i++) {
      const Xik = U[i].map(row => Float64Array.from(row));
      for (let col = 0; col < 2; col++) {
        const [alpha] = piE(F.sub(V[i][0][col], U[i][0][col]), F.sub(V[i][d - 1][col], U[i][d - 1][col]));
        for (let rr = 0; rr < d; rr++) Xik[rr][col] = F.add(Xik[rr][col], F.mul(alpha, Ea[rr]));
      }
      X.set(`${i},${k - i}`, Xik);
    }
    X.set(`${k},0`, U[k]); X.set(`0,${k}`, V[0]);
  }
  const out = [0, 0];
  for (const [ij, pvec] of detPoly) {
    const [ti, uj] = ij.split(',').map(Number); if (ti + uj < r) continue;
    const Xij = X.get(ij), sgn = ((ti + uj) % 2 === 0) ? 1 : F.mod(-1);
    for (let rr = 0; rr < d; rr++) { const pr = F.mul(sgn, pvec[rr]); if (pr === 0) continue; out[0] = (out[0] + pr * Xij[rr][0]) % F.P; out[1] = (out[1] + pr * Xij[rr][1]) % F.P; }
  }
  return out;
}

function lagrangeEval(xs, vecs, x0, F) {
  const n = xs.length, d = vecs[0].length, out = new Float64Array(d);
  for (let i = 0; i < n; i++) {
    let num = 1, den = 1;
    for (let j = 0; j < n; j++) { if (i === j) continue; num = F.mul(num, F.sub(x0, xs[j])); den = F.mul(den, F.sub(xs[i], xs[j])); }
    const w = F.div(num, den);
    for (let k = 0; k < d; k++) out[k] = F.add(out[k], F.mul(w, vecs[i][k]));
  }
  return out;
}

function evalMomentTuple(N, z, M, disps, nuType, F) {
  const z2 = F.mul(z, z), om = F.sub(1, z2), op = F.add(1, z2);
  const invOm = F.inv(om), invOm3 = F.pow(invOm, 3);
  const oneAngle = (k) => {
    const ak = Math.abs(k);
    if (nuType === 0) return k === 0 ? 1 : 0;
    if (nuType === -1) return F.mul(F.pow(z, ak), invOm);
    if (nuType === -2) return F.mul(F.mul(F.pow(z, ak), F.add(op, F.mul(ak, om))), invOm3);
    throw new Error('unsupported nu');
  };
  const fact = [1], invFact = [1];
  for (let i = 1; i <= M; i++) { fact.push(F.mul(fact[i - 1], i)); invFact.push(F.inv(fact[i])); }
  const Nz = F.mul(N, z), cA = [];
  for (let a = 0; a <= M; a++) {
    const bin = F.mul(fact[M], F.mul(invFact[a], invFact[M - a]));
    cA.push(F.mul(a % 2 === 0 ? 1 : F.mod(-1), F.mul(bin, F.pow(Nz, M - a))));
  }
  const makeS = (j) => Array.from({ length: M + 1 }, (_, p) =>
    Float64Array.from({ length: M + 1 }, (_, q) => F.mul(F.mul(invFact[p], invFact[q]), oneAngle(j + p - q)))
  );
  const mul2D = (A, B) => {
    const C = Array.from({ length: M + 1 }, () => new Float64Array(M + 1));
    for (let p1 = 0; p1 <= M; p1++) for (let q1 = 0; q1 <= M; q1++) {
      const a = A[p1][q1]; if (a === 0) continue;
      for (let p2 = 0; p2 <= M - p1; p2++) for (let q2 = 0; q2 <= M - q1; q2++) {
        const b = B[p2][q2]; if (b !== 0) C[p1 + p2][q1 + q2] = (C[p1 + p2][q1 + q2] + a * b) % F.P;
      }
    }
    return C;
  };
  let prod = makeS(disps[0]);
  for (let m = 1; m < N; m++) prod = mul2D(prod, makeS(disps[m]));
  let total = 0;
  for (let a = 0; a <= M; a++) for (let b = 0; b <= M; b++) total = F.add(total, F.mul(F.mul(cA[a], cA[b]), F.mul(F.mul(fact[a], fact[b]), prod[a][b])));
  return total;
}

function directU(N, z, hInt, nuType, F) {
  const cols = Array.from({ length: N }, (_, i) => i), mults = new Map();
  (function permute(start, sign) {
    if (start === N) {
      const key = cols.map((c, i) => i - c).sort((a, b) => a - b).join(',');
      mults.set(key, (mults.get(key) || 0) + sign); return;
    }
    for (let i = start; i < N; i++) { [cols[start], cols[i]] = [cols[i], cols[start]]; permute(start + 1, i === start ? sign : -sign); [cols[start], cols[i]] = [cols[i], cols[start]]; }
  })(0, 1);
  let total = 0;
  for (const [key, m] of mults) if (m !== 0) total = F.add(total, F.mul(F.mod(m), evalMomentTuple(N, z, hInt, key.split(',').map(Number), nuType, F)));
  return total;
}

// Exact BigInt rational direct U(5) determinant at N=5, z=2/7, s=-3 (nu=-2), h=2 (rho=1)
function exactRationalDirectU5_h2() {
  const gcd = (a, b) => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) { [a, b] = [b, a % b]; } return a; };
  const rat = (n, d = 1n) => { if (d < 0n) { n = -n; d = -d; } const g = gcd(n, d); return [n / g, d / g]; };
  const rAdd = (x, y) => rat(x[0] * y[1] + y[0] * x[1], x[1] * y[1]);
  const rMul = (x, y) => rat(x[0] * y[0], x[1] * y[1]);
  const zN = 2n, zD = 7n;
  const omN = 45n, omD = 49n; // 1 - 4/49 = 45/49
  const opN = 53n, opD = 49n; // 1 + 4/49 = 53/49
  const om3N = omN * omN * omN, om3D = omD * omD * omD;
  const oneAngle = (k) => {
    const ak = BigInt(Math.abs(k));
    const zpN = zN ** ak, zpD = zD ** ak;
    const linN = opN + ak * omN, linD = 49n;
    return rat(zpN * linN * om3D, zpD * linD * om3N);
  };
  const N = 5, M = 2;
  const fact = [1n, 1n, 2n];
  const cA = [rat(100n, 49n), rat(-20n, 7n), rat(1n, 1n)]; // (10/7 - S)^2 = 100/49 - 20/7 S + S^2
  const evalTup = (disps) => {
    const makeS = (j) => Array.from({ length: 3 }, (_, p) =>
      Array.from({ length: 3 }, (_, q) => rMul(rat(1n, fact[p] * fact[q]), oneAngle(j + p - q)))
    );
    const mul2D = (A, B) => {
      const C = Array.from({ length: 3 }, () => Array.from({ length: 3 }, () => [0n, 1n]));
      for (let p1 = 0; p1 <= 2; p1++) for (let q1 = 0; q1 <= 2; q1++)
        for (let p2 = 0; p2 <= 2 - p1; p2++) for (let q2 = 0; q2 <= 2 - q1; q2++)
          C[p1 + p2][q1 + q2] = rAdd(C[p1 + p2][q1 + q2], rMul(A[p1][q1], B[p2][q2]));
      return C;
    };
    let prod = makeS(disps[0]);
    for (let m = 1; m < N; m++) prod = mul2D(prod, makeS(disps[m]));
    let tot = [0n, 1n];
    for (let a = 0; a <= 2; a++) for (let b = 0; b <= 2; b++) {
      const mom = rMul(rat(fact[a] * fact[b], 1n), prod[a][b]);
      tot = rAdd(tot, rMul(rMul(cA[a], cA[b]), mom));
    }
    return tot;
  };
  const cols = [0, 1, 2, 3, 4], mults = new Map();
  (function permute(start, sign) {
    if (start === 5) {
      const key = cols.map((c, i) => i - c).sort((a, b) => a - b).join(',');
      mults.set(key, (mults.get(key) || 0) + sign); return;
    }
    for (let i = start; i < 5; i++) { [cols[start], cols[i]] = [cols[i], cols[start]]; permute(start + 1, i === start ? sign : -sign); [cols[start], cols[i]] = [cols[i], cols[start]]; }
  })(0, 1);
  let tot = [0n, 1n];
  for (const [key, m] of mults) if (m !== 0) tot = rAdd(tot, rMul(rat(BigInt(m), 1n), evalTup(key.split(',').map(Number))));
  return tot;
}

const receipt = {
  generated_at: new Date().toISOString(),
  note: 'Consistency checks only; universal all-rank claim is proved conceptually in Theorem 23.1A.',
  primes: [1000003, 1000033],
  manuscript_checkpoints: [],
  residue_and_polynomial_checks: [],
  n5_shortcut_profile: [],
  n5_resonant_specialization: [],
  exact_rational_n5_rho1: null,
  all_passed: true,
};

// 1. Exact rational U(5) determinant at N=5, z=2/7, s=-3, h=2 (rho=1)
const [u5Num, u5Den] = exactRationalDirectU5_h2();
receipt.exact_rational_n5_rho1 = {
  tuple: { N: 5, z: '2/7', s: -3, nu: -2, h: 2, rho: 1 },
  U_exact_rational: `${u5Num}/${u5Den}`,
  mod_1000003: makeField(1000003).frac(u5Num, u5Den),
  mod_1000033: makeField(1000033).frac(u5Num, u5Den),
};
console.log(`Exact rational U_2(10/7; 2/7) at N=5, s=-3 (rho=1): ${u5Num}/${u5Den}`);

for (const P of [1000003, 1000033]) {
  const F = makeField(P);
  console.log(`\n==================== PRIME P = ${P} ====================`);

  // Check 1: Published manuscript checkpoints (mod P)
  {
    // N=3, z=2/5, h=1, s=-2 (rho=2) -> U=41/21
    const base3 = buildBaseSystem(3, F.frac(2, 5), F), dd3 = buildDetPoly(base3, F.mod(-1), F);
    const W3 = base3.tuples.map(t => evalMomentTuple(3, F.frac(2, 5), 2, t, -1, F));
    const hs3 = [10, 11, 12], Q3 = lagrangeEval(hs3, hs3.map(hv => computeRow(base3, dd3, hv, F.mod(-2), F, false)), 1, F);
    let dot3 = 0; for (let i = 0; i < base3.d; i++) dot3 = F.add(dot3, F.mul(Q3[i], W3[i]));
    const u3 = F.div(dot3, 4), ok3 = u3 === F.frac(41, 21);
    // N=4, z=14/25, h=2, s=-3 (rho=4) -> U=8302946/268125
    const base4 = buildBaseSystem(4, F.frac(14, 25), F), dd4 = buildDetPoly(base4, F.mod(-1), F);
    const W4 = base4.tuples.map(t => evalMomentTuple(4, F.frac(14, 25), 4, t, -1, F));
    const hs4 = [10, 11, 12, 13, 14], Q4 = lagrangeEval(hs4, hs4.map(hv => computeRow(base4, dd4, hv, F.mod(-3), F, false)), 2, F);
    let dot4 = 0; for (let i = 0; i < base4.d; i++) dot4 = F.add(dot4, F.mul(Q4[i], W4[i]));
    const u4 = F.div(dot4, 144), ok4 = u4 === F.frac(8302946, 268125);
    // N=5, z=2/7, h=2, s=-5 (rho=11) -> U=34402/2401
    const base5 = buildBaseSystem(5, F.frac(2, 7), F), dd5 = buildDetPoly(base5, 0, F);
    const W5 = base5.tuples.map(t => evalMomentTuple(5, F.frac(2, 7), 6, t, 0, F));
    const Q5c = computeRow(base5, dd5, 2, F.mod(-5), F, false), Q5s = computeRow(base5, dd5, 2, F.mod(-5), F, true);
    let d5c = 0, d5s = 0; for (let i = 0; i < base5.d; i++) { d5c = F.add(d5c, F.mul(Q5c[i], W5[i])); d5s = F.add(d5s, F.mul(Q5s[i], W5[i])); }
    const poch5 = F.mul(360, 360), u5c = F.div(d5c, poch5), u5s = F.div(d5s, poch5), ok5c = u5c === F.frac(34402, 2401), ok5s = u5s === F.frac(34402, 2401);
    receipt.manuscript_checkpoints.push({ P, N3_ok: ok3, N4_ok: ok4, N5_canon_ok: ok5c, N5_shortcut_ok: ok5s });
    if (!ok3 || !ok4 || !ok5c || ok5s) receipt.all_passed = false;
    console.log(`Checkpoints: N=3:${ok3}, N=4:${ok4}, N=5 canon:${ok5c}, N=5 shortcut:${ok5s} (expected false)`);
  }

  // Check 2: Universal residue vanishing & polynomiality across ranks & two regular radii
  const configs = [
    [3, 7, 19, -41, 13], [4, 7, 19, -41, 13], [5, 7, 19, -41, 13], [6, 7, 19, -41, 13],
    [3, 11, 25, -17, 7], [4, 11, 25, -17, 7], [5, 11, 25, -17, 7],
  ];
  for (const [N, zN, zD, sN, sD] of configs) {
    const t0 = Date.now(), z = F.frac(zN, zD), s = F.frac(sN, sD), nu = F.sub(F.sub(0, N), s);
    const base = buildBaseSystem(N, z, F), detData = buildDetPoly(base, nu, F), { H, D } = detData;
    const Hplus = Math.floor((N - 2) * (N - 2) / 4);
    let allResZero = true, allCompat = true, allWrNonzero = true;
    for (let r = 1; r <= D; r++) {
      const res = computeExactResidue(base, detData, r, s, F);
      if (!res.allZero) allResZero = false;
      if (!res.compatExact) allCompat = false;
      if (!res.resWrNonzero) allWrNonzero = false;
    }
    const sampleHs = [], sampleQs = [];
    for (let hC = 100; sampleHs.length < D + 1; hC++) {
      const rho = F.add(F.add(hC, H), F.mul(N, F.add(1, nu)));
      let bad = false; for (let r = 1; r <= D; r++) if (rho === r) bad = true;
      if (!bad) { sampleHs.push(hC); sampleQs.push(computeRow(base, detData, hC, s, F, false)); }
    }
    let polyH = true;
    for (const hT of [200, 333, 777]) {
      const Qt = computeRow(base, detData, hT, s, F, false), Qp = lagrangeEval(sampleHs, sampleQs, hT, F);
      for (let i = 0; i < base.d; i++) if (Qt[i] !== Qp[i]) polyH = false;
    }
    let exactDegH = D;
    const Qt200 = computeRow(base, detData, 200, s, F, false);
    for (let deg = 0; deg <= D; deg++) {
      const qp = lagrangeEval(sampleHs.slice(0, deg + 1), sampleQs.slice(0, deg + 1), 200, F);
      if (Qt200.every((x, i) => x === qp[i])) { exactDegH = deg; break; }
    }
    let polyS = null, exactDegS = null;
    if (N <= 5 && zN === 7) {
      const maxS = D + H + Hplus, sampleSs = [], sampleQss = [];
      for (let sC = 50; sampleSs.length < maxS + 1; sC++) {
        const nuC = F.sub(F.sub(0, N), sC), rhoC = F.add(F.add(200, H), F.mul(N, F.add(1, nuC)));
        let bad = false; for (let r = 1; r <= D; r++) if (rhoC === r) bad = true;
        if (!bad) { sampleSs.push(sC); sampleQss.push(computeRow(base, buildDetPoly(base, nuC, F), 200, sC, F, false)); }
      }
      const Qst = computeRow(base, buildDetPoly(base, F.sub(F.sub(0, N), 500), F), 200, 500, F, false);
      polyS = Qst.every((x, i) => x === lagrangeEval(sampleSs, sampleQss, 500, F)[i]);
      for (let deg = 0; deg <= maxS; deg++) {
        if (Qst.every((x, i) => x === lagrangeEval(sampleSs.slice(0, deg + 1), sampleQss.slice(0, deg + 1), 500, F)[i])) { exactDegS = deg; break; }
      }
    }
    if (!allResZero || !allCompat || !allWrNonzero || !polyH || polyS === false) receipt.all_passed = false;
    receipt.residue_and_polynomial_checks.push({
      P, N, z: `${zN}/${zD}`, s: `${sN}/${sD}`, d: base.d, H, D,
      all_residues_zero: allResZero, pre_contraction_nonzero: allWrNonzero, exact_pde_compat: allCompat,
      poly_in_h: polyH, exact_deg_h: exactDegH, bound_deg_h: D,
      poly_in_s: polyS, exact_deg_s: exactDegS, bound_deg_s: D + H + Hplus, elapsed_ms: Date.now() - t0
    });
    console.log(`N=${N} z=${zN}/${zD}: resZero=${allResZero}, compat=${allCompat}, polyH=${polyH} (deg ${exactDegH}<=${D}), polyS=${polyS} (deg ${exactDegS}<=${D + H + Hplus}) [${Date.now() - t0}ms]`);

    if (N === 5 && zN === 7 && P === 1000003) {
      for (let r = 1; r <= D; r++) {
        const out = testShortcutInjection(base, detData, r, 200, s, F);
        receipt.n5_shortcut_profile.push({ r, Ea_out: out[0], Eb_out: out[1], killed: out[0] === 0 && out[1] === 0 });
      }
    }
  }

  // Check 4: Independent resonant specialization at N=5, z=2/7, s=-3 (nu=-2), h=2,3,4 (rho=1,2,3)
  {
    const N = 5, z = F.frac(2, 7), s = F.mod(-3), nu = F.mod(-2);
    const base = buildBaseSystem(N, z, F), dd = buildDetPoly(base, nu, F), { H, D } = dd;
    const hs = [10, 11, 12, 13, 14, 15, 16, 17, 18];
    const Qs = hs.map(hv => computeRow(base, dd, hv, s, F, false));
    for (const hInt of [2, 3, 4]) {
      const Udir = directU(N, z, hInt, -2, F);
      const Wg = base.tuples.map(t => evalMomentTuple(N, z, hInt + H, t, -2, F));
      const Qres = lagrangeEval(hs, Qs, hInt, F), Qsh = computeRow(base, dd, hInt, s, F, true);
      let poch = 1; for (let m = 1; m <= H; m++) poch = F.mul(poch, hInt + m);
      const p2 = F.mul(poch, poch);
      let dc = 0, ds = 0; for (let i = 0; i < base.d; i++) { dc = F.add(dc, F.mul(Qres[i], Wg[i])); ds = F.add(ds, F.mul(Qsh[i], Wg[i])); }
      const Uc = F.div(dc, p2), Us = F.div(ds, p2);
      const matchExactBigInt = hInt === 2 ? (Udir === F.frac(u5Num, u5Den)) : null;
      const ok = Uc === Udir && Us !== Udir && (matchExactBigInt !== false);
      if (!ok) receipt.all_passed = false;
      receipt.n5_resonant_specialization.push({
        P, h: hInt, rho: hInt - 1, direct_U: Udir, canon_interp_U: Uc, shortcut_U: Us,
        canon_matches_direct: Uc === Udir, shortcut_matches_direct: Us === Udir, matches_exact_rational: matchExactBigInt
      });
      console.log(`N=5 resonant h=${hInt} (rho=${hInt - 1}): direct=${Udir}, canon=${Uc} (match=${Uc === Udir}), shortcut=${Us} (match=${Us === Udir})`);
    }
  }
}

const outPath = path.join(__dirname, 'verification_receipt.json');
fs.writeFileSync(outPath, JSON.stringify(receipt, null, 2));
console.log(`\nALL CHECKS PASSED: ${receipt.all_passed}`);
console.log(`Receipt written to ${outPath}`);
if (!receipt.all_passed) process.exit(1);
