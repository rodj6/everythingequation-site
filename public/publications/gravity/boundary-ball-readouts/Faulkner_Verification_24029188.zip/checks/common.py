"""Shared result recording for the Faulkner-Guica-Hartman-Myers-Van Raamsdonk (arXiv:1312.7856v2) source-lift
verification package. Each check records: id, claim (paper anchor), kind, status, and the actual computed objects.
kind is one of: EXACT_SYMBOLIC (sympy identity simplified to 0 / exact rational or exact closed form),
NUMERICAL (floating point diagnostic with stated tolerance), CONTROL_FAILURE (a check that is designed to FAIL and is
reported as PASS only if the failure is reproduced)."""
import json, os
RESULTS = []
def record(cid, claim, kind, ok, **details):
    def conv(v):
        try:
            import sympy as sp
            if isinstance(v, sp.Basic): return str(v)
        except Exception: pass
        if isinstance(v, (list, tuple)): return [conv(x) for x in v]
        if isinstance(v, dict): return {str(k): conv(x) for k, x in v.items()}
        if isinstance(v, bool) or v is None or isinstance(v, (int, str)): return v
        if isinstance(v, float): return v
        return str(v)
    RESULTS.append({"id": cid, "claim": claim, "kind": kind, "status": "PASS" if ok else "FAIL",
                    "details": {k: conv(v) for k, v in details.items()}})
    print(("PASS " if ok else "FAIL ") + cid + " :: " + claim, flush=True)
def dump(name, outdir):
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, name + ".json")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump({"suite": name, "results": RESULTS}, f, indent=1, sort_keys=True)
    nfail = sum(r["status"] != "PASS" for r in RESULTS)
    print(f"[{name}] {len(RESULTS)} checks, {nfail} failures -> {path}")
    return nfail
