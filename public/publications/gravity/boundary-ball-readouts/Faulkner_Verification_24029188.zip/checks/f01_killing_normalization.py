"""F1: the AdS-Rindler Killing field xi_B of paper eq. (3.1): exact Killing, vanishes on the RT hemisphere, kappa = 2 pi,
null generator of the wedge horizon, boundary limit = conformal Killing field zeta_B of (2.6)-(2.7), the zeta~ relation
under (4.23), relation to the CHM normalisation (kappa = 1/R), and the static-potential property of its lapse V = N xi^t
on the t = t0 slice (used by route B of the Stokes identity)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
out = sys.argv[1]
R = sp.Symbol('R', positive=True); t0 = sp.Rational(1, 3)
for d in (2, 3, 4, 5):
    X = coords(d); n = d + 1; t, z = X[0], X[-1]; xs = X[1:-1]
    x0 = [sp.Rational((-1)**i*(i + 1), 5) for i in range(d - 1)]
    g = gbar(d, X); xi = xi_B(d, X, R, x0, t0)
    L = lie_metric(g, X, xi)
    record(f'F1.killing.d{d}', f'(3.1) xi_B is an exact Killing vector of Poincare AdS_{d+1} (off-centre x0, t0=1/3)', 'EXACT_SYMBOLIC',
           L == sp.zeros(n, n), lie_derivative_nonzero_entries=sum(1 for e in L if e != 0))
    # vanishes on B~: t=t0, |x-x0|^2+z^2=R^2 ; parametrize with rational point on the sphere
    u = [sp.Rational(3, 7)] + [sp.Rational(1, 7)]*(d - 2); zz = sp.sqrt(1 - sum(a**2 for a in u))
    pt = {t: t0, z: R*zz}; pt.update({xs[i]: x0[i] + R*u[i] for i in range(d - 1)})
    v = [sp.simplify(c.subs(pt)) for c in xi]
    record(f'F1.vanish.d{d}', 'xi_B = 0 on the hemisphere B~(R,x0) (bifurcation surface)', 'EXACT_SYMBOLIC', all(c == 0 for c in v), xi_at_point=v)
    # surface gravity: on bifurcation surface, kappa^2 = -(1/2) nabla_a xi_b nabla^a xi^b
    Gm = christoffel(g, X); gi = g.inv()
    low = g*xi
    Dxi = sp.Matrix(n, n, lambda a, b: sp.diff(low[b], X[a]) - sum(Gm[c][a][b]*low[c] for c in range(n)))
    asym = sp.simplify((Dxi + Dxi.T).subs(pt))
    k2 = sp.simplify(-sp.Rational(1, 2)*sum(Dxi[a, b]*sum(gi[a, c]*gi[b, e]*Dxi[c, e] for c in range(n) for e in range(n)) for a in range(n) for b in range(n)).subs(pt))
    record(f'F1.kappa.d{d}', 'kappa^2 = -(1/2) nabla_a xi_b nabla^a xi^b = (2 pi)^2 on B~ (paper: "normalized such that kappa = 2 pi")', 'EXACT_SYMBOLIC',
           sp.simplify(k2 - 4*sp.pi**2) == 0 and asym == sp.zeros(n, n), kappa_squared=k2)
    # future horizon point: t-t0 = tau, sqrt(|x-x0|^2+z^2) = R - tau
    tau = R/4; pth = {t: t0 + tau, z: (R - tau)*zz}; pth.update({xs[i]: x0[i] + (R - tau)*u[i] for i in range(d - 1)})
    norm = sp.simplify((xi.T*g*xi)[0, 0].subs(pth))
    acc = sp.Matrix(n, 1, lambda b, _: sum(xi[a]*(sp.diff(xi[b], X[a]) + sum(Gm[b][a][c]*xi[c] for c in range(n))) for a in range(n)))
    res = sp.simplify((acc - 2*sp.pi*xi).subs(pth))
    record(f'F1.horizon.d{d}', 'on the future horizon sqrt(|x-x0|^2+z^2) = R-(t-t0): g(xi,xi)=0 and xi^a nabla_a xi^b = 2 pi xi^b', 'EXACT_SYMBOLIC',
           norm == 0 and res == sp.zeros(n, 1), g_xi_xi=norm)
    # boundary limit to zeta_B (2.6)-(2.7) and zeta~ of (4.23)
    r2 = sum((xs[i] - x0[i])**2 for i in range(d - 1))
    zeta = [sp.pi/R*(R**2 - (t - t0)**2 - r2)] + [-2*sp.pi/R*(t - t0)*(xs[i] - x0[i]) for i in range(d - 1)]
    lim = [sp.simplify(xi[a].subs(z, 0) - zeta[a]) for a in range(d)]
    zt = sp.simplify(sp.limit(xi[-1]/z, z, 0))
    eta = sp.diag(*([-1] + [1]*(d - 1))); Y = X[:-1]; zl = eta*sp.Matrix(zeta)
    ck = sp.simplify(sp.Matrix(d, d, lambda a, b: sp.diff(zl[b], Y[a]) + sp.diff(zl[a], Y[b]) - 2*eta[a, b]*zt))
    record(f'F1.boundary.d{d}', 'lim_{z->0} xi_B^mu = zeta_B^mu (2.6)-(2.7); zeta~ = lim xi^z/z = -2 pi (t-t0)/R; d_mu zeta_nu + d_nu zeta_mu = 2 eta_munu zeta~ (4.23)', 'EXACT_SYMBOLIC',
           all(c == 0 for c in lim) and sp.simplify(zt + 2*sp.pi*(t - t0)/R) == 0 and ck == sp.zeros(d, d), zeta_tilde=zt)
    # CHM normalisation: zeta_CHM = xi_B/(2 pi R) has kappa = 1/R
    k2c = sp.simplify(k2/(2*sp.pi*R)**2)
    record(f'F1.chm.d{d}', 'reuse of CHM: zeta_CHM = xi_B/(2 pi R) (CHM ball generator, kappa = 1/R) ; modular Hamiltonian 2 pi K = int T(xi_B) <-> 2 pi R H_tau', 'EXACT_SYMBOLIC',
           sp.simplify(k2c - 1/R**2) == 0, kappa_CHM_squared=k2c)
    record(f'F1.chm_control.d{d}', 'CONTROL: the CHM-normalised field has kappa != 2 pi for generic R (normalisation is not optional)', 'CONTROL_FAILURE',
           sp.simplify(k2c.subs(R, 3) - 4*sp.pi**2) != 0, kappa_CHM_squared_at_R3=k2c.subs(R, 3))
    # static potential: V = N xi^t on slice t=t0, metric l^2/z^2 (dz^2 + dx^2)
    Xs = list(xs) + [z]; q = sp.diag(*([l**2/z**2]*d)); Gq = christoffel(q, Xs)
    V = sp.simplify((l/z*xi[0]).subs(t, t0))
    Hs = sp.Matrix(d, d, lambda a, b: sp.diff(V, Xs[a], Xs[b]) - sum(Gq[c][a][b]*sp.diff(V, Xs[c]) for c in range(d)))
    sp_ok = sp.simplify(Hs - V*q/l**2) == sp.zeros(d, d)
    gradV2 = sp.simplify(sum(q.inv()[a, b]*sp.diff(V, Xs[a])*sp.diff(V, Xs[b]) for a in range(d) for b in range(d)))
    ptS = {z: R*zz}; ptS.update({xs[i]: x0[i] + R*u[i] for i in range(d - 1)})
    record(f'F1.static_potential.d{d}', 'V = N xi^t|_{t0} satisfies Hess V = V qbar/l^2 on H^d (static potential: DR*(V) = 0), V=0 and |dV| = 2 pi on B~', 'EXACT_SYMBOLIC',
           sp_ok and sp.simplify(V.subs(ptS)) == 0 and sp.simplify(gradV2.subs(ptS) - 4*sp.pi**2) == 0, V=V)
    # orientation: xi^t > 0 on interior of Sigma (future-directed), e.g. at the top point's interior
    pin = {t: t0, z: R/2}; pin.update({xs[i]: x0[i] for i in range(d - 1)})
    record(f'F1.orientation.d{d}', 'xi_B^t > 0 inside Sigma (future-directed in the wedge; modular flow direction inherited from the CHM lift)', 'EXACT_SYMBOLIC',
           sp.simplify(xi[0].subs(pin)) == sp.Rational(3, 4)*sp.pi*R, xi_t_at_centre_half_height=sp.simplify(xi[0].subs(pin)))
sys.exit(dump('f01_killing_normalization', out))
