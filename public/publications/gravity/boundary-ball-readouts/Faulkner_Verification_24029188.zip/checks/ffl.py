"""First-law readouts for Einstein gravity in Poincare AdS_{d+1}, convention h_munu = z^{d-2} H_munu (actual metric
components, radial gauge h_za = 0). All quantities are multiplied by G_N (so 1/G_N factors drop out).
  G*dS(R,x0)   = (R l^{d-3}/8) int_{|y|<R} (delta_ij - y_i y_j/R^2) H_ij(t0, x0+y, sqrt(R^2-|y|^2))      [paper (4.7)]
  G*E_sp       = (d l^{d-3}/16pi)(pi/R) int_{|y|<R} (R^2-|y|^2) H_ii(t0,x0+y,0)        [(2.10)+(4.13) with H_tt->H_ii]
  G*E_hol      = same with H_tt(t0,x0+y,0)                                              [(2.10)+(4.13) literally]
  G*Bulk       = -(1/8pi) int_Sigma xi^t dE_tt (l/z)^{d-1} dz d^{d-1}x,  dE = 16 pi G deltaE^g          [(4.17)]"""
import sympy as sp
from fgeom import l, coords, lin_einstein
from fint import integrate_ball, integrate_halfball, integrate_hemigraph
def build(d, Hfun):
    """Hfun(X) -> symmetric (d+1)x(d+1) Matrix H (only boundary-direction block used). Returns X, h, dE."""
    X = coords(d); n = d + 1; z = X[-1]
    H = Hfun(X); h = sp.Matrix(n, n, lambda a, b: z**(d-2)*H[a, b] if (a < n-1 and b < n-1) else 0)
    dE, _ = lin_einstein(d, X, h)
    return X, H, h, dE
def readouts(d, X, H, dE, R, x0, t0):
    n = d + 1; t, z = X[0], X[-1]; xs = X[1:-1]; m = d - 1
    ys = sp.symbols('y1:%d' % (m + 1), real=True); sub = {t: t0}; sub.update({xs[i]: x0[i] + ys[i] for i in range(m)})
    r2 = sum(y**2 for y in ys)
    integrand_S = sum(((1 if i == j else 0) - ys[i]*ys[j]/R**2)*H[i+1, j+1] for i in range(m) for j in range(m)).subs(sub)
    GS = R*l**(d-3)/8*integrate_hemigraph(sp.expand(integrand_S), ys, z, R)
    trB = sum(H[i+1, i+1] for i in range(m)).subs(sub).subs(z, 0)
    GEsp = sp.Integer(d)*l**(d-3)/(16*sp.pi)*sp.pi/R*integrate_ball(sp.expand((R**2 - r2)*trB), ys, R)
    GEhol = sp.Integer(d)*l**(d-3)/(16*sp.pi)*sp.pi/R*integrate_ball(sp.expand((R**2 - r2)*H[0, 0].subs(sub).subs(z, 0)), ys, R)
    xit = sp.pi/R*(R**2 - z**2 - r2)
    bulk_integrand = sp.expand(sp.simplify(xit*dE[0, 0].subs(sub)*(l/z)**(d-1)))
    GB = -integrate_halfball(bulk_integrand, ys, z, R)/(8*sp.pi)
    return dict(GS=sp.simplify(GS), GEsp=sp.simplify(GEsp), GEhol=sp.simplify(GEhol), GB=sp.simplify(GB))
