"""F8 (Milestone 2): the restricted family F_{t0} = {B(R,x0) on the single boundary slice t = t0, all R > 0, all x0}.
Observable D_B = dS_B - E_B (first-law defect); also the entropy readout dS_B alone.
 (a) slice reduction: D on F_{t0} depends only on the induced slice data at t0 (exactly: two perturbations agreeing on the slice
     have identical readouts) and equals -(1/8 pi G) int_Sigma xi^t dE_tt (l/z)^{d-1} (F6), i.e. it is a transform of the single
     function rho = dE_tt|_{t0} (linearized Hamiltonian constraint on one slice).
 (b) explicit admissible invisible perturbations (residual != 0, readouts = 0), checked for linearized Bianchi and boundary data:
     (b1) temporal profile h + (t-t0)^2 k  -> invisible to F_{t0} only;
     (b2) lapse/shift h_tt, h_ti        -> invisible to rest-frame balls on ALL slices; seen by a boosted frame;
     (b3) off-shell TT profile h_xy(t,z) -> invisible to all rest-frame balls although its boundary data are traceless,
          conserved and nonzero; seen by a boosted frame;
     (b4) two-frame invisible h = f (u1 u2 + u2 u1) -> invisible to rest frame and frame u2, seen by a third frame.
 (c) residual vs metric: the on-shell TT graviton has dS_B = 0 for every rest-frame ball on every slice, though h != 0 and
     T_xy != 0: fixed-frame readouts cannot reconstruct the metric even on shell."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
from ffl import build, readouts
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
def boost_matrix(d, v):
    v = [sp.nsimplify(a) for a in v]; v2 = sum(a**2 for a in v); g = 1/sp.sqrt(1 - v2)
    L = sp.zeros(d, d); L[0, 0] = g
    for i in range(d - 1):
        L[0, i+1] = L[i+1, 0] = -g*v[i]
        for j in range(d - 1): L[i+1, j+1] = (1 if i == j else 0) + (g - 1)*v[i]*v[j]/v2
    return L
def boosted_H(d, Hfun, v):
    """H in primed (boosted) coordinates X' = L X: H'(X') = (L^-1)^T H(L^-1 X') L^-1 on the boundary block (z unchanged)."""
    def Hp(Xp):
        n = d + 1; L = boost_matrix(d, v); Li = L.inv()
        Y = Li*sp.Matrix(Xp[:-1]); Xorig = list(Y) + [Xp[-1]]
        Hf = Hfun(coords(d)); sub = dict(zip(coords(d), Xorig))
        Hb = Hf[:d, :d].subs(sub, simultaneous=True)
        Hb2 = Li.T*Hb*Li
        M = sp.zeros(n, n); M[:d, :d] = sp.simplify(Hb2)
        return M
    return Hp
def D_of(d, Hfun, R, x0, t0):
    X, H, h, dE = build(d, Hfun); ro = readouts(d, X, H, dE, R, x0, t0)
    return sp.simplify(ro['GS'] - ro['GEhol']), ro, dE, X
d = 3; t0 = sp.Rational(1, 2)
balls = [([sp.Rational(1, 3), sp.Rational(-1, 4)], t0), ([sp.Rational(-2, 3), sp.Rational(1, 2)], t0)]
# a base off-shell perturbation (so 'identical readouts' is nontrivial)
def base(X):
    n = len(X); t, x1, x2, z = X; M = sp.zeros(n, n)
    M[0, 0] = 2 + x1; M[1, 1] = 1 + x1 + z**2 + t*z; M[2, 2] = 1 - x1 + x2*z; M[1, 2] = M[2, 1] = x2 + t**2*z
    return M
def bump(X):  # spatial-tensor profile vanishing to high order at z = 0 (no boundary data)
    t, x1, x2, z = X; return z**3*(1 + x1*x2 - z**2)
def b1(X):
    M = base(X); t = X[0]; k = bump(X)
    M[1, 1] += (t - t0)**2*k; M[1, 2] += (t - t0)**2*2*k; M[2, 1] = M[1, 2]
    return M
Db, rob, dEb, X = D_of(d, base, R, *balls[0])
ok_same = True; vals = []
for bl in balls:
    D0, ro0, dE0, _ = D_of(d, base, R, *bl); D1, ro1, dE1, X = D_of(d, b1, R, *bl)
    ok_same &= sp.simplify(D0 - D1) == 0 and sp.simplify(ro0['GS'] - ro1['GS']) == 0; vals.append(D1)
_, _, dE1, X = D_of(d, b1, R, *balls[0])
pt = {X[0]: t0, X[1]: sp.Rational(1, 5), X[2]: sp.Rational(2, 7), X[3]: sp.Rational(1, 2)}
dEdiff = sp.simplify((dE1 - dEb).subs(pt))
record('F8.slice_reduction.b1', '(a)+(b1): h and h + (t-t0)^2 k (k a z^3-vanishing spatial tensor) have identical readouts dS_B and D_B for balls on t = t0 (symbolic R, two centres), but different residuals at t0: dE_tt equal, dE_ij different', 'EXACT_SYMBOLIC',
       ok_same and dEdiff[0, 0] == 0 and any(dEdiff[i, j] != 0 for i in (1, 2) for j in (1, 2)), D_readouts=vals, dE_difference_at_point=dEdiff)
# which residual components the slice family leaves unconstrained: linear temporal profile h + (t-t0) k
def b1lin(X):
    M = base(X); t = X[0]; k = bump(X)
    M[1, 1] += (t - t0)*k; M[2, 2] -= (t - t0)*k*X[1]; M[1, 2] += (t - t0)*k; M[2, 1] = M[1, 2]
    return M
same_lin = all(sp.simplify(D_of(d, base, R, *bl)[0] - D_of(d, b1lin, R, *bl)[0]) == 0 for bl in balls)
_, _, dEl, X = D_of(d, b1lin, R, *balls[0])
dd = sp.simplify((dEl - dEb).subs(pt))
nz = sorted({(min(a, b), max(a, b)) for a in range(4) for b in range(4) if dd[a, b] != 0})
names = ['t', 'x1', 'x2', 'z']
record('F8.unconstrained_components', 'the slice family fixes dE_tt|_{t0} only: perturbations with identical readouts on F_t0 differ at t0 in the momentum constraints dE_tA (A = x_i and z) for a linear temporal profile (components listed); dE_ij at t0 was shown free in F8.slice_reduction.b1', 'EXACT_SYMBOLIC',
       same_lin and dd[0, 0] == 0 and any(c[0] == 0 and c[1] in (1, 2) for c in nz) and (0, 3) in nz,
       nonzero_components_at_t0=[names[a] + names[b] for a, b in nz])
# (b2) lapse/shift
def b2(X):
    n = len(X); t, x1, x2, z = X; M = sp.zeros(n, n); f = z**3*(1 + x1 - x2**2 + t*z)
    M[0, 0] = f; M[0, 1] = M[1, 0] = z**3*(x2 + t)
    return M
Xg = coords(d); Hg = b2(Xg); hg = sp.Matrix(4, 4, lambda a, b: Xg[-1]*Hg[a, b] if (a < 3 and b < 3) else 0)
dE2, Dg = lin_einstein(d, Xg, hg)
ok_tt = sp.simplify(dE2[0, 0]) == 0
div2 = [sp.simplify(v) for v in cov_div_lower(d, Xg, dE2, Dg['g'], Dg['gi'], Dg['Gam'])]
Ds = [D_of(d, b2, R, x0, tt)[0] for x0, tt in [(balls[0][0], t0), (balls[1][0], sp.Rational(-3, 2)), (balls[0][0], sp.Integer(4))]]
Dboost = D_of(d, boosted_H(d, b2, [sp.Rational(3, 5), 0]), R, [sp.Rational(1, 3), 0], sp.Rational(1, 7))[0]
record('F8.lapse_shift.b2', '(b2): h_tt, h_tx1 = z^{d+1}(...) (radial gauge, no boundary data) has dE_tt = 0 at every t, nonzero dE_ij, satisfies linearized Bianchi; D_B = 0 for rest-frame balls on several slices; a boosted (v = 3/5) ball sees it', 'EXACT_SYMBOLIC',
       ok_tt and any(sp.simplify(dE2[i, j]) != 0 for i in (1, 2) for j in (1, 2)) and all(v == 0 for v in div2) and all(v == 0 for v in Ds) and Dboost != 0,
       D_rest=Ds, D_boosted=Dboost)
# (b3) off-shell TT profile (also: the wrong-profile graviton)
def b3(X, c=sp.Rational(1, 7)):
    n = len(X); t, x1, x2, z = X; M = sp.zeros(n, n); M[1, 2] = M[2, 1] = t**2 + c*z**2 + sp.Rational(1, 3)
    return M
X3, H3, h3, dE3 = build(d, b3)
offshell = any(sp.simplify(e) != 0 for e in dE3)
Ds3 = [D_of(d, b3, R, x0, tt)[0] for x0, tt in [(balls[0][0], t0), (balls[1][0], sp.Rational(-5, 3))]]
GS3 = [D_of(d, b3, R, x0, tt)[1]['GS'] for x0, tt in [(balls[0][0], t0)]]
Db3 = D_of(d, boosted_H(d, b3, [sp.Rational(1, 3), sp.Rational(2, 3)]), R, [sp.Rational(1, 4), sp.Rational(1, 5)], sp.Rational(2, 5))
record('F8.tt_profile.b3', '(b3): h_x1x2 = z(t^2 + z^2/7 + 1/3) is off shell (correct profile is z^2/5), its boundary data are traceless, conserved and nonzero, dE_tt = 0 identically, and D_B = dS_B = 0 for all rest-frame balls; a boosted ball (v = (1/3, 2/3), gamma = 3/2) gives D != 0, equal to its bulk integral', 'EXACT_SYMBOLIC',
       offshell and sp.simplify(dE3[0, 0]) == 0 and all(v == 0 for v in Ds3) and GS3[0] == 0 and Db3[0] != 0 and sp.simplify(Db3[0] - Db3[1]['GB']) == 0,
       D_boosted=Db3[0])
# (b4) two-frame invisible h = f (u1 (x) u2 + u2 (x) u1), u1 rest, u2 boosted along x1 with v = 3/5
v2 = sp.Rational(3, 5); gm = 1/sp.sqrt(1 - v2**2)
u1 = sp.Matrix([-1, 0, 0]); u2 = gm*sp.Matrix([-1, v2, 0])   # covectors (eta-lowered velocities)
def b4(X):
    n = len(X); t, x1, x2, z = X; f = z**3*(1 + x2 + t*x1 - z**2); A = f*(u1*u2.T + u2*u1.T)
    M = sp.zeros(n, n); M[:3, :3] = A
    return M
X4, H4, h4, dE4 = build(d, b4)
Dr = D_of(d, b4, R, balls[0][0], t0)[0]
Du2 = D_of(d, boosted_H(d, b4, [v2, 0]), R, [sp.Rational(1, 3), sp.Rational(1, 2)], sp.Rational(1, 3))[0]
Du3 = D_of(d, boosted_H(d, b4, [0, sp.Rational(3, 5)]), R, [sp.Rational(1, 3), sp.Rational(1, 2)], sp.Rational(1, 3))
record('F8.two_frame_invisible.b4', '(b4): h = f(u1 u2 + u2 u1) is off shell, invisible to rest-frame and u2-frame balls (D = 0 exactly), detected by a third frame (boost along x2), whose D equals its bulk integral', 'EXACT_SYMBOLIC',
       any(sp.simplify(e) != 0 for e in dE4) and Dr == 0 and Du2 == 0 and Du3[0] != 0 and sp.simplify(Du3[0] - Du3[1]['GB']) == 0, D_third=Du3[0])
# (c) residual vs metric: on-shell TT graviton
def grav(X): return b3(X, sp.Rational(1, 5))
Xg5, Hg5, hg5, dEg5 = build(d, grav)
onshell = all(sp.simplify(e) == 0 for e in dEg5)
GSr = [D_of(d, grav, R, x0, tt)[1]['GS'] for x0, tt in [(balls[0][0], t0), (balls[1][0], sp.Rational(7, 3))]]
GSb = D_of(d, boosted_H(d, grav, [sp.Rational(1, 3), sp.Rational(2, 3)]), R, [sp.Rational(1, 4), sp.Rational(1, 5)], sp.Rational(2, 5))[1]['GS']
record('F8.residual_vs_metric.c', '(c): the on-shell TT graviton (h != 0, T_xy != 0, not pure gauge since its boundary data are nonzero) has dS_B = 0 for every rest-frame ball on every slice; its metric is invisible to the fixed-frame family; a boosted frame has dS_B != 0', 'EXACT_SYMBOLIC',
       onshell and all(v == 0 for v in GSr) and GSb != 0, dS_boosted=GSb)
# boosted readout consistency: Lorentz covariance of the joint identity (boosted frame of the base perturbation)
Dbb = D_of(d, boosted_H(d, base, [sp.Rational(1, 3), sp.Rational(2, 3)]), R, [sp.Rational(1, 4), sp.Rational(1, 5)], sp.Rational(2, 5))
record('F8.boosted_identity', 'boosted-frame balls (realised as the AdS isometry acting on h): the joint identity dS - E_sp = bulk residual integral holds exactly in a boosted frame (v = (1/3,2/3)) for the off-shell base perturbation', 'EXACT_SYMBOLIC',
       sp.simplify(Dbb[1]['GS'] - Dbb[1]['GEsp'] - Dbb[1]['GB']) == 0)
sys.exit(dump('f08_restricted_family', out))
