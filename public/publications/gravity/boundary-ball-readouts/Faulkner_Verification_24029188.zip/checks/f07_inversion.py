"""F7: the integral-to-local step (paper (4.17)-(4.19), Appendix A) and what restricting the radii/centres destroys.
(a) Reynolds identities used in App. A: d/dR int_Sigma f = int_B~ f dA, d/dx0^i int_Sigma f = int_B~ f (x-x0)^i/R dA (Euclidean dA);
(b) the R-derivative trick (4.18): d/dR [R int_Sigma xi^t f] = 2 pi R int_Sigma f, boundary term killed by xi^t|_B~ = 0;
(c) moment step of App. A: int_Sigma x^i f = int_0^R dR' int_B~(R') x^i f dA (coarea in R), so vanishing hemisphere moments
    propagate to all polynomial moments; (d) sharper restriction: ONE radius on the slice is not injective (explicit exact kernel
    h_xx = z^4 cos(kx) in AdS_3 with J_{7/2}(kR0) = 0); a FIXED centre is not injective (odd perturbations).
The continuum injectivity itself is an analytic proof (Stone-Weierstrass, DERIVATION_REPORT Thm 4.3); no finite check here claims it."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import l, sp
from fint import integrate_halfball, integrate_hemigraph_zpow
from ffl import build, readouts
import mpmath as mp
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
for d in (2, 3):
    m = d - 1; ys = sp.symbols('y1:%d' % d, real=True); z = sp.Symbol('z', positive=True)
    x0 = sp.symbols('a1:%d' % d, real=True)
    f = lambda Y, Z: 3 + Y[0]*Z - 2*Z**2 + Y[0]**2*Z**3 + (Y[-1]**2 if m > 1 else 0) - Y[0]**3*Z
    # f as a function of absolute x = x0 + y
    F = integrate_halfball(sp.expand(f([x0[i] + ys[i] for i in range(m)], z)), ys, z, R)
    hemi = integrate_hemigraph_zpow(sp.expand(R*f([x0[i] + ys[i] for i in range(m)], z)), ys, z, R, -1)   # dA = (R/z) d^{d-1}y
    okR = sp.simplify(sp.diff(F, R) - hemi) == 0
    hemi_i = integrate_hemigraph_zpow(sp.expand(ys[0]*f([x0[i] + ys[i] for i in range(m)], z)), ys, z, R, -1)  # (y/R) dA = y/z
    oki = sp.simplify(sp.diff(F, x0[0]) - hemi_i) == 0
    record(f'F7.reynolds.d{d}', 'App. A (A.2)-(A.3): d_R int_Sigma f = int_B~ f dA and d_x0 int_Sigma f = int_B~ f (x-x0)/R dA (exact, polynomial f, symbolic R, x0)', 'EXACT_SYMBOLIC', okR and oki)
    w = sp.pi*(R**2 - z**2 - sum(y**2 for y in ys))   # R xi^t at t = t0
    lhs = sp.diff(integrate_halfball(sp.expand(w*f([x0[i] + ys[i] for i in range(m)], z)), ys, z, R), R)
    record(f'F7.R_trick.d{d}', '(4.18): d/dR [R int_Sigma xi^t f] = 2 pi R int_Sigma f (the B~ term vanishes because xi^t = 0 there)', 'EXACT_SYMBOLIC',
           sp.simplify(lhs - 2*sp.pi*R*F) == 0)
    Rp = sp.Symbol('Rp', positive=True)
    mom = integrate_halfball(sp.expand((x0[0] + ys[0])*f([x0[i] + ys[i] for i in range(m)], z)), ys, z, R)
    coarea = sp.integrate(integrate_hemigraph_zpow(sp.expand(Rp*(x0[0] + ys[0])*f([x0[i] + ys[i] for i in range(m)], z)), ys, z, Rp, -1), (Rp, 0, R))
    record(f'F7.coarea_moment.d{d}', 'App. A moment step: int_Sigma x^i f = int_0^R dR\' int_B~(R\') x^i f dA (concentric hemispheres foliate Sigma), so hemisphere moments of all orders vanish once (A.1) holds for all R, x0', 'EXACT_SYMBOLIC',
           sp.simplify(mom - coarea) == 0)
# (d) single radius: AdS_3 (d = 2), h_xx = z^{d-2} H_xx with H_xx = z^4 cos(k x): E = 0 (H(z=0) = 0), so D = dS
k, x0s, y = sp.symbols('k a y', real=True)
d = 2
GS = R*l**(d-3)/8*sp.integrate(sp.expand((1 - y**2/R**2)*(R**2 - y**2)**2*sp.cos(k*y)), (y, -R, R))   # cos(k(a+y)) -> cos(ka)cos(ky): sin part odd
bessel = R*l**(d-3)/8/R**2*sp.sqrt(sp.pi)*sp.gamma(4)*(2*R/k)**sp.Rational(7, 2)*sp.besselj(sp.Rational(7, 2), k*R)
okb = sp.simplify(sp.expand_func(bessel) - GS) == 0 or abs(sp.N((sp.expand_func(bessel) - GS).subs({R: sp.Rational(7, 5), k: sp.Rational(13, 7), l: 1}), 30)) < 1e-25
record('F7.single_radius_closed_form.d2', 'AdS_3, H_xx = z^4 cos(kx): G D(R, x0) = G dS = cos(k x0) (R l^{-1}/8) R^{-2} sqrt(pi) Gamma(4) (2R/k)^{7/2} J_{7/2}(kR), exact', 'EXACT_SYMBOLIC',
       okb, GS_over_cos=sp.simplify(GS))
X, H, h, dE = build(2, lambda X: sp.Matrix([[0, 0, 0], [0, X[-1]**4*sp.cos(k*X[1]), 0], [0, 0, 0]]))
record('F7.single_radius_offshell.d2', 'this perturbation is admissible (radial gauge, H smooth, H(z=0) = 0) and off shell: deltaE_tt != 0', 'EXACT_SYMBOLIC',
       sp.simplify(dE[0, 0]) != 0, dE_tt=sp.simplify(dE[0, 0]))
mp.mp.dps = 30
j1 = mp.besseljzero(mp.mpf(7)/2, 1); R0 = mp.mpf(1); kk = j1/R0
Dfun = lambda Rv, a: mp.cos(kk*a)*Rv/8*mp.quad(lambda yy: (1 - yy**2/Rv**2)*(Rv**2 - yy**2)**2*mp.cos(kk*yy), [-Rv, Rv])
vals0 = [Dfun(R0, a) for a in (0, mp.mpf('0.3'), mp.mpf('1.7'), mp.mpf('-2.2'))]
vals1 = [Dfun(mp.mpf('1.3'), a) for a in (0, mp.mpf('0.3'))]
record('F7.single_radius_kernel.d2', 'sharper restriction is NOT injective: with k R0 = j_{7/2,1} (first zero of J_{7/2}) the perturbation is invisible to every ball of radius R0 on the slice (all centres), but visible at R = 1.3 R0', 'NUMERICAL',
       max(abs(v) for v in vals0) < mp.mpf('1e-25') and min(abs(v) for v in vals1) > mp.mpf('1e-3'),
       k_R0=float(j1), D_at_R0=[float(v) for v in vals0], D_at_13R0=[float(v) for v in vals1])
# fixed centre: odd perturbation H_xx = z^4 sin(k(x - x0)) is invisible to all concentric balls at x0
GSo = sp.integrate(sp.expand((1 - y**2/R**2)*(R**2 - y**2)**2*sp.sin(k*y)), (y, -R, R))
record('F7.fixed_centre_kernel.d2', 'a fixed centre is not injective: H_xx = z^4 sin(k(x-x0)) gives dS = 0 = E for every radius about x0 (parity), while it is off shell', 'EXACT_SYMBOLIC',
       sp.simplify(GSo) == 0)
sys.exit(dump('f07_inversion', out))
