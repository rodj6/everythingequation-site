"""F3: small-ball limit of the first law (paper sec. 4.1): the weight integral (4.2), the Einstein stress-tensor
coefficient (4.10)/(4.13) from the RT variation (4.7), the frame form (4.11), the falloff lemma (4.9) for
h ~ z^{Delta-2} (d-2 < Delta < d excluded; Delta > d invisible at order R^d), and the polarisation step
'u^mu u^nu (c - eta tr c) = 0 for all timelike u  =>  c = 0' with an explicit finite uniqueness set of frames."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import l, sp
from fint import integrate_ball, integrate_hemigraph
from ffl import build, readouts
out = sys.argv[1]
R = sp.Symbol('R', positive=True); Dl = sp.Symbol('Delta', positive=True)
for d in range(2, 8):
    ys = sp.symbols('y1:%d' % d, real=True); r2 = sum(y**2 for y in ys)
    I = integrate_ball((R**2 - r2)/(2*R), ys, R); Om = 2*sp.pi**sp.Rational(d - 1, 2)/sp.gamma(sp.Rational(d - 1, 2))
    record(f'F3.weight.d{d}', '(4.2): int_{|x|<R} (R^2-x^2)/(2R) d^{d-1}x = R^d Omega_{d-2}/(d^2-1)', 'EXACT_SYMBOLIC',
           sp.simplify(I - R**d*Om/(d**2 - 1)) == 0, value=I)
for d in range(2, 7):
    ys = sp.symbols('y1:%d' % d, real=True); z = sp.Symbol('z', positive=True); m = d - 1
    c = sp.Matrix(m, m, lambda i, j: sp.Symbol('c%d%d' % (min(i, j), max(i, j))))
    GS = R*l**(d-3)/8*integrate_hemigraph(sp.expand(sum(((1 if i == j else 0) - ys[i]*ys[j]/R**2)*c[i, j] for i in range(m) for j in range(m))), ys, z, R)
    Om = 2*sp.pi**sp.Rational(d - 1, 2)/sp.gamma(sp.Rational(d - 1, 2))
    GTtt = sp.simplify(GS/(2*sp.pi*R**d*Om/(d**2 - 1)))
    record(f'F3.dictionary.d{d}', '(4.10): delta S = delta E at leading order gives delta<T_tt> = d l^{d-3}/(16 pi G) h^(d)_ii (Einstein holographic stress tensor (4.13) after tracelessness)', 'EXACT_SYMBOLIC',
           sp.simplify(GTtt - sp.Integer(d)*l**(d-3)/(16*sp.pi)*c.trace()) == 0, G_times_Ttt=GTtt)
    # falloff lemma: h_ij = z^{Delta-2} c_ij  -> delta S = R^Delta K(Delta,d) c_ii
    rr = sp.Symbol('r', positive=True)
    rad = sp.integrate(rr**(d-2)*(R**2 - rr**2)**((Dl - d)/2)*(1 - rr**2/((d - 1)*R**2)), (rr, 0, R), conds='none')
    K = sp.simplify(R*l**(d-3)/8*Om*rad/R**Dl)
    Ks = [sp.N(K.subs({Dl: sp.Rational(k, 4) + d - 2, l: 1})) for k in (1, 3, 4, 6, 9, 16)]
    record(f'F3.falloff.d{d}', '(4.9): for h_ij = z^{Delta-2}c_ij, G delta S = K(Delta,d) R^Delta c_ii with K > 0 on Delta > d-2: finite nonzero limit of dS/R^d forces Delta = d; d-2<Delta<d needs c_ii = 0 in every frame; Delta > d drops out at order R^d', 'EXACT_SYMBOLIC',
           all(k > 0 for k in Ks), K=K, K_samples_l1=[float(k) for k in Ks])
# polarisation with a finite set of frames: map c -> (u_k u_k c + tr_eta c)_k has rank N = d(d+1)/2
def boost(w):
    w2 = sum(a**2 for a in w); return [(1 + w2)/(1 - w2)] + [2*a/(1 - w2) for a in w]
import itertools
for d in (2, 3, 4):
    N = d*(d + 1)//2; eta = sp.diag(*([-1] + [1]*(d - 1)))
    pool = [[sp.Integer(0)]*(d - 1)] + [[sp.Rational(((7*k + 3*j) % 11) - 5, 13) for j in range(d - 1)] for k in range(1, 3*N)]
    us = [boost(w) for w in pool]
    idx = [(a, b) for a in range(d) for b in range(a, d)]
    def row(u):
        return [ (u[a]*u[b]*(1 if a == b else 2)) + (eta[a, b] if a == b else 0)*1 for (a, b) in idx]
    # u u c + tr_eta c with tr_eta c = eta^{ab} c_ab, c symmetric: coefficient of c_ab
    M = sp.Matrix([row(u) for u in us[:N]]); Mless = sp.Matrix([row(u) for u in us[:N - 1]])
    record(f'F3.frames.d{d}', f'{N} = d(d+1)/2 explicit rational frames (incl. rest frame) form a uniqueness set: u u (c - eta tr c) = 0 on them => c = 0; fewer than N cannot (rank)', 'EXACT_SYMBOLIC',
           M.rank() == N and Mless.rank() == N - 1, rank=M.rank(), N=N, velocities_w=[[str(a) for a in w] for w in pool[:N]])
# frame form (4.11): rest-frame combination c_tt - eta_tt tr c = c_ii
d = 3; ct = sp.Matrix(3, 3, lambda i, j: sp.Symbol('C%d%d' % (min(i, j), max(i, j)))); eta = sp.diag(-1, 1, 1)
u = sp.Matrix([1, 0, 0]); val = (u.T*(ct - eta*(eta.inv()*ct).trace())*u)[0]
record('F3.frame_form', '(4.11): u^mu u^nu (h_munu - eta_munu h) in the rest frame equals h_ii, so (4.10) lifts to delta T_munu = d l^{d-3}/16piG (h_munu - eta_munu h)', 'EXACT_SYMBOLIC',
       sp.simplify(val - ct[1, 1] - ct[2, 2]) == 0, value=val)
# smooth perturbation: dS/R^d has the dictionary limit, corrections O(R)
for d in (2, 3):
    def Hf(X):
        n = len(X); t, z = X[0], X[-1]; xs = X[1:-1]; M = sp.zeros(n, n)
        for a in range(1, n - 1): M[a, a] = 1 + xs[0] + 2*z + t*z
        if n > 3: M[1, 2] = M[2, 1] = xs[0]*z - sp.Rational(1, 2)
        return M
    X, H, h, dE = build(d, Hf); x0 = [sp.Rational(1, 2)]*(d - 1)
    ro = readouts(d, X, H, dE, R, x0, sp.Rational(1, 3))
    Om = 2*sp.pi**sp.Rational(d - 1, 2)/sp.gamma(sp.Rational(d - 1, 2))
    lead = sp.limit(ro['GS']/R**d, R, 0)
    trH0 = sum(H[a, a] for a in range(1, d)).subs({X[0]: sp.Rational(1, 3), X[-1]: 0}).subs({X[i + 1]: x0[i] for i in range(d - 1)})
    pred = 2*sp.pi*Om/(d**2 - 1)*sp.Integer(d)*l**(d-3)/(16*sp.pi)*trH0
    record(f'F3.smooth_limit.d{d}', '(4.3): for smooth H, lim_{R->0} G dS/R^d = 2 pi Omega/(d^2-1) x d l^{d-3}/(16 pi) H_ii(x0, z=0); next term O(R)', 'EXACT_SYMBOLIC',
           sp.simplify(lead - pred) == 0, GS=ro['GS'])
sys.exit(dump('f03_small_ball_dictionary', out))
