"""F4: the linearized Einstein residual dE_ab = 16 pi G deltaE^g_ab = delta(G_ab + Lambda g_ab) about Poincare AdS_{d+1}.
(a) linearized Bianchi identity nabla^a dE_ab = 0 for completely general off-shell h (d=2,3); (b) gauge invariance
dE[L_Y gbar] = 0 (d=2,3); (c) the tt component in radial gauge, eq. (4.29), with l restored (printed l-power is an l=1
form); (d) dE_tt involves only the induced metric of the t-slice, no time derivatives, and equals N^2 deltaR_Sigma/2
(linearized Hamiltonian constraint); (e) footnote 14: leading behaviour of dE_zz, dE_zmu; (f) eq. (4.22) is the general
solution of the Bianchi identity when dE_munu = 0, with C_z, C_mu equal to trace and divergence of h^(d)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
out = sys.argv[1]
def fn(name, args): return sp.Function(name)(*args)
for d in (2, 3):
    X = coords(d); n = d + 1
    h = sp.Matrix(n, n, lambda a, b: fn('h%d%d' % (min(a, b), max(a, b)), X))
    dE, D = lin_einstein(d, X, h)
    div = [sp.simplify(sp.expand(v)) for v in cov_div_lower(d, X, dE, D['g'], D['gi'], D['Gam'])]
    record(f'F4.bianchi.d{d}', '(4.21)/App. B: nabla^a deltaE_ab = 0 identically for arbitrary off-shell h (all components, all coordinates)', 'EXACT_SYMBOLIC',
           all(v == 0 for v in div), divergence=div)
    Yv = sp.Matrix([fn('Y%d' % a, X) for a in range(n)])
    hg = lie_metric(D['g'], X, Yv)
    dEg, _ = lin_einstein(d, X, hg)
    record(f'F4.gauge.d{d}', 'gauge invariance: deltaE[L_Y gbar] = 0 for arbitrary Y (background on shell)', 'EXACT_SYMBOLIC',
           all(sp.simplify(e) == 0 for e in dEg), nonzero=sum(1 for e in dEg if sp.simplify(e) != 0))
    # (d) dependence of dE_tt
    funcs = dE[0, 0].atoms(sp.core.function.AppliedUndef)
    names = sorted({f.func.__name__ for f in funcs})
    has_t = any(isinstance(dv, sp.Derivative) and any(v == X[0] for v, _ in dv.variable_count) for dv in dE[0, 0].atoms(sp.Derivative))
    spatial = all(not nm.startswith('h0') for nm in names)
    Xs = X[1:]; qbar = sp.diag(*([l**2/X[-1]**2]*d)); Gq = christoffel(qbar, Xs); qi = qbar.inv()
    q = h[1:, 1:]
    dGq = [[[sum(qi[c, e]*(sp.diff(q[b, e], Xs[a]) + sp.diff(q[a, e], Xs[b]) - sp.diff(q[a, b], Xs[e])) for e in range(d))/2
              - sum(qi[c, e]*q[e, f]*Gq[f][a][b] for e in range(d) for f in range(d)) for b in range(d)] for a in range(d)] for c in range(d)]
    dRic = sp.Matrix(d, d, lambda a, b: sum(sp.diff(dGq[c][a][b], Xs[c]) - sp.diff(dGq[c][a][c], Xs[b]) for c in range(d))
                     + sum(dGq[c][c][e]*Gq[e][a][b] + Gq[c][c][e]*dGq[e][a][b] - dGq[c][b][e]*Gq[e][a][c] - Gq[c][b][e]*dGq[e][a][c] for c in range(d) for e in range(d)))
    Ric = -sp.Integer(d - 1)/l**2*qbar
    dRs = sum(qi[a, b]*dRic[a, b] for a in range(d) for b in range(d)) - sum((qi*q*qi)[a, b]*Ric[a, b] for a in range(d) for b in range(d))
    ham = sp.simplify(dE[0, 0] - (l**2/X[-1]**2)*dRs/2)
    record(f'F4.hamiltonian_constraint.d{d}', 'dE_tt contains only the slice metric h_AB (A,B in x,z), no h_tA and no t-derivatives, and dE_tt = N^2 (1/2) deltaR[q] (linearized Hamiltonian constraint, K = 0 background)', 'EXACT_SYMBOLIC',
           spatial and not has_t and ham == 0, functions=names)
# (c) radial gauge tt component, d = 2..5
for d in (2, 3, 4, 5):
    X = coords(d); n = d + 1; z = X[-1]; S = range(1, n - 1)
    H = sp.Matrix(n, n, lambda a, b: fn('H%d%d' % (min(a, b), max(a, b)), X) if (0 < a < n - 1 and 0 < b < n - 1) else 0)
    dE, _ = lin_einstein(d, X, z**(d-2)*H)
    tr = sum(H[i, i] for i in S)
    bracket = sp.diff(tr, z, 2) + sp.Rational(d + 1)/z*sp.diff(tr, z) + sum(sp.diff(tr, X[i], 2) for i in S) - sum(sp.diff(H[i, j], X[i], X[j]) for i in S for j in S)
    ours = -z**d/(2*l**2)*bracket
    printed = -z**d*l**(2-d)/2*bracket
    record(f'F4.eq4_29.d{d}', '(4.29) structure: 16piG deltaE_tt = -(z^d/(2 l^2)) [d_z^2 H + (d+1)/z d_z H + d_j d^j H - d^i d^j H_ij] for h_ij = z^{d-2} H_ij (radial gauge); printed l^{2-d} agrees iff l=1 or d=4', 'EXACT_SYMBOLIC',
           sp.simplify(dE[0, 0]*z**(d-2) - ours*z**(d-2)) == 0 and sp.simplify((ours - printed).subs(l, 1)) == 0, printed_over_computed=sp.simplify(printed/ours))
# (e),(f)
for d in (2, 3, 4):
    X = coords(d); n = d + 1; z = X[-1]; Y = X[:-1]; eta = sp.diag(*([-1] + [1]*(d - 1)))
    H = sp.Matrix(n, n, lambda a, b: fn('H%d%d' % (min(a, b), max(a, b)), Y) if (a < n - 1 and b < n - 1) else 0)
    dE, D = lin_einstein(d, X, z**(d-2)*H)
    trH = sum(eta[a, a]*H[a, a] for a in range(d))
    ezz0 = sp.simplify(sp.limit(dE[d, d]/z**(d-2), z, 0))
    okz = sp.simplify(ezz0 + sp.Rational(d*(d - 1), 2)/l**2*trH) == 0
    okm = all(sp.simplify(sp.limit(dE[m, d]/z**(d-1), z, 0) - sp.Rational(d, 2)/l**2*(sum(eta[a, a]*sp.diff(H[a, m], Y[a]) for a in range(d)) - sp.diff(trH, Y[m]))) == 0 for m in range(d))
    record(f'F4.footnote14.d{d}', 'footnote 14: 16piG dE_zz = -(d(d-1)/2l^2) z^{d-2} h^(d)mu_mu + ..., 16piG dE_zmu = (d/2l^2) z^{d-1}(d^nu h^(d)_numu - d_mu h^(d)) + ...', 'EXACT_SYMBOLIC',
           okz and okm, Ezz_leading=ezz0)
    C = [fn('C%d' % m, Y) for m in range(d)]; Cz = fn('Cz', Y); dC = sum(eta[m, m]*sp.diff(C[m], Y[m]) for m in range(d))
    T = sp.zeros(n, n)
    for m in range(d): T[m, d] = T[d, m] = z**(d-1)*C[m]
    T[d, d] = z**(d-2)*Cz - z**d*dC/2
    div = [sp.simplify(v) for v in cov_div_lower(d, X, T, D['g'], D['gi'], D['Gam'])]
    f = [fn('f%d' % m, X) for m in range(d)]; F = fn('F', X); T2 = sp.zeros(n, n)
    for m in range(d): T2[m, d] = T2[d, m] = f[m]
    T2[d, d] = F
    div2 = [sp.simplify(v) for v in cov_div_lower(d, X, T2, D['g'], D['gi'], D['Gam'])]
    # general solution: the d+1 equations are first order linear ODEs in z (d_z of f_mu, F appears linearly): check structure
    first_order = all(sp.simplify(sp.diff(v, sp.Derivative(f[m], z))) != 0 for m, v in enumerate(div2[:d])) and sp.simplify(sp.diff(div2[d], sp.Derivative(F, z))) != 0
    record(f'F4.eq4_22.d{d}', '(4.22): with deltaE_munu = 0 the Bianchi identity is d+1 first-order ODEs in z for (E_zmu, E_zz); E_zmu = z^{d-1}C_mu, E_zz = z^{d-2}C_z - z^d d_mu C^mu/2 solves them and has d+1 free functions (general solution)', 'EXACT_SYMBOLIC',
           all(v == 0 for v in div) and first_order, residual=div)
sys.exit(dump('f04_linearized_einstein', out))
