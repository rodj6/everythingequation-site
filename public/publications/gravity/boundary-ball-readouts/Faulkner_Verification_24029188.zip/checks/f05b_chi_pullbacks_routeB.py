"""F5b (part 2): pullbacks of the route-A current to B~ (A2: entropy, needs kappa = 2 pi) and to z -> 0 (A3: energy E_sp),
the CHM-normalisation control, and the independent route B (Riemannian Hamiltonian-constraint identity with static potential)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
from fchi import build_X
import itertools
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
def fn(name, args): return sp.Function(name)(*args)
def perm_sign(p):
    p = list(p); s = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: s = -s
    return s
def levi(n):
    E = {}
    for p in itertools.permutations(range(n)): E[p] = perm_sign(p)
    return lambda *idx: E.get(tuple(idx), 0)
# (A2),(A3): pullbacks in radial gauge, J^B = sqrt(-g) X^{tB}; chi_Sigma = c' J with c' fixed by (A3) and then tested by (A2)
for d in (2, 3, 4):
    X = coords(d); n = d + 1; t, z = X[0], X[-1]; xs = X[1:-1]; t0 = 0; x0 = [0]*(d - 1)
    H = sp.Matrix(n, n, lambda a, b: fn('H%d%d' % (min(a, b), max(a, b)), X) if (0 < a < n - 1 and 0 < b < n - 1) else 0)
    h = z**(d-2)*H
    def chi_J(xi):
        Xm, g, gi = build_X(d, X, h, xi)
        sq = sp.sqrt(-g.det())
        return [sp.simplify((-sq*Xm[0, B]/(16*sp.pi)).subs(t, t0)) for B in range(1, n)]   # G*chi components ~ J^B (index over x.., z)
    xi = xi_B(d, X, R, x0, t0); J = chi_J(xi)
    # (A3): z -> 0 flux density of J^z
    Jz0 = sp.simplify(J[-1].subs(z, 0).doit())   # H smooth up to z = 0, so z*d_z H -> 0
    r2 = sum(v**2 for v in xs); trH = sum(H[i, i] for i in range(1, n - 1)).subs({t: t0, z: 0})
    e_dens = sp.Integer(d)*l**(d-3)/(16*sp.pi)*sp.pi/R*(R**2 - r2)*trH
    s3 = sp.simplify(Jz0/e_dens)
    record(f'F5.routeA_boundary.d{d}', '(4.24)/(A3): at z -> 0 the pulled-back chi is the modular-energy density (d l^{d-3}/16piG)(pi/R)(R^2-r^2) H_ii(z=0) (orientation sign c\')', 'EXACT_SYMBOLIC',
           s3 in (1, -1), orientation_sign=s3)
    # (A2): flux through B~ in graph form J^i x_i/z + J^z at z = sqrt(R^2-r^2) vs dA/4 density (R l^{d-3}/8) z^{2-d}(delta - xx/R^2) h_ij
    Zs = sp.Symbol('Z', positive=True)
    flux = (sum(J[i]*xs[i] for i in range(d - 1))/z + J[-1]).subs(z, Zs)
    Rr = sp.sqrt(r2 + Zs**2)
    dens = Rr*l**(d-3)/8*sum(((1 if i == j else 0) - xs[i]*xs[j]/Rr**2)*H[i+1, j+1].subs({t: t0, z: Zs}) for i in range(d - 1) for j in range(d - 1))
    s2 = sp.simplify((flux.subs(R, Rr))/dens)
    record(f'F5.routeA_bifurcation.d{d}', '(4.25)/(A2): on B~ the pulled-back chi = delta Q[xi] equals the delta A/4G density pointwise, with the same orientation sign as (A3) (so int_B~ chi - int_B chi = int_Sigma d chi reproduces dS - dE)', 'EXACT_SYMBOLIC',
           s2 == s3, orientation_sign=s2)
    Jc = chi_J(xi/(2*sp.pi*R))
    fluxc = (sum(Jc[i]*xs[i] for i in range(d - 1))/z + Jc[-1]).subs(z, Zs)
    s2c = sp.simplify(fluxc.subs(R, Rr)/dens)
    record(f'F5.control_chm_normalisation.d{d}', 'CONTROL: with the CHM normalisation zeta = xi/(2 pi R) (kappa = 1/R) the bifurcation-surface charge is dS/(2 pi R), not dS', 'CONTROL_FAILURE',
           sp.simplify(s2c - s3/(2*sp.pi*Rr)) == 0, ratio=s2c)
# Route B
for d in (2, 3):
    xs = sp.symbols('x1:%d' % d, real=True); z = sp.Symbol('z', positive=True); Xs = list(xs) + [z]
    qb = sp.diag(*([l**2/z**2]*d)); qi = qb.inv(); Gq = christoffel(qb, Xs)
    q = sp.Matrix(d, d, lambda a, b: fn('q%d%d' % (min(a, b), max(a, b)), Xs)); V = fn('V', Xs)
    sq = sp.sqrt(qb.det())
    def cov(T):  # D_A T^{BC} for contravariant 2-tensor: returns function
        return lambda A, B, C: sp.diff(T[B, C], Xs[A]) + sum(Gq[B][A][e]*T[e, C] + Gq[C][A][e]*T[B, e] for e in range(d))
    qup = qi*q*qi; trq = sum(qi[a, b]*q[a, b] for a in range(d) for b in range(d)); Dq = cov(qup)
    gradV = [sum(qi[A, B]*sp.diff(V, Xs[B]) for B in range(d)) for A in range(d)]
    U = [V*(sum(Dq(B, A, B) for B in range(d)) - sum(qi[A, B]*sp.diff(trq, Xs[B]) for B in range(d))) - sum(qup[A, B]*sp.diff(V, Xs[B]) for B in range(d)) + trq*gradV[A] for A in range(d)]
    divU = sum(sp.diff(sq*U[A], Xs[A]) for A in range(d))/sq
    dGq = [[[sum(qi[c, e]*(sp.diff(q[b, e], Xs[a]) + sp.diff(q[a, e], Xs[b]) - sp.diff(q[a, b], Xs[e])) for e in range(d))/2
              - sum(qi[c, e]*q[e, f]*Gq[f][a][b] for e in range(d) for f in range(d)) for b in range(d)] for a in range(d)] for c in range(d)]
    dRic = sp.Matrix(d, d, lambda a, b: sum(sp.diff(dGq[c][a][b], Xs[c]) - sp.diff(dGq[c][a][c], Xs[b]) for c in range(d))
                     + sum(dGq[c][c][e]*Gq[e][a][b] + Gq[c][c][e]*dGq[e][a][b] - dGq[c][b][e]*Gq[e][a][c] - Gq[c][b][e]*dGq[e][a][c] for c in range(d) for e in range(d)))
    Ric = -sp.Integer(d - 1)/l**2*qb
    dR = sum(qi[a, b]*dRic[a, b] for a in range(d) for b in range(d)) - sum(qup[a, b]*Ric[a, b] for a in range(d) for b in range(d))
    HV = sp.Matrix(d, d, lambda a, b: sp.diff(V, Xs[a], Xs[b]) - sum(Gq[c][a][b]*sp.diff(V, Xs[c]) for c in range(d)))
    LapV = sum(qi[a, b]*HV[a, b] for a in range(d) for b in range(d))
    adj = sum(q[a, b]*(qi*(HV - qb*LapV - V*Ric)*qi)[a, b] for a in range(d) for b in range(d))
    ok = sp.simplify(sp.expand(V*dR - divU - adj)) == 0
    record(f'F5.routeB_identity.d{d}', 'route B: V deltaR[q] - D_A U^A = q^AB(D_A D_B V - qbar_AB Lap V - V Ric_AB) for arbitrary V and q (all components)', 'EXACT_SYMBOLIC', ok)
    # B~ flux: with V = 0 there and grad V = -2pi nu (nu outward unit normal), U.nu = 2pi (q_nunu - tr q) = -2pi tr_{B~} q
    Vs = sp.pi*l/(R*z)*(R**2 - z**2 - sum(v**2 for v in xs))
    nuv = sp.Matrix([*xs, z]); nnorm = sp.sqrt((nuv.T*qb*nuv)[0]); nu_up = nuv/nnorm
    Us = [u.subs(V, Vs).doit() for u in U]
    Unu = sum((qb*nu_up)[A]*Us[A] for A in range(d))
    nu_low = qb*nu_up
    trB = trq - sum(nu_up[A]*nu_up[B]*q[A, B] for A in range(d) for B in range(d))
    u_ = [sp.Rational(2, 7)]*(d - 1); pt = {z: R*sp.sqrt(1 - sum(a**2 for a in u_))}; pt.update({xs[i]: R*u_[i] for i in range(d - 1)})
    chk = sp.simplify((Unu + 2*sp.pi*trB).subs(pt))
    record(f'F5.routeB_bifurcation.d{d}', 'route B on B~: U.nu = -2 pi tr_{B~} q = -2 pi gamma^{ab} delta gamma_ab, so the B~ flux is -4 pi delta A (= -16 pi G dS)', 'EXACT_SYMBOLIC', chk == 0, residual=chk)
sys.exit(dump('f05b_chi_pullbacks_routeB', out))
