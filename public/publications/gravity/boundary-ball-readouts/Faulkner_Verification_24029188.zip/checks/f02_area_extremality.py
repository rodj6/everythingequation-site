"""F2: entropy readout for the Einstein branch. (a) B~ is totally geodesic (both extrinsic curvatures vanish);
(b) the first area variation at fixed surface is (4.7), derived from delta A = (1/2) int sqrt(gamma) gamma^{ab} delta gamma_ab
for a general slice perturbation (all components) and reduced in radial gauge; (c) a normal deformation with fixed
anchoring does not change the area at first order (why the background extremal surface suffices, footnote 8);
controls: non-anchored deformation and a non-extremal surface; (d) Wald functional = A/4G for L = R/16 pi G."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
for d in (2, 3, 4):
    m = d - 1; xs = sp.symbols('x1:%d' % d, real=True); z = sp.Symbol('z', positive=True); Xs = list(xs) + [z]
    q = sp.diag(*([l**2/z**2]*d)); Gq = christoffel(q, Xs)
    F = sum(x**2 for x in xs) + z**2 - R**2
    dF = sp.Matrix([sp.diff(F, v) for v in Xs]); nrm = sp.sqrt((dF.T*q.inv()*dF)[0, 0]); nl = dF/nrm
    Dn = sp.Matrix(d, d, lambda a, b: sp.diff(nl[b], Xs[a]) - sum(Gq[c][a][b]*nl[c] for c in range(d)))
    nu = q.inv()*nl; P = sp.eye(d) - nu*nl.T  # projector P^a_b
    K = P.T*Dn*P
    u = [sp.Rational(2, 9)]*(m); zz = sp.sqrt(1 - sum(a**2 for a in u)); pt = {z: R*zz}; pt.update({xs[i]: R*u[i] for i in range(m)})
    Kp = sp.simplify(K.subs(pt))
    record(f'F2.totally_geodesic.d{d}', 'hemisphere B~ has vanishing extrinsic curvature in the H^d slice; the slice t=t0 is totally geodesic (static); so B~ is extremal with K=0 for both normals', 'EXACT_SYMBOLIC',
           Kp == sp.zeros(d, d), K_at_point=Kp)
    # (b) area variation for general symmetric slice perturbation q_AB
    qf = sp.Matrix(d, d, lambda a, b: sp.Function('q%d%d' % (min(a, b), max(a, b)))(*Xs))
    Zs = sp.Symbol('Z', positive=True)   # Z = sqrt(R^2 - |x|^2) on B~, i.e. R^2 = |x|^2 + Z^2
    E = sp.Matrix(d, m, lambda A, a: (1 if A == a else 0) if A < m else -xs[a]/Zs)
    qz = q.subs(z, Zs); qfz = qf.subs(z, Zs)
    gam = sp.simplify(E.T*qz*E); dgam = E.T*qfz*E
    sq = l**(m)*sp.sqrt(sum(x**2 for x in xs) + Zs**2)/Zs**(m + 1)   # sqrt(det gamma), positive branch
    assert sp.simplify(sq**2 - gam.det()) == 0
    dens = sq*sum((gam.inv()*dgam)[a, a] for a in range(m))/2
    zf = {qf[a, b].func for a in range(d) for b in range(d) if a == d - 1 or b == d - 1}
    dens_rad = dens.replace(lambda e: isinstance(e, sp.core.function.AppliedUndef) and e.func in zf, lambda e: 0)
    Rr = sp.sqrt(sum(x**2 for x in xs) + Zs**2)
    target = Rr*l**(d-3)/2*Zs**(2-d)*sum(((1 if i == j else 0) - xs[i]*xs[j]/Rr**2)*qfz[i, j] for i in range(m) for j in range(m))
    diff47 = sp.simplify(dens_rad - target)
    record(f'F2.area_variation.d{d}', '(4.7): delta A = (R l^{d-3}/2) int d^{d-1}x z^{2-d}(delta_ij - x_i x_j/R^2) h_ij in radial gauge, from the general first variation (sqrt(gamma) gamma^{ab} delta gamma_ab / 2)', 'EXACT_SYMBOLIC',
           diff47 == 0, general_density_has_hz_terms=any(dens.has(qf[a, d-1].func) for a in range(d)))
# (c) normal deformation with fixed anchoring, d=3, polar parametrisation
th, ph, eps = sp.symbols('theta phi epsilon', real=True); dl = sp.Symbol('delta', positive=True)
eta_ = sp.Symbol('eta', positive=True)
def first_var(w, conformal=True):
    """d/d eps of the area of r = R + eps w(theta,phi) with the physical cutoff z >= eta:
    interior term int_0^{theta0} d1 + moving-cutoff term int dphi theta1 dens0(theta0), R cos(theta0) = eta,
    theta1 = w cos(theta0)/(R sin(theta0)). Returned in terms of c0 = cos(theta0) = eta/R."""
    rr = R + eps*w; Xv = sp.Matrix([rr*sp.sin(th)*sp.cos(ph), rr*sp.sin(th)*sp.sin(ph), rr*sp.cos(th)])
    Xt, Xp = Xv.diff(th), Xv.diff(ph)
    EE, FF, GG = (Xt.T*Xt)[0], (Xt.T*Xp)[0], (Xp.T*Xp)[0]
    dens = (l**2/Xv[2]**2 if conformal else 1)*sp.sqrt(EE*GG - FF**2)
    d1 = sp.simplify(sp.diff(dens, eps).subs(eps, 0)); d0 = sp.simplify(dens.subs(eps, 0))
    c = sp.Symbol('c', positive=True)
    to_c = lambda e: sp.simplify(e.subs(sp.cos(th), c).subs(sp.sin(th), sp.sqrt(1 - c**2)).subs(th, sp.acos(c)))
    Iph = sp.integrate(sp.expand(d1), (ph, 0, 2*sp.pi))
    interior = sp.integrate(to_c(Iph/sp.sin(th)), (c, eta_/R, 1))
    bnd = sp.integrate(to_c(w*sp.cos(th)/(R*sp.sin(th))*d0), (ph, 0, 2*sp.pi)).subs(c, eta_/R)
    return sp.simplify(interior + bnd)
w1 = sp.cos(th)**2*(1 + sp.sin(th)*sp.cos(ph))       # normal displacement O(z^2) = o(z) at the anchor
I1 = first_var(w1); L1 = sp.limit(I1, eta_, 0)
record('F2.normal_variation_fixed_anchor.d3', 'first area variation of B~ (cutoff z >= eta) under a normal deformation that is o(z) at the anchor dB -> 0 as eta -> 0 (footnote 8: background extremal surface suffices)', 'EXACT_SYMBOLIC',
       L1 == 0, regulated_first_variation=I1, limit=L1)
w2 = sp.cos(th)*(1 + sp.sin(th)*sp.cos(ph)); L2 = sp.limit(first_var(w2), eta_, 0)
record('F2.anchor_order_z.d3', 'CONTROL (domain condition): a normal displacement of exact order z at the anchor changes the area at first order by (l^2/R) oint (w/cos theta)|_rim dphi = 2 pi l^2/R != 0', 'CONTROL_FAILURE',
       sp.simplify(L2 - 2*sp.pi*l**2/R) == 0 and L2 != 0, limit=L2)
I3 = first_var(sp.Integer(1))
record('F2.control_moved_anchor.d3', 'CONTROL: moving the anchor (R -> R+eps) gives a first variation 2 pi l^2/eta that diverges with the cutoff', 'CONTROL_FAILURE',
       sp.simplify((I3 - 2*sp.pi*l**2/eta_).replace(sp.Abs, lambda a: a)) == 0, regulated_first_variation=I3)
I4 = sp.simplify(sp.piecewise_fold(first_var(w1, conformal=False)).subs(eta_, 0))
record('F2.control_nonextremal.d3', 'CONTROL: the same hemisphere in the flat metric is not extremal: nonzero first variation under the same o(z) deformation', 'CONTROL_FAILURE',
       sp.simplify(I4) != 0, first_variation_flat=I4)
# (d) Wald functional for Einstein: binormal of {t=t0} and B~ at a point of AdS_4
d = 3; X = coords(d); g = gbar(d, X); gi = g.inv(); t, x1, x2, z = X
pt = {t: 0, x1: R*sp.Rational(2, 3), x2: R*sp.Rational(1, 3), z: R*sp.Rational(2, 3)}
n1 = sp.Matrix([l/z, 0, 0, 0]).subs(pt)  # unit future normal (lower index, sign irrelevant)
dF = sp.Matrix([0, 2*x1, 2*x2, 2*z]).subs(pt); n2 = dF/sp.sqrt((dF.T*gi.subs(pt)*dF)[0])
nab = n1*n2.T - n2*n1.T; giP = gi.subs(pt)
nn = sp.simplify(sum(nab[a, b]*(giP*nab*giP)[a, b] for a in range(4) for b in range(4)))
G_ = sp.Symbol('G_N', positive=True)
ER = lambda a, b, c, e: (giP[a, c]*giP[b, e] - giP[a, e]*giP[b, c])/(32*sp.pi*G_)
con = sp.simplify(sum(ER(a, b, c, e)*nab[a, b]*nab[c, e] for a in range(4) for b in range(4) for c in range(4) for e in range(4)))
record('F2.wald_einstein', 'binormal n_ab n^ab = -2 and (dL/dR_abcd) n_ab n_cd = -1/(8 pi G) for L=R/16piG, so (1.5) gives S_Wald = A/4G (RT; same contraction as the CHM lift)', 'EXACT_SYMBOLIC',
       nn == -2 and sp.simplify(con + 1/(8*sp.pi*G_)) == 0, binormal_norm=nn, contraction=con)
sys.exit(dump('f02_area_extremality', out))
