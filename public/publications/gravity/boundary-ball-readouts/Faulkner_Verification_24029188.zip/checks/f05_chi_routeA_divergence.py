"""F5 (part 1): route A of the Einstein off-shell identity: form lemma (A0), divergence identity (A1)
nabla_b X^{ab} = 2 xi_b dE^{ab} for arbitrary off-shell h (d=2,3), and the non-Killing / off-shell-background controls.
See f05b for the pullbacks (A2),(A3) and route B. chi = -(1/16piG)(1/2) X^{ab} eps_ab as in (4.26)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from fgeom import *
from fchi import build_X
import itertools
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
def fn(name, args): return sp.Function(name)(*args)
def perm_sign(p):
    p = list(p); s = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: s = -s
    return s
def levi(n):
    E = {}
    for p in itertools.permutations(range(n)): E[p] = perm_sign(p)
    return lambda *idx: E.get(tuple(idx), 0)
# (A0) form lemma in flat space with Levi-Civita symbol (sqrt g = 1), n = 3 and 4
for n in (3, 4):
    X = sp.symbols('u0:%d' % n, real=True); eps = levi(n)
    Xab = sp.Matrix(n, n, lambda a, b: fn('X%d%d' % (a, b), X) if a < b else (-fn('X%d%d' % (b, a), X) if a > b else 0))
    # omega components omega_{c...} (rank n-2) = (1/2) X^{ab} eps_{ab c...}
    idx = list(itertools.combinations(range(n), n - 2))
    om = {c: sum(Xab[a, b]*eps(a, b, *c) for a in range(n) for b in range(n))/2 for c in itertools.permutations(range(n), n - 2)}
    ok = True
    for cc in itertools.permutations(range(n), n - 1):
        # (d omega)_{c0 c1 ...} = sum over positions: (n-1) d_[c0 omega_{c1..}]
        dom = 0
        for k in range(n - 1):
            rest = cc[:k] + cc[k+1:]; sgn = (-1)**k
            dom += sgn*sp.diff(om[rest], X[cc[k]]) if len(set(rest)) == len(rest) else 0
        div = [sum(sp.diff(Xab[a, b], X[b]) for b in range(n)) for a in range(n)]
        rhs = sum(div[a]*eps(a, *cc) for a in range(n))
        if sp.simplify(dom - rhs) != 0: ok = False
    record(f'F5.form_lemma.n{n}', 'with N = (1/p!) N_{a..} dx^a.. and eps_a, eps_ab as in (5.3): d((1/2) X^{ab} eps_ab) = (nabla_b X^{ab}) eps_a (sign +1)', 'EXACT_SYMBOLIC', ok)
for d in (2, 3):
    X = coords(d); n = d + 1; t0 = sp.Rational(1, 4); x0 = [sp.Rational(1, 3)]*(d - 1)
    h = sp.Matrix(n, n, lambda a, b: fn('h%d%d' % (min(a, b), max(a, b)), X))
    xi = xi_B(d, X, R, x0, t0)
    Xm, g, gi = build_X(d, X, h, xi)
    dE, D = lin_einstein(d, X, h)
    sq = sp.sqrt(-g.det()); dEup = gi*dE*gi; xil = g*xi
    lhs = [sp.expand(sum(sp.diff(sq*Xm[a, b], X[b]) for b in range(n))/sq) for a in range(n)]
    rhs = [sum(xil[b]*dEup[a, b] for b in range(n)) for a in range(n)]
    ratio_ok = all(sp.cancel(sp.expand(lhs[a] - 2*rhs[a])) == 0 for a in range(n))
    record(f'F5.routeA_divergence.d{d}', '(4.15)/(5.24) Einstein: nabla_b X^{ab} = 2 xi_b dE^{ab} for arbitrary off-shell h (all components) => d chi = -2 xi^a deltaE_ab eps^b', 'EXACT_SYMBOLIC', ratio_ok)
    # controls
    xi_bad = xi + sp.Matrix([X[-1]**2] + [0]*(n - 1))
    Xb, _, _ = build_X(d, X, h, xi_bad)
    lb = [sp.expand(sum(sp.diff(sq*Xb[a, b], X[b]) for b in range(n))/sq) for a in range(n)]
    xilb = g*xi_bad; rb = [sum(xilb[b]*dEup[a, b] for b in range(n)) for a in range(n)]
    record(f'F5.control_nonkilling.d{d}', 'CONTROL: for a non-Killing vector (xi + z^2 d_t) the identity fails', 'CONTROL_FAILURE',
           any(sp.cancel(sp.expand(lb[a] - 2*rb[a])) != 0 for a in range(n)))
    dEw = dE + sp.Rational(1, 7)/l**2*h; dEwup = gi*dEw*gi
    rw = [sum(xil[b]*dEwup[a, b] for b in range(n)) for a in range(n)]
    record(f'F5.control_offshell_background.d{d}', 'CONTROL: pairing with the residual of a wrong cosmological constant (background off shell for it) breaks the identity', 'CONTROL_FAILURE',
           any(sp.cancel(sp.expand(lhs[a] - 2*rw[a])) != 0 for a in range(n)))
sys.exit(dump('f05_chi_routeA_divergence', out))
