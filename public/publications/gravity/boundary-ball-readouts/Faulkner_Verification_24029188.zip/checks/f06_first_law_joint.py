"""F6: the joined first-law identity for the Einstein branch, exactly, with no form conventions involved:
   G dS_B - G E_B = -(1/8pi) int_Sigma xi^t dE_tt (l/z)^{d-1} dz d^{d-1}x     ( = -2 int_Sigma xi^t deltaE_tt eps^t, eq. (4.17) )
with dS from the RT variation (4.7), E_B from the holographic stress tensor (4.13) with the spatial trace (E_sp), and dE from
the linearized Einstein operator (F4). Exact polynomial integration, symbolic R, off-centre balls, t0 != 0, d = 2,3,4.
On-shell controls (planar black brane; z-dependent TT graviton) give dS = dE exactly; off-shell, normalisation, sign and
trace-premise controls fail as they should."""
import sys, os, random; sys.path.insert(0, os.path.dirname(__file__))
from common import record, dump
from ffl import build, readouts, sp, l
out = sys.argv[1]
R = sp.Symbol('R', positive=True)
random.seed(20261106)
def rnd(): return sp.Rational(random.randint(-6, 6), random.randint(1, 5))
def random_H(X):
    n = len(X); t, z = X[0], X[-1]; xs = X[1:-1]
    mons = [1, t, z, z**2, t*z, t**2, z**3] + list(xs) + [x*z for x in xs] + [x*t for x in xs] + [x*x for x in xs] + [z**2*x for x in xs]
    M = sp.zeros(n, n)
    for a in range(n - 1):
        for b in range(a, n - 1): M[a, b] = M[b, a] = sum(rnd()*mm for mm in mons)
    return M
for d in (2, 3, 4):
    X, H, h, dE = build(d, random_H)
    for k, (x0, t0) in enumerate([([sp.Rational(1, 3)*(-1)**i for i in range(d - 1)], sp.Rational(1, 2)), ([sp.Rational(-2, 5)]*(d - 1), sp.Rational(-3, 4))]):
        ro = readouts(d, X, H, dE, R, x0, t0)
        res = sp.simplify(ro['GS'] - ro['GEsp'] - ro['GB'])
        record(f'F6.offshell_identity.d{d}.ball{k}', f'(4.17) exact for a random off-shell radial-gauge perturbation (time-dependent, all h_ij, polynomial in x,z): G(dS - E_sp) = -(1/8pi) int_Sigma xi^t dE_tt (l/z)^(d-1); x0={x0}, t0={t0}, symbolic R', 'EXACT_SYMBOLIC',
               res == 0, GS=ro['GS'], GEsp=ro['GEsp'], GBulk=ro['GB'])
        if k == 0:
            record(f'F6.offshell_defect_nonzero.d{d}', 'CONTROL: off shell the first law fails, dS - E != 0 (the identity is not a tautology)', 'CONTROL_FAILURE',
                   sp.simplify(ro['GS'] - ro['GEsp']) != 0, defect=sp.simplify(ro['GS'] - ro['GEsp']))
# on-shell controls
for d in (2, 3, 4):
    def brane(X):  # linearized planar black brane in FG gauge: h^(d) = c diag(d-1, 1, ..., 1), traceless, exact solution
        n = len(X); M = sp.zeros(n, n); M[0, 0] = sp.Integer(d - 1)*sp.Rational(3, 7)
        for a in range(1, n - 1): M[a, a] = sp.Rational(3, 7)
        return M
    X, H, h, dE = build(d, brane)
    on = all(sp.simplify(e) == 0 for e in dE)
    ro = readouts(d, X, H, dE, R, [sp.Rational(1, 5)]*(d - 1), sp.Rational(2, 3))
    record(f'F6.onshell_brane.d{d}', 'on-shell control (linearized black brane, h^(d) traceless): deltaE = 0 exactly and dS = E_sp = E_hol for an off-centre ball', 'EXACT_SYMBOLIC',
           on and sp.simplify(ro['GS'] - ro['GEsp']) == 0 and sp.simplify(ro['GS'] - ro['GEhol']) == 0, GS=ro['GS'])
    ECHM = ro['GEhol']/(2*sp.pi*R)
    record(f'F6.control_chm_energy.d{d}', 'CONTROL: using the CHM-normalised generator (kappa = 1/R) for the energy breaks the on-shell first law', 'CONTROL_FAILURE',
           sp.simplify(ro['GS'] - ECHM) != 0)
    record(f'F6.control_sign.d{d}', 'CONTROL: reversing the charge sign (dS = -E) fails on shell', 'CONTROL_FAILURE', sp.simplify(ro['GS'] + ro['GEhol']) != 0)
for d in (3, 4):
    def graviton(X, c=None):  # TT graviton h_x1x2 = z^{d-2}(t^2 + z^2/(d+2)): boundary data traceless and conserved, exact solution
        n = len(X); t, z = X[0], X[-1]; M = sp.zeros(n, n); cc = sp.Rational(1, d + 2) if c is None else c
        M[1, 2] = M[2, 1] = t**2 + cc*z**2 + X[1]**0*sp.Rational(1, 3)
        return M
    X, H, h, dE = build(d, graviton)
    on = all(sp.simplify(e) == 0 for e in dE)
    ro = readouts(d, X, H, dE, R, [sp.Rational(1, 2), sp.Rational(-1, 3)] + [0]*(d - 3), sp.Rational(3, 5))
    record(f'F6.onshell_graviton.d{d}', 'on-shell control (z-dependent TT graviton): deltaE = 0 exactly and dS = E for an off-centre ball', 'EXACT_SYMBOLIC',
           on and sp.simplify(ro['GS'] - ro['GEhol']) == 0 and ro['GB'] == 0, GS=ro['GS'])
    def brane_z(X):  # black brane plus an off-shell radial profile in the spatial block
        n = len(X); z = X[-1]; M = sp.zeros(n, n); M[0, 0] = sp.Integer(d - 1)*sp.Rational(3, 7)
        for a in range(1, n - 1): M[a, a] = sp.Rational(3, 7) + sp.Rational(2, 9)*z**2
        return M
    X, H, h, dE = build(d, brane_z)
    ro = readouts(d, X, H, dE, R, [sp.Rational(1, 2), sp.Rational(-1, 3)] + [0]*(d - 3), sp.Rational(3, 5))
    record(f'F6.control_wrong_profile.d{d}', 'CONTROL: the black brane with a wrong radial profile in h_ij is off shell; its first-law defect is nonzero and equals the bulk residual integral', 'CONTROL_FAILURE',
           sp.simplify(ro['GS'] - ro['GEhol']) != 0 and sp.simplify(ro['GS'] - ro['GEhol'] - ro['GB']) == 0, defect=sp.simplify(ro['GS'] - ro['GEhol']))
# trace premise: E_hol (h^(d)_tt) agrees with E_sp (h^(d)_ii) only if the boundary trace vanishes
d = 3
def tr_viol(X):
    n = len(X); M = sp.zeros(n, n); M[0, 0] = 1 + X[1]; M[1, 1] = M[2, 2] = sp.Rational(1, 4)
    return M
X, H, h, dE = build(d, tr_viol)
ro = readouts(d, X, H, dE, R, [sp.Rational(1, 3), 0], 0)
record('F6.control_trace_premise.d3', 'CONTROL (premise): if h^(d) is not traceless, E_hol (uses h^(d)_tt) differs from E_sp (uses h^(d)_ii); the gravity identity holds with E_sp, the CFT identification needs the Ward identity T^mu_mu = 0', 'CONTROL_FAILURE',
       sp.simplify(ro['GEhol'] - ro['GEsp']) != 0 and sp.simplify(ro['GS'] - ro['GEsp'] - ro['GB']) == 0, Ehol_minus_Esp=sp.simplify(ro['GEhol'] - ro['GEsp']))
# printed (4.24): d/(16 G R) int (R^2 - r^2) H_ii has no l^{d-3}; equals our E_sp iff l = 1 or d = 3
for d in (2, 3, 4):
    X, H, h, dE = build(d, lambda X: sp.diag(*([0] + [1]*(d - 1) + [0])))
    ro = readouts(d, X, H, dE, R, [0]*(d - 1), 0)
    ys = sp.symbols('y1:%d' % d, real=True)
    from fint import integrate_ball
    printed = sp.Integer(d)/(16*R)*integrate_ball(sp.expand((R**2 - sum(y**2 for y in ys))*(d - 1)), ys, R)
    rat = sp.simplify(ro['GEsp']/printed)
    record(f'F6.printed_4_24.d{d}', 'printed (4.24) lacks the l^{d-3} of (4.13); ratio ours/printed = l^{d-3} (an l = 1 form; harmless)', 'EXACT_SYMBOLIC',
           sp.simplify(rat - l**(d-3)) == 0, ratio=rat)
sys.exit(dump('f06_first_law_joint', out))
