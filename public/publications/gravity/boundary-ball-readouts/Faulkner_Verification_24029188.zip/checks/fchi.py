"""Route-A current X^{ab} of chi (paper (4.26)) for Einstein gravity on Poincare AdS; shared by f05 and f05b."""
from fgeom import *
def build_X(d, X, h, xi, Lam_shift=0):
    n = d + 1; g = gbar(d, X); gi = g.inv(); Gm = christoffel(g, X)
    hup = gi*h*gi; trh = sum(gi[a, b]*h[a, b] for a in range(n) for b in range(n))
    # background nabla_c xi^b and nabla^a xi^b
    Dxi = [[sp.diff(xi[b], X[c]) + sum(Gm[b][c][e]*xi[e] for e in range(n)) for b in range(n)] for c in range(n)]  # Dxi[c][b] = nabla_c xi^b
    Dup = [[sum(gi[a, c]*Dxi[c][b] for c in range(n)) for b in range(n)] for a in range(n)]
    dGam = [[[sum(gi[c, e]*(sp.diff(h[b, e], X[a]) + sp.diff(h[a, e], X[b]) - sp.diff(h[a, b], X[e])) for e in range(n))/2
              - sum(gi[c, e]*h[e, f]*Gm[f][a][b] for e in range(n) for f in range(n)) for b in range(n)] for a in range(n)] for c in range(n)]
    ddup = [[-sum(hup[a, c]*g[c, e]*Dup[e][b] for c in range(n) for e in range(n))*0 for b in range(n)] for a in range(n)]
    # delta(g^{ac} nabla_c xi^b) = -h^{ac} nabla_c xi^b + g^{ac} dGam^b_{cd} xi^d
    for a in range(n):
        for b in range(n):
            ddup[a][b] = -sum(hup[a, c]*Dxi[c][b] for c in range(n)) + sum(gi[a, c]*dGam[b][c][e]*xi[e] for c in range(n) for e in range(n))
    # nabla_c h^{ac} - nabla^a h
    def Dh(c, a, b):  # nabla_c h^{ab}
        return sp.diff(hup[a, b], X[c]) + sum(Gm[a][c][e]*hup[e, b] + Gm[b][c][e]*hup[a, e] for e in range(n))
    theta = [sum(Dh(c, a, c) for c in range(n)) - sum(gi[a, c]*sp.diff(trh, X[c]) for c in range(n)) for a in range(n)]
    Y = sp.Matrix(n, n, lambda a, b: ddup[a][b] + trh*Dup[a][b]/2 + xi[b]*theta[a])
    Xm = Y - Y.T
    return Xm, g, gi
