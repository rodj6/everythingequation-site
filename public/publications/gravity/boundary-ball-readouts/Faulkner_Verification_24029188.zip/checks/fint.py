"""Exact polynomial integration over balls B(R,x0) (boundary), hemispheres (as graphs z=sqrt(R^2-|y|^2) with
measure d^{d-1}x) and half-balls Sigma(R,x0) (bulk, z>0), via monomial moment formulas with Gamma functions."""
import sympy as sp
def _ball_abs_moment(alphas, Rr):
    # integral over |y|<=R in n=len(alphas) dims of prod |y_i|^{alpha_i}
    n = len(alphas); b = [sp.Rational(a + 1, 2) for a in alphas]; N = sum(alphas) + n
    return 2*sp.prod([sp.gamma(x) for x in b])/sp.gamma(sum(b))*Rr**N/N
def ball_moment(alphas, Rr):
    if any(a % 2 for a in alphas): return sp.Integer(0)
    return _ball_abs_moment(alphas, Rr)
def integrate_ball(expr, ys, Rr):
    """int_{|y|<R} expr d^n y for expr polynomial in ys."""
    P = sp.Poly(sp.expand(expr), *ys); out = 0
    for mon, c in P.terms(): out += c*ball_moment(mon, Rr)
    return sp.simplify(out)
def integrate_halfball(expr, ys, zs, Rr):
    """int over {|y|^2+z^2<R^2, z>0} of expr polynomial in ys and z (any integer powers z^k, k>=0)."""
    P = sp.Poly(sp.expand(expr), *(list(ys) + [zs])); out = 0
    for mon, c in P.terms():
        a, k = mon[:-1], mon[-1]
        if any(x % 2 for x in a): continue
        out += c*_ball_abs_moment(list(a) + [k], Rr)/2
    return sp.simplify(out)
def integrate_hemigraph(expr, ys, zs, Rr):
    """int_{|y|<R} expr(y, z=sqrt(R^2-|y|^2)) d^n y for expr polynomial in ys, z (z^k, k>=0)."""
    P = sp.Poly(sp.expand(expr), *(list(ys) + [zs])); out = 0; n = len(ys)
    for mon, c in P.terms():
        a, k = mon[:-1], mon[-1]
        if any(x % 2 for x in a): continue
        b = [sp.Rational(x + 1, 2) for x in a]; m = sum(a) + n
        ang = 2*sp.prod([sp.gamma(x) for x in b])/sp.gamma(sum(b))
        bb = (sp.Rational(m, 2), sp.Rational(k, 2) + 1); rad = Rr**(m + k)*sp.gamma(bb[0])*sp.gamma(bb[1])/sp.gamma(bb[0] + bb[1])/2
        out += c*ang*rad
    return sp.simplify(out)
def integrate_hemigraph_zpow(expr, ys, zs, Rr, p):
    """int_{|y|<R} expr(y, z) z^p d^n y on z = sqrt(R^2-|y|^2), expr polynomial in ys, z; p integer >= -1 (integrable)."""
    P = sp.Poly(sp.expand(expr), *(list(ys) + [zs])); out = 0; n = len(ys)
    for mon, c in P.terms():
        a, k = mon[:-1], mon[-1] + p
        if any(x % 2 for x in a): continue
        b = [sp.Rational(x + 1, 2) for x in a]; m = sum(a) + n
        ang = 2*sp.prod([sp.gamma(x) for x in b])/sp.gamma(sum(b))
        bb = (sp.Rational(m, 2), sp.Rational(k, 2) + 1)
        out += c*ang*Rr**(m + k)*sp.gamma(bb[0])*sp.gamma(bb[1])/sp.gamma(bb[0] + bb[1])/2
    return sp.simplify(out)
