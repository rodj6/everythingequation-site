Verification for DOI 10.5281/zenodo.24029188

Install requirements.txt in a Python environment. Run python run_all.py replay
from this directory to regenerate the original suites. The reference directory
contains the retained original results. Run python errata/check_errata.py for
the exact correction checks. The errata directory also contains the affected
suite output from the correction replay.
