Targeted checks for the corrected Jacobson and Faulkner papers.
Install requirements.txt and run python check_errata.py.
The JSON files record fresh runs of the original Codazzi and restricted-family
suites. Their mathematical implementations already used the corrected
screen rotation and on-shell profile.
