"""Shared geometry for the Faulkner et al. (arXiv:1312.7856v2) Einstein-branch verification.
Poincare AdS_{d+1}: coordinates X = (t, x_1..x_{d-1}, z), metric gbar = (l^2/z^2) diag(-1,1,..,1,1).
Linearized curvature is computed from the exact first-variation formulas (no truncation of h)."""
import sympy as sp
l, G = sp.symbols('ell G_N', positive=True)
def coords(d):
    t = sp.Symbol('t', real=True); z = sp.Symbol('z', positive=True)
    xs = sp.symbols('x1:%d' % d, real=True) if d > 1 else ()
    return [t] + list(xs) + [z]
def gbar(d, X):
    n = d + 1; z = X[-1]
    return sp.diag(*([-l**2/z**2] + [l**2/z**2]*(n-1)))
def christoffel(g, X):
    n = len(X); gi = g.inv()
    return [[[sp.simplify(sum(gi[c, e]*(sp.diff(g[e, a], X[b]) + sp.diff(g[e, b], X[a]) - sp.diff(g[a, b], X[e])) for e in range(n))/2)
              for b in range(n)] for a in range(n)] for c in range(n)]
def lin_einstein(d, X, h, expand=True):
    """Return (dE, data) with dE_ab = 16 pi G * deltaE^g_ab = delta(G_ab + Lambda g_ab), lower indices, Lambda=-d(d-1)/(2l^2)."""
    n = d + 1; g = gbar(d, X); gi = g.inv(); Gm = christoffel(g, X)
    Lam = -sp.Rational(d*(d-1), 2)/l**2
    dGam = [[[0]*n for _ in range(n)] for _ in range(n)]
    for c in range(n):
        for a in range(n):
            for b in range(a, n):
                v = sum(gi[c, e]*(sp.diff(h[b, e], X[a]) + sp.diff(h[a, e], X[b]) - sp.diff(h[a, b], X[e])) for e in range(n))/2
                v -= sum(gi[c, e]*h[e, f]*Gm[f][a][b] for e in range(n) for f in range(n))
                dGam[c][a][b] = dGam[c][b][a] = v
    dR = sp.zeros(n, n)
    for a in range(n):
        for b in range(a, n):
            v = sum(sp.diff(dGam[c][a][b], X[c]) for c in range(n)) - sum(sp.diff(dGam[c][a][c], X[b]) for c in range(n))
            v += sum(dGam[c][c][e]*Gm[e][a][b] + Gm[c][c][e]*dGam[e][a][b] - dGam[c][b][e]*Gm[e][a][c] - Gm[c][b][e]*dGam[e][a][c]
                     for c in range(n) for e in range(n))
            dR[a, b] = dR[b, a] = v
    Rbar_ab = -sp.Integer(d)/l**2*g; Rbar = -sp.Integer(d*(d+1))/l**2
    dRs = sum(gi[a, b]*dR[a, b] for a in range(n) for b in range(n)) - sum((gi*h*gi)[a, b]*Rbar_ab[a, b] for a in range(n) for b in range(n))
    dE = sp.zeros(n, n)
    for a in range(n):
        for b in range(a, n):
            v = dR[a, b] - h[a, b]*Rbar/2 - g[a, b]*dRs/2 + Lam*h[a, b]
            dE[a, b] = dE[b, a] = sp.expand(v) if expand else v
    return dE, dict(g=g, gi=gi, Gam=Gm, dGam=dGam, Lam=Lam)
def cov_div_lower(d, X, T, g, gi, Gm):
    """(nabla^a T_ab) for symmetric lower-index T on the background."""
    n = d + 1; out = []
    for b in range(n):
        v = 0
        for a in range(n):
            for c in range(n):
                v += gi[a, c]*(sp.diff(T[c, b], X[a]) - sum(Gm[e][a][c]*T[e, b] + Gm[e][a][b]*T[c, e] for e in range(n)))
        out.append(v)
    return out
def xi_B(d, X, R, x0=None, t0=0):
    """Paper eq. (3.1): kappa = 2 pi normalized Killing vector of the AdS-Rindler wedge of B(R,x0) at time t0."""
    t, z = X[0], X[-1]; xs = X[1:-1]; x0 = x0 or [0]*len(xs)
    r2 = sum((xi - a)**2 for xi, a in zip(xs, x0))
    v = [sp.pi/R*(R**2 - z**2 - (t - t0)**2 - r2)] + [-2*sp.pi/R*(t - t0)*(xi - a) for xi, a in zip(xs, x0)] + [-2*sp.pi/R*(t - t0)*z]
    return sp.Matrix(v)
def lie_metric(g, X, v):
    n = len(X)
    return sp.Matrix(n, n, lambda a, b: sp.simplify(sum(v[c]*sp.diff(g[a, b], X[c]) + g[c, b]*sp.diff(v[c], X[a]) + g[a, c]*sp.diff(v[c], X[b]) for c in range(n))))
