import sympy as s
from fgeom import coords, lin_einstein, l
c2,c3,p2,p3,C=s.symbols("c2 c3 Phi_j2 Phi_j3 C_j")
R=s.MutableDenseNDimArray.zeros(3,3)
# R(a,b) = Riemann(k,e_j,a,b), indexed by k,e_2,e_3.
R[0,1], R[0,2], R[1,2] = p2,p3,C
for i in range(3):
    for j in range(i+1,3):
        R[j,i]=-R[i,j]
e2=s.Matrix([c2,1,0]); e3=s.Matrix([c3,0,1])
assert s.expand((e2.T*s.Matrix(R.tolist())*e3)[0]-C)==-c3*p2+c2*p3
J=s.Matrix([[0,-1],[1,0]])
assert J.det()==1
print("PASS screen rotation sign and invertible screen-parameter map")
X=coords(3); t,_,_,z=X
H=s.Function("H")(t,z)
D=lambda f: s.diff(f,z,2)+4*s.diff(f,z)/z-s.diff(f,t,2)
g=z**3*H
assert s.expand(s.diff(g,z,2)-2*s.diff(g,z)/z-s.diff(g,t,2)-z**3*D(H))==0
h=s.zeros(4);h[1,2]=h[2,1]=z*H
E,_=lin_einstein(3,X,h)
expected=s.zeros(4);expected[1,2]=expected[2,1]=-z**3*D(H)/(2*l**2)
assert all(s.simplify(a-b)==0 for a,b in zip(E,expected))
assert D(t*t+z*z/5+s.Rational(1,3))==0
assert D(t*t+z*z/7+s.Rational(1,3))==-s.Rational(4,7)
assert D(t*t-z*z+s.Rational(1,3))==-12
print("PASS independent curvature, rescaled operator, both corrected examples and old-profile negative control")
