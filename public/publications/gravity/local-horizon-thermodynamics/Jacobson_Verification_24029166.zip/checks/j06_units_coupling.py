"""Jacobson 1995, eq (6) and "G = (4 hbar eta)^-1, eta^-1/2 = 2 l_P", with hbar, c, k_B restored.
Dimension vectors (M, L, T, Theta); homogeneity of every equation in the chain; the restored coupling; controls;
cross-check with the CHM lift's Einstein Wald density; numerical CODATA diagnostic."""
import sys, os, sympy as sp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
dim = {'hbar': (1, 2, -1, 0), 'c': (0, 1, -1, 0), 'kB': (1, 2, -2, -1), 'G': (-1, 3, -2, 0),
       'Tab': (1, -1, -2, 0),          # energy density (coordinates of length, k^a dimensionless)
       'Rab': (0, -2, 0, 0), 'kappa': (0, -1, 0, 0),   # geometric surface gravity: chi = -kappa lambda k dimensionless
       'lam': (0, 1, 0, 0), 'A': (0, 2, 0, 0), 'eta': (1, 0, -2, -1), 'Temp': (0, 0, 0, 1), 'Energy': (1, 2, -2, 0), 'Entropy': (1, 2, -2, -1)}
def D(*facs):
    v = [0, 0, 0, 0]
    for name, p in facs:
        for i in range(4): v[i] += p*dim[name][i]
    return tuple(v)
checks = {
 'Unruh T = hbar c kappa/(2 pi kB) is a temperature': D(('hbar', 1), ('c', 1), ('kappa', 1), ('kB', -1)) == dim['Temp'],
 'heat delta Q = kappa lambda^2 A T_kk is an energy': D(('kappa', 1), ('lam', 2), ('A', 1), ('Tab', 1)) == dim['Energy'],
 'dS = eta dA is an entropy': D(('eta', 1), ('A', 1)) == dim['Entropy'],
 'T dS is an energy': D(('Temp', 1), ('Entropy', 1)) == dim['Energy'],
 'inferred T_kk = (hbar c eta/2pi kB) R_kk is homogeneous': D(('hbar', 1), ('c', 1), ('eta', 1), ('kB', -1), ('Rab', 1)) == dim['Tab'],
 '(8 pi G/c^4) T_ab has the dimension of curvature': D(('G', 1), ('c', -4), ('Tab', 1)) == dim['Rab'],
 'G = kB c^3/(4 hbar eta) has the dimension of G': D(('kB', 1), ('c', 3), ('hbar', -1), ('eta', -1)) == dim['G']}
record('J6.units.homogeneity', 'every equation of the chain is dimensionally homogeneous with hbar, c, k_B restored (dimension vectors M,L,T,Theta)', 'EXACT_SYMBOLIC', all(checks.values()), checks=checks)
hb, c, kB, eta, G, kap, lam0, A0, Tkk, Rkk = sp.symbols('hbar c k_B eta G kappa lambda0 A0 T_kk R_kk', positive=True)
dQ = kap*A0*lam0**2*Tkk/2; TdS = hb*c*kap/(2*sp.pi*kB)*eta*A0*Rkk*lam0**2/2
Tsol = sp.solve(sp.Eq(dQ, TdS), Tkk)[0]
coupling = sp.simplify(Rkk/Tsol)                     # R_kk = coupling * T_kk  <=>  R_ab + f g_ab = coupling T_ab
Gsol = sp.solve(sp.Eq(coupling, 8*sp.pi*G/c**4), G)[0]
record('J6.coupling.restored', 'Clausius at leading order gives R_ab + f g_ab = (2 pi k_B/(hbar c eta)) T_ab; matching 8 pi G/c^4 gives G = k_B c^3/(4 hbar eta) [Jacobson: G = (4 hbar eta)^-1 for c = k_B = 1]', 'EXACT_SYMBOLIC',
       sp.simplify(coupling - 2*sp.pi*kB/(hb*c*eta)) == 0 and sp.simplify(Gsol - kB*c**3/(4*hb*eta)) == 0 and sp.simplify(Gsol.subs({c: 1, kB: 1}) - 1/(4*hb*eta)) == 0, coupling=coupling, G=Gsol)
lP = sp.sqrt(hb*G/c**3)
eta_of_G = sp.solve(sp.Eq(G, kB*c**3/(4*hb*eta)), eta)[0]
record('J6.planck_length', 'eta = k_B/(4 l_P^2) with l_P^2 = hbar G/c^3; for k_B = 1, eta^{-1/2} = 2 l_P ("twice the Planck length")', 'EXACT_SYMBOLIC',
       sp.simplify(eta_of_G - kB/(4*lP**2)) == 0 and sp.simplify(sp.sqrt(1/eta_of_G.subs(kB, 1)) - 2*lP) == 0)
# control: Unruh temperature without hbar (classical "temperature") is not a temperature and breaks the coupling's dimension
record('J6.control.no_hbar', 'dropping hbar from the Unruh temperature (T = c kappa/2pi k_B) is dimensionally inconsistent: the coupling of a classical Einstein equation needs the quantum hbar of the Unruh effect', 'CONTROL_FAILURE',
       D(('c', 1), ('kappa', 1), ('kB', -1)) != dim['Temp'])
# cross-check with the CHM lift: Einstein Wald density S/A = 1/(4G) (hbar=c=kB=1) means eta = 1/(4 G hbar) -> Jacobson returns the same G
record('J6.crosscheck.CHM', 'cross-lift consistency: the Einstein Wald density 1/(4G) recovered in the CHM lift (W.einstein.*) is eta = c^3 k_B/(4 hbar G); inserted into Jacobson\'s coupling it returns the same G', 'EXACT_SYMBOLIC',
       sp.simplify((kB*c**3/(4*hb*eta)).subs(eta, kB*c**3/(4*hb*G)) - G) == 0)
# numerical CODATA diagnostic
vals = {G: sp.Float('6.67430e-11'), hb: sp.Float('1.054571817e-34'), c: sp.Float('299792458'), kB: sp.Float('1.380649e-23')}
eta_num = eta_of_G.subs(vals); lP_num = lP.subs(vals)
ratio = sp.sqrt(vals[kB]/eta_num)/(2*lP_num)
record('J6.numeric.codata', 'numerical diagnostic: with CODATA 2018 constants eta = %.4e J K^-1 m^-2 and sqrt(k_B/eta) = 2 l_P to machine precision (l_P = %.4e m)' % (float(eta_num), float(lP_num)), 'NUMERICAL', abs(float(ratio) - 1) < 1e-12,
       eta_SI=float(eta_num), l_P=float(lP_num), ratio=float(ratio))
sys.exit(dump('j06_units_coupling', sys.argv[1] if len(sys.argv) > 1 else '../results'))
