"""Jacobson 1995, from R_ab + f g_ab = (2pi/hbar eta) T_ab to eq (6). Contracted Bianchi identity (exact on sample
metrics with arbitrary functions), the conservation inference f = -R/2 + Lambda, control without conservation,
trace-free form, vacuum-energy degeneracy, and the reverse implication Einstein => E_kk = 0 for all null k."""
import sys, os, sympy as sp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
t, x, y, z = X = sp.symbols('t x y z', real=True)
A, B, C, F, H = [sp.Function(n)(t, x) for n in 'ABCFH']
def geom(g, simp=True):
    S_ = sp.simplify if simp else (lambda e: e)
    n = 4; gi = S_(g.inv())
    G = [[[S_(sum(gi[a, e]*(sp.diff(g[e, b], X[c]) + sp.diff(g[e, c], X[b]) - sp.diff(g[b, c], X[e])) for e in range(n))/2) for c in range(n)] for b in range(n)] for a in range(n)]
    Ric = sp.Matrix(n, n, lambda b, d: S_(sum(sp.diff(G[a][b][d], X[a]) - sp.diff(G[a][b][a], X[d]) + sum(G[a][a][e]*G[e][b][d] - G[a][d][e]*G[e][b][a] for e in range(n)) for a in range(n))))
    Rs = S_(sum(gi[a, b]*Ric[a, b] for a in range(n) for b in range(n)))
    return gi, G, Ric, Rs
def div(gi, G, M, simp=True):  # nabla^a M_ab for symmetric M
    n = 4; S_ = sp.simplify if simp else (lambda e: e)
    return [S_(sum(gi[a, c]*(sp.diff(M[c, b], X[a]) - sum(G[e][a][c]*M[e, b] + G[e][a][b]*M[c, e] for e in range(n))) for a in range(n) for c in range(n))) for b in range(n)]
metrics = {'diagonal(A,B,C)': sp.diag(-sp.exp(2*A), sp.exp(2*B), sp.exp(2*C), sp.exp(2*C))}   # explicit off-diagonal instance: j05b
kp = sp.symbols('kappa_p', positive=True)                    # kappa' = 2 pi/(hbar eta) = 8 pi G
f = F
for name, g in metrics.items():
    dg = name.startswith('diagonal')
    gi, G, Ric, Rs = geom(g, simp=dg)
    Ein = Ric - Rs*g/2
    pt = {t: sp.Rational(1, 3), x: sp.Rational(-2, 5), y: sp.Rational(3, 7), z: sp.Rational(1, 2)}
    bian = div(gi, G, Ein) if dg else [sp.nsimplify(v.subs(pt)) for v in div(gi, G, Ein, simp=False)]
    record('J5.bianchi.%s' % name, 'contracted Bianchi identity nabla^a(R_ab - R g_ab/2) = 0 (exact check: identically for arbitrary functions [diagonal], exactly at a rational point [explicit off-diagonal]; the identity itself is inherited)', 'EXACT_SYMBOLIC', all(sp.simplify(v) == 0 for v in bian))
    if name.startswith('diagonal'):
        # inference: T := (R_ab + f g_ab)/kappa'  =>  kappa' nabla^a T_ab = d_b (f + R/2)
        divT = div(gi, G, (Ric + f*g)/kp)
        target = [sp.diff(f + Rs/2, X[b])/kp for b in range(4)]
        record('J5.conservation.inference', 'with T_ab := (R_ab + f g_ab)/kappa\', nabla^a T_ab = d_b(f + R/2)/kappa\' identically; so nabla^a T_ab = 0 iff f = -R/2 + Lambda with d Lambda = 0 (Lambda constant on each connected component)', 'EXACT_SYMBOLIC',
               all(sp.simplify(divT[b] - target[b]) == 0 for b in range(4)))
        phi = sp.Function('phi')(t, x)
        divT2 = div(gi, G, (Ric + (-Rs/2 + phi)*g)/kp)
        record('J5.control.no_conservation', 'without local conservation the metric-proportional term is undetermined: f = -R/2 + phi(t,x) with nonconstant phi gives nabla^a T_ab = d_b phi/kappa\' != 0 (conservation is exactly the input that fixes f)', 'CONTROL_FAILURE',
               any(sp.simplify(v) != 0 for v in divT2) and all(sp.simplify(divT2[b] - sp.diff(phi, X[b])/kp) == 0 for b in range(4)))
        # trace-free form and Lambda from conservation
        T = sp.Matrix(4, 4, lambda a, b: sp.Function('T%d%d' % (min(a, b), max(a, b)))(t, x))
        trT = sum(gi[a, b]*T[a, b] for a in range(4) for b in range(4))
        Lam = sp.symbols('Lambda')
        tf_lhs = Ric - Rs*g/4 - kp*(T - trT*g/4)
        ein_lhs = Ric - Rs*g/2 + Lam*g - kp*T
        diffm = sp.simplify(tf_lhs - (ein_lhs - (Lam - (Rs + kp*trT)/4)*g))
        record('J5.tracefree.equivalence', 'E_ab = Phi g_ab is the trace-free Einstein equation R_ab - R g/4 = kappa\'(T_ab - T g/4); it equals (6) minus (Lambda - (R + kappa\' T)/4) g_ab, so with conservation (R + kappa\' T)/4 = Lambda is constant', 'EXACT_SYMBOLIC', diffm == sp.zeros(4, 4))
# vacuum-energy degeneracy and the reverse implication, pointwise in an orthonormal frame
etaM = sp.diag(-1, 1, 1, 1)
Rsym = sp.Matrix(4, 4, lambda a, b: sp.Symbol('R%d%d' % (min(a, b), max(a, b)), real=True))
rho_v, Lam = sp.symbols('rho_v Lambda', real=True)
Rsc = sum(etaM[a, a]*Rsym[a, a] for a in range(4))
Tein = (Rsym - Rsc*etaM/2 + Lam*etaM)/kp                       # matter defined by (6)
u1, u2 = sp.symbols('u1 u2', real=True); qq = u1**2 + u2**2
k = [1, 2*u1/(1 + qq), 2*u2/(1 + qq), (1 - qq)/(1 + qq)]
Ekk = sp.simplify(sum((Rsym[a, b] - kp*Tein[a, b])*k[a]*k[b] for a in range(4) for b in range(4)))
record('J5.reverse.pointwise', 'reverse implication at the point: if (6) holds (any Lambda) then (R_ab - (2pi/hbar eta) T_ab) k^a k^b = 0 for every null k, i.e. the leading Clausius coefficient vanishes for all local Rindler horizons', 'EXACT_SYMBOLIC', Ekk == 0)
Tvac = -rho_v*etaM
Tkk_vac = sp.simplify(sum(Tvac[a, b]*k[a]*k[b] for a in range(4) for b in range(4)))
record('J5.vacuum_energy', 'a vacuum-energy term T_ab = -rho_v g_ab carries no heat (T_kk = 0): it is invisible to the Clausius data and appears only through Lambda_eff = Lambda + kappa\' rho_v, i.e. Lambda and vacuum energy are degenerate in this derivation', 'EXACT_SYMBOLIC', Tkk_vac == 0)
sys.exit(dump('j05_bianchi_conservation', sys.argv[1] if len(sys.argv) > 1 else '../results'))
