"""Second instance of the contracted Bianchi identity (explicit off-diagonal metric depending on all four coordinates,
evaluated exactly at a rational point). Companion to j05. Jacobson 1995, from R_ab + f g_ab = (2pi/hbar eta) T_ab to eq (6). Contracted Bianchi identity (exact on sample
metrics with arbitrary functions), the conservation inference f = -R/2 + Lambda, control without conservation,
trace-free form, vacuum-energy degeneracy, and the reverse implication Einstein => E_kk = 0 for all null k."""
import sys, os, sympy as sp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
t, x, y, z = X = sp.symbols('t x y z', real=True)
A, B, C, F, H = [sp.Function(n)(t, x) for n in 'ABCFH']
def geom(g, simp=True):
    S_ = sp.simplify if simp else (lambda e: e)
    n = 4; gi = S_(g.inv())
    G = [[[S_(sum(gi[a, e]*(sp.diff(g[e, b], X[c]) + sp.diff(g[e, c], X[b]) - sp.diff(g[b, c], X[e])) for e in range(n))/2) for c in range(n)] for b in range(n)] for a in range(n)]
    Ric = sp.Matrix(n, n, lambda b, d: S_(sum(sp.diff(G[a][b][d], X[a]) - sp.diff(G[a][b][a], X[d]) + sum(G[a][a][e]*G[e][b][d] - G[a][d][e]*G[e][b][a] for e in range(n)) for a in range(n))))
    Rs = S_(sum(gi[a, b]*Ric[a, b] for a in range(n) for b in range(n)))
    return gi, G, Ric, Rs
def div(gi, G, M, simp=True):  # nabla^a M_ab for symmetric M
    n = 4; S_ = sp.simplify if simp else (lambda e: e)
    return [S_(sum(gi[a, c]*(sp.diff(M[c, b], X[a]) - sum(G[e][a][c]*M[e, b] + G[e][a][b]*M[c, e] for e in range(n))) for a in range(n) for c in range(n))) for b in range(n)]
g = sp.Matrix([[-(1 + x**2/9), t*y/11, 0, 0], [t*y/11, 1 + t**2/7, 0, z/13], [0, 0, 1 + x*z/17, 0], [0, z/13, 0, 1 + y**2/5]])
gi, G, Ric, Rs = geom(g, simp=False)
pt = {t: sp.Rational(1, 3), x: sp.Rational(-2, 5), y: sp.Rational(3, 7), z: sp.Rational(1, 2)}
bian = [sp.nsimplify(v.subs(pt)) for v in div(gi, G, Ric - Rs*g/2, simp=False)]
nonzero_ric = sp.nsimplify(Ric[0, 1].subs(pt))
record('J5.bianchi.offdiagonal_explicit', 'contracted Bianchi identity nabla^a(R_ab - R g_ab/2) = 0 at a rational point of an explicit non-diagonal metric depending on all four coordinates (nonzero curvature there); the identity itself is inherited', 'EXACT_SYMBOLIC',
       all(v == 0 for v in bian) and nonzero_ric != 0, R01_at_point=nonzero_ric)
sys.exit(dump('j05b_bianchi_offdiagonal', sys.argv[1] if len(sys.argv) > 1 else '../results'))
