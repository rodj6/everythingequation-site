"""Jacobson 1995, step "T_ab k^a k^b = (hbar eta/2pi) R_ab k^a k^b for all null k implies (2pi/hbar eta)T_ab = R_ab + f g_ab".
(a) null-cone lemma as an exact polynomial identity (stereographic parametrisation), D=3,4,5;
(b) explicit reconstruction of the trace-free part from 9 rational null directions (D=4);
(c) uniqueness-set criterion: data on a set S of null directions determine E^TF iff no nonzero element of H_{<=2}
    (spherical harmonics of degree <= 2 on the celestial sphere) vanishes on S: 9 generic directions suffice,
    8 do not, a circle does not (4 undetermined components), a small cap does;
(d) direction-dependent boost normalisation is incompatible with any tensor equation."""
import sys, os, itertools, random, sympy as sp, numpy as np
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
def symE(D):
    return sp.Matrix(D, D, lambda a, b: sp.Symbol('E%d%d' % (min(a, b), max(a, b)), real=True))
for D in (3, 4, 5):
    E = symE(D); us = sp.symbols('u1:%d' % (D - 1), real=True); q = sum(v**2 for v in us)
    n = [2*v/(1 + q) for v in us] + [(1 - q)/(1 + q)]
    k = [sp.Integer(1)] + n
    Ekk = sp.together(sum(E[a, b]*k[a]*k[b] for a in range(D) for b in range(D)))
    num = sp.Poly(sp.expand(sp.numer(Ekk)), *us)
    sol = sp.solve(num.coeffs(), sorted(E.free_symbols, key=str), dict=True)[0]   # sorted: deterministic choice of the free parameter
    Es = E.subs(sol); Phi = Es[1, 1]
    ok = sp.simplify(Es - Phi*sp.diag(-1, *[1]*(D - 1))) == sp.zeros(D, D)
    record('J4.lemma.D%d' % D, 'E_ab k^a k^b = 0 for all null k (polynomial identity on the stereographically parametrised celestial sphere) iff E_ab = Phi g_ab, D=%d' % D, 'EXACT_SYMBOLIC', ok, free_parameter=str(Phi))
# (b) D=4 reconstruction from 9 rational null directions
def nullk(n): return [sp.Integer(1)] + [sp.Rational(c) for c in n]
dirs9 = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 0, 0), (0, -1, 0), (sp.Rational(3, 5), sp.Rational(4, 5), 0), (0, sp.Rational(3, 5), sp.Rational(4, 5)), (sp.Rational(4, 5), 0, sp.Rational(3, 5)), (sp.Rational(2, 3), sp.Rational(2, 3), sp.Rational(1, 3))]
assert all(sum(c**2 for c in d) == 1 for d in dirs9)
pairs = [(a, b) for a in range(4) for b in range(a, 4)]
def row(kv): return [kv[a]*kv[b]*(1 if a == b else 2) for (a, b) in pairs]
Mfull = sp.Matrix([row(nullk(d)) for d in dirs9])            # 9 x 10, kernel must be g
etaflat = [-1, 1, 1, 1]
gvec = sp.Matrix([etaflat[a] if a == b else 0 for (a, b) in pairs])
rk = Mfull.rank(); ker = Mfull.nullspace()
record('J4.reconstruction.rank', '9 explicit rational null directions give an evaluation map of rank 9 on symmetric tensors with kernel exactly span(g): they determine E^TF', 'EXACT_SYMBOLIC',
       rk == 9 and len(ker) == 1 and sp.Matrix.hstack(ker[0], gvec).rank() == 1)
# explicit inverse on the trace-free subspace: gauge-fix E_33 via E^TF trace = 0, i.e. append the row of the trace
trace_row = [(-1 if a == 0 else 1) if a == b else 0 for (a, b) in pairs]          # eta^ab E_ab
Maug = Mfull.col_join(sp.Matrix([trace_row]))
Minv = Maug.inv()
random.seed(3)
Erand = sp.Matrix(4, 4, lambda a, b: 0)
vals = [sp.Rational(random.randint(-9, 9), random.randint(1, 5)) for _ in pairs]
for (a, b), v in zip(pairs, vals): Erand[a, b] = v; Erand[b, a] = v
trE = sum(etaflat[a]*Erand[a, a] for a in range(4))
ETF = Erand - trE/4*sp.diag(*etaflat)
data = sp.Matrix([sum(ETF[a, b]*nullk(d)[a]*nullk(d)[b] for a in range(4) for b in range(4)) for d in dirs9] + [0])
rec = Minv*data
ok_rt = all(sp.simplify(rec[i] - ETF[pairs[i][0], pairs[i][1]]) == 0 for i in range(10))
record('J4.reconstruction.roundtrip', 'recovery map iota: the trace-free tensor is reconstructed exactly from its 9 null-direction Clausius coefficients (explicit inverse, exact rational roundtrip)', 'EXACT_SYMBOLIC', ok_rt)
# (c) uniqueness sets
def rank_of(dirs):
    return sp.Matrix([row(nullk(d)) for d in dirs]).rank()
M8 = sp.Matrix([row(nullk(d)) for d in dirs9[:8]]); ker8 = M8.nullspace()
nonE = None
for v in ker8:
    if sp.Matrix.hstack(v, gvec).rank() == 2: nonE = v; break
Ek = sp.zeros(4, 4)
for i, (a, b) in enumerate(pairs): Ek[a, b] = nonE[i]; Ek[b, a] = nonE[i]
vanish8 = all(sum(Ek[a, b]*nullk(d)[a]*nullk(d)[b] for a in range(4) for b in range(4)) == 0 for d in dirs9[:8])
record('J4.uniqueness.eight_insufficient', 'Clausius on 8 null directions does not fix the tensor: an explicit E not proportional to g has E_kk = 0 on all 8 (rank 8)', 'CONTROL_FAILURE', M8.rank() == 8 and vanish8 and nonE is not None, counterexample=Ek)
# circle: great circle n_z = 0 and small circle n_z = 3/5
circ = [(sp.Rational(c), sp.Rational(s), 0) for c, s in [(1, 0), (0, 1), (-1, 0), (0, -1), (sp.Rational(3, 5), sp.Rational(4, 5)), (sp.Rational(-3, 5), sp.Rational(4, 5)), (sp.Rational(5, 13), sp.Rational(12, 13)), (sp.Rational(-12, 13), sp.Rational(-5, 13)), (sp.Rational(8, 17), sp.Rational(-15, 17)), (sp.Rational(7, 25), sp.Rational(24, 25)), (sp.Rational(-20, 29), sp.Rational(21, 29))]]
small = [(sp.Rational(4, 5)*c, sp.Rational(4, 5)*s, sp.Rational(3, 5)) for c, s in [(1, 0), (0, 1), (-1, 0), (0, -1), (sp.Rational(3, 5), sp.Rational(4, 5)), (sp.Rational(-3, 5), sp.Rational(4, 5)), (sp.Rational(5, 13), sp.Rational(12, 13)), (sp.Rational(-12, 13), sp.Rational(-5, 13)), (sp.Rational(8, 17), sp.Rational(-15, 17)), (sp.Rational(7, 25), sp.Rational(24, 25))]]
rc, rs = rank_of(circ), rank_of(small)
record('J4.uniqueness.circle_insufficient', 'null directions on a circle of the celestial sphere (great circle: directions tangent to a timelike hyperplane; or a small circle) leave 10-1-rank = 4 trace-free components undetermined (rank 5): restricted observer families cannot fix the Einstein tensor', 'CONTROL_FAILURE',
       rc == 5 and rs == 5, rank_great_circle=rc, rank_small_circle=rs)
# small cap: rational points within angular radius ~0.2 rad of the z-axis
cap = []
for (p_, q_) in [(1, 30), (1, 36), (2, 45), (1, 60), (3, 75), (1, 24), (2, 33), (1, 42), (3, 51), (2, 63), (1, 27), (4, 69)]:
    for sx, sy in [(1, 1), (1, -1), (-1, 1)]:
        u1, u2 = sp.Rational(sx*p_, q_), sp.Rational(sy*p_, q_ + 3)
        qq = u1**2 + u2**2; cap.append((2*u1/(1 + qq), 2*u2/(1 + qq), (1 - qq)/(1 + qq)))
rcap = rank_of(cap)
maxang = max(float(sp.acos(d[2])) for d in cap)
record('J4.uniqueness.small_cap_sufficient', 'Clausius on null directions in a small cap of the celestial sphere determines E^TF (exact rank 9 with 36 rational directions within %.3f rad of one direction); the general statement (any open set) follows from real-analyticity of H_{<=2} (proof in report)' % maxang, 'EXACT_SYMBOLIC', rcap == 9, max_angle_rad=maxang)
# H_{<=2} identification: the null-cone function E_kk/(k^0)^2 on S^2 spans exactly the 9 harmonics of degree <= 2 as E^TF varies
nx, ny, nz = sp.symbols('n_x n_y n_z', real=True)
basis = [sp.Integer(1), nx, ny, nz, nx*ny, ny*nz, nz*nx, nx**2 - ny**2, 3*nz**2 - 1]
E = symE(4); kk = [1, nx, ny, nz]
fE = sp.expand(sum(E[a, b]*kk[a]*kk[b] for a in range(4) for b in range(4)))
cs = sp.symbols('h0:9'); comb = sum(c*b_ for c, b_ in zip(cs, basis))
eqs = sp.Poly(sp.expand((fE - comb).subs(nz**2, 1 - nx**2 - ny**2)), nx, ny, nz).coeffs()
solh = sp.solve(eqs, list(cs), dict=True)
record('J4.harmonics.identification', 'E_ab k^a k^b/(k^0)^2 restricted to the celestial sphere lies in H_{<=2} (spherical harmonics of degree <= 2, dim 9) and every element arises: the leading Clausius data at p are exactly an element of H_{<=2}', 'EXACT_SYMBOLIC', len(solh) == 1 and all(solh[0].get(c) is not None for c in cs) and sp.Matrix([[sp.diff(solh[0][c], ev) for ev in sorted(E.free_symbols, key=str)] for c in cs]).rank() == 9)
# (d) direction-dependent normalisation: r(n) = 1 + eps n_z^2 multiplying the temperature (kappa_T/kappa_Q depends on k)
eps = sp.Rational(1, 7)
Rsym = sp.Matrix(4, 4, lambda a, b: 0)
Rv = {(0, 0): 3, (0, 1): 1, (1, 1): 2, (2, 2): 5, (3, 3): 1, (1, 3): -1, (0, 2): 2}
for (a, b), v in Rv.items(): Rsym[a, b] = v; Rsym[b, a] = v
fR = sp.expand(sum(Rsym[a, b]*kk[a]*kk[b] for a in range(4) for b in range(4)))
target_f = sp.expand((1 + eps*nz**2)*fR)
sol_t = sp.solve(sp.Poly(sp.expand((target_f - comb).subs(nz**2, 1 - nx**2 - ny**2)), nx, ny, nz).coeffs(), list(cs), dict=True)
record('J4.mismatch.direction_dependent', 'if the boost normalisation of temperature relative to heat depends on the null direction (ratio 1+eps n_z^2), the required null-cone data contain degree-4 harmonics and no tensor equation reproduces them (inconsistent linear system): a common chi per pencil and a direction-independent ratio are necessary', 'CONTROL_FAILURE',
       len(sol_t) == 0)
sys.exit(dump('j04_null_cone_tensor', sys.argv[1] if len(sys.argv) > 1 else '../results'))
