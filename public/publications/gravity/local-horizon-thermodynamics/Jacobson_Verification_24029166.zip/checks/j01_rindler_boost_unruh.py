"""Jacobson 1995, eqs (1)-(2) and the temperature paragraph. Flat tangent-space model of the local Rindler
horizon: horizon H, affine generator k, boost chi, orientation, unit-norm orbit, Tolman scaling, heat integrand,
scale and affine invariances, mismatch control, and KMS orientation of the chi-flow (Unruh) in the vacuum."""
import sys, os, sympy as sp, mpmath as mp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
t, x, y, z = X = sp.symbols('t x y z', real=True)
kap, lam, hb = sp.symbols('kappa lambda hbar', positive=True)
lamr = sp.symbols('lambda_r', real=True)
eta = sp.diag(-1, 1, 1, 1)
chi = [kap*x, kap*t, sp.Integer(0), sp.Integer(0)]                      # chi = kappa (x d_t + t d_x)
chil = [sum(eta[a, b]*chi[b] for b in range(4)) for a in range(4)]
kill = sp.Matrix(4, 4, lambda a, b: sp.diff(chil[a], X[b]) + sp.diff(chil[b], X[a]))
record('J1.flat.chi_killing', 'chi = kappa(x d_t + t d_x) is a Killing field of Minkowski space (exact local boost of the tangent-space model)', 'EXACT_SYMBOLIC', kill == sp.zeros(4, 4))
# inside past horizon of P={t=x=0}: H = {t=-x, x>0}; generator X(lambda) = (lambda,-lambda,y,z), lambda<0
k = [sp.Integer(1), sp.Integer(-1), sp.Integer(0), sp.Integer(0)]
Xl = {t: lamr, x: -lamr}
chiH = [sp.simplify(c.subs(Xl)) for c in chi]
nk = sum(eta[a, a]*k[a]**2 for a in range(4))
ok = all(sp.simplify(chiH[a] - (-kap*lamr*k[a])) == 0 for a in range(4)) and nk == 0
record('J1.flat.chi_on_H', '(2): on H, chi = -kappa lambda k exactly, k=(1,-1,0,0) null affine (straight generators), lambda=0 on P, lambda<0 to the past', 'EXACT_SYMBOLIC', ok, chi_on_H=chiH)
record('J1.flat.orientation', 'chi is future-pointing on H for lambda<0 (chi^t = -kappa lambda > 0), as required ("future pointing to the inside past of P")', 'EXACT_SYMBOLIC',
       sp.simplify(chiH[0].subs(lamr, -lam)) == kap*lam)
# unit-norm orbit: x^2 - t^2 = 1/kappa^2; proper acceleration
eta_r = sp.symbols('eta_r', real=True); rho = sp.symbols('rho', positive=True)
orb = [rho*sp.sinh(eta_r), rho*sp.cosh(eta_r), 0, 0]           # boost orbit with |chi| = kappa rho
tau_p = rho*eta_r
u = [sp.diff(c, eta_r)/rho for c in orb]                          # d/d(proper time) = (1/rho) d/d eta
acc = [sp.diff(c, eta_r)/rho for c in u]
a2 = sp.simplify(sum(eta[a, a]*acc[a]**2 for a in range(4)))
chinorm = sp.sqrt(sp.simplify(-sum(eta[a, a]*c.subs({t: orb[0], x: orb[1]})**2 for a, c in enumerate(chi))))
record('J1.flat.unit_orbit_acceleration', 'orbit at rho has |chi|=kappa rho and proper acceleration 1/rho; on the unit-norm orbit (rho=1/kappa) the acceleration is kappa', 'EXACT_SYMBOLIC',
       sp.simplify(a2 - 1/rho**2) == 0 and sp.simplify(chinorm - kap*rho) == 0 and sp.simplify(sp.sqrt(a2).subs(rho, 1/kap) - kap) == 0)
Tloc = hb/(2*sp.pi*rho)                                             # Unruh temperature of the orbit at rho
record('J1.flat.tolman', 'Tolman relation: local Unruh temperature hbar a/2pi = hbar/(2 pi rho) times |chi| is the constant Killing temperature hbar kappa/2pi', 'EXACT_SYMBOLIC',
       sp.simplify(Tloc*chinorm - hb*kap/(2*sp.pi)) == 0)
# heat integrand with a generic symmetric T_ab
Tsym = sp.Matrix(4, 4, lambda a, b: sp.Symbol('T%d%d' % (min(a, b), max(a, b)), real=True))
Tkk = sum(Tsym[a, b]*k[a]*k[b] for a in range(4) for b in range(4))
integrand = sum(Tsym[a, b]*chiH[a]*k[b] for a in range(4) for b in range(4))
record('J1.heat.integrand', '(1)->(2): T_ab chi^a dSigma^b with dSigma^b = k^b dlambda dA equals -kappa lambda T_ab k^a k^b dlambda dA', 'EXACT_SYMBOLIC', sp.simplify(integrand - (-kap*lamr*Tkk)) == 0)
# leading heat and scale/affine invariance using a Taylor model along the generator
T0, T1, A0, cst, aff = sp.symbols('T0 T1 A0 c a', positive=True)
lam0 = sp.symbols('lambda0', negative=True)
Tk = T0 + T1*lamr
dQ = -kap*sp.integrate(lamr*Tk, (lamr, lam0, 0))*A0
TU = hb*kap/(2*sp.pi)
record('J1.heat.leading', 'delta Q = kappa A0 [T_kk lambda0^2/2 + (dT_kk/dlambda) lambda0^3/3] (lambda0<0); leading term >= 0 for T_kk >= 0 (NEC)', 'EXACT_SYMBOLIC',
       sp.simplify(dQ - kap*A0*(T0*lam0**2/2 + T1*lam0**3/3)) == 0, deltaQ=sp.expand(dQ))
scaled = (dQ.subs(kap, cst*kap))/(TU.subs(kap, cst*kap))
record('J1.scale.cancellation', 'common rescaling chi -> c chi (kappa -> c kappa) multiplies delta Q and T by c; delta Q/T and the area readout are unchanged', 'EXACT_SYMBOLIC',
       sp.simplify(scaled - dQ/TU) == 0 and sp.simplify(dQ.subs(kap, cst*kap) - cst*dQ) == 0, ratio=sp.simplify(dQ/TU))
# affine rescaling lambda = a lambda', k = k'/a: chi = -kappa lambda k invariant; T_kk' = a^2 T_kk; lambda0' = lambda0/a
lp = sp.symbols('lambda_p', real=True); lam0p = lam0/aff
Tkp = aff**2*Tk.subs(lamr, aff*lp)
dQp = -kap*sp.integrate(lp*Tkp, (lp, lam0p, 0))*A0
record('J1.affine.invariance', 'affine reparametrisation lambda -> a lambda, k -> k/a leaves chi = -kappa lambda k and delta Q unchanged (kappa is tied to chi, not to the affine scale)', 'EXACT_SYMBOLIC',
       sp.simplify(dQp - dQ) == 0 and sp.simplify((-kap*(aff*lp))*(sp.Integer(1)/aff) - (-kap*lp)) == 0)
# mismatched normalisation: heat with kappa1, temperature with kappa2
k1, k2, R0, etaS = sp.symbols('kappa1 kappa2 R0 eta_S', positive=True)
dQ1 = k1*A0*T0*lam0**2/2; TdS2 = hb*k2/(2*sp.pi)*etaS*A0*R0*lam0**2/2
sol = sp.solve(sp.Eq(dQ1, TdS2), T0)[0]
record('J1.mismatch.control', 'heat built with kappa1 and temperature with kappa2: Clausius gives T_kk = (kappa2/kappa1)(hbar eta/2pi) R_kk, i.e. G_eff = (kappa1/kappa2) G; only a COMMON chi cancels', 'CONTROL_FAILURE',
       sp.simplify(sol - (k2/k1)*hb*etaS/(2*sp.pi)*R0) == 0 and sp.simplify(sol.subs(k2, k1) - hb*etaS/(2*sp.pi)*R0) == 0, inferred_T_kk=sol)
# modular reading: delta Q / T = (2pi/hbar) x (flux of xi = chi/kappa): kappa-free
record('J1.modular.ratio', 'delta Q/T = (2 pi/hbar) * int T_ab xi^a dSigma^b with xi = chi/kappa (rapidity-normalised boost, cf. CHM sigma_s = alpha_{-2 pi s}); independent of kappa', 'EXACT_SYMBOLIC',
       sp.simplify(dQ/TU - (2*sp.pi/hb)*(dQ/kap)) == 0 and not sp.simplify(dQ/TU).has(kap))
# local observer limit: observer on orbit rho measures flux T_ab u^a and temperature T_loc; ratio independent of rho
record('J1.local_observer_ratio', 'observer on the orbit with |chi|=kappa rho: local flux scales as 1/(kappa rho), local temperature as 1/rho; their ratio equals the Killing ratio for every rho (finite as the orbit approaches H)', 'EXACT_SYMBOLIC',
       sp.simplify((integrand/(kap*rho))/(Tloc) - integrand/(hb*kap/(2*sp.pi))) == 0)
# KMS of the vacuum with respect to the chi-flow (chi-time s: boost rapidity kappa s), forward chi: beta = 2 pi/kappa
mp.mp.dps = 30
def wightman(Dl, dt, dx2, eps=mp.mpf('1e-18')): return (-(dt - 1j*eps)**2 + dx2)**(-Dl)
def cont(fw, Dl, path):
    acc = mp.arg(fw(path[0])); prev = fw(path[0])
    for th in path[1:]:
        wv = fw(th); acc += mp.arg(wv/prev); prev = wv
    return mp.e**(-Dl*(mp.log(abs(prev)) + 1j*acc)), mp.e**(-Dl*(mp.log(abs(fw(path[0]))) + 1j*mp.arg(fw(path[0]))))
Dl = mp.mpf('0.41'); a_, b_ = mp.mpf('0.6'), mp.mpf('1.7'); kv = mp.mpf('2.3'); s0 = mp.mpf('0.55')
eta0 = kv*s0
dt = -b_*mp.sinh(eta0); dxx = a_ - b_*mp.cosh(eta0)
Wf = wightman(Dl, dt, dxx**2); Wr = wightman(Dl, -dt, dxx**2)
beta = 2*mp.pi/kv; E = mp.mpf('1e-12')
path = [E] + [beta*j/3000 for j in range(1, 3000)] + [beta - E]
fw = lambda th: a_**2 + b_**2 - 2*a_*b_*mp.cosh(kv*(s0 + 1j*th))
end, start = cont(fw, Dl, path)
e1 = abs(start - Wf)/abs(Wf); e2 = abs(end - Wr)/abs(Wr); mn = min(abs(fw(th)) for th in path[::30])
record('J1.KMS.chi_flow', 'Minkowski vacuum: F(s)=<phi(x) alpha^chi_s(phi(y))> continues to 0<Im s<2pi/kappa without zeros and the boundary value at Im s=2pi/kappa is the reversed order: KMS at beta=2pi/kappa for FORWARD chi, T=hbar kappa/2pi', 'NUMERICAL',
       e1 < 1e-8 and e2 < 1e-6 and mn > 1e-3, kappa=str(kv), start_rel=float(e1), end_rel=float(e2), min_abs=float(mn))
lo = (fw(-mp.mpf('1e-7')))**(-Dl)
record('J1.KMS.orientation_control', 'for the past-directed field -chi the forward ordering is NOT the boundary value of an analytic continuation into positive imaginary chi-time: KMS would be at beta=-2pi/kappa (negative temperature); orientation of chi is fixed by KMS positivity', 'CONTROL_FAILURE',
       abs(lo - Wr)/abs(Wr) < 1e-4 and abs(lo - Wf)/abs(Wf) > 1e-2, lower_vs_reversed=float(abs(lo - Wr)/abs(Wr)), lower_vs_forward=float(abs(lo - Wf)/abs(Wf)))
sys.exit(dump('j01_rindler_boost_unruh', sys.argv[1] if len(sys.argv) > 1 else '../results'))
