"""Jacobson 1995, eqs (3)-(5). (A) exact Raychaudhuri equation with expansion, shear and Ricci computed
independently from the metric (Bianchi I, D=4 and D=5) + wrong-coefficient control; (B) pencil expansions of
heat and area along one generator: leading Clausius coefficient, O(lambda0^3) residual for Einstein solutions,
boost-weighted entropy identity, nonzero initial expansion/shear controls, next-order overconstraint;
(C) exact FRW pencil (independent route from the metric) confirming (B)."""
import sys, os, sympy as sp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
def christoffel(g, X):
    n = len(X); gi = g.inv()
    return [[[sp.simplify(sum(gi[a, e]*(sp.diff(g[e, b], X[c]) + sp.diff(g[e, c], X[b]) - sp.diff(g[b, c], X[e])) for e in range(n))/2) for c in range(n)] for b in range(n)] for a in range(n)]
def ricci(g, X, G):
    n = len(X)
    return sp.Matrix(n, n, lambda b, d: sp.simplify(sum(sp.diff(G[a][b][d], X[a]) - sp.diff(G[a][b][a], X[d]) + sum(G[a][a][e]*G[e][b][d] - G[a][d][e]*G[e][b][a] for e in range(n)) for a in range(n))))
def raychaudhuri_bianchi(D):
    t = sp.symbols('t', real=True); xs = sp.symbols('x1:%d' % D, real=True); X = [t] + list(xs)
    fs = [sp.Function('a%d' % i, positive=True)(t) for i in range(1, D)]
    g = sp.diag(-1, *[f**2 for f in fs]); gi = g.inv(); G = christoffel(g, X); Ric = ricci(g, X, G)
    a = fs[0]
    k = [1/a, 1/a**2] + [0]*(D - 2)                                   # null geodesic along x1, k_x1 = 1
    kl = [sum(g[m, n]*k[n] for n in range(D)) for m in range(D)]
    geo = [sp.simplify(sum(k[n]*(sp.diff(k[m], X[n]) + sum(G[m][n][r]*k[r] for r in range(D))) for n in range(D))) for m in range(D)]
    B = sp.Matrix(D, D, lambda m, n: sp.diff(kl[n], X[m]) - sum(G[r][m][n]*kl[r] for r in range(D)))   # B_mn = nabla_m k_n
    l = [a/2, -sp.Rational(1, 2)] + [0]*(D - 2); ll = [sum(g[m, n]*l[n] for n in range(D)) for m in range(D)]
    h = sp.Matrix(D, D, lambda m, n: g[m, n] + kl[m]*ll[n] + ll[m]*kl[n])
    hup = gi*h*gi
    theta = sp.simplify(sum(hup[m, n]*B[m, n] for m in range(D) for n in range(D)))
    hmix = gi*h                                                          # h^m_n
    Bs = (B + B.T)/2
    Bp = sp.Matrix(D, D, lambda m, n: sum(hmix[r, m]*hmix[q, n]*Bs[r, q] for r in range(D) for q in range(D)))
    sig = Bp - theta*h/(D - 2)
    sig2 = sp.simplify(sum((gi*sig*gi)[m, n]*sig[m, n] for m in range(D) for n in range(D)))
    Rkk = sp.simplify(sum(Ric[m, n]*k[m]*k[n] for m in range(D) for n in range(D)))
    dth = sp.simplify(sum(k[m]*sp.diff(theta, X[m]) for m in range(D)))
    res = sp.simplify(dth + theta**2/(D - 2) + sig2 + Rkk)
    wrong = sp.simplify(dth + theta**2/(D - 1) + sig2 + Rkk)
    norm = sp.simplify(sum(kl[m]*k[m] for m in range(D)))
    return geo, norm, theta, sig2, Rkk, res, wrong
for D in (4, 5):
    geo, norm, theta, sig2, Rkk, res, wrong = raychaudhuri_bianchi(D)
    record('J2.raychaudhuri.exact.D%d' % D, '(4): for the affine null geodesic congruence of Bianchi I (D=%d) d theta/d lambda = -theta^2/(D-2) - sigma^2 - R_kk, all terms computed independently from the metric (shear nonzero)' % D,
           'EXACT_SYMBOLIC', res == 0 and norm == 0 and all(q == 0 for q in geo) and sig2 != 0, theta=theta, sigma_sq=sig2, R_kk=Rkk)
    record('J2.raychaudhuri.coefficient_control.D%d' % D, 'the coefficient 1/(D-1) in place of 1/(D-2) fails (expected failure reproduced), D=%d' % D, 'CONTROL_FAILURE', wrong != 0, residual=wrong)
# (B) Taylor model along one generator
lam, l0 = sp.symbols('lambda lambda0', real=True)
th0, R0, R1, R2, S0, S1, S2, T0, T1, T2, kap, A0, etaS = sp.symbols('theta0 R0 R1 R2 S0 S1 S2 T0 T1 T2 kappa A0 eta_S', real=True)
N = 5
def theta_series(th0v, S):
    # solve theta' = -theta^2/2 - sigma^2 - R_kk as a power series (D=4); sigma^2 = S(lambda)
    cs = sp.symbols('c0:%d' % (N + 1)); th = sum(cs[i]*lam**i for i in range(N + 1))
    Rk = R0 + R1*lam + R2*lam**2
    eq = sp.expand(sp.diff(th, lam) + th**2/2 + S + Rk)
    sol = {cs[0]: th0v}
    for i in range(N):
        ci = sp.solve(sp.expand(eq.subs(sol)).coeff(lam, i), cs[i + 1])[0]; sol[cs[i + 1]] = ci
    return sp.expand(th.subs(sol))
Tk = T0 + T1*lam + T2*lam**2
def readouts(th):
    Iin = sp.integrate(th, (lam, lam, 0))                       # int_lambda^0 theta
    A_lam = A0*sp.series(sp.exp(-Iin), lam, 0, N + 1).removeO()   # area element along the pencil (A(0)=A0)
    dA = sp.expand(A0 - A_lam.subs(lam, l0))                     # true area change A(P) - A(lambda0)
    dQ = sp.expand(-kap*sp.integrate(sp.expand(lam*Tk*A_lam), (lam, l0, 0)))
    Sbw = sp.expand(sp.integrate(sp.expand((-lam)*(-sp.diff(th, lam))*A_lam), (lam, l0, 0)))   # boost-weighted focusing
    return dA, dQ, Sbw
def trunc(e, n): return sp.expand(sum(sp.expand(e).coeff(l0, i)*l0**i for i in range(n + 1)))
cS = etaS/(2*sp.pi)          # hbar=1: T dS = (kappa/2pi) eta dA, and the Clausius coefficient c = eta/2pi
th = theta_series(0, S2*lam**2)                                  # equilibrium: theta(0)=0, sigma(0)=0 so sigma^2 = O(lambda^2)
dA, dQ, Sbw = readouts(th)
resid = trunc(dQ - kap/(2*sp.pi)*etaS*dA, 3)
target = kap*A0*(l0**2/2*(T0 - cS*R0) + l0**3*(T1/3 - cS*R1/6))
record('J2.pencil.clausius_expansion', 'equilibrium pencil: delta Q - T dS = kappa A0[(lambda0^2/2)(T_kk - (eta/2pi)R_kk) + lambda0^3(T1/3 - (eta/2pi)R1/6)] + O(lambda0^4) (hbar=1)', 'EXACT_SYMBOLIC',
       sp.simplify(resid - target) == 0, residual_to_lambda0_cubed=resid)
record('J2.pencil.leading_area', '(5): theta = -lambda R_kk + O(lambda^2) and delta A = A0 R_kk lambda0^2/2 + O(lambda0^3) = -int lambda R_kk dlambda dA at leading order', 'EXACT_SYMBOLIC',
       sp.expand(th).coeff(lam, 1) == -R0 and sp.simplify(trunc(dA, 2) - A0*R0*l0**2/2) == 0 and sp.simplify(trunc(-sp.integrate(lam*R0, (lam, l0, 0))*A0, 2) - A0*R0*l0**2/2) == 0)
ein = {T0: cS*R0, T1: cS*R1, T2: cS*R2}
r3 = sp.simplify(trunc(dQ - kap/(2*sp.pi)*etaS*dA, 3).subs(ein))
record('J2.pencil.reverse_leading', 'reverse implication: if T_kk = (eta/2pi) R_kk along the generator (Einstein, kk-component) the Clausius residual vanishes at O(lambda0^2)', 'EXACT_SYMBOLIC',
       sp.expand(r3).coeff(l0, 2) == 0)
record('J2.pencil.reverse_cubic_residual', 'but at O(lambda0^3) a residual (hbar kappa eta/12 pi) A0 lambda0^3 dR_kk/dlambda survives for Einstein solutions with the plain area change: Clausius holds only to the leading local-equilibrium order', 'EXACT_SYMBOLIC',
       sp.simplify(r3 - kap*etaS*A0*R1*l0**3/(12*sp.pi)) == 0, residual=r3)
rbw = sp.simplify(trunc(sp.expand(dQ - kap/(2*sp.pi)*etaS*Sbw).subs(ein), 4))
target_bw = -kap/(2*sp.pi)*etaS*trunc(sp.integrate(sp.expand((-lam)*(th**2/2 + S2*lam**2)*A0), (lam, l0, 0)), 4)
record('J2.pencil.boost_weighted_identity', 'with the boost-weighted entropy change eta int(-lambda)(-d theta/d lambda)dlambda dA, Einstein gives delta Q - T dS_bw = -(kappa eta/2pi) int(-lambda)(theta^2/2+sigma^2) = O(lambda0^4) <= 0 (no lambda0^3 residual)', 'EXACT_SYMBOLIC',
       sp.simplify(rbw - target_bw) == 0 and sp.expand(rbw).coeff(l0, 3) == 0, residual_order4=sp.factor(rbw))
# next-order obstruction with the plain area: O(lambda0^3) Clausius would require T1 = (eta/2pi) R1/2, while the leading law holding near p requires T1 = (eta/2pi) R1
te = sp.expand(target); sol = sp.solve([te.coeff(l0, 2), te.coeff(l0, 3)], [T0, T1], dict=True)[0]
record('J2.pencil.next_order_overconstraint', 'imposing Clausius at O(lambda0^3) with dS = eta dA gives T1 = (eta/2pi)R1/2, incompatible with the derivative of the leading law (T1=(eta/2pi)R1) unless dR_kk/dlambda = 0: the plain-area Clausius relation cannot be imposed beyond leading order', 'CONTROL_FAILURE',
       sp.simplify(sol[T1] - cS*R1/2) == 0 and sp.simplify(sol[T1] - cS*R1) != 0, T1_required=sol[T1])
# nonzero initial expansion / shear
thA = theta_series(th0, S2*lam**2); dAa, dQa, _ = readouts(thA)
cA = sp.expand(dAa).coeff(l0, 1)
record('J2.control.initial_expansion', 'theta(P)=theta0 != 0: the area change acquires an O(lambda0) term -theta0 lambda0 A0 with no heat counterpart (heat starts at lambda0^2): leading-order Clausius forces theta0 = 0 (non-equilibrium otherwise)', 'CONTROL_FAILURE',
       sp.simplify(cA + th0*A0) == 0 and sp.expand(dQa).coeff(l0, 1) == 0, area_order1=cA)
thS = theta_series(0, S0 + S2*lam**2); dAs, dQs, _ = readouts(thS)
c2 = sp.simplify(trunc(dQs - kap/(2*sp.pi)*etaS*dAs, 2).coeff(l0, 2))
record('J2.control.initial_shear', 'sigma(P)^2 = S0 != 0: leading Clausius gives T_kk = (eta/2pi)(R_kk + sigma0^2): a non-tensorial, sign-definite shift (shear behaves as entropy production); equilibrium requires sigma(P)=0', 'CONTROL_FAILURE',
       sp.simplify(c2 - kap*A0*(T0 - cS*(R0 + S0))/2) == 0, lambda0sq_coefficient=c2)
# (C) exact FRW pencil, conformal time, a(e)=1+alpha e^2+beta e^3 (theta=0 at e=0), from the metric
e_, x1, x2, x3 = sp.symbols('eta_c x1 x2 x3', real=True); X4 = [e_, x1, x2, x3]
al, be = sp.symbols('alpha beta', real=True)
a = 1 + al*e_**2 + be*e_**3
g = a**2*sp.diag(-1, 1, 1, 1); Gm = christoffel(g, X4); Ric = ricci(g, X4, Gm)
kv = [1/a**2, 1/a**2, 0, 0]                    # affine null geodesic along x1 (future, moving +x1)
geo = [sp.simplify(sum(kv[n]*(sp.diff(kv[m], X4[n]) + sum(Gm[m][n][r]*kv[r] for r in range(4))) for n in range(4))) for m in range(4)]
thetaF = sp.simplify(sp.diff(a**4*kv[0], e_)/a**4)       # (1/sqrt(-g)) d(sqrt(-g) k^mu), sqrt(-g)=a^4
RkkF = sp.simplify(sum(Ric[m, n]*kv[m]*kv[n] for m in range(4) for n in range(4)))
ord_ = 5
lam_of_e = sp.integrate(sp.expand(a**2), (e_, 0, e_))           # dlambda = a^2 d eta, lambda=0 at e=0
e0 = sp.symbols('e0', real=True)
lam_ser = sp.series(lam_of_e, e_, 0, ord_ + 1).removeO()
# invert lambda(e) as a series
cinv = sp.symbols('d1:%d' % (ord_ + 1)); einv = sum(cinv[i]*lam**(i + 1) for i in range(ord_))
eqs = sp.expand(sp.series(lam_ser.subs(e_, einv), lam, 0, ord_ + 1).removeO() - lam)
solinv = {}
for i in range(ord_):
    solinv[cinv[i]] = sp.solve(eqs.subs(solinv).coeff(lam, i + 1), cinv[i])[0]
e_of_l = einv.subs(solinv)
def along(expr): return sp.expand(sp.series(expr.subs(e_, e_of_l), lam, 0, ord_).removeO())
thL = along(thetaF); RkkL = along(RkkF)
AL = along(a**2)                                           # comoving cross-section area element a^2 (A0 = 1 at P)
TkkL = cS*RkkL                                             # Einstein-defined matter: T_ab := G_ab/(8 pi G) with 8 pi G = 2 pi/eta, T_kk = (eta/2pi) R_kk
dA_ex = sp.expand(1 - AL.subs(lam, l0))
dQ_ex = sp.expand(-kap*sp.integrate(sp.expand(lam*TkkL*AL), (lam, l0, 0)))
resF = sp.expand(trunc(dQ_ex - kap/(2*sp.pi)*etaS*dA_ex, 3))
R0F = RkkL.coeff(lam, 0); R1F = RkkL.coeff(lam, 1)
dthdl = along(sp.diff(thetaF, e_)/a**2)
ray_ok = all(sp.simplify(sp.expand(dthdl + thL**2/2 + RkkL).coeff(lam, i)) == 0 for i in range(3))
record('J2.FRW.exact_pencil', 'exact FRW pencil from the metric (theta(P)=0, sigma=0): Raychaudhuri holds; Einstein-defined matter gives Clausius residual 0 at lambda0^2 and exactly (kappa eta/12pi) A0 R1 lambda0^3 at the next order, R1 = dR_kk/dlambda|_P', 'EXACT_SYMBOLIC',
       all(q == 0 for q in geo) and sp.simplify(thL.coeff(lam, 0)) == 0 and ray_ok and sp.simplify(resF.coeff(l0, 2)) == 0 and sp.simplify(resF.coeff(l0, 3) - kap*etaS*R1F/(12*sp.pi)) == 0 and sp.simplify(R1F) != 0,
       R_kk_P=R0F, R1=R1F, residual=resF)
sys.exit(dump('j02_raychaudhuri_pencil', sys.argv[1] if len(sys.argv) > 1 else '../results'))
