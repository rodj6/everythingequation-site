"""Local-equilibrium preparation of P (Jacobson p.3: "It is always possible to choose P through p so that the expansion
and shear vanish in a first order neighborhood of p"). Riemann normal coordinates with exact algebraic curvature
tensors; P = general surface through p with free tangent plane (null rotation c about k) and free quadratic and
cubic embedding coefficients.
Results: (i) theta(p)=sigma(p)=0 always; (ii) D theta(p)=0 always; (iii) the antisymmetric part of D chi(p) is the
Codazzi vector C_j = R(k,e_j,e_2,e_3), independent of the embedding, and shifts under null rotation by the optical
tidal matrix Phi_ij = R(k,e_i,k,e_j); so full first-order vanishing (D sigma(p)=0 as well) is possible iff
C lies in range(Phi) -- generically yes (det Phi != 0), but NOT for degenerate tidal data (counterexample)."""
import sys, os, itertools, sympy as sp
sys.path.insert(0, os.path.dirname(__file__)); from common import record, dump
def KN(h, k):
    return {(a, b, c, d): h[a][c]*k[b][d] + h[b][d]*k[a][c] - h[a][d]*k[b][c] - h[b][c]*k[a][d] for a, b, c, d in itertools.product(range(4), repeat=4)}
eta = [-1, 1, 1, 1]; G0 = [[eta[a] if a == b else 0 for b in range(4)] for a in range(4)]
S = [[[sp.Rational(v) for v in row] for row in M] for M in (
    [[2, 1, -1, 3], [1, -2, 4, 0], [-1, 4, 1, 2], [3, 0, 2, -3]],
    [[1, -3, 2, 1], [-3, 0, 1, 5], [2, 1, -4, 1], [1, 5, 1, 2]],
    [[-2, 2, 0, 1], [2, 3, -1, -2], [0, -1, 1, 4], [1, -2, 4, 0]])]
def generic():
    Rm = {key: 0 for key in itertools.product(range(4), repeat=4)}
    for M in S:
        kn = KN(M, M)
        for key in Rm: Rm[key] += kn[key]/2
    return Rm
def degenerate():
    # Weyl = 0, R = KN(P, g) with P = sym(l (x) e2) (lower indices): R_kk = 0 and Phi = 0, but R(k,e_2) != 0 (transverse momentum flux)
    l_low = [-sp.Rational(1, 2), sp.Rational(1, 2), 0, 0]           # lowered l = (1/2,1/2,0,0); eta(k,l) = -1 for k=(1,-1,0,0)
    e2_low = [0, 0, 1, 0]
    P = [[(l_low[a]*e2_low[b] + e2_low[a]*l_low[b]) for b in range(4)] for a in range(4)]
    return KN(P, G0)
def flat(): return {key: 0 for key in itertools.product(range(4), repeat=4)}
X = sp.symbols('x0:4', real=True); s1, s2 = sg = sp.symbols('s1 s2', real=True)
k0 = [1, -1, 0, 0]
def R4(Rm, u, v, w, q): return sum(Rm[(a, b, c, d)]*u[a]*v[b]*w[c]*q[d] for a, b, c, d in itertools.product(range(4), repeat=4))
def analyse(Rm, cvals):
    g = sp.Matrix(4, 4, lambda m, n: G0[m][n] - sp.Rational(1, 3)*sum(Rm[(m, a, n, b)]*X[a]*X[b] for a in range(4) for b in range(4)))
    gi0 = sp.diag(*eta)
    Gam = [[[sum(gi0[a, e]*(sp.diff(g[e, b], X[c]) + sp.diff(g[e, c], X[b]) - sp.diff(g[b, c], X[e])) for e in range(4))/2 for c in range(4)] for b in range(4)] for a in range(4)]
    ok_curv = all(sp.simplify(eta[a]*(sp.diff(Gam[a][b][d], X[c]) - sp.diff(Gam[a][b][c], X[d])).subs({xx: 0 for xx in X}) - Rm[(a, b, c, d)]) == 0 for a, b, c, d in itertools.product(range(4), repeat=4))
    c1, c2 = cvals
    a11, a12, a22 = sp.symbols('a11 a12 a22'); B = sp.symbols('b0:4'); Bp = sp.symbols('bp0:4')
    quad = a11*s1**2 + 2*a12*s1*s2 + a22*s2**2
    cub = lambda c: c[0]*s1**3 + 3*c[1]*s1**2*s2 + 3*c[2]*s1*s2**2 + c[3]*s2**3
    lin = c1*s1 + c2*s2                                                   # tangent plane e_i = d_{2+i} + c_i k0
    emb = [lin + quad + cub(B), -lin - quad + cub(Bp), s1, s2]
    e = [[sp.diff(c, si) for c in emb] for si in sg]
    K = sp.symbols('K0:8'); kvec = [sp.Integer(1), -1 + K[1]*s1 + K[5]*s2, K[2]*s1 + K[6]*s2, K[3]*s1 + K[7]*s2]
    def first(expr):
        ex = sp.expand(expr); return [ex.coeff(s1, 1).subs(s2, 0), ex.coeff(s2, 1).subs(s1, 0)]
    eqs = []
    for i in range(2): eqs += first(sum(eta[m]*kvec[m]*e[i][m] for m in range(4)))
    eqs += first(sum(eta[m]*kvec[m]**2 for m in range(4)))
    solK = sp.solve(eqs, [K[1], K[2], K[3], K[5], K[6], K[7]], dict=True)[0]
    kl = [eta[m]*sp.expand(kvec[m].subs(solK)) for m in range(4)]
    sub = {X[m]: emb[m] for m in range(4)}
    chi = [[sp.expand(-sum(kl[m]*(sp.diff(emb[m], sg[i], sg[j]) + sum(Gam[m][n][r].subs(sub)*e[i][n]*e[j][r] for n in range(4) for r in range(4))) for m in range(4))) for j in range(2)] for i in range(2)]
    z0 = {s1: 0, s2: 0}
    chi0 = [[sp.simplify(chi[i][j].subs(z0)) for j in range(2)] for i in range(2)]
    D = [[[sp.expand(sp.diff(chi[i][j], sg[l]).subs(z0)) for j in range(2)] for i in range(2)] for l in range(2)]
    A = [sp.expand(D[0][1][j] - D[1][0][j]) for j in range(2)]          # A_j = D_1 chi_2j - D_2 chi_1j
    E = [[c1, -c1, 1, 0], [c2, -c2, 0, 1]]
    C = [sp.expand(R4(Rm, k0, E[j], E[0], E[1])) for j in range(2)]
    th = [sp.expand(D[l][0][0] + D[l][1][1]) for l in range(2)]
    sh = [sp.expand(D[l][0][0] - D[l][1][1]) for l in range(2)] + [D[l][0][1] for l in range(2)]
    free = set(B) | set(Bp) | {a11, a12, a22}
    return dict(ok_curv=ok_curv, chi0=chi0, A=A, C=C, th=th, sh=sh, B=list(B) + list(Bp), free=free)
c1s, c2s = sp.symbols('c1 c2', real=True)
# generic curvature, symbolic tangent plane
Rg = generic()
r = analyse(Rg, (c1s, c2s))
sym = all(Rg[(a, b, c, d)] == -Rg[(b, a, c, d)] == Rg[(c, d, a, b)] for a, b, c, d in itertools.product(range(4), repeat=4)) and all(Rg[(a, b, c, d)] + Rg[(a, c, d, b)] + Rg[(a, d, b, c)] == 0 for a, b, c, d in itertools.product(range(4), repeat=4))
record('J3.curvature.algebraic', 'exact generic algebraic curvature tensor (sum of Kulkarni-Nomizu squares) has all symmetries incl. first Bianchi; the RNC metric eta-(1/3)Rxx reproduces it at p', 'EXACT_SYMBOLIC', sym and r['ok_curv'])
record('J3.equilibrium.point', 'theta(p)=sigma(p)=0 for the k-congruence for every tangent plane (null rotation c) and every remaining quadratic and cubic coefficient', 'EXACT_SYMBOLIC', all(v == 0 for row in r['chi0'] for v in row))
codok = all(not (sp.expand(r['A'][j]).free_symbols & r['free']) for j in range(2)) and all(sp.simplify(r['A'][j] + r['C'][j]) == 0 for j in range(2))
record('J3.codazzi.vector', 'Codazzi: the antisymmetric part A_j = D_1 chi_2j - D_2 chi_1j at p is independent of all embedding coefficients and equals -R(k,e_j,e_2,e_3) (e_i the null-rotated tangent frame)', 'EXACT_SYMBOLIC', codok, A=r['A'])
Phi = sp.Matrix(2, 2, lambda j, i: R4(Rg, k0, [0, 0, 1 if j == 0 else 0, 1 if j == 1 else 0], k0, [0, 0, 1 if i == 0 else 0, 1 if i == 1 else 0]))
C0 = sp.Matrix([sp.expand(r['C'][j]).subs({c1s: 0, c2s: 0}) for j in range(2)])
shift = sp.Matrix([sp.expand(r['C'][j]) for j in range(2)]) - C0
Jrot = sp.Matrix([[0, -1], [1, 0]])
shift_pred = Phi*Jrot*sp.Matrix([c1s, c2s])
lin_ok = all(sp.simplify(shift[j] - shift_pred[j]) == 0 for j in range(2))
Rkk_direct = sum(Rg[(a, b, c, d)]*k0[a]*k0[c]*(1/sp.Integer(eta[b]))*(1 if b == d else 0) for a, b, c, d in itertools.product(range(4), repeat=4))
record('J3.codazzi.null_rotation', 'under a null rotation e_i -> e_i + c_i k the Codazzi vector shifts affinely, C(c) = C(0) + Phi J c, with Phi_ij = R(k,e_i,k,e_j) the optical tidal matrix (tr Phi = R_kk) and J the 90-degree rotation; removable iff C(0) in range(Phi)', 'EXACT_SYMBOLIC',
       lin_ok and sp.simplify(Phi.trace() - Rkk_direct) == 0, Phi=Phi, det_Phi=Phi.det(), C_at_c0=C0, R_kk=Rkk_direct)
# fixed coordinate tangent plane (c=0): no first-order shear vanishing
r0 = analyse(Rg, (0, 0))
fix = sp.solve(r0['th'] + r0['sh'], r0['B'], dict=True)
record('J3.fixed_plane.obstruction', 'with the tangent plane fixed (c=0) and C != 0, D theta(p)=D sigma(p)=0 has no solution (the plane must be adapted to the curvature)', 'CONTROL_FAILURE', len(fix) == 0 and any(v != 0 for v in C0))
dth = sp.solve(r0['th'], r0['B'], dict=True)
record('J3.equilibrium.Dtheta_achievable', 'D theta(p)=0 is achievable for any tangent plane by the cubic part of the embedding', 'EXACT_SYMBOLIC', len(dth) > 0)
cstar = sp.solve(r['C'], [c1s, c2s], dict=True)
ok_full = False
if cstar:
    rs = analyse(Rg, (cstar[0][c1s], cstar[0][c2s]))
    full = sp.solve(rs['th'] + rs['sh'], rs['B'], dict=True); ok_full = len(full) > 0
record('J3.equilibrium.generic_full_first_order', 'generic curvature (det Phi != 0): choosing the tangent plane by C + Phi c = 0 and then the cubic coefficients makes theta, sigma AND their first tangential derivatives vanish at p -- Jacobson\'s first-order claim holds, with the plane selected by the curvature', 'EXACT_SYMBOLIC',
       ok_full and Phi.det() != 0, c_star=cstar)
# degenerate tidal data: Phi = 0 but C != 0 -> impossible for every tangent plane
Rd = degenerate()
rd = analyse(Rd, (c1s, c2s))
Phid = sp.Matrix(2, 2, lambda j, i: R4(Rd, k0, [0, 0, 1 if j == 0 else 0, 1 if j == 1 else 0], k0, [0, 0, 1 if i == 0 else 0, 1 if i == 1 else 0]))
Cd = [sp.simplify(v) for v in rd['C']]
Rkk_d = sum(Rd[(a, b, c, d)]*eta[a]*eta[c]*0 for a, b, c, d in [(0, 0, 0, 0)])
record('J3.degenerate.obstruction', 'precise obstruction: conformally flat curvature with R_kk = 0 and R(k,e_2) != 0 has Phi = 0 and a Codazzi vector C != 0 that NO tangent plane removes; then shear cannot vanish in a first-order neighbourhood of p for any P (the p.3 "always possible" fails in this case)', 'CONTROL_FAILURE',
       Phid == sp.zeros(2, 2) and any(v != 0 for v in Cd) and all(not v.free_symbols for v in Cd) and rd['ok_curv'], C=Cd)
rf = analyse(flat(), (0, 0))
record('J3.control.flat', 'flat control: theta, sigma and all their first derivatives at p can be set to zero', 'EXACT_SYMBOLIC', len(sp.solve(rf['th'] + rf['sh'], rf['B'], dict=True)) > 0)
sys.exit(dump('j03_codazzi_equilibrium', sys.argv[1] if len(sys.argv) > 1 else '../results'))
