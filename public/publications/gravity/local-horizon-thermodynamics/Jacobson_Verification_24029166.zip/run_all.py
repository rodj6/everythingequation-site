"""Run the check suites into an output directory and/or aggregate them into SUMMARY.json.
  python run_all.py <out_dir>                 run every suite, then summarise (needs ~5 minutes in one process)
  python run_all.py <out_dir> c01 c05 ...     run only the named suites (prefix match), no summary
  python run_all.py <out_dir> --summarize     aggregate the suites already present in <out_dir>
Each suite is a separate process; its exit code is its number of failed checks. Per-suite run logs are written
to <out_dir>/_runlog_<suite>.json so suites can be executed in separate sessions and then aggregated."""
import sys, os, subprocess, json, time, hashlib, platform
here = os.path.dirname(os.path.abspath(__file__))
out = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'results', 'run'))
args = sys.argv[2:]
os.makedirs(out, exist_ok=True)
suites = sorted(f for f in os.listdir(os.path.join(here, 'checks')) if f.startswith('j') and f[1:3].isdigit() and f.endswith('.py'))
def run(s):
    t0 = time.time()
    p = subprocess.run([sys.executable, '-u', os.path.join(here, 'checks', s), out], capture_output=True, text=True)
    log = {'suite': s, 'exit_code': p.returncode, 'seconds': round(time.time() - t0, 1), 'stdout': p.stdout[-6000:], 'stderr': p.stderr[-3000:],
           'sha256': hashlib.sha256(open(os.path.join(here, 'checks', s), 'rb').read()).hexdigest()}
    with open(os.path.join(out, '_runlog_' + s[:-3] + '.json'), 'w', encoding='utf-8', newline='\n') as f: json.dump(log, f, indent=1)
    print(s, 'exit', p.returncode, 'in', log['seconds'], 's', flush=True)
def summarize():
    import sympy, mpmath, numpy
    counts = {'total': 0, 'PASS': 0, 'FAIL': 0, 'missing_suites': [], 'by_kind': {}}; runs = {}
    for s in suites:
        fn = os.path.join(out, s[:-3] + '.json'); lg = os.path.join(out, '_runlog_' + s[:-3] + '.json')
        if not os.path.exists(fn): counts['missing_suites'].append(s); continue
        if os.path.exists(lg): runs[s] = {k: v for k, v in json.load(open(lg, encoding='utf-8')).items() if k in ('exit_code', 'seconds', 'sha256')}
        for r in json.load(open(fn, encoding='utf-8'))['results']:
            counts['total'] += 1; counts[r['status']] += 1
            counts['by_kind'][r['kind']] = counts['by_kind'].get(r['kind'], 0) + 1
    cur = {s: hashlib.sha256(open(os.path.join(here, 'checks', s), 'rb').read()).hexdigest() for s in suites + ['common.py']}
    stale = [s for s in runs if runs[s]['sha256'] != cur[s]]
    summary = {'counts': counts, 'runs': runs, 'stale_suites_script_changed_since_run': stale, 'script_sha256_now': cur,
               'environment': {'python': platform.python_version(), 'platform': platform.platform(), 'sympy': sympy.__version__, 'mpmath': mpmath.__version__, 'numpy': numpy.__version__}}
    with open(os.path.join(out, 'SUMMARY.json'), 'w', encoding='utf-8', newline='\n') as f: json.dump(summary, f, indent=1, sort_keys=True)
    print(json.dumps({'counts': counts, 'stale': stale}))
    return counts['FAIL'] == 0 and not counts['missing_suites'] and not stale
if args == ['--summarize']:
    sys.exit(0 if summarize() else 1)
sel = [s for s in suites if not args or any(s.startswith(a) for a in args)]
for s in sel: run(s)
if not args: sys.exit(0 if summarize() else 1)
