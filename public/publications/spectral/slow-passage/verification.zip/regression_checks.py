"""Scientific mutations must fail; legitimate diagnostics and CRLF may vary."""
from pathlib import Path
import copy,json,tempfile,shutil
from validation import acceptance,tables
def run():
    base=Path(__file__).resolve().parent;d=json.loads((base/'results/calculations_checked.json').read_text());sp=json.loads((base/'specification.json').read_text());count=0
    def reject(x):
        nonlocal count
        try:acceptance(x,d,sp)
        except AssertionError:count+=1;return
        raise AssertionError('Scientific mutation accepted')
    x=copy.deepcopy(d);x['checks'][0]['threshold']*=10;reject(x)
    x=copy.deepcopy(d);x['cycles'][0]['events'][0]['input']+=.01;reject(x)
    x=copy.deepcopy(d);x['folds'][0]['stable_count']=6;reject(x)
    x=copy.deepcopy(d);x['checks'][0]['name']='wrong observable';reject(x)
    x=copy.deepcopy(d);x['checks'][0]['passed']=False;reject(x)
    x=copy.deepcopy(d);x['cycles'][0]['events'][0]['tight_input_difference']=sp['criteria']['event_convergence_max']/2;acceptance(x,d,sp);count+=1
    with tempfile.TemporaryDirectory() as temp:
        folder=Path(temp);shutil.copytree(base/'assets',folder/'assets')
        for p in (folder/'assets').glob('*.csv'):p.write_bytes(p.read_bytes().replace(b'\n',b'\r\n'))
        tables(folder);count+=1
        p=folder/'assets/delay.csv';p.write_text(p.read_text().replace('actual_delay','wrong_definition'))
        try:tables(folder)
        except AssertionError:count+=1
        else:raise AssertionError('Scientific table definition changed undetected')
    print(json.dumps({'status':'PASS','checker_regressions':count}))
if __name__=='__main__':run()
