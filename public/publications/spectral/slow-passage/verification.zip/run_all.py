"""Reproduce from a clean extraction into a new directory; retain references."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,platform,tempfile
import numpy as np
import scipy
from validation import acceptance,tables,own_arrays
def check_existing(base):
    base=Path(base);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    for row in json.loads((base/'MANIFEST.json').read_text())['files']:assert sha(base/row['path'])==row['sha256'],row['path']
    for freeze in ['FROZEN.json','INDEPENDENT_FROZEN.json']:
        for name,h in json.loads((base/freeze).read_text())['files'].items():
            if name=='DERIVATIONS.txt':continue
            assert sha(base/name)==h,name
    sp=json.loads((base/'specification.json').read_text());d=json.loads((base/'results/calculations_checked.json').read_text())
    acceptance(d,d,sp);tables(base);array_check=own_arrays(base)
    ind=json.loads((base/'results/independent_modal.json').read_text())
    assert ind['all_checks_pass'] and len(ind['events'])==4
    assert ind['criterion']==sp['criteria']['independent_event_max']
    for e in ind['events']:assert 0<=e['difference_from_complete_Radau']<ind['criterion']
    local=json.loads((base/'results/local_checks.json').read_text());assert local['all_checks_pass'] and len(local['cases'])==2
    for c in local['cases']:
        assert c['complete_zero_count']==1 and c['complete_stable_count']==7
        assert c['complete_stable_gap']>sp['criteria']['transverse_linear_gap_min']
        assert c['full_source_and_four_ledger_jacobian_FD_error']<2e-6 and c['left_kernel_error']<1e-9 and c['reflection_equivariance_error']<1e-12
    proc=subprocess.run([sys.executable,str(base/'regression_checks.py')],capture_output=True,text=True)
    assert proc.returncode==0;reg=json.loads(proc.stdout);assert reg['checker_regressions']==8
    if (base/'VERIFICATION_RESULTS.json').exists():
        record=json.loads((base/'VERIFICATION_RESULTS.json').read_text())
        for name,h in record['scientific_input_hashes'].items():assert sha(base/name)==h,name
        assert record['full_replay']['status']=='PASS'
    return {'status':'PASS','mode':'saved-data validation; no new ODE integration','frozen_comparisons':113,'arrays':24,'modal_events':4,'Jacobian_cases':2,'checker_regressions':8,'own_array_balances':array_check}
def run(output):
    base=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    for row in json.loads((base/'MANIFEST.json').read_text())['files']:assert sha(base/row['path'])==row['sha256'],row['path']
    for name in ['FROZEN.json','INDEPENDENT_FROZEN.json']:
        for n,h in json.loads((base/name).read_text())['files'].items():
            if n=='DERIVATIONS.txt':continue # historical proof-note identity; proof is in the paper
            assert sha(base/n)==h,n
    sp=json.loads((base/'specification.json').read_text());ref=json.loads((base/'results/calculations_checked.json').read_text());acceptance(ref,ref,sp);tables(base);own_arrays(base)
    out=Path(output).resolve();assert not out.exists() or not any(out.iterdir()),'Use a new empty output directory';out.mkdir(exist_ok=True,parents=True);shutil.copytree(base/'code',out/'code',ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copy2(base/'specification.json',out/'specification.json')
    for name in ['calculate.py','check_results.py','independent_modal.py','local_checks.py','post_analysis.py','make_assets.py','paper_assets.py']:
        proc=subprocess.run([sys.executable,str(out/'code'/name),'--base',str(out)],capture_output=True,text=True);(out/(name+'.log')).write_text(proc.stdout+proc.stderr,encoding='utf-8')
        assert proc.returncode==0,name+' failed; preserve its log';print(name+': PASS',flush=True)
    actual=json.loads((out/'results/calculations_checked.json').read_text());acceptance(actual,ref,sp)
    with np.load(base/'results/trajectories.npz') as a,np.load(out/'results/trajectories.npz') as b:
        assert set(a.files)==set(b.files)
        for name in a.files:np.testing.assert_allclose(a[name],b[name],rtol=sp['criteria']['replay_rtol'],atol=sp['criteria']['replay_atol'],err_msg=name)
    independent=json.loads((out/'results/independent_modal.json').read_text());assert independent['all_checks_pass'] and len(independent['events'])==4
    local=json.loads((out/'results/local_checks.json').read_text());assert local['all_checks_pass'] and len(local['cases'])==2
    tables(out);arrays=own_arrays(out)
    proc=subprocess.run([sys.executable,str(base/'regression_checks.py')],capture_output=True,text=True);assert proc.returncode==0;reg=json.loads(proc.stdout);assert reg['checker_regressions']==8
    result={'status':'PASS','frozen_comparisons':113,'scientific_comparison_failures':actual['failures'],'trajectory_arrays_compared':24,'independent_BDF_modal_event_comparisons':4,'local_full_source_and_ledger_Jacobian_checks':2,'checker_regressions':8,'own_run_tables':'PASS','own_array_energy_reconstruction':arrays,'raw_reporting_correction':'Four derived fold-start residuals corrected by explicit check_results stage; raw data preserved','environment':{'python':platform.python_version(),'system':platform.system(),'numpy':np.__version__,'scipy':scipy.__version__},'scope':'Actual clean extracted full replay with installed dependencies. Distinct modal BDF formulation shares SciPy backend. No fresh install, second OS, interval-flow certification or physical experiment.'}
    (out/'REPLAY_RECEIPT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);ap.add_argument('--check-existing',action='store_true');args=ap.parse_args()
    if args.check_existing:print(json.dumps(check_existing(Path(__file__).resolve().parent),indent=2))
    else:
        if args.output is None:ap.error('--output is required for full reproduction')
        run(args.output)
