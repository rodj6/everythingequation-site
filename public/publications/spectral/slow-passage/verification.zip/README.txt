SLOW PASSAGE AND PREPARED HYSTERESIS IN ADAPTIVE SPECTRAL CARRIERS
Jeremy Rodgers | November 2026
Reserved DOI: 10.5281/zenodo.23935694
https://doi.org/10.5281/zenodo.23935694

This verification companion accompanies the self-contained paper. The author
controls publication; inclusion of the reserved DOI does not imply an upload.

FULL REPRODUCTION
Locate Python 3.12 with NumPy, SciPy and Matplotlib. Tested versions are listed
in requirements.txt and the executed environment in VERIFICATION_RESULTS.json.
From a clean extraction:
  python run_all.py --output ../new_empty_replay
Use a new empty output directory. Allow several minutes. Progress is written
to results/progress.json in that directory. Scientific stage logs and a final
REPLAY_RECEIPT.json are retained there. The runner executes complete Radau
cycles/refinements, explicit correction, separate dynamic-memory modal BDF,
local Jacobian checks, post-analysis and own-run asset generation. It verifies
113 frozen comparisons, 24 trajectory arrays, four modal events, two Jacobian
cases, reflection symmetry and eight checker regressions.

For a quick check of the supplied archive and saved numerical results:
  python run_all.py --check-existing
This verifies hashes, definitions, saved scientific criteria, array balances,
modal/Jacobian results and checker regressions. It does not integrate new ODE
trajectories and does not replace the full reproduction command above.

CONTENTS AND TRACEABILITY
specification.json gives all rates, preparations, endpoints, reversal rules,
thresholds, coefficients and solver settings. FROZEN.json and
INDEPENDENT_FROZEN.json preserve the scientific freeze. The sole skipped hash
is the ancestral non-executable DERIVATIONS.txt proof note; proofs are in the
paper. All executable/input freeze hashes remain enforced. Historical scope
text inside the unchanged specification describes the original experiment.
provenance.json records source ancestry and CLAIM_MAP.json maps paper claims.
MANIFEST.json binds the delivered files. VERIFICATION_RESULTS.json contains
actual execution results and the scientific input hashes used in that run.

code/paper_assets.py produces all nine publication tables and three figures
from its own run's checked outputs. assets/PAPER_ASSETS.json binds their seven
input files. Small assets/paper_*.tex files are generated numerical fragments,
not manuscript source. CSV checks normalize irrelevant line endings. Scientific
labels, counts, definitions and thresholds remain exact; tiny diagnostics use
their declared scientific ceilings, rather than historical roundoff digits.

REPORTING CORRECTION
results/calculations.json is the untouched original producer output. Four
fold-start Riccati_error fields used the tracked-branch reference before the
prediction fields were replaced by the preparation-specific ones.
code/check_results.py changes only those four derived residuals in the separate
calculations_checked.json. REPORTING_CORRECTION.json records the raw hash and
every old/new value. Events, predictions, leading ratios and all 113 frozen
comparison outcomes are unaffected. Every full replay applies this stage.

SCOPE
The numerical exit levels .25 and .5 have no certified analytical chart radius.
Quadratic finite-threshold predictions are reduced-equation comparisons.
The modal BDF system retains dynamic memory exactly in the symmetric sector
and shares SciPy with the complete Radau calculation. Complete-state transverse
preparations are tested separately. Sampled geometric areas are distinct from
physical work. The paper proves a prepared quasistatic limit, not fixed-rate
periodic-orbit attraction. The executions use installed dependencies on the
recorded system, without a fresh-install, second-platform, directed trajectory
certificate or physical-validation claim.
