"""Post-result algebraic comparisons, not newly frozen empirical holdouts."""
from pathlib import Path
import json,argparse
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from model import curve
def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());d=json.loads((base/'results/calculations.json').read_text());p=sp['parameters'];ff=d['folds'];c2=p['gamma']**2+p['alpha']**2
    def R(a,branch):
        lo,hi=(0,ff[0]['s']) if branch=='low' else (ff[1]['s'],20)
        s=brentq(lambda s:curve(s,p)-a*a/c2,lo,hi,xtol=1e-13)
        return np.sqrt(4*p['kappa']/3*s*np.exp(s))
    area,error=quad(lambda a:R(a,'high')-R(a,'low'),ff[1]['a'],ff[0]['a'],epsabs=1e-10,epsrel=1e-10,limit=150)
    inst=[]
    for f in ff:
        rq=np.array(f['right'][:6]);d0=p['gamma']/c2*(rq@rq);dfull=d0+2/p['eta'];factor=dfull/d0
        inst.append({'fold':f['name'],'full_denominator':float(dfull),'instant_memory_denominator':float(d0),'instant_memory_A_factor':float(factor),'full_K':f['K'],'instant_memory_K':float(f['K']/factor**(2/3))})
    ratios=[]
    for f in ff:
        for theta in sp['exit_thresholds']:
            fast=next(e for e in d['cycles'][0]['events'] if e['fold']==f['name'] and e['threshold']==theta);slow=next(e for e in d['cycles'][len(sp['rates'])-1]['events'] if e['fold']==f['name'] and e['threshold']==theta)
            rr=sp['rates'][0]/sp['rates'][-1]
            ratios.append({'fold':f['name'],'threshold':theta,'fast_to_slow_delay_ratio':fast['delay']/slow['delay'],'power_two_thirds':rr**(2/3),'power_one_half':rr**.5,'power_one':rr})
    cycles=[{'rate':r['rate'],'absolute_area':abs(r['oriented_geometric_area']),'difference_from_quasistatic_area':abs(r['oriented_geometric_area'])-area,'work_coefficient_relative_error':r['work_leading_relative_error'],'end_capture_error':r['end_capture_error'],'turn_capture_error':r['turn_capture_error']} for r in d['cycles'][:len(sp['rates'])]]
    result={'scope':'Post-result evaluation of already derived area formula and an explicit rejected stationary-memory reduction. No coefficients fitted to delay data. Quadrature is floating, not a formal enclosure.','quasistatic_geometric_area':float(area),'quadrature_error_estimate':float(error),'cycles':cycles,'instantaneous_memory_obstruction':inst,'unfitted_power_ratio_comparison':ratios}
    (base/'results/post_analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
