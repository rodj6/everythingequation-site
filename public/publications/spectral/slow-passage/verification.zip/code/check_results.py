"""Explicitly correct one retained reporting residual; never change trajectories."""
from pathlib import Path
import argparse,json,hashlib,copy
def run(base):
    base=Path(base);raw=base/'results/calculations.json';d=json.loads(raw.read_text());fixed=copy.deepcopy(d);repairs=[]
    for row in fixed['finite_initialization']:
        for e in row['events']:
            value=e['delay']-e['prediction']['finite_threshold_Riccati_delay']
            repairs.append({'fold':row['fold'],'threshold':e['threshold'],'field':'Riccati_error','retained_raw_value':e['Riccati_error'],'corrected_value':value})
            e['Riccati_error']=value
    for row in fixed['cycles']:
        for e in row['events']:assert abs(e['Riccati_error']-(e['delay']-e['prediction']['finite_threshold_Riccati_delay']))<1e-14
    (base/'results/calculations_checked.json').write_text(json.dumps(fixed,indent=2))
    receipt={'scope':'Post-result reporting correction, not a changed experiment or threshold. The raw frozen producer is preserved. Its fold-start residual was calculated before replacing the tracked-initialization prediction. Switching locations, leading ratios and all 113 check results were already correct. The canonical checked result changes only four derived residuals.','raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'repairs':repairs}
    (base/'results/REPORTING_CORRECTION.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
