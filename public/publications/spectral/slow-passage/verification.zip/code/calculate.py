"""Frozen small ramp experiment: complete source, localized events and work."""
from pathlib import Path
import json,argparse,time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.special import airy
from model import V3,folds,equilibrium,parts,energy,tilt,rhs_jac,hessian,matrices

def airy_prediction(fold,rate,threshold,initial='tracked'):
    A,b=fold['A'],fold['b'];hs=rate**(2/3)/(A*b)**(1/3);us=(A*rate/b**2)**(1/3)
    mix=0. if initial=='tracked' else 1/np.sqrt(3)
    pole=fold['zeta'] if mix==0 else brentq(lambda T:airy(-T)[0]+mix*airy(-T)[2],1.,2.338)
    def ratio(T):
        ai,aip,bi,bip=airy(-T);return (aip+mix*bip)/(ai+mix*bi)
    target=threshold/us
    T=brentq(lambda T:ratio(T)-target,0.,pole-1e-9,xtol=1e-13)
    return {'leading_delay':hs*pole,'universal_leading_delay':hs*fold['zeta'],'finite_threshold_Riccati_delay':hs*T,'inner_amplitude_scale':us,'inner_input_scale':hs,'pole_constant':float(pole),'interpretation':'Exact finite-threshold prediction in the quadratic reduced equation; its subleading correction is not claimed universal for the complete source'}

def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());p=sp['parameters'];fs=folds(p);out=base/'results';out.mkdir(exist_ok=True);arrays={};rows=[];checks=[]
    def check(name,val,relation,threshold):
        val=float(val);ok=np.isfinite(val) and {'lt':val<threshold,'gt':val>threshold,'eq':val==threshold}[relation]
        checks.append({'name':name,'value':val,'relation':relation,'threshold':float(threshold),'passed':bool(ok)})
    def progress(name):(out/'progress.json').write_text(json.dumps({'stage':name}))
    def solve(x0,aa,bb,rate,pp,fold=None,tight=False):
        slope=np.sign(bb-aa)*rate;T=abs(bb-aa)/rate;rhs,jac=rhs_jac(pp,aa,slope);events=[]
        if fold:
            for threshold in sp['exit_thresholds']:
                def ev(t,y,threshold=threshold):return fold['sigma']*np.dot(fold['left'],y[:8]-fold['x'])-threshold
                ev.direction=1;ev.terminal=False;events.append(ev)
        maxstep=min(sp['max_time_step'],sp['max_input_step']/rate)/(2 if tight else 1)
        sol=solve_ivp(rhs,[0,T],np.r_[x0,np.zeros(4)],method='Radau',jac=jac,rtol=sp['tight_rtol'] if tight else sp['rtol'],atol=sp['tight_atol'] if tight else sp['atol'],dense_output=True,max_step=maxstep,events=events or None)
        assert sol.success,sol.message
        tt=np.linspace(0,T,sp['samples_per_leg']);yy=sol.sol(tt);aa_grid=aa+slope*tt;F=np.array([energy(y,pp) for y in yy.T]);V=np.array([tilt(y,a,pp) for y,a in zip(yy.T,aa_grid)])
        physical=F-F[0]+yy[8]-yy[9];tilted=V-V[0]+yy[10]+yy[11]
        denom=1+np.abs(yy[8])+np.abs(yy[9]);led=float(max(np.max(abs(physical)/denom),np.max(abs(tilted)/denom)))
        eventrows=[]
        if fold:
            for threshold,ts,states in zip(sp['exit_thresholds'],sol.t_events,sol.y_events):
                assert len(ts)==1,(fold['name'],rate,threshold,ts)
                t=float(ts[0]);a=aa+slope*t;h=fold['sigma']*(a-fold['a']);pred=airy_prediction(fold,rate,threshold)
                eventrows.append({'fold':fold['name'],'threshold':threshold,'time':t,'input':float(a),'delay':float(h),'prediction':pred,'leading_ratio':float(h/pred['leading_delay']),'Riccati_error':float(h-pred['finite_threshold_Riccati_delay']),'event_residual':float(abs(fold['sigma']*np.dot(fold['left'],states[0,:8]-fold['x'])-threshold))})
        return sol,{'times':tt,'values':yy,'inputs':aa_grid},eventrows,{'physical_ledger_abs':float(np.max(abs(physical))),'tilted_ledger_abs':float(np.max(abs(tilted))),'scaled_ledger':led,'steps':len(sol.t),'function_calls':sol.nfev}
    def cycle(name,rate,pp,x0,compare_tight=True):
        progress(name);lo,hi=sp['endpoints'];current=x0.copy();offset=np.zeros(4);xx=[];tt=[];aa=[];evrows=[];diagnostics=[];T0=0.;ends=[]
        for i,(a0,a1) in enumerate([(lo,hi),(hi,lo)]):
            fold=fs[i] if pp['mu']==p['mu'] else None
            sol,data,events,diag=solve(current,a0,a1,rate,pp,fold)
            if compare_tight:
                tight,td,te,tg=solve(current,a0,a1,rate,pp,fold,True)
                if fold:
                    for e,t in zip(events,te):e['tight_input_difference']=abs(e['input']-t['input']);check(name+'/'+e['fold']+'/threshold_'+str(e['threshold'])+'/event_convergence',e['tight_input_difference'],'lt',sp['criteria']['event_convergence_max'])
                diag['tight_endpoint_difference']=float(np.linalg.norm(sol.y[:8,-1]-tight.y[:8,-1]));check(name+'/'+str(i)+'/state_convergence',diag['tight_endpoint_difference'],'lt',sp['criteria']['state_convergence_max'])
            current=sol.y[:8,-1].copy();ends.append(current.copy());data['values'][8:]+=offset[:,None];offset=data['values'][8:,-1].copy()
            take=slice(None) if i==0 else slice(1,None);xx.append(data['values'][:,take]);tt.append(data['times'][take]+T0);aa.append(data['inputs'][take]);T0+=abs(a1-a0)/rate;evrows+=events;diagnostics.append(diag)
            check(name+'/'+str(i)+'/ledger',diag['scaled_ledger'],'lt',sp['criteria']['scaled_ledger_max'])
        vals=np.concatenate(xx,axis=1);times=np.concatenate(tt);inputs=np.concatenate(aa);radius=abs(V3@(vals[:3]+1j*vals[3:6]));area=float(np.trapezoid(radius,inputs))
        arrays[name+'_times']=times;arrays[name+'_states_ledgers']=vals;arrays[name+'_input']=inputs
        high=equilibrium(hi,pp,'high');low=equilibrium(lo,pp,'low');turnerr=float(np.linalg.norm(ends[0]-high));enderr=float(np.linalg.norm(ends[1]-low))
        check(name+'/end_capture',enderr,'lt',sp['criteria']['end_capture_max']);check(name+'/turn_capture',turnerr,'lt',sp['criteria']['turn_capture_max'])
        W=float(vals[9,-1]);Q=float(vals[8,-1]);dF=energy(ends[1],pp)-energy(x0,pp);whole=abs(dF-W+Q);check(name+'/whole_ledger',whole/(1+abs(W)+abs(Q)),'lt',sp['criteria']['scaled_ledger_max'])
        expected=2*pp['gamma']/(abs(complex(pp['gamma'],pp['alpha']))**2)*(hi**3-lo**3)/3
        if pp['mu']==p['mu']:
            for event in evrows:
                check(name+'/'+event['fold']+'/'+str(event['threshold'])+'/positive_delay',event['delay'],'gt',0)
                error=abs(event['leading_ratio']-1);limit=sp['criteria']['slow_leading_relative_max'] if rate==min(sp['rates']) else sp['criteria']['leading_relative_max'];check(name+'/'+event['fold']+'/'+str(event['threshold'])+'/leading_prediction',error,'lt',limit)
        return {'name':name,'rate':rate,'events':evrows,'legs':diagnostics,'turn_capture_error':turnerr,'end_capture_error':enderr,'supplied_work':W,'dissipation':Q,'energy_change':dF,'whole_physical_ledger_abs':whole,'oriented_geometric_area':area,'rate_times_work':rate*W,'adiabatic_work_coefficient':float(expected),'work_leading_relative_error':float(abs(rate*W/expected-1)),'initial_state':x0.tolist(),'turn_state':ends[0].tolist(),'final_state':ends[1].tolist()}
    initial=equilibrium(sp['endpoints'][0],p,'low')
    for rate in sp['rates']:rows.append(cycle('cycle_'+format(rate,'.0e'),rate,p,initial))
    slow=rows[-1];pert=cycle('transverse_preparation',sp['rates'][-1],p,initial+np.array(sp['perturbation']));rows.append(pert)
    perturb_difference=max(abs(a['input']-b['input']) for a,b in zip(slow['events'],pert['events']));check('transverse_preparation_event_difference',perturb_difference,'lt',sp['criteria']['preparation_event_max'])
    pp=dict(p);pp['mu']=sp['unique_mu'];unique=cycle('unique_control',sp['rates'][0],pp,equilibrium(sp['endpoints'][0],pp,'low'));rows.append(unique)
    fixed={};lo,hi=sp['endpoints'];rate=sp['rates'][0];c=complex(p['gamma'],p['alpha']);kk=p['mu']+3;u=lo/(c*kk);rr=[];aa=[]
    for a0,a1 in [(lo,hi),(hi,lo)]:
        slope=np.sign(a1-a0)*rate;t=np.linspace(0,abs(a1-a0)/rate,sp['samples_per_leg']);a=a0+slope*t;uu=a/(c*kk)-slope/(c*kk)**2+(u-a0/(c*kk)+slope/(c*kk)**2)*np.exp(-c*kk*t);u=uu[-1];rr.append(abs(uu));aa.append(a)
    fixed={'rate':rate,'oriented_geometric_area':float(sum(np.trapezoid(r,a) for r,a in zip(rr,aa))),'endpoint_error':float(abs(u-lo/(c*kk))),'contract':'Exact time-dependent fixed-carrier amplitude solution, same triangular drive, no memory dynamics'}
    check('unique_area_relative_to_bistable',abs(unique['oriented_geometric_area']/rows[0]['oriented_geometric_area']),'lt',sp['criteria']['control_area_ratio_max']);check('fixed_area_relative_to_bistable',abs(fixed['oriented_geometric_area']/rows[0]['oriented_geometric_area']),'lt',sp['criteria']['control_area_ratio_max'])
    finite=[]
    for fold in fs:
        progress('finite_initialization_'+fold['name']);rate=sp['rates'][-1];a0=fold['a'];a1=a0+fold['sigma']*sp['finite_initialization_span']
        sol,data,events,diag=solve(np.array(fold['x']),a0,a1,rate,p,fold)
        tight,td,te,tg=solve(np.array(fold['x']),a0,a1,rate,p,fold,True)
        for e,t in zip(events,te):
            e['prediction']=airy_prediction(fold,rate,e['threshold'],'fold_start');e['leading_ratio']=e['delay']/e['prediction']['leading_delay'];e['tight_input_difference']=abs(e['input']-t['input']);check('finite_initialization/'+fold['name']+'/'+str(e['threshold'])+'/convergence',e['tight_input_difference'],'lt',sp['criteria']['event_convergence_max']);check('finite_initialization/'+fold['name']+'/'+str(e['threshold'])+'/prediction',abs(e['leading_ratio']-1),'lt',sp['criteria']['slow_leading_relative_max'])
        arrays['finite_'+fold['name']+'_times']=data['times'];arrays['finite_'+fold['name']+'_states_ledgers']=data['values'];arrays['finite_'+fold['name']+'_input']=data['inputs'];finite.append({'fold':fold['name'],'events':events,'diagnostics':diag})
    exponents=[]
    for fold in fs:
        for threshold in sp['exit_thresholds']:
            selected=[next(e for e in row['events'] if e['fold']==fold['name'] and e['threshold']==threshold) for row in rows[:len(sp['rates'])]]
            fit=float(np.polyfit(np.log(sp['rates']),np.log([e['delay'] for e in selected]),1)[0]);exponents.append({'fold':fold['name'],'threshold':threshold,'log_fit_exponent':fit,'classification':'Post-result diagnostic; no fitted coefficient used in predictions'})
    result={'status':'complete','folds':fs,'cycles':rows,'fixed_control':fixed,'finite_initialization':finite,'transverse_event_difference':perturb_difference,'exponents':exponents,'checks':checks,'all_checks_pass':all(c['passed'] for c in checks),'failures':[c for c in checks if not c['passed']],'scope':'Full source Radau with localized events; separate tighter solves. Numerical flows, not interval certificates; source-derived prediction coefficients not fitted.'}
    (out/'calculations.json').write_text(json.dumps(result,indent=2));np.savez_compressed(out/'trajectories.npz',**arrays);progress('complete')
    print(json.dumps({'checks':len(checks),'failures':result['failures'],'events':[[r['rate'],[(e['fold'],e['threshold'],e['delay'],e['leading_ratio']) for e in r['events']]] for r in rows[:len(sp['rates'])]],'exponents':exponents},indent=2),flush=True)
    # Scientific failures are retained as outcomes, not hidden by aborting output.
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
