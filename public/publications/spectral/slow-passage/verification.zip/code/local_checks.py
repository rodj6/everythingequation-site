"""Post-design local implementation audit; no ramp prediction is fitted."""
from pathlib import Path
import json,argparse
import numpy as np
from model import rhs_jac,folds,hessian,matrices,V3,EDGES
def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());p=sp['parameters'];fs=folds(p);rows=[]
    for fold in fs:
        x=np.array(fold['x']);rhs,jac=rhs_jac(p,fold['a'],fold['sigma']*sp['rates'][0]);y=np.r_[x+np.array(sp['perturbation']),np.zeros(4)];eps=1e-6
        fd=np.column_stack([(rhs(0,y+eps*np.eye(12)[:,j])-rhs(0,y-eps*np.eye(12)[:,j]))/(2*eps) for j in range(12)])
        error=float(np.linalg.norm(fd-jac(0,y),2));assert error<2e-6
        rr=np.array(fold['right']);ll=np.array(fold['left']);G,D=matrices(p);A=-D@hessian(x,p)[0];left_error=float(np.linalg.norm(ll@A));assert left_error<1e-9
        assert fold['normalization_error']<sp['criteria']['fold_normalization_max'] and fold['kernel_residual']<sp['criteria']['fold_kernel_max'];assert fold['zero_count']==1 and fold['stable_count']==7 and fold['stable_gap']>sp['criteria']['transverse_linear_gap_min']
        # Reflection-odd amplitude and memory, plus both collective quadratures,
        # are part of the stable count; exact source symmetry is also tested.
        perm=np.array([2,1,0,5,4,3,7,6,8,9,10,11]);sym_error=float(np.linalg.norm(rhs(0,y[perm])-rhs(0,y)[perm]));assert sym_error<1e-12
        rows.append({'fold':fold['name'],'full_source_and_four_ledger_jacobian_FD_error':error,'left_kernel_error':left_error,'complete_zero_count':1,'complete_stable_count':7,'complete_stable_gap':fold['stable_gap'],'reflection_equivariance_error':sym_error})
    result={'all_checks_pass':True,'cases':rows,'scope':'Post-design finite-difference and symmetry implementation checks on fold states plus declared perturbation; not unseen ramp outcomes or formal enclosures'}
    (base/'results/local_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
