"""Same full amplitude-memory law; real coordinates and physical ledgers."""
import numpy as np
from scipy.optimize import brentq
from scipy.special import ai_zeros,airy
V3=np.array([1.,-2.,1.])/np.sqrt(6)
INC=np.array([[1.,-1.,0.],[0.,1.,-1.]])
EDGES=np.einsum('ei,ej->eij',INC,INC)
J=np.block([[np.zeros((3,3)),-np.eye(3)],[np.eye(3),np.zeros((3,3))]])
def matrices(p):
    G=p['gamma']*np.eye(6)+p['alpha']*J
    D=np.zeros((8,8));D[:6,:6]=G;D[6:,6:]=p['eta']*np.eye(2)
    return G,D
def parts(x,p):
    z=x[:3]+1j*x[3:6];m=x[6:8];w=np.exp(m)
    K=p['mu']*np.eye(3)+w[0]*EDGES[0]+w[1]*EDGES[1]
    force=K@z;g=p['kappa']*m+.5*w*abs(INC@z)**2
    return z,m,w,K,force,g
def hessian(x,p):
    z,m,w,K,force,g=parts(x,p);KR=np.kron(np.eye(2),K)
    B=np.column_stack([w[e]*np.r_[EDGES[e]@z.real,EDGES[e]@z.imag] for e in range(2)])
    Hm=np.diag(p['kappa']+.5*w*abs(INC@z)**2)
    return np.block([[KR,B],[B.T,Hm]]),KR,B,Hm
def energy(x,p):
    z,m,w,K,force,g=parts(x,p)
    return float(.5*np.vdot(z,force).real+.5*p['kappa']*(m@m))
def tilt(x,a,p):
    c=complex(p['gamma'],p['alpha']);z=x[:3]+1j*x[3:6]
    return energy(x,p)-float(np.vdot(a*V3/c,z).real)
def curve(s,p):
    return 4*p['kappa']/3*s*np.exp(s)*(p['mu']+3*np.exp(-s))**2
def state(s,p):
    c=complex(p['gamma'],p['alpha']);z=abs(c)/c*np.sqrt(4*p['kappa']/3*s*np.exp(s))*V3
    return np.r_[z.real,z.imag,-s,-s]
def equilibrium(a,p,branch):
    c=complex(p['gamma'],p['alpha']);load=a*a/abs(c)**2
    chi=(2-np.sqrt(3))*np.exp(-np.sqrt(3))
    if p['mu']>=3*chi:lo,hi=0.,20.
    else:
        fm=folds(p);lo,hi=(0.,fm[0]['s']) if branch=='low' else (fm[1]['s'],20.)
    return state(brentq(lambda s:curve(s,p)-load,lo,hi,xtol=1e-13),p)
def folds(p):
    c=complex(p['gamma'],p['alpha']);G,D=matrices(p)
    q=lambda s:np.exp(-s)*(s-1)/(s+1)
    ss=[brentq(lambda s:q(s)-p['mu']/3,1.,np.sqrt(3),xtol=1e-14),brentq(lambda s:q(s)-p['mu']/3,np.sqrt(3),40.,xtol=1e-14)]
    rows=[]
    for name,s,sigma in zip(['up','down'],ss,[1,-1]):
        x=state(s,p);a=abs(c)*np.sqrt(curve(s,p));R=np.linalg.norm(x[:6]);rp=R*(1+s)/(2*s)
        rr=np.r_[(abs(c)/c*rp*V3).real,(abs(c)/c*rp*V3).imag,-1.,-1.]
        hh=np.r_[(V3/c).real,(V3/c).imag,0.,0.];den=rr@np.linalg.solve(D,rr);ll=np.linalg.solve(D.T,rr)/den
        A=float(rr@hh/den);hpp=4*p['kappa']/3*(p['mu']**2*np.exp(s)*(s+2)+9*np.exp(-s)*(s-2));app=abs(c)*hpp/(2*np.sqrt(curve(s,p)));B=-A*app/2
        H=hessian(x,p)[0];ev=np.linalg.eigvals(-D@H);stable=ev[abs(ev)>1e-7]
        rows.append({'name':name,'s':float(s),'a':float(a),'sigma':sigma,'x':x.tolist(),'right':rr.tolist(),'left':ll.tolist(),'A':A,'B':float(B),'b':float(abs(B)),'normalization_error':float(abs(ll@rr-1)),'kernel_residual':float(np.linalg.norm(H@rr)),'zero_count':int(sum(abs(ev)<1e-7)),'stable_count':int(sum(ev.real<-1e-7)),'stable_gap':float(-max(stable.real))})
    zeta=float(-ai_zeros(1)[0][0])
    for row in rows:row['zeta']=zeta;row['K']=zeta/(row['A']*row['b'])**(1/3)
    return rows
def rhs_jac(p,a0,slope):
    G,D=matrices(p);c=complex(p['gamma'],p['alpha']);fr=np.r_[V3,np.zeros(3)];ellprime=np.r_[(slope*V3/c).real,(slope*V3/c).imag]
    def rhs(t,y):
        a=a0+slope*t;z,m,w,K,force,g=parts(y,p);f=a*V3;dz=-c*force+f;eff=np.r_[force.real,force.imag];ell=np.r_[(f/c).real,(f/c).imag]
        return np.r_[dz.real,dz.imag,-p['eta']*g,p['gamma']*(eff@eff)+p['eta']*(g@g),float(np.vdot(force,f).real),p['gamma']*((eff-ell)@(eff-ell))+p['eta']*(g@g),ellprime@y[:6]]
    def jac(t,y):
        a=a0+slope*t;H,KR,B,Hm=hessian(y,p);z,m,w,K,force,g=parts(y,p);eff=np.r_[force.real,force.imag];fR=a*fr;ell=np.r_[(a*V3/c).real,(a*V3/c).imag]
        JJ=np.zeros((12,12));JJ[:8,:8]=-D@H
        JJ[8,:6]=2*p['gamma']*KR@eff+2*p['eta']*B@g;JJ[8,6:8]=2*p['gamma']*B.T@eff+2*p['eta']*Hm@g
        JJ[9,:6]=KR@fR;JJ[9,6:8]=B.T@fR
        JJ[10,:6]=2*p['gamma']*KR@(eff-ell)+2*p['eta']*B@g;JJ[10,6:8]=2*p['gamma']*B.T@(eff-ell)+2*p['eta']*Hm@g
        JJ[11,:6]=ellprime
        return JJ
    return rhs,jac
