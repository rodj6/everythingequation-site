"""Separate invariant modal dynamics and BDF event calculation; memory retained."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());pp=sp['parameters'];g=pp['gamma'];al=pp['alpha'];eta=pp['eta'];mu=pp['mu'];kap=pp['kappa'];c=complex(g,al);v=np.array([1.,-2.,1.])/np.sqrt(6);lo,hi=sp['endpoints'];rate=sp['rates'][-1]
    # Independent scalar preparation and explicit three-state source, no full
    # eight-state Hessian, gradient routine or stationary-memory substitution.
    H=lambda s:4*kap/3*s*np.exp(s)*(mu+3*np.exp(-s))**2
    sf=sp['folds'][0]['s'];s0=brentq(lambda s:H(s)-lo*lo/abs(c)**2,0,sf,xtol=1e-14);u0=(lo/c)/(mu+3*np.exp(-s0));state=np.array([u0.real,u0.imag,-s0]);rows=[]
    for leg,(a0,a1) in enumerate([(lo,hi),(hi,lo)]):
        slope=np.sign(a1-a0)*rate;T=abs(a1-a0)/rate;fold=sp['folds'][leg];ll=np.array(fold['left']);xf=np.array(fold['x'])
        def rhs(t,y):
            zr,zi,m=y;w=np.exp(m);k=mu+3*w
            return [-g*k*zr+al*k*zi+a0+slope*t,-al*k*zr-g*k*zi,-eta*(kap*m+.75*w*(zr*zr+zi*zi))]
        def jac(t,y):
            zr,zi,m=y;w=np.exp(m);k=mu+3*w;h=kap+.75*w*(zr*zr+zi*zi)
            return [[-g*k,al*k,3*w*(-g*zr+al*zi)],[-al*k,-g*k,3*w*(-al*zr-g*zi)],[-1.5*eta*w*zr,-1.5*eta*w*zi,-eta*h]]
        events=[]
        for threshold in sp['exit_thresholds']:
            def ev(t,y,threshold=threshold):
                zr,zi,m=y;x=np.r_[zr*v,zi*v,m,m]
                return fold['sigma']*(ll@(x-xf))-threshold
            ev.direction=1;ev.terminal=False;events.append(ev)
        sol=solve_ivp(rhs,[0,T],state,method='BDF',jac=jac,rtol=1e-11,atol=1e-13,max_step=min(sp['max_time_step'],sp['max_input_step']/rate)/2,events=events)
        assert sol.success;state=sol.y[:,-1]
        for threshold,times in zip(sp['exit_thresholds'],sol.t_events):
            assert len(times)==1
            rows.append({'fold':fold['name'],'threshold':threshold,'input':float(a0+slope*times[0]),'delay':float(fold['sigma']*(a0+slope*times[0]-fold['a']))})
    d=json.loads((base/'results/calculations.json').read_text());full=d['cycles'][len(sp['rates'])-1]['events'];differences=[]
    for a,b in zip(rows,full):
        assert a['fold']==b['fold'] and a['threshold']==b['threshold'];a['difference_from_complete_Radau']=abs(a['input']-b['input']);differences.append(a['difference_from_complete_Radau'])
    result={'events':rows,'maximum_input_difference':max(differences),'criterion':sp['criteria']['independent_event_max'],'all_checks_pass':max(differences)<sp['criteria']['independent_event_max'],'scope':'Independent explicit 3-real-state invariant formulation with dynamic memory and BDF algorithm versus complete 8-real-state Radau. Applies only to exactly symmetry-preserving preparation; SciPy backend shared. No interval/physical certification.'}
    (base/'results/independent_modal.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
