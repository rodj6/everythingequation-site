"""Tables and figures generated exclusively from this run's checked outputs."""
from pathlib import Path
import json,argparse,csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def generate(base):
    base=Path(base);d=json.loads((base/'results/calculations_checked.json').read_text());post=json.loads((base/'results/post_analysis.json').read_text());sp=json.loads((base/'specification.json').read_text());out=base/'assets';out.mkdir(exist_ok=True)
    primary=d['cycles'][:len(sp['rates'])]
    tables={
      'delay':{'columns':['rate','fold','threshold','actual_delay','leading_prediction','actual_over_leading','quadratic_finite_threshold','actual_minus_quadratic','event_tight_difference'],'rows':[[r['rate'],e['fold'],e['threshold'],e['delay'],e['prediction']['leading_delay'],e['leading_ratio'],e['prediction']['finite_threshold_Riccati_delay'],e['Riccati_error'],e['tight_input_difference']] for r in primary for e in r['events']]},
      'cycles':{'columns':['rate','turn_state_error','end_state_error','geometric_area_absolute','work','dissipation','delta_F','nu_times_work','work_limit_coefficient'],'rows':[[r['rate'],r['turn_capture_error'],r['end_capture_error'],abs(r['oriented_geometric_area']),r['supplied_work'],r['dissipation'],r['energy_change'],r['rate_times_work'],r['adiabatic_work_coefficient']] for r in primary]},
      'initialization':{'columns':['fold','threshold','actual_delay','fold_start_leading','tracked_branch_leading','fold_start_finite_threshold','corrected_Riccati_error'],'rows':[[r['fold'],e['threshold'],e['delay'],e['prediction']['leading_delay'],e['prediction']['universal_leading_delay'],e['prediction']['finite_threshold_Riccati_delay'],e['Riccati_error']] for r in d['finite_initialization'] for e in r['events']]},
      'folds':{'columns':['fold','input','A','B','K','stable_modes','zero_modes','stable_gap'],'rows':[[f['name'],f['a'],f['A'],f['B'],f['K'],f['stable_count'],f['zero_count'],f['stable_gap']] for f in d['folds']]}}
    for name,t in tables.items():
        with (out/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:w=csv.writer(f,lineterminator='\n');w.writerow(t['columns']);w.writerows(t['rows'])
    (out/'table_data.json').write_text(json.dumps(tables,indent=2))
    plt.rcParams.update({'font.size':10,'axes.titlesize':12,'legend.fontsize':8})
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained')
    for ax,name in zip(axs,['up','down']):
        for threshold in sp['exit_thresholds']:
            ee=[next(e for e in r['events'] if e['fold']==name and e['threshold']==threshold) for r in primary];ax.loglog(sp['rates'],[e['delay'] for e in ee],'o-',label='Full source, u='+str(threshold))
        f=next(f for f in d['folds'] if f['name']==name);rr=np.geomspace(min(sp['rates']),max(sp['rates']),100);ax.loglog(rr,f['K']*rr**(2/3),'k--',label='Unfitted leading Airy prediction');ax.set(xlabel='Ramp rate nu',ylabel='Oriented input delay',title=name.capitalize()+' fold passage');ax.grid(alpha=.25);ax.legend()
    fig.savefig(out/'delay_scaling.png',dpi=180);plt.close(fig)
    npz=np.load(base/'results/trajectories.npz');v=np.array([1.,-2.,1.])/np.sqrt(6)
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained')
    for r in primary:
        x=npz[r['name']+'_states_ledgers'];aa=npz[r['name']+'_input'];R=abs(v@(x[:3]+1j*x[3:6]));axs[0].plot(aa,R,label='nu='+format(r['rate'],'.0e'))
    for f in d['folds']:axs[0].axvline(f['a'],color='grey',ls=':',lw=1)
    axs[0].set(xlabel='Prescribed input amplitude a',ylabel='Mode amplitude radius R',title='Uninterrupted forward and reverse cycles');axs[0].grid(alpha=.25);axs[0].legend()
    rr=[r['rate'] for r in primary];axs[1].semilogx(rr,[abs(r['oriented_geometric_area']) for r in primary],'o-',label='Sampled geometric loop area');axs[1].axhline(post['quasistatic_geometric_area'],color='k',ls='--',label='Stationary-branch limit');axs[1].set(xlabel='Ramp rate nu',ylabel='Geometric area (not work)',title='Cycle graph approaches static limit');axs[1].grid(alpha=.25);axs[1].legend()
    fig.savefig(out/'cycles_and_area.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained');r=primary[-1];tt=npz[r['name']+'_times'];x=npz[r['name']+'_states_ledgers']
    axs[0].plot(tt,x[9],label='Supplied work');axs[0].plot(tt,x[8],ls='--',label='Dissipation');axs[0].set(xlabel='Time',ylabel='Cumulative physical energy',title='Slowest cycle: continuing maintenance work');axs[0].legend();axs[0].grid(alpha=.25)
    axs[1].semilogx(rr,[r['rate_times_work'] for r in primary],'o-',label='nu times actual cycle work');axs[1].axhline(primary[0]['adiabatic_work_coefficient'],color='k',ls='--',label='Source-derived slow limit');axs[1].ticklabel_format(axis='y',style='plain',useOffset=False);axs[1].set(xlabel='Ramp rate nu',ylabel='Rate-scaled work',title='Work scales as 1/nu');axs[1].legend();axs[1].grid(alpha=.25)
    fig.savefig(out/'physical_work.png',dpi=180);plt.close(fig)
    (out/'GENERATION.json').write_text(json.dumps({'inputs':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['results/calculations_checked.json','results/post_analysis.json','results/trajectories.npz','specification.json']},'table_binding':'table_data.json contains raw own-run values; text line endings are irrelevant to CSV contracts','geometric_area_scope':'Trapezoid on 501 samples per leg, display diagnostic, not certified area quadrature or physical work','event_scope':'Switches localized by solver event roots, independent of the display sample grid'},indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);generate(ap.parse_args().base)
