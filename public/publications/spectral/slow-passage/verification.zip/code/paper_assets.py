"""Publication tables/plots bound to the checked numerical outputs of this run."""
from pathlib import Path
import json,argparse,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def generate(base):
    base=Path(base);out=base/'assets';sp=json.loads((base/'specification.json').read_text());d=json.loads((base/'results/calculations_checked.json').read_text());post=json.loads((base/'results/post_analysis.json').read_text());cor=json.loads((base/'results/REPORTING_CORRECTION.json').read_text());ind=json.loads((base/'results/independent_modal.json').read_text());loc=json.loads((base/'results/local_checks.json').read_text());rows=d['cycles'][:len(sp['rates'])]
    def token(v,f):
        if f is None:return str(v).replace('_',r'\_')
        s=format(v,f)
        if 'e' in s:
            m,e=s.split('e');return r'$'+m+r'\times10^{'+str(int(e))+'}$'
        return s
    def table(name,heads,rr,formats):
        lines=[r'\begin{tabular}{'+'l'+'r'*(len(heads)-1)+'}',r'\toprule',' & '.join(heads)+r' \\',r'\midrule']
        for row in rr:lines.append(' & '.join(token(v,f) for v,f in zip(row,formats))+r' \\')
        lines += [r'\bottomrule',r'\end{tabular}'];(out/(name+'.tex')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    table('paper_folds',['Fold',r'$a_f$',r'$A_f$',r'$B_f$',r'$K_f$'],[[f['name'],f['a'],f['A'],f['B'],f['K']] for f in d['folds']],[None,'.9f','.9f','.9f','.9f'])
    for fold in ['up','down']:
        table('paper_delay_'+fold,[r'$\nu$',r'$d$',r'$\Delta a$',r'$K_f\nu^{2/3}$','Ratio','Quadratic exit'],[[r['rate'],e['threshold'],e['delay'],e['prediction']['leading_delay'],e['leading_ratio'],e['prediction']['finite_threshold_Riccati_delay']] for r in rows for e in r['events'] if e['fold']==fold],['.0e','.2f','.6f','.6f','.5f','.6f'])
    table('paper_initialization',['Fold',r'$d$',r'$\Delta a$','Fold-start lead','Ratio','Tracked lead'],[[f['fold'],e['threshold'],e['delay'],e['prediction']['leading_delay'],e['leading_ratio'],e['prediction']['universal_leading_delay']] for f in d['finite_initialization'] for e in f['events']],[None,'.2f','.7f','.7f','.5f','.7f'])
    table('paper_capture',[r'$\nu$','Turn error','Return error','Sampled area',r'$\nu W$'],[[r['rate'],r['turn_capture_error'],r['end_capture_error'],abs(r['oriented_geometric_area']),r['rate_times_work']] for r in rows],['.0e','.3e','.3e','.6f','.8f'])
    table('paper_work',[r'$\nu$',r'$W$',r'$Q$',r'$\Delta F$','Ledger ratio'],[[r['rate'],r['supplied_work'],r['dissipation'],r['energy_change'],max(q['scaled_ledger'] for q in r['legs'])] for r in rows],['.0e','.5f','.5f','.3e','.2e'])
    table('paper_correction',['Fold',r'$d$','Retained raw residual','Checked residual'],[[r['fold'],r['threshold'],r['retained_raw_value'],r['corrected_value']] for r in cor['repairs']],[None,'.2f','.6e','.6e'])
    table('paper_memory',['Fold',r'$d_0$',r'$d_{\rm full}$',r'$K_{\rm inst}$',r'$K_{\rm full}$'],[[r['fold'],r['instant_memory_denominator'],r['full_denominator'],r['instant_memory_K'],r['full_K']] for r in post['instantaneous_memory_obstruction']],[None,'.6f','.6f','.6f','.6f'])
    table('paper_checks',['Check','Value'],[['Maximum event refinement difference',max(e['tight_input_difference'] for r in d['cycles'] for e in r['events'])],['Independent modal BDF difference',ind['maximum_input_difference']],['Full Jacobian finite-difference error',max(r['full_source_and_four_ledger_jacobian_FD_error'] for r in loc['cases'])],['Initial perturbation event difference',d['transverse_event_difference']],['Fixed-carrier sampled area',abs(d['fixed_control']['oriented_geometric_area'])],['Unique adaptive sampled area',abs(d['cycles'][-1]['oriented_geometric_area'])]],[None,'.3e'])
    def rate_label(rate):
        mantissa,exponent=format(rate,'.0e').split('e');exponent=str(int(exponent))
        return r'$\nu='+('' if mantissa=='1' else mantissa+r'\times ')+r'10^{'+exponent+r'}$'
    plt.rcParams.update({'font.size':10,'axes.titlesize':11,'legend.fontsize':8.5,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(7.2,3.6),layout='constrained')
    for ax,fold in zip(axs,['up','down']):
        for theta in sp['exit_thresholds']:
            ee=[next(e for e in r['events'] if e['fold']==fold and e['threshold']==theta) for r in rows];ax.loglog(sp['rates'],[e['delay'] for e in ee],'o-',label=r'$d='+str(theta)+r'$')
        f=next(f for f in d['folds'] if f['name']==fold);rate=np.geomspace(min(sp['rates']),max(sp['rates']),100);ax.loglog(rate,f['K']*rate**(2/3),'k--',label='Unfitted leading law');ax.set(xlabel=r'Ramp rate $\nu$',ylabel='Oriented input delay',title=fold.capitalize()+'ward passage');ax.grid(alpha=.2);ax.legend()
    fig.savefig(out/'paper_delay.pdf');plt.close(fig)
    data=np.load(base/'results/trajectories.npz');v=np.array([1.,-2.,1.])/np.sqrt(6)
    fig,ax=plt.subplots(figsize=(6.8,4.1),layout='constrained')
    for r in rows:
        x=data[r['name']+'_states_ledgers'];aa=data[r['name']+'_input'];radius=abs(v@(x[:3]+1j*x[3:6]));ax.plot(aa,radius,label=rate_label(r['rate']))
    for f in d['folds']:ax.axvline(f['a'],color='grey',ls=':',lw=1)
    ax.set(xlabel='Prescribed input amplitude $a$',ylabel='Highest-mode radius $R$',title='Continuous triangular cycles without holds');ax.grid(alpha=.2);ax.legend(ncol=2)
    fig.savefig(out/'paper_cycles.pdf');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(7.2,3.6),layout='constrained');rr=[r['rate'] for r in rows]
    axs[0].semilogx(rr,[abs(r['oriented_geometric_area']) for r in rows],'o-',label='Sampled cycle');axs[0].axhline(post['quasistatic_geometric_area'],ls='--',color='k',label='Stationary limit');axs[0].set(xlabel=r'Ramp rate $\nu$',ylabel='Geometric area',title='Geometric hysteresis');axs[0].legend();axs[0].grid(alpha=.2)
    axs[1].semilogx(rr,[r['rate_times_work'] for r in rows],'o-',label=r'Actual $\nu W$');axs[1].axhline(rows[0]['adiabatic_work_coefficient'],ls='--',color='k',label='Source-derived limit');axs[1].set(xlabel=r'Ramp rate $\nu$',ylabel='Rate-scaled supplied work',title='Rate-scaled maintenance work');axs[1].ticklabel_format(axis='y',style='plain',useOffset=False);axs[1].legend();axs[1].grid(alpha=.2)
    fig.savefig(out/'paper_area_work.pdf');plt.close(fig)
    binding={'inputs':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['specification.json','results/calculations_checked.json','results/REPORTING_CORRECTION.json','results/trajectories.npz','results/post_analysis.json','results/independent_modal.json','results/local_checks.json']},'table_fragments':[p.name for p in sorted(out.glob('paper_*.tex'))],'figures':['paper_delay.pdf','paper_cycles.pdf','paper_area_work.pdf'],'scope':'All publication assets generated from this run; original raw data and criteria unchanged. Figure sampling is display only, not event detection.'}
    (out/'PAPER_ASSETS.json').write_text(json.dumps(binding,indent=2));print('Nine publication tables and three figures generated from own-run outputs',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);generate(ap.parse_args().base)
