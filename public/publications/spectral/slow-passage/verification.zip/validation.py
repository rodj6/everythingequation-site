"""Definitions/counts exact; numeric diagnostics checked against scientific ceilings."""
from pathlib import Path
import json,math,csv
import numpy as np
def acceptance(actual,reference,sp):
    assert len(actual['checks'])==113==len(reference['checks'])
    for a,r in zip(actual['checks'],reference['checks']):
        assert a['name']==r['name'] and a['relation']==r['relation'] and a['threshold']==r['threshold']
        v=a['value'];t=a['threshold'];passed=math.isfinite(v) and {'lt':v<t,'gt':v>t,'eq':v==t}[a['relation']]
        assert passed==a['passed']==r['passed'],a
    assert actual['all_checks_pass']==all(c['passed'] for c in actual['checks'])
    assert actual['failures']==[c for c in actual['checks'] if not c['passed']]
    def walk(a,r,key=''):
        if key in {'checks','failures'}:return
        if isinstance(r,dict):
            assert a.keys()==r.keys()
            for k in r:walk(a[k],r[k],k)
        elif isinstance(r,list):
            assert len(a)==len(r)
            for aa,rr in zip(a,r):walk(aa,rr,key)
        elif key in {'steps','function_calls'}:assert isinstance(a,int) and a>0
        elif isinstance(r,(str,int,bool)) or r is None:assert type(a)==type(r) and a==r,(key,a,r)
        elif key=='scaled_ledger':assert math.isfinite(a) and 0<=a<sp['criteria']['scaled_ledger_max']
        elif key=='tight_input_difference':assert 0<=a<sp['criteria']['event_convergence_max']
        elif key=='tight_endpoint_difference':assert 0<=a<sp['criteria']['state_convergence_max']
        elif key=='normalization_error':assert 0<=a<sp['criteria']['fold_normalization_max']
        elif key=='kernel_residual':assert 0<=a<sp['criteria']['fold_kernel_max']
        elif key=='event_residual':assert 0<=a<1e-9
        elif key in {'physical_ledger_abs','tilted_ledger_abs','whole_physical_ledger_abs'}:assert math.isfinite(a) and 0<=a # Roundoff values are not required to match: own-array balances enforce the frozen scaled criterion.
        elif key=='transverse_event_difference':assert 0<=a<sp['criteria']['preparation_event_max']
        else:assert math.isclose(a,r,rel_tol=sp['criteria']['replay_rtol'],abs_tol=sp['criteria']['replay_atol']),(key,a,r)
    walk(actual,reference)
    for f in actual['folds']:
        assert f['zero_count']==1 and f['stable_count']==7 and f['stable_gap']>sp['criteria']['transverse_linear_gap_min']
    return 113
def own_arrays(base):
    import sys
    sys.path.insert(0,str(Path(base)/'code'))
    from model import energy,tilt
    base=Path(base);d=json.loads((base/'results/calculations_checked.json').read_text());sp=json.loads((base/'specification.json').read_text())
    data=np.load(base/'results/trajectories.npz');assert len(data.files)==24
    maximum=0.
    for row in d['cycles']:
        x=data[row['name']+'_states_ledgers'];a=data[row['name']+'_input'];t=data[row['name']+'_times'];assert x.shape==(12,2*sp['samples_per_leg']-1) and len(a)==len(t)==x.shape[1]
        assert np.all(np.isfinite(x)) and np.all(np.diff(t)>0)
        p=dict(sp['parameters'])
        if row['name']=='unique_control':p['mu']=sp['unique_mu']
        F=np.array([energy(y,p) for y in x.T]);V=np.array([tilt(y,aa,p) for y,aa in zip(x.T,a)]);scale=1+abs(x[8])+abs(x[9]);err=max(np.max(abs(F-F[0]+x[8]-x[9])/scale),np.max(abs(V-V[0]+x[10]+x[11])/scale))
        assert err<sp['criteria']['scaled_ledger_max'];maximum=max(maximum,float(err))
    correction=json.loads((base/'results/REPORTING_CORRECTION.json').read_text());import hashlib
    assert correction['raw_sha256']==hashlib.sha256((base/'results/calculations.json').read_bytes()).hexdigest()
    assert len(correction['repairs'])==4
    for row in d['finite_initialization']:
        for e in row['events']:assert abs(e['Riccati_error']-(e['delay']-e['prediction']['finite_threshold_Riccati_delay']))<1e-14
    return {'arrays':len(data.files),'reconstructed_whole_cycle_scaled_ledger_max':maximum,'reporting_residuals_consistent':True}
def tables(base):
    base=Path(base);d=json.loads((base/'assets/table_data.json').read_text())
    for name,table in d.items():
        with (base/'assets'/(name+'.csv')).open(newline='',encoding='utf-8') as f:rows=list(csv.reader(f))
        assert rows[0]==table['columns'] and len(rows)==len(table['rows'])+1
        for tokens,values in zip(rows[1:],table['rows']):
            assert len(tokens)==len(values)
            for token,value in zip(tokens,values):
                if isinstance(value,str):assert token==value
                else:assert math.isclose(float(token),value,rel_tol=4e-15,abs_tol=4*math.ulp(value))
