"""Focused acceptance/rejection tests for the portable verifier."""
from pathlib import Path
import copy,json
from validation import accept,check_tables,table_check,skeleton,PAT
def run():
    base=Path(__file__).resolve().parent;contract=json.loads((base/'verification_contract.json').read_text())
    data=json.loads((base/'assets/tables/data.json').read_text());d=json.loads((base/'results/calculations.json').read_text())
    count=0
    def reject(fun):
        nonlocal count
        try:fun()
        except (AssertionError,ValueError):count+=1;return
        raise AssertionError('Invalid mutation was accepted')
    for name,cells in data.items():
        text=(base/'assets/tables'/(name+'.tex')).read_text();sk=contract['table_skeletons'][name]
        table_check(text.replace('\n','\r\n'),cells,sk);count+=1
        reject(lambda:table_check(text.replace('\\caption{','\\caption{CHANGED '),cells,sk))
        reject(lambda:table_check(PAT.sub(lambda m:r'\checknum{99}',text,count=1),cells,sk))
    changed=copy.deepcopy(d);changed['checks'][1]['value']=5e-10;accept(changed,d);count+=1
    changed=copy.deepcopy(d);changed['checks'][1]['threshold']=1e-8;reject(lambda:accept(changed,d))
    changed=copy.deepcopy(d);changed['checks'][1]['value']=2e-9;reject(lambda:accept(changed,d))
    changed=copy.deepcopy(d);changed['cases']['one_port']['equilibrium'][0]+=.01;reject(lambda:accept(changed,d))
    print(json.dumps({'portable_checker_regressions':'PASS','checks':count}))
if __name__=='__main__':run()
