"""Run from a clean extracted package. Saved references are never overwritten."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,platform,tempfile
import numpy as np
import scipy
from validation import accept,check_tables,digest

def run(out=None):
    base=Path(__file__).resolve().parent
    manifest=json.loads((base/'MANIFEST.json').read_text())
    for entry in manifest['files']:assert digest(base/entry['path'])==entry['sha256'],entry['path']
    frozen=json.loads((base/'verification_contract.json').read_text())
    for name,value in frozen['specifications'].items():assert json.loads((base/name).read_text())==value,name
    # Original freeze records are preserved. Proof-note hashes identify private
    # research ancestors; proofs needed here are in the self-contained paper.
    omitted=[]
    for name in ['FROZEN.json','REFINEMENT_FROZEN.json']:
        for path,expected in json.loads((base/name).read_text())['files'].items():
            if (base/path).exists():assert digest(base/path)==expected,path
            else:omitted.append(path)
    assert sorted(omitted)==['DERIVATIONS.txt','REFINEMENT_AND_EXACT_BOUND.txt']
    check_tables(base/'assets/tables',frozen['table_skeletons'])
    reference=json.loads((base/'results/calculations.json').read_text());accept(reference,reference)
    initial=json.loads((base/'results_initial/calculations.json').read_text())
    failed=[c['name'] for c in initial['checks'] if not c['pass']]
    assert failed==['uniform/no_contrast'] and not initial['all_frozen_conditions_pass']
    out=Path(out).resolve() if out else Path(tempfile.mkdtemp(prefix='driven_verification_'))
    assert not out.exists() or not any(out.iterdir()),'Use a new empty output directory'
    out.mkdir(parents=True,exist_ok=True);shutil.copytree(base/'code',out/'code')
    for name in frozen['specifications']:shutil.copy2(base/name,out/name)
    for name in ['calculate.py','scalar_check.py','make_assets.py']:
        result=subprocess.run([sys.executable,str(out/'code'/name),'--base',str(out)],capture_output=True,text=True)
        (out/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
        if result.returncode:raise RuntimeError(name+' failed; see its output log')
        print(name+': PASS',flush=True)
    actual=json.loads((out/'results/calculations.json').read_text());n=accept(actual,reference)
    with np.load(base/'results/trajectories.npz') as ref,np.load(out/'results/trajectories.npz') as new:
        assert set(ref.files)==set(new.files) and len(ref.files)==13
        for name in ref.files:
            assert ref[name].shape==new[name].shape
            np.testing.assert_allclose(new[name],ref[name],rtol=2e-8,atol=2e-10,err_msg=name)
        arrays=len(ref.files)
    check_tables(out/'assets/tables',frozen['table_skeletons'])
    scalar=json.loads((out/'results/scalar_check.json').read_text());assert scalar['all_checks_pass'] is True
    receipt={'status':'PASS','frozen_conditions':n,'trajectory_arrays':arrays,'scalar_check':True,'retained_initial_failure':failed,'reference_and_own_run_tables':'PASS','python':platform.python_version(),'platform':platform.system(),'numpy':np.__version__,'scipy':scipy.__version__,'scope':'Clean extracted execution with installed dependencies; no fresh install, interval certification or physical validation.'}
    (out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);run(p.parse_args().output)
