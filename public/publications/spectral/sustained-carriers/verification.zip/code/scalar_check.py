"""Post-review independent high-precision scalar check; not a new holdout."""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,json
def run(base):
    base=Path(base);out=base/'results';out.mkdir(exist_ok=True)
    with localcontext() as ctx:
        ctx.prec=60;D=Decimal;mu=D(2)/5;kappa=D(1);load_squared=D(5)/9
        def fun(s):return 4*kappa*s*s.exp()*(mu+(-s).exp())**2-load_squared
        lo=D(0);hi=D(1);assert fun(lo)<0<fun(hi)
        for _ in range(200):
            mid=(lo+hi)/2
            if fun(mid)>0:hi=mid
            else:lo=mid
        s=(lo+hi)/2;gain=(mu+1)/(mu+(-s).exp());res=abs(fun(s));assert res<D('1e-50')
        ref=json.loads((out/'calculations.json').read_text())['contrast_gain']
        difference=abs(float(gain)-ref);assert difference<2e-12
        result={'precision_digits':60,'bisections':200,'s':str(s),'gain':str(gain),
            'scalar_residual':str(res),'difference_from_retained_gain':difference,'all_checks_pass':True,
            'scope':'Independent Decimal bisection, without Lambert-W or SciPy root evaluation. Rounded arithmetic, not a directed interval certificate. Post-result verification.'}
    (out/'scalar_check.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(parser.parse_args().base)
