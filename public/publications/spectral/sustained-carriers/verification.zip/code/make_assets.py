"""Generate every paper table and figure directly from a specified run."""
from pathlib import Path
import argparse,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def generate(base):
    base=Path(base);d=json.loads((base/'results/calculations.json').read_text());a=np.load(base/'results/trajectories.npz')
    out=base/'assets';tables=out/'tables';tables.mkdir(parents=True,exist_ok=True);contract={}
    def table(name,caption,headers,rows,formats):
        cells=[];lines=[r'\begin{table}[tb]',r'\centering\small',r'\caption{'+caption+'}',r'\label{tab:'+name+'}',r'\begin{tabular}{l'+'r'*(len(headers)-1)+'}',r'\toprule',' & '.join(headers)+r' \\',r'\midrule']
        for label,values in rows:
            printed=[]
            for v,f in zip(values,formats):
                s=format(v,f);printed.append(r'\checknum{'+s+'}');cells.append({'value':float(v),'format':f,'printed':s})
            lines.append(label+' & '+' & '.join(printed)+r' \\')
        lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
        (tables/(name+'.tex')).write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');contract[name]=cells
    names=['uniform','contrast','one_port'];labels=['Uniform','Contrast','One port'];cs=d['cases']
    table('states','Stationary matched controls. Contrast norms refer to the complete amplitude with its mean removed; $\\Delta w=|w_1-w_2|$.',
          ['Input','Fixed contrast','Adaptive contrast','$\\|m_*\\|$','$\\Delta w$','$P_*$'],
          [(label,[cs[k]['fixed_observables']['contrast_norm'],cs[k]['adaptive_observables']['contrast_norm'],cs[k]['adaptive_observables']['memory_norm'],cs[k]['adaptive_observables']['weight_heterogeneity'],cs[k]['steady_power']]) for k,label in zip(names,labels)],['.7f']*5)
    table('stability','Complete equilibrium stability. The last column evaluates the conservative parameter bound, rather than fitting the numerical eigenvalues.',
          ['Input','$\\lambda_{\\min}(\\mathcal H)$','$\\max\\Re\\lambda(A_{\\rm full})$','$\\sigma h_0$'],
          [(label,[cs[k]['full_hessian_minimum'],cs[k]['jacobian_spectral_abscissa'],cs[k]['analytic_parameter_rate_bound']]) for k,label in zip(names,labels)],['.7f','.7f','.8f'])
    metrics=[('Equilibrium residual','equilibrium_residual',1e-9),('Direct/reduced root difference','independent_equilibrium_difference',1e-8),('Terminal equilibrium error','terminal_equilibrium_difference',2e-7),('Coarse/tight trajectory difference','tolerance_convergence_max',2e-7),('Physical energy ledger','energy_ledger_max',2e-7),('Tilted loss ledger','tilted_ledger_max',2e-7),('Collective-mode formula','mean_formula_max',1e-9)]
    rows=[(label,[max(cs[k][key] for k in names),threshold]) for label,key,threshold in metrics]
    rows += [('Independent real-gradient RK4',[d['independent_RK4_endpoint_max'],2e-7]),('Second initial-state terminal error',[d['second_initial_terminal_difference'],2e-7])]
    table('validation','Maximum diagnostics over the three preparations, except the two separately identified one-port checks. Every upper criterion retains its original strict threshold.', ['Diagnostic','Observed','Criterion: less than'],rows,['.3e','.1e'])
    rr=d['response'];hh=d['histories']
    rows=[('Full/clamped impulse gap',[rr['full_vs_clamped_impulse_difference']]),('Full/clamped static transfer gap',[rr['static_transfer_difference']]),('Full/clamped frequency transfer gap',[rr['frequency_transfer_difference']]),('Full Jacobian finite difference',[rr['full_jacobian_finite_difference_error']]),('Static probe finite difference',[rr['full_static_probe_error']])]
    for k,label in [('contrast','Contrast'),('one_port','One port')]:
        for field,descr in [('factorization_error','factorization gap'),('interaction_picture_error','interaction error'),('affine_column_error','affine error'),('commutator_integral_quadrature','commutator quadrature')]: rows.append((label+' '+descr,[hh[k][field]]))
    table('response','Response and conditional-history diagnostics. Transfer gaps use the operator norm; the impulse gap uses the specified first real-coordinate probe. Commutator quadrature is not a formal enclosure.', ['Quantity','Value'],rows,['.6e'])
    (tables/'data.json').write_text(json.dumps(contract,indent=2),encoding='utf-8',newline='\n')
    plt.rcParams.update({'font.size':11,'axes.titlesize':12,'axes.labelsize':11,'legend.fontsize':8.5,'pdf.fonttype':42})
    fig,axs=plt.subplots(2,2,figsize=(9,6.7),layout='constrained');t=a['times'];colors=['#377eb8','#e87d22','#3b986a']
    for k,label,col in zip(names,labels,colors):
        x=a[k+'_state'];z=x[:3]+1j*x[3:6];fixed=a[k+'_fixed'];contrast=np.linalg.norm(z-z.mean(axis=0),axis=0);fc=np.linalg.norm(fixed-fixed.mean(axis=0),axis=0)
        axs[0,0].plot(t,contrast,color=col,label=label+' adaptive');axs[0,0].plot(t,fc,'--',color=col,label=label+' fixed')
        axs[0,1].plot(t,x[6],color=col,label=label+' edge 1');axs[0,1].plot(t,x[7],'--',color=col,label=label+' edge 2')
        axs[1,0].plot(t,abs(np.exp(x[6])-np.exp(x[7])),color=col,label=label)
        b=np.array([[1,-1,0],[0,1,-1.]]);force=.4*z+b.T@(np.exp(x[6:8])*(b@z));power=np.real(np.sum(force.conj()*np.array(cs[k]['drive'])[:,None],axis=0))
        axs[1,1].plot(t,power,color=col,label=label)
    for ax,title,ylabel in zip(axs.flat,['Contrast amplitude','Persistent memory','Edge heterogeneity','Supplied power'],['Contrast norm','Memory coordinate','$|w_1-w_2|$','$P_{in}$']):
        ax.set(xlim=(0,30),xlabel='Time',ylabel=ylabel,title=title);ax.grid(alpha=.2);ax.legend(loc='best',ncol=1)
    fig.savefig(out/'organization.pdf');fig.savefig(out/'organization.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(9,4),layout='constrained')
    for i,(k,label,col) in enumerate(zip(names,labels,colors)):
        ev=np.array(cs[k]['jacobian_eigenvalues']);axs[0].scatter(ev[:,0],ev[:,1],marker=['o','x','+'][i],s=60,color=col,label=label,alpha=.8)
    axs[0].axvline(0,color='gray',lw=1);axs[0].set(xlabel='Real part',ylabel='Imaginary part',title='Complete Jacobian spectrum');axs[0].legend();axs[0].grid(alpha=.2)
    x=np.arange(2);width=.35
    for j,(field,label,col) in enumerate([('factorization_error','Factorization','#b4494b'),('interaction_picture_error','Interaction picture','#377eb8')]):
        axs[1].bar(x+(j-.5)*width,[hh[k][field] for k in ['contrast','one_port']],width,label=label,color=col)
    axs[1].set(xticks=x,xticklabels=['Contrast','One port'],yscale='log',ylabel='Operator-norm error',title='Conditional history at time 4',ylim=(1e-16,1e-2));axs[1].legend();axs[1].grid(axis='y',alpha=.2)
    fig.savefig(out/'response.pdf');fig.savefig(out/'response.png',dpi=160);plt.close(fig)
    return contract
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);generate(p.parse_args().base)
