"""Frozen driven-source calculations; all units normalized, all inputs prescribed."""
from pathlib import Path
import argparse,json,math
from fractions import Fraction
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm,norm
from scipy.optimize import root,brentq
from scipy.special import lambertw

def run(base):
    base=Path(base);spec=json.loads((base/'specification.json').read_text());p=spec['parameters'];criteria=spec['criteria']
    out=base/'results';out.mkdir(exist_ok=True)
    b=np.array(p['incidence'],float);edge=np.einsum('ei,ej->eij',b,b);n=3
    mu,kappa,g,a,eta=[p[k] for k in ['mu','kappa','gamma','alpha','eta']];c=g+1j*a
    L=edge.sum(axis=0);K0=mu*np.eye(n)+L;J=np.block([[np.zeros((n,n)),-np.eye(n)],[np.eye(n),np.zeros((n,n))]])
    G=g*np.eye(2*n)+a*J;D=np.block([[G,np.zeros((6,2))],[np.zeros((2,6)),eta*np.eye(2)]])
    S=np.diag([g]*6+[eta]*2);phase=abs(c)/c
    drives={'uniform':np.ones(3)/np.sqrt(3),'contrast':np.array([1.,0.,-1.])/np.sqrt(2),'one_port':np.array([1.,0.,0.])}
    drives={k:spec['drive_norm']*f for k,f in drives.items()}
    def parts(x):
        z=x[:3]+1j*x[3:6];m=x[6:8];w=np.exp(m);K=mu*np.eye(3)+np.einsum('e,eij->ij',w,edge)
        fm=kappa*m+.5*w*abs(b@z)**2
        return z,m,w,K,fm
    def energy(x):
        z,m,w,K,fm=parts(x);return float(.5*np.vdot(z,K@z).real+.5*kappa*m@m)
    def hessian(x):
        z,m,w,K,fm=parts(x);KR=np.kron(np.eye(2),K)
        B=np.column_stack([w[e]*np.r_[edge[e]@z.real,edge[e]@z.imag] for e in range(2)])
        Hm=np.diag(kappa+.5*w*abs(b@z)**2)
        H=np.block([[KR,B],[B.T,Hm]])
        return H,KR,B,Hm
    def rhs(f,ledger=True):
        ell=f/c
        def fun(t,x):
            z,m,w,K,fm=parts(x);force=K@z;dz=-c*force+f;dm=-eta*fm
            result=np.r_[dz.real,dz.imag,dm]
            if ledger:
                loss=g*np.vdot(force,force).real+eta*(fm@fm);power=np.vdot(force,f).real
                tilt=g*np.vdot(force-ell,force-ell).real+eta*(fm@fm)
                result=np.r_[result,loss,power,tilt]
            return result
        return fun
    def reduced_equilibrium(f):
        target=f/abs(c)
        def fun(u):
            s=lambertw((b@u)**2/(2*kappa)).real;w=np.exp(-s)
            return (mu*np.eye(3)+np.einsum('e,eij->ij',w,edge))@u-target
        def jac(u):
            s=lambertw((b@u)**2/(2*kappa)).real;coef=np.exp(-s)*(1-s)/(1+s)
            return mu*np.eye(3)+np.einsum('e,eij->ij',coef,edge)
        sol=root(fun,np.linalg.solve(K0,target),jac=jac,tol=spec['root_tolerance'])
        assert norm(fun(sol.x))<criteria['equilibrium_residual_max']
        z=phase*sol.x;m=-lambertw((b@sol.x)**2/(2*kappa)).real
        return np.r_[z.real,z.imag,m]
    def full_equilibrium(f):
        ell=f/c
        def fun(x):
            z,m,w,K,fm=parts(x);r=K@z-ell;return np.r_[r.real,r.imag,fm]
        startz=np.linalg.solve(K0,ell)
        sol=root(fun,np.r_[startz.real,startz.imag,0.,0.],jac=lambda x:hessian(x)[0],tol=spec['root_tolerance'])
        assert norm(fun(sol.x))<criteria['equilibrium_residual_max'];return sol.x
    def observable(x):
        z,m,w,K,fm=parts(x);contrast=z-np.mean(z)
        return {'contrast_norm':float(norm(contrast)),'edge_contrast_norm':float(norm(b@z)),
            'memory_norm':float(norm(m)),'weight_heterogeneity':float(abs(w[0]-w[1])),
            'mean_real':float(np.mean(z).real),'mean_imag':float(np.mean(z).imag),'stored_energy':energy(x)}
    def integrate(f,initial,rtol,atol):
        sol=solve_ivp(rhs(f),[0,spec['T']],np.r_[initial,0.,0.,0.],method='DOP853',rtol=rtol,atol=atol,dense_output=True)
        assert sol.success;return sol
    times=np.linspace(0,spec['T'],spec['samples']);initial=np.r_[spec['initial_z_real'],spec['initial_z_imag'],spec['initial_memory']]
    chi=(2-math.sqrt(3))*math.exp(-math.sqrt(3));delta=mu-chi*norm(L,2)
    checks=[];cases={};arrays={'times':times};solutions={};equilibria={}
    def check(name,value,relation,threshold):
        passed={'lt':value<threshold,'gt':value>threshold,'le':value<=threshold}[relation]
        checks.append({'name':name,'value':float(value),'relation':relation,'threshold':float(threshold),'pass':bool(passed)})
    check('strong_convexity_margin',delta,'gt',0.)
    for name,f in drives.items():
        (out/'progress.json').write_text(json.dumps({'stage':name,'status':'running'}))
        eq=reduced_equilibrium(f);independent=full_equilibrium(f);equilibria[name]=eq
        sol=integrate(f,initial,spec['rtol'],spec['atol']);solutions[name]=sol
        tight=integrate(f,initial,spec['tight_rtol'],spec['tight_atol']);x=sol.sol(times)
        energies=np.array([energy(row) for row in x.T]);z=x[:3]+1j*x[3:6];ell=f/c
        tilt=energies-np.real(np.sum(np.conj(ell[:,None])*z,axis=0))
        V0=energy(initial)-np.vdot(ell,initial[:3]+1j*initial[3:6]).real
        mean_expected=np.mean(f)/(c*mu)+(np.mean(initial[:3]+1j*initial[3:6])-np.mean(f)/(c*mu))*np.exp(-c*mu*times)
        fixedstar=np.linalg.solve(K0,ell)
        fixed=np.column_stack([fixedstar+expm(-c*K0*t)@(-fixedstar) for t in times])
        H,KR,B,Hm=hessian(eq);Jac=-D@H;Schur=KR-B@np.linalg.solve(Hm,B.T)
        theta0=norm(ell)*math.sqrt(sum(norm(v)**4 for v in b))/(kappa*mu)
        h0=min(delta,kappa)/(1+theta0)**2;rate=min(g,eta)*h0
        eig=np.linalg.eigvals(Jac);hmin=np.linalg.eigvalsh(H)[0]
        power=np.vdot(parts(eq)[3]@parts(eq)[0],f).real;power_expected=g*norm(f)**2/(g*g+a*a)
        row={'drive':f.tolist(),'equilibrium':eq.tolist(),'fixed_equilibrium_real':fixedstar.real.tolist(),'fixed_equilibrium_imag':fixedstar.imag.tolist(),
            'adaptive_observables':observable(eq),'fixed_observables':observable(np.r_[fixedstar.real,fixedstar.imag,0.,0.]),
            'equilibrium_residual':float(norm(rhs(f,False)(0,eq))),
            'independent_equilibrium_difference':float(norm(eq-independent)),
            'terminal_equilibrium_difference':float(norm(x[:8,-1]-eq)),
            'tolerance_convergence_max':float(np.max(abs(x-tight.sol(times)))),
            'energy_ledger_max':float(np.max(abs(energies-energy(initial)+x[8]-x[9]))),
            'tilted_ledger_max':float(np.max(abs(tilt-V0+x[10]))),
            'mean_formula_max':float(np.max(abs(np.mean(z,axis=0)-mean_expected))),
            'full_hessian_minimum':float(hmin),'schur_minimum':float(np.linalg.eigvalsh(Schur)[0]),
            'analytic_parameter_rate_bound':float(rate),'jacobian_spectral_abscissa':float(max(eig.real)),
            'jacobian_eigenvalues':[[float(v.real),float(v.imag)] for v in eig],
            'steady_power':float(power),'predicted_steady_power':float(power_expected)}
        for metric in ['equilibrium_residual','independent_equilibrium_difference','terminal_equilibrium_difference','tolerance_convergence_max','energy_ledger_max','tilted_ledger_max','mean_formula_max']:
            check(name+'/'+metric,row[metric],'lt',criteria[metric+'_max'] if metric+'_max' in criteria else criteria[metric])
        check(name+'/H_positive',hmin,'gt',0.)
        check(name+'/stable_eigenvalues',row['jacobian_spectral_abscissa'],'lt',criteria['jacobian_spectral_abscissa_max'])
        check(name+'/analytic_rate_eigenvalue',row['jacobian_spectral_abscissa']+rate,'le',criteria['analytic_rate_eigenvalue_slack'])
        check(name+'/power_formula',abs(power-power_expected),'lt',criteria['steady_power_formula_max'])
        U=expm(-c*parts(eq)[3]*spec['response_time']);DD=expm(-g*parts(eq)[3]*spec['response_time']);VV=expm(-1j*a*parts(eq)[3]*spec['response_time'])
        check(name+'/stationary_conditional_factorization',norm(U-DD@VV,2),'lt',criteria['conditional_factorization_max'])
        if name=='uniform':
            check('uniform/no_memory',np.max(abs(x[6:8])),'lt',criteria['uniform_memory_max'])
            check('uniform/no_contrast',np.max(abs(z-np.mean(z,axis=0))),'lt',criteria['uniform_contrast_max'])
        else:check(name+'/nonzero_memory',row['adaptive_observables']['memory_norm'],'gt',criteria['positive_memory_displacement_min'])
        arrays[name+'_state']=x;arrays[name+'_fixed']=fixed;arrays[name+'_energy']=energies;arrays[name+'_tilt']=tilt
        cases[name]=row
    contrast=cases['contrast'];gain=contrast['adaptive_observables']['contrast_norm']/contrast['fixed_observables']['contrast_norm']
    c_eq=equilibria['contrast'];s=-c_eq[6];pred_gain=(mu+1)/(mu+math.exp(-s));loadnorm=norm(drives['contrast']/c)
    scalar_res=abs(4*kappa*s*math.exp(s)*(mu+math.exp(-s))**2-loadnorm**2)
    check('contrast/gain',gain-1,'gt',criteria['contrast_gain_excess_min'])
    check('contrast/scalar_formula',scalar_res,'lt',criteria['contrast_scalar_formula_max'])
    check('contrast/gain_formula',abs(gain-pred_gain),'lt',criteria['contrast_scalar_formula_max'])
    # Independent full-real edge-gradient RK4, with input and both energy ledgers.
    f=drives['one_port'];fr=np.r_[f,np.zeros(3)];ellr=np.linalg.solve(G,fr)
    def independent_rhs(y):
        q=y[:6];m=y[6:8];force=mu*q.copy();gm=kappa*m.copy()
        for e in range(2):
            w=math.exp(m[e]);dr=float(b[e]@q[:3]);di=float(b[e]@q[3:])
            force[:3]+=w*dr*b[e];force[3:]+=w*di*b[e];gm[e]+=.5*w*(dr*dr+di*di)
        dq=np.r_[-g*force[:3]+a*force[3:],-g*force[3:]-a*force[:3]]+fr
        return np.r_[dq,-eta*gm,g*(force@force)+eta*(gm@gm),force@fr,g*((force-ellr)@(force-ellr))+eta*(gm@gm)]
    y=np.r_[initial,0.,0.,0.];dt=spec['T']/spec['independent_RK4_steps']
    for _ in range(spec['independent_RK4_steps']):
        k1=independent_rhs(y);k2=independent_rhs(y+dt*k1/2);k3=independent_rhs(y+dt*k2/2);k4=independent_rhs(y+dt*k3);y+=dt*(k1+2*k2+2*k3+k4)/6
    rk_error=float(np.max(abs(y-solutions['one_port'].y[:,-1])));check('independent_RK4',rk_error,'lt',criteria['independent_RK4_endpoint_max'])
    other=np.r_[spec['second_initial_z_real'],spec['second_initial_z_imag'],spec['second_initial_memory']]
    alt=integrate(f,other,spec['tight_rtol'],spec['tight_atol']);second_error=float(norm(alt.y[:8,-1]-equilibria['one_port']))
    check('second_initial_convergence',second_error,'lt',criteria['second_initial_terminal_difference_max'])
    # Matched full/clamped small signals about the one-port equilibrium.
    eq=equilibria['one_port'];H,KR,B,Hm=hessian(eq);Jac=-D@H;v=np.eye(8)[:,0];tau=spec['response_time']
    gap=norm((expm(Jac*tau)@v)[:6]-expm(-G@KR*tau)@v[:6])
    check('full_vs_clamped',gap,'gt',criteria['full_vs_clamped_response_min'])
    eps=spec['response_epsilon'];Jfd=np.column_stack([(rhs(f,False)(0,eq+eps*np.eye(8)[:,j])-rhs(f,False)(0,eq-eps*np.eye(8)[:,j]))/(2*eps) for j in range(8)])
    jac_error=norm(Jfd-Jac,2);check('full_Jacobian_finite_difference',jac_error,'lt',criteria['jacobian_finite_difference_max'])
    Schur=KR-B@np.linalg.solve(Hm,B.T);static=np.linalg.solve(Schur,np.linalg.solve(G,np.eye(6)[:,0]))
    fplus=f.copy();fminus=f.copy();fplus[0]+=eps;fminus[0]-=eps
    finite=(reduced_equilibrium(fplus)[:6]-reduced_equilibrium(fminus)[:6])/(2*eps)
    static_error=norm(finite-static);check('full_static_finite_difference',static_error,'lt',criteria['static_probe_finite_difference_max'])
    frequency=1j*spec['response_frequency'];chi_clamp=np.linalg.inv(frequency*np.eye(6)+G@KR)
    chi_full=np.linalg.inv(frequency*np.eye(6)+G@KR-eta*G@B@np.linalg.solve(frequency*np.eye(2)+eta*Hm,B.T))
    response={'full_vs_clamped_impulse_difference':float(gap),'full_jacobian_finite_difference_error':float(jac_error),
        'full_static_probe_error':float(static_error),'frequency_transfer_difference':float(norm(chi_full-chi_clamp,2)),
        'static_transfer_difference':float(norm(np.linalg.solve(Schur,np.linalg.inv(G))-np.linalg.solve(KR,np.linalg.inv(G)),2)),
        'joint_alignment_commutator':float(norm(H@np.block([[J,np.zeros((6,2))],[np.zeros((2,8))]])-np.block([[J,np.zeros((6,2))],[np.zeros((2,8))]])@H,2))}
    histories={}
    for name in ['contrast','one_port']:
        sol=solutions[name];drive=drives[name]
        def prop(t,state):
            K=parts(sol.sol(t))[3];U,DD,V,RR=state[:36].reshape(4,3,3);aff=state[36:39]
            return np.r_[np.array([-c*K@U,-g*K@DD,-1j*a*K@V,-g*(V.conj().T@K@V)@RR]).ravel(),-c*K@aff+drive]
        initialprop=np.r_[np.tile(np.eye(3,dtype=complex).ravel(),4),np.zeros(3,dtype=complex)]
        pr=solve_ivp(prop,[0,spec['ordering_time']],initialprop,method='DOP853',rtol=spec['tight_rtol'],atol=spec['tight_atol']);assert pr.success
        U,DD,V,RR=pr.y[:36,-1].reshape(4,3,3);aff=pr.y[36:39,-1]
        grid=np.linspace(0,spec['ordering_time'],spec['ordering_samples']);ww=np.exp(sol.sol(grid)[6:8])
        kernel=np.sqrt(3)*abs(ww[0,:,None]*ww[1,None,:]-ww[1,:,None]*ww[0,None,:])
        integ=np.trapezoid([np.trapezoid(kernel[j,:j+1],grid[:j+1]) for j in range(len(grid))],grid)*g*a
        actual=parts(sol.sol(spec['ordering_time']))[0]
        histories[name]={'factorization_error':float(norm(U-DD@V,2)),'interaction_picture_error':float(norm(U-V@RR,2)),
            'affine_column_error':float(norm(aff-actual)),'omitted_affine_error':float(norm(actual)),
            'commutator_integral_quadrature':float(integ),'quadrature_is_formal_enclosure':False}
        check(name+'/interaction_picture',histories[name]['interaction_picture_error'],'lt',criteria['interaction_picture_max'])
        check(name+'/affine_column',histories[name]['affine_column_error'],'lt',criteria['affine_column_error_max'])
    check('symmetric_history_factorization',histories['contrast']['factorization_error'],'lt',criteria['symmetric_history_factorization_max'])
    check('one_port_history_nonfactorization',histories['one_port']['factorization_error'],'gt',criteria['one_port_history_factorization_min'])
    # Exact rational negative-curvature fixture and a rational sufficient margin.
    F=Fraction;negative=2*(F(2,5)-F(7,11));assert negative==F(-26,55)
    exp_lower=1+F(5,3)+F(5,3)**2/2+F(5,3)**3/6;assert exp_lower>4
    rational={'joint_hessian_negative_value':str(negative),'sqrt3_gt_5over3':3>F(25,9),
        'exp5over3_Taylor_lower':str(exp_lower),'chi_strict_upper':'1/12','delta_strict_lower':'3/20',
        'full_local_H_norm_rate_strict_lower':'9/7225','scope':'Analytic sufficient bounds at the frozen unit input and normalized parameters; not a matrix interval certificate'}
    result={'all_frozen_conditions_pass':all(x['pass'] for x in checks),'chi':chi,'strong_convexity_margin':float(delta),
        'cases':cases,'contrast_gain':float(gain),'predicted_contrast_gain':float(pred_gain),'contrast_scalar_residual':float(scalar_res),
        'independent_RK4_endpoint_max':rk_error,'second_initial_terminal_difference':second_error,
        'response':response,'histories':histories,'exact_fixtures':rational,'checks':checks,
        'evidence':'Exact derivations plus new synthetic computations; eigenvalues/quadrature floating; no experiment'}
    (out/'calculations.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez_compressed(out/'trajectories.npz',**arrays)
    (out/'progress.json').write_text(json.dumps({'stage':'complete','all_frozen_conditions_pass':result['all_frozen_conditions_pass']}))
    print(json.dumps(result,indent=2));assert result['all_frozen_conditions_pass'],'Some frozen tests failed; preserve outputs'

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);args=parser.parse_args();run(args.base)
