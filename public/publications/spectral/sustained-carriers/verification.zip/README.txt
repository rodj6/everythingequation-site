Sustained Adaptive Spectral States: public verification

Paper: Sustained Adaptive Spectral States: Global Attraction, Nonlinear Gain,
and Linked Coherent-Dissipative Response
Author: Jeremy Rodgers
Reserved DOI: 10.5281/zenodo.23927855
DOI link: https://doi.org/10.5281/zenodo.23927855
Author website: https://everythingequation.com
The identifier is reserved; this package does not assert publication or deposit.

Scope
This package verifies the finite constant-input equations, numerical predictions
and figures of the accompanying self-contained paper. It contains no manuscript
LaTeX or bibliography. assets/tables/*.tex are explicitly permitted small generated
verification fragments, not manuscript source. The paper supplies all proofs.

Run
Use Python 3.12 or a compatible Python 3 version, with NumPy, SciPy and Matplotlib.
The retained author environment is specified in requirements.txt. In a new
environment, optional installation is: python -m pip install -r requirements.txt
No fresh installation is claimed by the author-side checks.
Extract the ZIP into a new directory, open a terminal there, then run:
  python regression_checks.py
  python run_all.py --output ../my-new-empty-verification-run
Omitting --output selects a fresh temporary directory. The calculation may take
several minutes. Logs, regenerated outputs/assets and REPLAY_RECEIPT.json are put
in that directory; saved package references are never overwritten. Do not run
calculate.py directly against the package root if preserving reference bytes.

Scientific inputs and controls
specification.json is the original scientific contract, with exact drive patterns,
parameters, initial states, time grid, methods, probe definitions and thresholds.
refinement_specification.json records the post-failure source-derived step cap.
FROZEN.json and REFINEMENT_FROZEN.json are original unchanged ancestor records.
The two named proof notes are not bundled: their hashes are provenance pointers
to the private research record, not missing executable inputs. The paper presents
their mathematical content. Bundled frozen specifications/calculation hashes are
checked directly; verification_contract.json also freezes parsed specifications,
table structure and provenance. MANIFEST.json gives all package file hashes.

Model and main equations
K(m)=mu I+sum exp(m_e)b_e b_e^T; F=z* K z/2+kappa |m|^2/2.
z'=-(gamma+i alpha)Kz+f; m'_e=-eta(kappa m_e+exp(m_e)|b_e^Tz|^2/2).
f is a constant externally powered two-quadrature amplitude-rate flow;
P_in=Re[(Kz)*f]. Physical balance: F'=-gamma||Kz||^2-eta||F_m||^2+P_in.
ell=f/(gamma+i alpha), V=F-Re(ell*z),
V'=-gamma||Kz-ell||^2-eta||F_m||^2.
Stationary m_e=-W0(|b_e^Tz|^2/(2 kappa)). The sufficient attraction condition is
mu > (2-sqrt(3))*exp(-sqrt(3))*||L||, L=sum b_e b_e^T.
For the path contrast preparation, a^2/|c|^2=4 kappa s exp(s)(mu+exp(-s))^2
and gain=(mu+1)/(mu+exp(-s)). P*=gamma||f||^2/(gamma^2+alpha^2).
Full feedback transfer retains the memory Schur term; see the paper's response
section for matrices, inverse-existence conditions and measurement requirements.

Files and traceability
CLAIM_MAP.json connects paper claims to proofs, executable calculations and arrays.
results/ contains the retained refined JSON, 13-array NPZ and Decimal scalar check.
results_initial/ and code/calculate_initial.py retain the initial failed control.
assets/ contains figures and small table fragments generated solely by
code/make_assets.py. assets/tables/data.json records the run values and formats.
code/calculate.py is unchanged from the frozen research refinement. It computes
all 55 original conditions and preserves eight source coordinates plus three
integrated energy ledgers. Frozen criteria are independently reevaluated by the
runner; exact labels, relations and thresholds cannot drift.

Portable checking
Thirteen arrays and stable physical quantities use rtol=2e-8, atol=2e-10, inherited
from the prior portable verification approach. Eigenvalues are compared as a
multiset, retaining all eight values. Tiny residuals and error diagnostics are
checked against original scientific inequalities rather than identical digits.
Text CRLF/LF differences are normalized. Each table cell is checked against its
own run's recorded value within half its final printed unit plus four ULPs;
captions, labels, headers, row labels and ordering remain exact. Saved reference
tables and regenerated tables are checked separately. Regression tests accept a
legitimate residual variation and CRLF, and reject changed labels, values,
thresholds, failed criteria and physical states. No broad tolerance relaxation
was used to hide the initial failure.

Failure and evidence classes
Initial uniform sampled contrast 7.352543968441593e-8 failed the 1e-9 criterion.
The exact uniform invariant identifies numerical error. The source-derived cap
1/[8|c|(mu+exp(M0)||L||)], with M0=0.1, was frozen after that failure and before
refined outcomes. All physical inputs and original thresholds remain unchanged.
This is post-result numerical refinement. Independent real-gradient RK4, direct
versus reduced roots, and Decimal bisection are separate formulations, not unseen
empirical holdouts. Commutator quadrature and numerical eigenvalues are not
interval certificates. No physical validation, fresh installation or author-run
Linux replication is claimed. A user-reported Linux/SciPy 1.17.0 review reproduced
55 checks, 13 arrays, the separate scalar check and 16 checker regressions, but
its logs are unavailable here; it is not an archived author-side replay.
No random seeds or empirical datasets are needed.
