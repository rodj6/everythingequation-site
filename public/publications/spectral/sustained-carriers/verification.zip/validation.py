"""Portable scientific criteria and own-run table checks; no roundoff digit oracle."""
import json,math,re,hashlib
from pathlib import Path
import numpy as np
PAT=re.compile(r'\\checknum\{([^}]+)\}')
def normtext(s):return s.replace('\r\n','\n').replace('\r','\n')
def skeleton(s):return PAT.sub(r'\\checknum{<NUMBER>}',normtext(s))
def table_check(text,cells,expected_skeleton):
    assert skeleton(text)==expected_skeleton,'Table labels, caption, structure or column ordering changed'
    printed=PAT.findall(normtext(text));assert len(printed)==len(cells)
    for token,cell in zip(printed,cells):
        value=cell['value'];fmt=cell['format'];number=float(token);assert math.isfinite(number)
        # Half one unit of the requested last decimal place plus arithmetic slack.
        digits=int(fmt[1:-1]);exponent=int(token.lower().split('e')[1]) if 'e' in token.lower() else 0
        unit=10.**(exponent-digits)
        assert abs(number-value)<=.5*unit+4*math.ulp(value),(token,value,fmt)
def check_tables(folder,contract):
    data=json.loads((folder/'data.json').read_text());assert set(data)==set(contract)
    for name,cells in data.items():table_check((folder/(name+'.tex')).read_text(),cells,contract[name])
def accept(d,reference):
    checks=d['checks'];refs=reference['checks'];assert len(checks)==len(refs)==55
    for actual,ref in zip(checks,refs):
        for key in ['name','relation','threshold']:assert actual[key]==ref[key],(key,actual,ref)
        v=actual['value'];t=actual['threshold'];assert math.isfinite(v)
        passed={'lt':v<t,'gt':v>t,'le':v<=t}[actual['relation']]
        assert actual['pass'] is True and passed,actual
    assert d['all_frozen_conditions_pass'] is True
    assert d['exact_fixtures']==reference['exact_fixtures']
    for k in reference['cases']:
        r=reference['cases'][k];a=d['cases'][k]
        assert a['drive']==r['drive']
        for field in ['equilibrium','fixed_equilibrium_real','fixed_equilibrium_imag','adaptive_observables','fixed_observables','full_hessian_minimum','schur_minimum','analytic_parameter_rate_bound','jacobian_spectral_abscissa','steady_power','predicted_steady_power']:
            def compare(x,y):
                if isinstance(x,dict):
                    assert x.keys()==y.keys()
                    for key in x:compare(x[key],y[key])
                else:np.testing.assert_allclose(x,y,rtol=2e-8,atol=2e-10)
            compare(r[field],a[field])
        # Eigenvalues are a multiset; a solver may reorder them.
        x=np.array(a['jacobian_eigenvalues']);y=np.array(r['jacobian_eigenvalues'])
        from scipy.optimize import linear_sum_assignment
        dist=np.linalg.norm(x[:,None]-y[None,:],axis=2);ii,jj=linear_sum_assignment(dist)
        assert len(ii)==8 and np.max(dist[ii,jj])<2e-8
    for key in ['chi','source_max_step','strong_convexity_margin','contrast_gain','predicted_contrast_gain']:
        assert math.isclose(d[key],reference[key],rel_tol=2e-8,abs_tol=2e-10),key
    for key in ['full_vs_clamped_impulse_difference','frequency_transfer_difference','static_transfer_difference','joint_alignment_commutator']:
        assert math.isclose(d['response'][key],reference['response'][key],rel_tol=2e-8,abs_tol=2e-10),key
    for name in ['contrast','one_port']:
        a=d['histories'][name];r=reference['histories'][name];assert a['quadrature_is_formal_enclosure'] is False
        for field in ['omitted_affine_error','commutator_integral_quadrature']:
            assert math.isclose(a[field],r[field],rel_tol=2e-8,abs_tol=2e-10),(name,field)
    # Diagnostic errors are judged by their unchanged criteria above, rather than
    # demanding equality of machine-dependent residual digits.
    return len(checks)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
