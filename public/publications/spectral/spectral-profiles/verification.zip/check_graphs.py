"""Separate direct graph reconstruction and Boolean counting, including all saved spatial views."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import argparse,json,csv,numpy as np
from scipy.linalg import eigh,helmert,cho_factor,cho_solve
from scipy.optimize import brentq
from scipy.spatial.distance import pdist,squareform
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out)
if out.exists():raise SystemExit('Output already exists; choose a fresh directory.')
out.mkdir(parents=True);root=Path(__file__).resolve().parent;centres=np.load(root/'inputs/hydrogen/inputs/constants.npy');widths=[.03,.01,.005]
def counts(v):
 r=v[:,None]/v[None,:];mask=~np.eye(len(v),dtype=bool)
 return [[int(np.count_nonzero(mask&(r>=c*(1-t))&(r<=c*(1+t)))) for c in centres] for t in widths]
def lap(w):return np.diag(w.sum(axis=1))-w
z=np.load(root/'inputs/hydrogen/inputs/h30_graph.npz');s=z['states'];W=np.zeros((465,465));W[z['edge_i'],z['edge_j']]=z['observed_weights'];W+=W.T;L=lap(W);Q=helmert(465,full=False).T;rates=eigh(Q.T@L@Q,eigvals_only=True);hcounts=counts(np.log1p(rates/rates[0]));rows=list(csv.DictReader((root/'references/natural_signed_development.csv').open()));target=[[int(next(r for r in rows if float(r['width'])==t and int(r['slot'])==j)['joint_lower_count']) for j in range(15)] for t in widths];assert hcounts==target
lag=abs(s[:,0,None]-s[None,:,0]);B=lap(W*(lag<=1));b,U=eigh(Q.T@B@Q);V=Q@U;A=V.T@L@V;pred=np.concatenate([eigh(A[j:j+16,j:j+16],eigvals_only=True) for j in range(0,464,16)]);pred.sort()
# Independent source minimum: isolate the ground contrast and solve its scalar Schur equation.
rest=helmert(464,full=False).T;alpha=465/464*W[0].sum();H=rest.T@L[1:,1:]@rest;coupling=-np.sqrt(465/464)*(rest.T@W[0,1:]);source_min=brentq(lambda x:alpha-x-coupling@cho_solve(cho_factor(H-x*np.eye(463)),coupling),1.,alpha,xtol=1e-13);pred[0]=source_min;pc=counts(np.log1p(pred/source_min));expected=[[int(next(r for r in rows if float(r['width'])==t and int(r['slot'])==j)['fixed_prediction_count']) for j in range(15)] for t in widths];assert pc==expected
spatial=[]
for f in sorted((root/'inputs/spatial').glob('*.npz')):
 d=np.load(f);distance=pdist(d['points']);sigma=np.median(distance);G=np.exp(-squareform(distance)**2/(2*sigma*sigma));lam=eigh(lap(G),eigvals_only=True);tol=max(1e-12,1e-12*max(abs(lam)));assert sum(abs(lam)<=tol)==1 and min(lam)>=-tol;positive=lam[lam>tol];err=float(max(abs(positive-d['raw_eigenvalues'])));assert np.allclose(positive,d['raw_eigenvalues'],rtol=2e-10,atol=2e-9);co=counts(positive);assert co==counts(d['native_values']);spatial.append({'view':f.stem,'sites':len(G),'max_spectrum_error':err,'all45_counts_match':True})
result={'hydrogen_counts':hcounts,'all45_hydrogen_match':True,'source_minimum':source_min,'fixed16_counts':pc,'all45_fixed16_match':True,'adjacent_own_minimum_RMS45':float(np.sqrt(np.mean((np.array(counts(np.log1p(b/b[0])))-np.array(hcounts))**2)))/214832,'fixed16_RMS45':float(np.sqrt(np.mean((np.array(pc)-np.array(hcounts))**2)))/214832,'spatial':spatial,'all14_spatial_views_match':len(spatial)==14,'classification':'Separate direct numerical graph eigensolver and Boolean count checks; no pixel extraction or formal interval certificate'}
(out/'graph_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['spatial','hydrogen_counts','fixed16_counts']},indent=2))
