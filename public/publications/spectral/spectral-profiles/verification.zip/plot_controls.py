"""Generate the hydrogen control table and figure from executed source results."""
from pathlib import Path
import argparse,json,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=Path(__file__).resolve().parent/'references/hydrogen_controls.json');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
if a.out.exists():raise SystemExit('Use a fresh output directory.')
a.out.mkdir(parents=True);d=json.loads(a.data.read_text());rows=d['records'];labels=['Natural','Ground','Core','Half G','Half C','3/4 G\n+1/4 C'];plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(1,2,figsize=(8.0,4.0),layout='constrained');x=np.arange(6);w=.25
for offset,key,label,color in [(-1,'actual_RMS45','Actual discrepancy','#264653'),(0,'predicted_RMS45','Predicted discrepancy','#2a9d8f'),(1,'prediction_error_RMS45','Componentwise error','#e9c46a')]:ax[0].bar(x+offset*w,[r[key]*1e4 for r in rows],w,label=label,color=color)
ax[0].set_xticks(x,labels,rotation=35,ha='right',fontsize=10);ax[0].set_ylabel(r'RMS of 45 incidences ($\times10^{-4}$)');ax[0].set_title('(a) Magnitude and prediction error',loc='left',fontsize=11);ax[0].legend(fontsize=10,frameon=False)
for name,label,color,marker in [('natural','Natural','#2a9d8f','o'),('ground','Ground only','#e76f51','s'),('core','Core only','#264653','^')]:
 v=d['vectors'][name];s=np.array(v['spectral_incidence']).ravel()*1e4;n=np.array(v['normalization_incidence']).ravel()*1e4;ax[1].scatter(s,-n,label=label,color=color,marker=marker,s=22,alpha=.7)
lim=max(abs(np.array(ax[1].get_xlim()+ax[1].get_ylim())))*1.05;ax[1].plot([-lim,lim],[-lim,lim],color='.45',lw=1,ls='--');ax[1].set_xlim(-lim,lim);ax[1].set_ylim(-lim,lim);ax[1].set_aspect('equal');ax[1].set_xlabel(r'Spectral contribution $E_s$ ($\times10^{-4}$)');ax[1].set_ylabel(r'Opposite normalization $-E_a$ ($\times10^{-4}$)');ax[1].set_title('(b) Signed contributions',loc='left',fontsize=11);ax[1].legend(fontsize=10,frameon=False)
for ext in ['pdf','png','svg']:fig.savefig(a.out/('hydrogen_controls.'+ext),dpi=180)
plt.close(fig)
lines=[r'\begin{table}[htbp]\centering\small',r'\caption{Source-reconstructed controls for $B+gR_g+cR_c$. The Predicted, Actual and Error columns are RMS45 values in units of $10^{-4}$: predicted and actual uncorrected discrepancy, and the componentwise prediction error. The last column is the cosine between the actual spectral and normalization vectors $E_s,E_a$ in Eq.~\eqref{eq:cancel}. These are known mathematical development controls, not unseen observations.}\label{tab:controls}',r'\begin{tabular}{lrrrrrr}\toprule Control &$g$&$c$&Predicted&Actual&Error&Cosine\\\midrule']
texlabels=['Natural','Ground only','Core only','Half ground','Half core',r'$3R_g/4+R_c/4$']
for label,r in zip(texlabels,rows):lines.append(f"{label} & {r['ground_coefficient']:g} & {r['core_coefficient']:g} & {r['predicted_RMS45']*1e4:.5f} & {r['actual_RMS45']*1e4:.5f} & {r['prediction_error_RMS45']*1e4:.5f} & {r['actual_signed_cosine']:.5f}"+r'\\')
lines += [r'\bottomrule\end{tabular}\end{table}'];(a.out/'control_table.tex').write_text('\n'.join(lines)+'\n');shutil.copy2(a.data,a.out/'hydrogen_controls_data.json');print('Generated data-derived figure and control table.')
