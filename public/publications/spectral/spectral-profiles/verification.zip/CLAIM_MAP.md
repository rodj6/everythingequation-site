# Claim-to-code and data map

| Paper claim | Executable and input | Evidence class |
|---|---|---|
| H30 counts, adjacent-shell discrepancy, fixed16 predictor | check_graphs.py; graph NPZ, constants, source count CSV | Separate numerical reconstruction and direct Boolean counters |
| Same-shell radial construction, scalar tail budget, stored-edge rounding | inputs/radial/radial.py; code/radial_exact_budget.py and radial_edge_certificate.py | Exact rational scalar/edge regeneration, not full matrix certification |
| Signed shell return and six sharp HH windows | HH_partner_* discovery, HH_arithmetic_audit.py, radial_endpoint_wide.py, radial_count_return.py | Numerical matrix/gap/inertia return; conditional exact theorem in paper |
| Remaining mixed threshold | mixed_* and minimum_gap_audit.py | Residual-model numerical source repair |
| Noncommuting signed expansion | exact_shell_fixture.py | Independent exact rational fixture |
| Bath obstruction | carrier_obstruction_check.py plus analytic angular proof | Verified nonzero actual edges and conditional mathematical obstruction |
| Spatial preparation and anisotropy | spatial_preparation.py and specification | Frozen synthetic diagnostic; conditional population theorem in paper |
| All saved-centroid graph spectra and profiles | check_graphs.py; fourteen numerical NPZ inputs | Separate numerical graph replay, no pixel acquisition |
| Coordinate and deletion bounds | spatial_position.py, spatial_deletion.py | Nominated numerical checks of proved inequalities |
| Kerr angular/radial generation | kerr_full.py, kerr_branch_repair.py, kerr_full_depth_audit.py | Finite-truncation numerical pole reconstruction |
| Failed and repaired full Kerr profiles | kerr_full_profile.py, kerr_depth_profile.py | All45 counts, native exposure and multiplicities; failed branch retained |
| Damping/frequency inversion | kerr_rotating_obstruction.py; supplied source poles | Numerical obstruction on specified finite sets |
| Ratio nonidentifiability, response completion | homometric_readout_check.py, response_discrimination.py, finite_response_reconstruction.py | Exact integer/Fraction fixtures and constructed numerical response |
| One-point density insufficiency | density_pair_counterexample.py | Exact finite ensemble fixture |
| Generated numerical tables | make_tables.py; scientific reference CSV/JSON | Machine-derived manuscript tables and all45 component errors |

Static-response, scale and projection claims have complete finite proofs in the manuscript. Code checks supplement those proofs; they are not empirical observations. Scientific references supplied to the fast route are inputs, not regenerated discoveries. The full route regenerates the explicitly listed discovery and pole stages while retaining its declared baseline source inputs.

| Hydrogen ground/core and mixed-control comparison | hydrogen_controls.py; radial graph and control_reference.json | Recomputed all45 vectors, fixed16 predictor, signed cancellation; known controls |
| Mechanism figure and control table | plot_controls.py; hydrogen_controls.json | Generated from executed numeric results |
| Portable endpoint acceptance | acceptance.py, check_acceptance.py | Recomputed rank inequalities;15 adversarial rejection fixtures |
