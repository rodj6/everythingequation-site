# Source structure to spectral profiles: public verification

This supplement accompanies Jeremy Rodgers's companion paper. It reproduces specified mathematical and numerical claims, not atomic experiments, black-hole observations or historical photograph acquisition. Manuscript LaTeX is delivered separately.

Use Python 3.12 with the versions in `requirements.txt`. In a new virtual environment run `python -m pip install -r requirements.txt`. From this directory:

```
python verify_integrity.py
python check_graphs.py --out results_graphs
python hydrogen_controls.py --out results_controls
python plot_controls.py --data results_controls/hydrogen_controls.json --out results_figure
python check_acceptance.py --out results_acceptance
python run.py fast --out results_fast
python run.py exact --out results_exact
python run.py full --out results_full
python make_tables.py --out generated_tables
```

Each `--out` must be a new directory. Scripts and numerical inputs are copied there before execution; supplied references are never overwritten. Review `verification.json` and individual logs. A nonzero exit or mismatch stops the sequence. Integers and Booleans compare exactly. Stage-specific endpoint acceptance recomputes the scientific inequalities instead of matching incidental residual/error-budget values; see ACCEPTANCE.md. Other numerical comparisons retain relative tolerance 2e-8 and absolute tolerance 2e-9. Hash fields and execution timings are excluded from numerical equivalence. These tolerances are comparison rules, not mathematical error certificates. Exact rational fixtures and scalar certificates use exact arithmetic internally.

`fast` checks exact fixtures, response discrimination, the bath obstruction, spatial uncertainty/preparation, hydrogen endpoint/count return and failed/repaired Kerr profile counting. It deliberately starts from supplied hydrogen partner enclosures and supplied computed Kerr poles. Its first local run took less than a minute, with substantial platform dependence.

`exact` regenerates the 5,486 near/external radial budget acquisitions and all 8,990 original edges and checks scalar/edge rounding premises. It does not certify floating matrix inverses or inertia.

`full` additionally regenerates mixed-threshold repair, the 53-rank hydrogen partner discovery, full 540-label Kerr continuation, the smaller-step branch repair and 90 radial-depth checks, then runs fast and exact checks. It starts from the supplied baseline hydrogen enclosures and Schwarzschild barrier seeds, which are declared inputs rather than outputs of this route. It does not recreate earlier statistical control campaigns. Allow several minutes or longer on a CPU, a few hundred MB of working memory, and space for fresh copied inputs, results and logs. No GPU or network mode-cache lookup is needed after dependency installation. Final measured timings are recorded in `verification/` when available.

`check_graphs.py` separately reconstructs the complete H30 graph, its source-minimum fixed16 predictor and all14 saved-centroid spatial graphs, comparing all45 count coordinates. It takes about ten seconds on the preparation machine. This is a separate eigensolver/count implementation, not a new physical observation.

The `code/` directory contains adapted scientific implementations; `inputs/` contains numerical graph, spatial, catalogue and seed data; `references/` contains scientific results and declared parameters. `make_tables.py` generates every native count and all 45 fixed-predictor component errors from the retained machine outputs. Provenance, dependency notices, claim mappings and input hashes are supplied separately.

Photographic pixels are excluded. Saved centroids support graph-to-spectrum replay. Exact pixel reproduction requires lawful acquisition of the matching bytes plus the declared extraction procedure; six stable acquisition mappings and photographic redistribution permissions remain unresolved. No substitute image is an exact replication.

The original 15 coordinates, widths .03/.01/.005, multiplicities, ordered nonself pairs, inclusive matching endpoints, shared hydrogen minimum and open Kerr exposure cutoff are retained. SUM counts overlap multiplicity; UNION counts each eligible pair once. The failed Kerr fixed-step result and failed coarse radial bound are scientific diagnostics, not successful replacements for the final results.

The new hydrogen-controls command reconstructs natural, ground-only, core-only and three mixed source interventions, checks retained metrics and saves every45-coordinate target/prediction and signed contribution. Plotting reads that actual output, generating the manuscript figure and control table. Matplotlib is needed for plotting only. These are known mathematical development controls.
