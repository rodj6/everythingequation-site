"""Exact finite Laguerre expansion. Atomic length unit a0=1."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial,comb

@lru_cache(None)
def coefficients(n,l,m):
    q=n-l-1;d=n+m
    return tuple((-1)**j*comb(n+l,q-j)*(factorial(q)//factorial(j))*(2*m)**j*d**(q-j) for j in range(q+1))

def squared_radial(n,l,m,k):
    """Returns exact rational weight and radial sign, never fitted/table looked up."""
    q=n-l-1;p=m-k-1;d=n+m;power=l+k+3
    a=coefficients(n,l,m);b=coefficients(m,k,n)
    c=[0]*(q+p+1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    numerator=sum(x*factorial(power+j) for j,x in enumerate(c))
    scale=F(4,n*n*m*m)*F(2,n)**l*F(2,m)**k*F(n*m,d)**(power+1)
    scale*=F(numerator,factorial(q)*factorial(p)*d**(q+p))
    norm=F(factorial(q)*factorial(p),factorial(n+l)*factorial(m+k))
    return scale*scale*norm,(numerator>0)-(numerator<0)

def same_shell_strength(n,l):
    return F(9,4)*n*n*((n*n-l*l if l>0 else 0)+(n*n-(l+1)**2 if l<n-1 else 0))

def second_moment(n,l):return F(n*n,2)*(5*n*n+1-3*l*(l+1))
