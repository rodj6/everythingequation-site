"""Adversarial fixtures for endpoint acceptance; never accept flags alone."""
from pathlib import Path
from copy import deepcopy
import json,argparse
from acceptance import endpoint_audit,radial_endpoint_audit
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out)
if out.exists():raise SystemExit('Use a fresh output directory.')
out.mkdir(parents=True);root=Path(__file__).resolve().parent;good=json.loads((root/'references/endpoint_certificate_fixture.json').read_text());ref=json.loads((root/'references/HH_arithmetic_audit.json').read_text());assert endpoint_audit(good,ref);tests=[]
def reject(name,mutate):
 x=deepcopy(good);mutate(x);passed=not endpoint_audit(x,ref);tests.append({'fixture':name,'invalid_certificate_rejected':passed});assert passed,name
reject('false_success_flag',lambda x:x.update(all106_verified=False))
reject('missing_endpoint',lambda x:x['checks'].pop())
reject('nonpositive_gap_despite_success',lambda x:x['checks'][0].update(exterior_gap=-1))
reject('unearned_transport_denominator',lambda x:x['checks'][0].update(transport_ratio=1))
reject('inconsistent_error_sum',lambda x:x['checks'][0].update(total_budget=0))
reject('nonfinite_error',lambda x:x['checks'][0].update(product_budget=float('nan')))
reject('false_inertia_despite_success',lambda x:x['checks'][0].update(upper_inertia=9999))
reject('wrong_rank_label',lambda x:x['checks'][0].update(rank=999))
def enlarged(x):
 r=x['checks'][0];r['product_budget']+=1e12;r['total_budget']+=1e12;x['maximum_endpoint_budget']=max(c['total_budget'] for c in x['checks']);r['lower_inertia']=r['outside_inertia']+sum(v+r['total_budget']<0 for v in r['retained_eigenvalues']);r['upper_inertia']=r['outside_inertia']+sum(v-r['total_budget']<0 for v in r['retained_eigenvalues'])
reject('valid_budget_sum_but_failed_rank_inequality',enlarged)
# The saved diagnostics are not numerical targets. Altering only their reference
# magnitudes must leave a valid recomputed certificate accepted.
different=deepcopy(ref);different['maximum_endpoint_budget']=99.;different['assembly_budget']=42.;assert endpoint_audit(good,different)
radial=json.loads((root/'references/radial_endpoint_certificate_fixture.json').read_text());rref=json.loads((root/'references/radial_endpoint_wide.json').read_text());assert radial_endpoint_audit(radial,rref)
for key,value in [('series_ratio',1.),('inverse_residual',1.),('transport_ratio',1.),('far_beta',float('inf')),('exterior_gap',-1.),('lower_inertia',-1)]:
 x=deepcopy(radial);x['checks'][0][key]=value;passed=not radial_endpoint_audit(x,rref);assert passed,key;tests.append({'fixture':'radial_'+key,'invalid_certificate_rejected':passed})
different=deepcopy(rref);different['maximum_error']=100.;assert radial_endpoint_audit(radial,different)
(out/'acceptance_checks.json').write_text(json.dumps({'valid_certificate_accepted':True,'valid_radial_certificate_accepted':True,'incidental_reference_diagnostics_not_targets':True,'invalid_fixtures':tests,'all_pass':True},indent=2));print('Valid certificates accepted; fifteen invalid certificates rejected.')
