"""Generate manuscript tables directly from supplied scientific outputs."""
from pathlib import Path
import argparse,csv,json
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True);ref=Path(__file__).resolve().parent/'references'
h=list(csv.DictReader((ref/'natural_signed_development.csv').open()));k=json.loads((ref/'kerr_depth_profile.json').read_text());widths=[.03,.01,.005]
labels=[r'$\varphi$',r'$\varphi^{-1}$',r'$\varphi^2$',r'$\sqrt2$',r'$\sqrt3$',r'$\sqrt5$',r'$\pi$',r'$\pi/2$',r'$\pi/10$',r'$e$',r'$e^{-1}$',r'$\log2$',r'$j_{0,1}$',r'$3/13$',r'$1/7$']
lines=[r'\begin{longtable}{lrrrrrr}',r'\caption{Recovered native counts generated from the retained source outputs. Hydrogen exposure is 214832; Kerr exposure is 272049. Columns retain the original widths and labelled multiplicities.}\\',r'\toprule',r'&\multicolumn{3}{c}{Hydrogen}&\multicolumn{3}{c}{Kerr}\\',r'Centre &3\%&1\%&0.5\%&3\%&1\%&0.5\%\\\midrule',r'\endfirsthead',r'\toprule Centre &3\%&1\%&0.5\%&3\%&1\%&0.5\%\\\midrule\endhead']
rows=[]
for j,label in enumerate(labels):
 hr=[next(r for r in h if int(r['slot'])==j and float(r['width'])==t) for t in widths];counts=[int(r['joint_lower_count']) for r in hr];assert all(r['joint_lower_count']==r['joint_upper_count'] for r in hr)
 kr=[k['predicted_counts'][i][j] for i in range(3)];lines.append(label+' & '+' & '.join(map(str,counts+kr))+r'\\');rows.append([j]+counts+kr)
lines += [r'\midrule SUM & '+' & '.join(str(sum(r[c] for r in rows)) for c in range(1,7))+r'\\',r'\bottomrule\end{longtable}']
with (out/'native_counts.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['slot','H_3pct','H_1pct','H_halfpct','K_3pct','K_1pct','K_halfpct']);w.writerows(rows)
sp=json.loads((ref/'spatial_preparation_results.json').read_text());lines += [r'\begin{table}[htbp]\centering',r'\caption{Frozen anisotropic Gaussian examples, 512 sites. Variance error refers to the population-kernel-mass plug-in diagnostic; profile RMS and rank are relative to the isotropic example.}',r'\begin{tabular}{lrrr}\toprule Covariance &Variance error &RMS45 &3\% rank\\\midrule']
for r in sp:lines.append(str(tuple(r['covariance']))+f" & {r['relative_variance_error']:.5f} & {r['RMS45_vs_isotropic']:.7f} & {r['rank_3pct_vs_isotropic']:.6f}"+r'\\')
lines += [r'\bottomrule\end{tabular}\end{table}'];(out/'generated_tables.tex').write_text('\n'.join(lines)+'\n')
with (out/'hydrogen_component_errors.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['width','slot','source_count','baseline_count','fixed16_count','signed_actual','signed_predicted','prediction_error'])
 for r in h:
  target=int(r['joint_lower_count']);base=int(r['base_count']);pred=int(r['fixed_prediction_count']);w.writerow([r['width'],r['slot'],target,base,pred,(target-base)/214832,(pred-base)/214832,(pred-target)/214832])
print('Generated native counts, all45 fixed16 component errors, and anisotropy table.')
