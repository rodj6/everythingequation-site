"""Authenticate bundled files against their relative-path SHA256 manifest."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text());fail=[]
for row in manifest['files']:
 p=(root/row['path']).resolve()
 if not p.is_relative_to(root) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:fail.append(row['path'])
print(json.dumps({'checked':len(manifest['files']),'all_match':not fail,'failures':fail},indent=2));raise SystemExit(bool(fail))
