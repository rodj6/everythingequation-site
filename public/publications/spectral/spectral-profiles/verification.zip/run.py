"""Run public scientific checks in a new output directory; never overwrite references."""
from acceptance import accept
from pathlib import Path
import argparse,subprocess,sys,shutil,json,time,datetime,math,platform
p=argparse.ArgumentParser();p.add_argument('scope',choices=['fast','full','exact']);p.add_argument('--out',required=True);a=p.parse_args()
package=Path(__file__).resolve().parent;out=Path(a.out).resolve()
if (package/'manifest.json').exists():
 subprocess.run([sys.executable,str(package/'verify_integrity.py')],check=True)
if out.exists():raise SystemExit('Choose a fresh --out directory; this path already exists.')
out.mkdir(parents=True);work=out/'work';work.mkdir();code=work/'code';shutil.copytree(package/'code',code);shutil.copytree(package/'inputs',work/'inputs')
for f in (package/'references').iterdir():shutil.copy2(f,code/f.name)
fast=[('exact_shell_fixture','EXACT_SHELL_FIXTURE.json'),('homometric_readout_check','homometric_readout_check.json'),('response_discrimination','response_discrimination.json'),('finite_response_reconstruction','FINITE_RESPONSE_RECONSTRUCTION.json'),('density_pair_counterexample','density_pair_counterexample.json'),('carrier_obstruction_check','carrier_obstruction_check.json'),('spatial_position','spatial_position_results.json'),('spatial_deletion','spatial_deletion_results.json'),('spatial_preparation','spatial_preparation_results.json'),('HH_arithmetic_audit','HH_arithmetic_audit.json'),('HH_count_development','HH_count_development.json'),('HH_aggregate_development','HH_aggregate_development.json'),('radial_external_bound','radial_external_bound.json'),('radial_endpoint_wide','radial_endpoint_wide.json'),('radial_count_return','radial_count_return.json'),('kerr_full_profile','kerr_full_profile.json'),('kerr_depth_profile','kerr_depth_profile.json')]
full=[('mixed_threshold_geometry','mixed_threshold_geometry.json'),('mixed_minimum_repair','mixed_minimum_repair.json'),('mixed_residual_budget','mixed_residual_budget.json'),('minimum_gap_audit','minimum_gap_audit.json'),('mixed_count_return','mixed_count_return.json'),('validate_mixed_return','mixed_return_validation.json'),('HH_frontier_geometry','HH_frontier_geometry.json'),('HH_required_ranks','HH_required_ranks.json'),('HH_partner_gaps','HH_partner_gaps.json'),('HH_partner_enclose','HH_partner_execution.json'),('HH_verify_endpoints','HH_endpoint_verification.json'),('kerr_full','kerr_full_source.json'),('kerr_branch_repair','kerr_refined_source.json'),('kerr_full_depth_audit','kerr_full_depth_audit.json')]
exact=[('radial_exact_budget','radial_exact_budget.json'),('radial_edge_certificate','RADIAL_EDGE_CERTIFICATE.json')]
jobs=fast if a.scope=='fast' else exact if a.scope=='exact' else full+fast+exact
def equivalent(x,y):
 if type(x) is not type(y):return False
 if isinstance(x,dict):return x.keys()==y.keys() and all(equivalent(v,y[k]) for k,v in x.items() if 'sha256' not in k and k not in ['seconds','elapsed_seconds'])
 if isinstance(x,list):return len(x)==len(y) and all(equivalent(u,v) for u,v in zip(x,y))
 if isinstance(x,float):return math.isclose(x,y,rel_tol=2e-8,abs_tol=2e-9)
 return x==y
records=[]
for script,result in jobs:
 start=time.perf_counter();proc=subprocess.run([sys.executable,str(code/(script+'.py'))],capture_output=True,text=True,encoding='utf-8',errors='replace');(out/(script+'.log')).write_text(proc.stdout+proc.stderr,encoding='utf-8');ref=package/'references'/result;got=code/result
 match=False;rule='execution/output failure'
 if proc.returncode==0 and got.exists() and ref.exists():match,rule=accept(script,json.loads(got.read_text()),json.loads(ref.read_text()),equivalent)
 records.append({'script':script+'.py','result':result,'exit_code':proc.returncode,'reference_match':match,'acceptance_rule':rule,'seconds':time.perf_counter()-start});print(json.dumps(records[-1]),flush=True)
 if not match:break
receipt={'scope':a.scope,'platform':platform.platform(),'python':platform.python_version(),'numpy':__import__('numpy').__version__,'scipy':__import__('scipy').__version__,'jobs':records,'all_pass':len(records)==len(jobs) and all(r['reference_match'] for r in records),'comparison':'Stage-specific scientific acceptance; see ACCEPTANCE.md. HH endpoint residual budgets are recomputed, not matched to incidental reference values. Other comparison tolerances unchanged.'}
(out/'verification.json').write_text(json.dumps(receipt,indent=2));raise SystemExit(0 if receipt['all_pass'] else 1)

