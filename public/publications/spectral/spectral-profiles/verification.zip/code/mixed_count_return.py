from pathlib import Path
import json,csv,numpy as np
root=Path(__file__).parent;parent=root.parent/'inputs/hydrogen';repair=json.loads((root/'mixed_residual_budget.json').read_text());assert repair['inertia_counts']==[317,317]
rows=[dict(r) for r in csv.DictReader((parent/'results/complete_signed.csv').open()) if r['case']=='natural'];target=next(r for r in rows if float(r['width'])==.005 and int(r['slot'])==11)
# Upper mixed endpoint contracts by one while its lower endpoint is unchanged.
old_lower=int(target['joint_lower_count']);old_upper=int(target['joint_upper_count']);mixed_lower=int(target['focus_mixed_lower']);mixed_upper=int(target['focus_mixed_upper']);assert mixed_upper-mixed_lower==1
# Recombine retained LL+HH+mixed bound; tightening only a sub-bound does not
# license decrementing an already intersected global bound without checking.
old_hh_upper=int(target['focus_HH_upper']);ll_possible=int(target['upper_count']) # not an LL bound; recover from unchanged source geometry below.
z=np.load(parent/'results/final_enclosures.npz');lo=z['natural_lo'];hi=z['natural_hi'];amin,amax=z['natural_min_interval'];c=float(target['constant']);t=.005
bounds=[]
for a in [amin,amax]:
 vl=np.log1p(lo[:64]/a);vh=np.log1p(hi[:64]/a);vl[0]=vh[0]=np.log(2);bounds.append((vl[:,None]/vh[None,:],vh[:,None]/vl[None,:]))
rl=np.minimum(bounds[0][0],bounds[1][0]);rh=np.maximum(bounds[0][1],bounds[1][1]);mask=~np.eye(64,dtype=bool);LLupper=int(np.count_nonzero(mask&(rh>=c*(1-t))&(rl<=c*(1+t))))
recombined_upper=LLupper+old_hh_upper+mixed_lower
new_upper=min(old_upper,recombined_upper);assert old_lower<=new_upper
before=dict(target);target['focus_mixed_upper']=str(mixed_lower);target['joint_upper_count']=str(new_upper);exposure=464*463;target['joint_signed_upper']=str((new_upper-int(target['base_count']))/exposure)
with (root/'natural_signed_after_mixed.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def rmsbounds(rows):
 pairs=[(float(r['joint_signed_lower']),float(r['joint_signed_upper'])) for r in rows];return [float(np.sqrt(np.mean([0 if l<=0<=u else min(abs(l),abs(u))**2 for l,u in pairs]))),float(np.sqrt(np.mean([max(abs(l),abs(u))**2 for l,u in pairs])))]
summary=dict(old_count_interval=[old_lower,old_upper],new_count_interval=[old_lower,new_upper],LL_upper=LLupper,HH_upper=old_hh_upper,mixed_count=mixed_lower,recombined_upper=recombined_upper,RMS_interval=rmsbounds(rows),changed_coordinate=dict(width=.005,slot=11),evidence='source floating residual/inertia repair; no target spectrum used')
(root/'mixed_count_return.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
