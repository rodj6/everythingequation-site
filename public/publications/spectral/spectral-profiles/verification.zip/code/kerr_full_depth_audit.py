exec((__import__('pathlib').Path(__file__).parent/'kerr_angular.py').read_text().split('for row in csv.DictReader')[0])
from scipy.optimize import root as solve_root
from qnm.radial import leaver_cf_trunc_inversion
source=json.loads((root/'kerr_refined_source.json').read_text());checks=[]
for r in source:
 if r['n']!=3 or abs(r['spin']-.9)>1e-10:continue
 previous=complex(*r['omega']);A0guess=r['ell']*(r['ell']+1)-2;ev=np.linalg.eigvals(angular(r['m'],r['spin']*previous,20));Aguess=ev[np.argmin(abs(ev-A0guess))]
 for depth in [2400,4800]:
  def fun(z):
   w=complex(*z);ev=np.linalg.eigvals(angular(r['m'],r['spin']*w,20));A=ev[np.argmin(abs(ev-Aguess))];f=leaver_cf_trunc_inversion(w,r['spin'],-2,r['m'],A,3,N=depth);return [f.real,f.imag]
  sol=solve_root(fun,[previous.real,previous.imag],tol=1e-10);w=complex(*sol.x);checks.append(dict(ell=r['ell'],m=r['m'],depth=depth,success=bool(sol.success),residual=float(np.linalg.norm(fun(sol.x))),change=abs(w-previous),omega=[w.real,w.imag]));previous=w
(root/'kerr_full_depth_audit.json').write_text(json.dumps(checks,indent=2));print(json.dumps(dict(checks=len(checks),all_success=all(r['success'] for r in checks),maximum_change_2400=max(r['change'] for r in checks if r['depth']==2400),maximum_change_4800=max(r['change'] for r in checks if r['depth']==4800)),indent=2))
