from fractions import Fraction as F
from pathlib import Path
import json
add=lambda A,B:[[a+b for a,b in zip(x,y)] for x,y in zip(A,B)]
scale=lambda t,A:[[t*a for a in row] for row in A]
def mul(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),F(0)) for j in range(len(B[0]))] for i in range(len(A))]
def inv(A):
 det=A[0][0]*A[1][1]-A[0][1]*A[1][0];return scale(1/det,[[A[1][1],-A[0][1]],[-A[1][0],A[0][0]]])
D=[[F(-2),F(0)],[F(0),F(3)]];E=[[F(1,10),F(1,20)],[F(1,20),F(1,5)]];G=inv(D);C=[[F(1),F(2)]];Ct=[[F(1)],[F(2)]];exact=mul(mul(C,inv(add(D,E))),Ct)[0][0];T=scale(-1,mul(G,E));word=G;series=[[F(0),F(0)],[F(0),F(0)]];checks=[];rho=F(1,8)
assert mul(G,E)!=mul(E,G)
for m in range(8):
 series=add(series,word);value=mul(mul(C,series),Ct)[0][0];bound=F(5,2)*rho**(m+1)/(1-rho);error=abs(exact-value);assert error<=bound;assert series[0][1]==series[1][0];checks.append(dict(degree=m,error=str(error),bound=str(bound),passes=True));word=mul(T,word)
result=dict(noncommuting=True,indefinite_exterior=True,PSD_external=True,all_pass=True,checks=checks,classification='exact rational finite fixture for signed noncommuting series and self-energy remainder, not full H30 interval certificate')
Path(__file__).with_name('EXACT_SHELL_FIXTURE.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
