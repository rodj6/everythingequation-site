from collections import Counter
from fractions import Fraction
from pathlib import Path
import json
A=[0,1,4,10,12,17];B=[0,1,8,11,13,17]
def differences(x):return Counter(i-j for k,i in enumerate(x) for l,j in enumerate(x) if k!=l)
da,db=differences(A),differences(B);assert da==db;assert A!=B;assert sorted(17-x for x in A)!=B
result=dict(A=A,B=B,ordered_nonself_difference_counts={str(k):v for k,v in sorted(da.items())},same_complete_difference_measure=da==db,reflection_related=False,exposure=30,construction='positive readouts v_i=exp(A_i/100) or exp(B_i/100); exact ratio measures identical; no original radial/physical graph equivalence claimed')
Path(__file__).with_name('homometric_readout_check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
