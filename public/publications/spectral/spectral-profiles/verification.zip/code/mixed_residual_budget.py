exec((__import__('pathlib').Path(__file__).parent/'mixed_minimum_repair.py').read_text().split('geom=json.loads')[0])
from scipy.linalg import ldl
lam=(lower+upper)/2;restpart=-cho_solve(cho_factor(H-lam*np.eye(len(H))),coupling);q0=np.r_[np.sqrt((N-1)/N),np.full(N-1,-1/np.sqrt(N*(N-1)))];vec=q0.copy();vec[1:]+=rest@restpart;vec/=np.linalg.norm(vec);L=lap(W);res=L@vec-lam*vec;eps=np.finfo(float).eps;gamma=(N+10)*eps/(1-(N+10)*eps);arithmetic=10*gamma*(np.linalg.norm(abs(L)@abs(vec))+abs(lam));bound=float(np.linalg.norm(res)+arithmetic);interval=[lam-bound,lam+bound]
geom=json.loads((root/'mixed_threshold_geometry.json').read_text());q=geom['reciprocal_upper_q'];l,u=geom['low_mode_interval'];threshold=[a*np.expm1(q*np.log1p(x/a)) for a in interval for x in [l,u]];cuts=[min(threshold)-.002,max(threshold)+.002];counts=[]
# Original constant-complement matrix, numerical LDL inertia only.
A=Q.T@L@Q
for cut in cuts:
 _,D,_=ldl(A-cut*np.eye(len(A)),lower=True);counts.append(int(np.count_nonzero(np.linalg.eigvalsh(D)<0)))
result=dict(minimum_candidate=lam,original_coordinate_residual=float(np.linalg.norm(res)),matvec_rounding_budget=arithmetic,residual_radius=bound,minimum_interval=interval,threshold_cuts=cuts,inertia_counts=counts,mixed_upper_rank_resolved=counts[0]==counts[1],classification='explicit residual budget under binary64 model; LDL and gap checks numerical, not formal intervals')
(root/'mixed_residual_budget.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
