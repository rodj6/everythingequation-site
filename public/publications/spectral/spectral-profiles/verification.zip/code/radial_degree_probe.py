exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
far=W*(lag>=4);degree=far.sum(1);beta=2*float(degree.max());rows=[]
windows=json.loads((root/'shell_window_probe.json').read_text())
for a,w in zip(json.loads((root/'shell_gap_probe.json').read_text()),windows):
 rows.append(dict(core=a['core'],graph_far_norm_bound=beta,uniform_ratio_graph_bound=beta/(a['gap']-w['radius']),uniform_condition_graph_bound=beta<a['gap']-w['radius']))
result=dict(max_far_weighted_degree=float(degree.max()),graph_laplacian_bound=beta,sectors=rows,lag_degree_bounds=[dict(lag=int(k),norm_bound=2*float((W*(lag==k)).sum(1).max())) for k in range(2,30)])
(root/'radial_degree_probe.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
