# Endpoint verification uses the exact full-exterior solve residual, not a
# second evaluation of the signed-series remainder estimate.
exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from scipy.linalg import solve
z=np.load(root/'HH_partner_enclosures.npz');low=z['lo'];high=z['hi'];sectors=json.loads((root/'HH_partner_gaps.json').read_text());receipts=json.loads((root/'HH_partner_execution.json').read_text());A=A0+E;checks=[]
for sector,rec in zip(sectors,receipts):
 p0,p1=sector['retained'];p=np.arange(p0,p1);q=np.setdiff1d(np.arange(len(b)),p);C=A[np.ix_(p,q)];D=A[np.ix_(q,q)];App=A[np.ix_(p,p)];outside=int(np.count_nonzero(eigh(D-sector['center']*np.eye(len(q)),eigvals_only=True)<0));h=1/(sector['uniform_gap_before_far']-sector['far_graph_bound']);cn=float(norm(C,2))
 for rank in rec['ranks']:
  for side,x in [('lower',low[rank]),('upper',high[rank])]:
   M=D-x*np.eye(len(q));Z=solve(M,C.T,assume_a='sym');res=M@Z-C.T;err=cn*h*float(norm(res,'fro'))+.0001;S=App-x*np.eye(len(p))-C@Z;vals=eigh((S+S.T)/2,eigvals_only=True);nlo=outside+int(np.count_nonzero(vals+err<0));nhi=outside+int(np.count_nonzero(vals-err<0));valid=nhi<=rank if side=='lower' else nlo>rank
   checks.append(dict(rank=rank,side=side,cut=float(x),solve_residual_error=err,inertia_lower=nlo,inertia_upper=nhi,bracket_verified=valid))
result=dict(endpoint_checks=len(checks),all_verified=all(c['bracket_verified'] for c in checks),checks=checks,classification='independent full-exterior residual check with development arithmetic pad; not formal intervals')
(root/'HH_endpoint_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
