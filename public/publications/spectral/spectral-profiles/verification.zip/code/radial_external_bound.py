exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from fractions import Fraction
namespace={};exec((root.parent/'inputs/radial/radial.py').read_text(),namespace);radial=namespace['squared_radial'];moment=namespace['second_moment'];rows=[];calls=0
for i,(n0,l0) in enumerate(s):
 n,l=int(n0),int(l0);nu=int(l>0)+int(l<29);retained=float((W[i]*(lag[i]<=3)).sum());external=Fraction(0)
 for m in [31,32,33]:
  for k in [l-1,l+1]:
   if 0<=k<30:
    weight,_=radial(n,l,m,k);external+=weight;calls+=1
 bound=nu*float(moment(n,l))-retained-float(external);actual=float((W[i]*(lag[i]>=4)).sum());assert bound>=actual-1e-7
 rows.append(dict(n=n,ell=l,external_mass=float(external),far_row_bound=max(0,bound),actual_far_degree=actual))
beta=2*max(r['far_row_bound'] for r in rows);sectors=json.loads((root/'HH_partner_gaps.json').read_text());result=dict(exact_radial_calls=calls,beta=beta,maximum_state=max(rows,key=lambda r:r['far_row_bound']),sector_ratios=[dict(core=r['core'],ratio=beta/r['uniform_gap_before_far'],contractive=bool(beta<r['uniform_gap_before_far'])) for r in sectors],rows=rows,classification='exact external-channel subtraction with floating finite budgets; not directed intervals')
(root/'radial_external_bound.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
