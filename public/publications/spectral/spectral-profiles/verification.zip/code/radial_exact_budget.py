from pathlib import Path
from fractions import Fraction as F
import numpy as np,json,hashlib
root=Path(__file__).parent;ns={};exec((root.parent/'inputs/radial/radial.py').read_text(),ns);radial=ns['squared_radial'];moment=ns['second_moment'];z=np.load(root.parent/'inputs/hydrogen/inputs/h30_graph.npz');states=z['states'];near=[F(0) for _ in states];near_calls=0
for i0,j0,w in zip(z['edge_i'],z['edge_j'],z['observed_weights']):
 i,j=int(i0),int(j0);n,l=map(int,states[i]);m,k=map(int,states[j])
 if abs(n-m)<=3:
  exact,_=radial(n,l,m,k);assert float(exact)==w;near[i]+=exact;near[j]+=exact;near_calls+=1
rows=[];budgets=[];external_calls=0
for i,(n0,l0) in enumerate(states):
 n,l=int(n0),int(l0);external=F(0)
 for m in [31,32,33]:
  for k in [l-1,l+1]:
   if 0<=k<30:external+=radial(n,l,m,k)[0];external_calls+=1
 bound=(int(l>0)+int(l<29))*moment(n,l)-near[i]-external;assert bound>=0;budgets.append(bound);rows.append(dict(n=n,ell=l,retained_exact=str(near[i]),external_exact=str(external),far_bound_exact=str(bound)))
beta=2*max(budgets);u=F(1,2**53);binary_bound=beta/(1-u);upper=float(binary_bound)
while F.from_float(upper)<binary_bound:upper=float(np.nextafter(upper,np.inf))
result=dict(near_edge_calls=near_calls,external_channel_calls=external_calls,maximum_index=int(np.argmax([float(b) for b in budgets])),beta_exact=str(beta),binary64_far_beta_upper=upper,upper_verified_exactly=F.from_float(upper)>=binary_bound,rows=rows,classification='exact rational scalar radial budget; original nearest-rounded binary64 far weights charged by1/(1-u); not full matrix interval certificate')
(root/'radial_exact_budget.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['rows','beta_exact']},indent=2))
