from pathlib import Path
import json, os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from scipy.linalg import eigh, helmert, norm
root=Path(__file__).resolve().parent
parent=root.parent/'inputs/hydrogen'
z=np.load(parent/'inputs/h30_graph.npz');s=z['states'];W=np.zeros((len(s),len(s)));W[z['edge_i'],z['edge_j']]=z['observed_weights'];W+=W.T
lag=abs(s[:,0,None]-s[None,:,0])
def lap(w):return np.diag(w.sum(1))-w
Q=helmert(len(s),full=False).T
b,U=eigh(Q.T@lap(W*(lag<=1))@Q);V=Q@U
E=V.T@lap(W*(lag>=4))@V
A0=np.diag(b)+V.T@lap(W*((lag==2)|(lag==3)))@V
records=json.loads((parent/'results/mixed_resolvent.json').read_text())+json.loads((parent/'results/high_resolvent.json').read_text())
rows=[]
for rec in records:
 if rec['case']!='natural':continue
 for info in rec['clusters']:
  p0,p1=info['source_indices'];p=np.arange(p0,p1);q=np.setdiff1d(np.arange(len(b)),p);sigma=info['center']
  D=A0[np.ix_(q,q)]-sigma*np.eye(len(q));ev=eigh(D,eigvals_only=True);gap=float(abs(ev).min());en=float(norm(E[np.ix_(q,q)],2));fn=float(norm(E[np.ix_(p,q)],2));cn=float(norm(A0[np.ix_(p,q)],2));rho=en/gap
  rows.append(dict(core=info['core'],retained=[p0,p1],gap=gap,far_exterior_norm=en,far_coupling_norm=fn,retained_coupling_norm=cn,rho=rho,sufficient_condition=rho<1))
(root/'shell_gap_probe.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
