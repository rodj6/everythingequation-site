from pathlib import Path
import numpy as np,json,collections
root=Path(__file__).parent;parent=root.parent/'inputs/hydrogen';z=np.load(parent/'results/final_enclosures.npz');lo=z['natural_lo'];hi=z['natural_hi'];amin,amax=z['natural_min_interval'];C=np.load(parent/'inputs/constants.npy');pairs=[];scores=collections.Counter();sectors=[(64,96),(96,128),(128,160),(160,192),(416,448)]
rl=[];rh=[]
for a in [amin,amax]:
 vl=np.log1p(lo/a);vh=np.log1p(hi/a);rl.append(vl[:,None]/vh[None,:]);rh.append(vh[:,None]/vl[None,:])
lower=np.minimum(*rl);upper=np.maximum(*rh)
for t in [.03,.01,.005]:
 for constant in [np.sqrt(2),np.log(2)]:
  slot=int(np.argmin(abs(C-constant)));left=C[slot]*(1-t);right=C[slot]*(1+t);possible=(upper>=left)&(lower<=right);sure=(lower>=left)&(upper<=right);amb=possible&~sure;amb[:64,:]=False;amb[:,:64]=False;np.fill_diagonal(amb,False)
  for i,j in zip(*np.where(amb)):
   pairs.append(dict(width=t,slot=slot,i=int(i),j=int(j),ratio_lower=float(lower[i,j]),ratio_upper=float(upper[i,j]),both_in_selected_cores=all(any(a<=k<b for a,b in sectors) for k in [i,j])))
   scores[(int(i)//32)*32]+=1;scores[(int(j)//32)*32]+=1
result=dict(ambiguous_pair_records=len(pairs),both_covered_records=sum(r['both_in_selected_cores'] for r in pairs),core_participation=[dict(start=k,incidences=v) for k,v in scores.most_common()],pairs=pairs,classification='source interval ambiguity, not actual crossings; inherited jointly constrained counts can be narrower')
(root/'HH_frontier_geometry.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='pairs'},indent=2))
