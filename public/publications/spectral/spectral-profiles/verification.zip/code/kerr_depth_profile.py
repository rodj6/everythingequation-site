from pathlib import Path
import numpy as np,json,csv,hashlib
root=Path(__file__).parent;path=root/'kerr_depth_source.json';seal=json.loads((root/'kerr_depth_seal.json').read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==seal['sha256'];source=json.loads(path.read_text());assert not seal['failures'] and len(source)==540
key=lambda r:(int(r['ell']),int(r['m']),int(r['n']),round(float(r['spin']),8));index={key(r):r for r in source};assert len(index)==540
actual=list(csv.DictReader((root.parent/'inputs/radial/inputs/kerr_development.csv').open()));pred=[];observed=[];comparison=[]
for row in actual:
 k=(int(row['ell']),int(row['m']),int(row['physical_n']),round(float(row['spin_a_over_M']),8));r=index[k];omega=complex(*r['omega']);obs=(float(row['raw_column_2'])+1j*float(row['raw_column_3']))/2;pred.append(-2*omega.imag);observed.append(float(row['source_lambda']));comparison.append(dict(ell=k[0],m=k[1],n=k[2],spin=k[3],pole_error=abs(omega-obs),source_residual=r['residual']))
C=np.load(root.parent/'inputs/hydrogen/inputs/constants.npy');T=12.115276586285876

def counts(rates):
 rates=np.array(rates);v=-np.expm1(-T*rates)/(T*rates);R=v[:,None]/v[None,:];off=~np.eye(len(v),dtype=bool);eligible=off&(R>.05)&(R<5);ex=int(eligible.sum());result=np.array([[np.count_nonzero(eligible&(R>=c*(1-t))&(R<=c*(1+t))) for c in C] for t in [.03,.01,.005]]);unions=[]
 for t in [.03,.01,.005]:
  matched=np.zeros(R.shape,bool)
  for c in C:matched|=(R>=c*(1-t))&(R<=c*(1+t))
  unions.append(int(np.count_nonzero(eligible&matched)))
 return result,ex,unions
p,pe,pu=counts(pred);o,oe,ou=counts(observed);result=dict(labels=540,source_sha256=seal['sha256'],maximum_pole_error=max(r['pole_error'] for r in comparison),predicted_exposure=pe,observed_exposure=oe,count_mismatches=int(np.count_nonzero(p-o)),predicted_counts=p.tolist(),observed_counts=o.tolist(),predicted_UNION=pu,observed_UNION=ou,RMS45=float(np.sqrt(np.mean((p/pe-o/oe)**2))),per_label=comparison,classification='full original development labels, source-derived continuation; numerical finite truncation, not formal pole certificate or unseen validation')
(root/'kerr_depth_profile.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['per_label','predicted_counts','observed_counts']},indent=2))

