from pathlib import Path
import json,numpy as np
root=Path(__file__).parent;sets=json.loads((root/'homometric_readout_check.json').read_text());responses=[]
for name in ['A','B']:
 v=np.log(2)*np.exp(np.array(sets[name])/100);rates=np.expm1(v);responses.append(dict(name=name,rates=rates.tolist(),mean_survival_t1=float(np.mean(np.exp(-rates))),mean_rate=float(np.mean(rates))))
difference=abs(responses[0]['mean_survival_t1']-responses[1]['mean_survival_t1']);result=dict(responses=responses,survival_difference=difference,frozen_threshold=1e-5,passes=difference>1e-5,classification='finite constructed-carrier calculation, no physical measurement')
(root/'response_discrimination.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
