exec((__import__('pathlib').Path(__file__).parent/'kerr_angular.py').read_text().split('for row in csv.DictReader')[0])
from scipy.optimize import root as solve_root
from qnm.radial import leaver_cf_trunc_inversion
import hashlib
original=json.loads((root/'kerr_full_source.json').read_text());results=[dict(r) for r in original];failures=[];paths=[]
for ell in range(3,7):
 for m in range(1,ell+1):
  for n in [2,3]:
   seed=next(r for r in original if r['ell']==ell and r['m']==m and r['n']==n and abs(r['spin']-.5)<1e-10);omega=complex(*seed['omega']);ev=np.linalg.eigvals(angular(m,.5*omega,20));Aprevious=ev[np.argmin(abs(ev-(ell*(ell+1)-2)))];older=None
   for a in np.linspace(.51,.9,40):
    guess=omega if older is None else 2*omega-older
    def fun(z):
     w=complex(*z);ev=np.linalg.eigvals(angular(m,a*w,20));A=ev[np.argmin(abs(ev-Aprevious))];f=leaver_cf_trunc_inversion(w,a,-2,m,A,n,N=1200);return [f.real,f.imag]
    sol=solve_root(fun,[guess.real,guess.imag],tol=1e-10);res=float(np.linalg.norm(fun(sol.x)));w=complex(*sol.x)
    if not sol.success or res>=1e-8:failures.append(dict(ell=ell,m=m,n=n,spin=float(a),residual=res));break
    paths.append(dict(ell=ell,m=m,n=n,spin=float(a),omega=[w.real,w.imag],residual=res));older,omega=omega,w;ev=np.linalg.eigvals(angular(m,a*w,20));Aprevious=ev[np.argmin(abs(ev-Aprevious))]
   else:
    r=next(r for r in results if r['ell']==ell and r['m']==m and r['n']==n and abs(r['spin']-.9)<1e-10);r.update(omega=[omega.real,omega.imag],residual=res)
  print('completed',ell,m,'failures',len(failures),flush=True)
path=root/'kerr_refined_source.json';path.write_text(json.dumps(results,indent=2));(root/'kerr_refined_seal.json').write_text(json.dumps(dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),labels=len(results),failures=failures),indent=2));(root/'kerr_refined_paths.json').write_text(json.dumps(paths,indent=2))
