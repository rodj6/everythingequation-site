import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,json
from scipy.spatial.distance import pdist,squareform
from scipy.stats import spearmanr
root=Path(__file__).parent;spec=json.loads((root/'SPATIAL_PREPARATION_SPEC.json').read_text(encoding='utf-8-sig'));C=np.load(root.parent/'inputs/hydrogen/inputs/constants.npy');rows=[];profiles=[]
for cov in spec['covariances']:
 rng=np.random.default_rng(spec['seed']);x=rng.standard_normal((spec['N'],2))*np.sqrt(cov);dist=pdist(x);sigma=float(np.median(dist));G=np.exp(-squareform(dist)**2/(2*sigma*sigma));L=np.diag(G.sum(1))-G;v=np.linalg.eigvalsh(L)[1:];ratio=v[:,None]/v[None,:];mask=~np.eye(len(v),dtype=bool)
 profile=np.array([[np.count_nonzero(mask&(ratio>=c*(1-t))&(ratio<=c*(1+t)))/(len(v)*(len(v)-1)) for c in C] for t in [.03,.01,.005]])
 B=np.array(cov)/(sigma*sigma+np.array(cov));logq=-.5*np.sum(x*x/(sigma*sigma+np.array(cov)),axis=1);pred=.5*float(B@B);actual=float(np.var(logq,ddof=1));profiles.append(profile)
 rows.append(dict(covariance=cov,sigma_squared=sigma*sigma,predicted_logq_variance=pred,sample_logq_variance=actual,relative_variance_error=abs(actual/pred-1),passes_frozen_tolerance=abs(actual/pred-1)<.25,profile=profile.tolist()))
for row,p in zip(rows,profiles):row['RMS45_vs_isotropic']=float(np.sqrt(np.mean((p-profiles[0])**2)));row['rank_3pct_vs_isotropic']=float(spearmanr(p[0],profiles[0][0]).statistic)
(root/'spatial_preparation_results.json').write_text(json.dumps(rows,indent=2));print(json.dumps([{k:v for k,v in r.items() if k!='profile'} for r in rows],indent=2))
