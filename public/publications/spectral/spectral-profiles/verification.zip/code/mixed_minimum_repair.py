exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from scipy.linalg import cho_factor,cho_solve
N=len(W);rest=helmert(N-1,full=False).T;w=W[0,1:];alpha=N/(N-1)*w.sum();H=rest.T@lap(W)[1:,1:]@rest;coupling=-np.sqrt(N/(N-1))*(rest.T@w);g=2*alpha;cho_factor(H-g*np.eye(len(H)));lower=0.;upper=float(alpha);history=[]
for step in range(8):
 def f(x):return float(alpha-coupling@cho_solve(cho_factor(H-x*np.eye(len(H))),coupling))
 lower,upper=max(lower,f(upper)),min(upper,f(lower));history.append([lower,upper])
geom=json.loads((root/'mixed_threshold_geometry.json').read_text());q=geom['reciprocal_upper_q'];l,u=geom['low_mode_interval'];threshold=[a*np.expm1(q*np.log1p(x/a)) for a in [lower,upper] for x in [l,u]]
result=dict(minimum_interval_history=history,threshold_interval=[min(threshold),max(threshold)],threshold_width=max(threshold)-min(threshold),classification='source Schur inequalities in floating arithmetic, no formal interval rounding or target diagonalization')
(root/'mixed_minimum_repair.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
