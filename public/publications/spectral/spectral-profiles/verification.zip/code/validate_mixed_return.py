from pathlib import Path
import csv,json,hashlib
root=Path(__file__).parent;source=root/'natural_signed_after_mixed.csv';seal=hashlib.sha256(source.read_bytes()).hexdigest();rows=list(csv.DictReader(source.open()));actual=list(csv.DictReader((root.parent/'inputs/hydrogen/results/validated_components.csv').open()));checks=[]
for r in rows:
 a=next(a for a in actual if a['case']=='natural' and a['width']==r['width'] and a['slot']==r['slot']);count=int(a['target_count']);checks.append(dict(width=r['width'],slot=r['slot'],target_count=count,contained=int(r['joint_lower_count'])<=count<=int(r['joint_upper_count'])))
result=dict(source_sha256=seal,all45_contained=all(c['contained'] for c in checks),checks=checks,classification='comparison with previously inspected i05 validation counts, not new holdout')
(root/'mixed_return_validation.json').write_text(json.dumps(result,indent=2));print(result['all45_contained'])
