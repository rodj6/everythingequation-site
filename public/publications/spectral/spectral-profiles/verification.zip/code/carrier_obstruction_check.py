from pathlib import Path
import numpy as np,json
root=Path(__file__).parent
z=np.load(root.parent/'inputs/hydrogen/inputs/h30_graph.npz');s=z['states'];index={tuple(x):i for i,x in enumerate(s)};edges={(int(i),int(j)):float(w) for i,j,w in zip(z['edge_i'],z['edge_j'],z['observed_weights'])};rows=[]
for a,b in [((2,0),(3,1)),((2,1),(3,2))]:
 i,j=index[a],index[b];w=edges.get((min(i,j),max(i,j)),0);factor=(a[1]+1)/(2*a[1]+1)
 assert w>0
 rows.append(dict(initial=a,final=b,radial_weight=w,angular_factor=factor,normalized_forward_rate=factor))
result=dict(transitions=rows,normalized_ratio=rows[0]['angular_factor']/rows[1]['angular_factor'],radial_prediction=1,classification='source-graph check under stipulated isotropic bath, not experiment')
(root/'carrier_obstruction_check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
