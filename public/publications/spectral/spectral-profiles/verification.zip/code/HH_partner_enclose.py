exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from scipy.linalg import solve
import math,time
required=json.loads((root/'HH_required_ranks.json').read_text())['partner_ranks'];sectors=json.loads((root/'HH_partner_gaps.json').read_text());prior=np.load(parent/'results/final_enclosures.npz');lo=prior['natural_lo'].copy();hi=prior['natural_hi'].copy();A=A0+E;beta=2*float((W*(lag>=4)).sum(1).max());receipts=[]
for sector in sectors:
 start,end=sector['core'];wanted=[k for k in required if start<=k<end];p0,p1=sector['retained'];p=np.arange(p0,p1);q=np.setdiff1d(np.arange(len(b)),p);D0=A0[np.ix_(q,q)];Eq=E[np.ix_(q,q)];C=A[np.ix_(p,q)];App=A[np.ix_(p,p)];rho=sector['uniform_series_ratio'];gap=sector['uniform_gap_before_far'];cn=float(norm(C,2));pref=cn*cn/gap/(1-rho);m=max(0,math.ceil(math.log(1e-4/pref)/math.log(rho))-1);error=pref*rho**(m+1)+.002;outside=int(np.count_nonzero(eigh(D0-sector['center']*np.eye(len(q)),eigvals_only=True)<0));cache={}
 def counts(x):
  if x not in cache:
   G=solve(D0-x*np.eye(len(q)),np.eye(len(q)),assume_a='sym');word=G@C.T;sig=C@word
   for j in range(m):word=-G@Eq@word;sig+=C@word
   vals=eigh(App-x*np.eye(len(p))-(sig+sig.T)/2,eigvals_only=True);cache[x]=(outside+int(np.count_nonzero(vals+error<0)),outside+int(np.count_nonzero(vals-error<0)))
  return cache[x]
 for k in wanted:
  left=max(float(lo[k]),sector['center']-sector['radius']);right=min(float(hi[k]),sector['center']+sector['radius']);original=[left,right];a1,b1=left,right
  for j in range(28):
   mid=(a1+b1)/2
   if counts(mid)[1]<=k:a1=mid
   else:b1=mid
  low=a1;a1,b1=left,right
  for j in range(28):
   mid=(a1+b1)/2
   if counts(mid)[0]>k:b1=mid
   else:a1=mid
  high=b1;lo[k]=max(lo[k],low);hi[k]=min(hi[k],high);assert lo[k]<=hi[k]
 receipts.append(dict(core=[start,end],ranks=wanted,degree=m,remainder_with_development_pad=error,queries=len(cache),max_width=float(max(hi[wanted]-lo[wanted]))));print(json.dumps(receipts[-1]),flush=True)
np.savez_compressed(root/'HH_partner_enclosures.npz',lo=lo,hi=hi);(root/'HH_partner_execution.json').write_text(json.dumps(receipts,indent=2))
