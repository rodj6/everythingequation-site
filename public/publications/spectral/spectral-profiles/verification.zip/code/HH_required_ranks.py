from pathlib import Path
import json,collections,numpy as np
root=Path(__file__).parent;records=json.loads((root/'HH_frontier_geometry.json').read_text())['pairs'];ranks=sorted({k for r in records for k in [r['i'],r['j']] if k>=96});low=sorted({k for r in records for k in [r['i'],r['j']] if 64<=k<96});groups=collections.defaultdict(list)
for k in ranks:groups[k//32*32].append(k)
result=dict(partner_ranks=ranks,partner_count=len(ranks),low_ranks=low,low_count=len(low),groups=dict(groups),next='refine only these partner ranks; original selected low core retained')
(root/'HH_required_ranks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
