from fractions import Fraction as F
from pathlib import Path
import json
x=[F(1,2),F(2,3),F(3,4),F(3,4)];m=len(x);power=[None]+[sum((v**k for v in x),F(0)) for k in range(1,m+1)];e=[F(1)]
for k in range(1,m+1):e.append(sum(((-1)**(i-1)*e[k-i]*power[i] for i in range(1,k+1)),F(0))/k)
coeff=[(-1)**k*e[k] for k in range(m+1)]
remaining=coeff.copy()
for value in x:
 quotient=[remaining[0]]
 for c in remaining[1:-1]:quotient.append(c+value*quotient[-1])
 remainder=remaining[-1]+value*quotient[-1];assert remainder==0;remaining=quotient
assert remaining==[F(1)]
a=F(1,2);delta=F(1,1000);moment_change=(a-delta)**2+(a+delta)**2-2*a*a;assert moment_change==2*delta**2
result=dict(mode_count=m,survival_samples=[str(power[k]/m) for k in range(1,m+1)],polynomial_coefficients=[str(c) for c in coeff],exact_factorization_pass=True,repeated_modes_retained=True,cluster_example=dict(split=str(delta),second_power_sum_change=str(moment_change)),scope='exact finite equal-weight response reconstruction, not a noisy experimental inversion guarantee')
Path(__file__).with_name('FINITE_RESPONSE_RECONSTRUCTION.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
