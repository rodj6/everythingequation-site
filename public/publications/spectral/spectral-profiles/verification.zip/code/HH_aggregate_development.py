from pathlib import Path
import numpy as np,json,csv,hashlib
root=Path(__file__).parent;parent=root.parent/'inputs/hydrogen';rows=list(csv.DictReader((root/'natural_signed_after_mixed.csv').open()));hh=json.loads((root/'HH_count_development.json').read_text());z=np.load(parent/'results/final_enclosures.npz');lo=z['natural_lo'];hi=z['natural_hi'];amin,amax=json.loads((root/'mixed_residual_budget.json').read_text())['minimum_interval'];exp=464*463;changes=[]
for h in hh:
 row=next(r for r in rows if float(r['width'])==h['width'] and int(r['slot'])==h['slot']);t=h['width'];c=float(row['constant']);bounds=[]
 for a in [amin,amax]:
  vl=np.log1p(lo[:64]/a);vh=np.log1p(hi[:64]/a);vl[0]=vh[0]=np.log(2);bounds.append((vl[:,None]/vh[None,:],vh[:,None]/vl[None,:]))
 low=np.minimum(bounds[0][0],bounds[1][0]);high=np.maximum(bounds[0][1],bounds[1][1]);mask=~np.eye(64,dtype=bool);ll=int(np.count_nonzero(mask&(low>=c*(1-t))&(high<=c*(1+t))));lu=int(np.count_nonzero(mask&(high>=c*(1-t))&(low<=c*(1+t))));ml=int(row['focus_mixed_lower']);mu=int(row['focus_mixed_upper']);total_low=max(int(row['joint_lower_count']),ll+ml+h['HH_lower']);total_high=min(int(row['joint_upper_count']),lu+mu+h['HH_upper']);assert total_low<=total_high
 row.update(joint_lower_count=str(total_low),joint_upper_count=str(total_high),joint_signed_lower=str((total_low-int(row['base_count']))/exp),joint_signed_upper=str((total_high-int(row['base_count']))/exp),focus_HH_lower=str(h['HH_lower']),focus_HH_upper=str(h['HH_upper']));changes.append(dict(width=t,slot=h['slot'],LL=[ll,lu],mixed=[ml,mu],HH=[h['HH_lower'],h['HH_upper']],total=[total_low,total_high]))
path=root/'natural_signed_development.csv'
with path.open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary=dict(exact_coordinates=sum(r['joint_lower_count']==r['joint_upper_count'] for r in rows),RMS45=float(np.sqrt(np.mean([float(r['joint_signed_lower'])**2 for r in rows]))),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),changes=changes,classification='development point-count result, arithmetic promotion gate still open')
(root/'HH_aggregate_development.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
# Prior validation is consulted only after source table is saved and hashed.
actual=list(csv.DictReader((parent/'results/validated_components.csv').open()));checks=[]
for r in rows:
 a=next(a for a in actual if a['case']=='natural' and a['width']==r['width'] and a['slot']==r['slot']);checks.append(int(r['joint_lower_count'])<=int(a['target_count'])<=int(r['joint_upper_count']))
(root/'HH_aggregate_validation.json').write_text(json.dumps(dict(all45_contained=all(checks),source_sha256=summary['source_sha256'],classification='previously inspected validation counts'),indent=2));print('all45_contained',all(checks))
