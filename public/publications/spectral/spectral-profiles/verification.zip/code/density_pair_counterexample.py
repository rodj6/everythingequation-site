from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
ensembles={'anticorrelated':[(F(1),[F(1),F(2)])],'clustered':[(F(1,2),[F(1),F(1)]),(F(1,2),[F(2),F(2)])]};results={}
for name,ensemble in ensembles.items():
 density=Counter();hit=F(0)
 for weight,values in ensemble:
  for v in values:density[v]+=weight
  hits=sum(F(97,50)<=a/b<=F(103,50) for i,a in enumerate(values) for j,b in enumerate(values) if i!=j);hit+=weight*F(hits,2)
 results[name]={'mean_counting_density':{str(k):str(v) for k,v in density.items()},'expected_incidence_near_2':str(hit)}
assert results['anticorrelated']['mean_counting_density']==results['clustered']['mean_counting_density'];assert results['anticorrelated']['expected_incidence_near_2']=='1/2';assert results['clustered']['expected_incidence_near_2']=='0'
out=dict(results=results,scope='exact finite two-mode ensemble witness; multiplicities and nonself exposure retained; not original-data experiment')
Path(__file__).with_name('density_pair_counterexample.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
