exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from scipy.linalg import solve
z=np.load(root/'HH_partner_enclosures.npz');sectors=json.loads((root/'HH_partner_gaps.json').read_text());receipts=json.loads((root/'HH_partner_execution.json').read_text());A=A0+E;L=lap(W);eps=np.finfo(float).eps/2;n=len(b);gamma=500*eps/(1-500*eps)
# Original-coordinate intertwining plus polar-factor defect charges assembly
# relative to the orthogonalized supplied baseline basis.
orth=float(norm(V.T@V-np.eye(n),'fro'));intertwine=float(norm(L@V-V@A,'fro'));assembly=intertwine+2*float(norm(L,'fro'))*orth+20*gamma*float(norm(L,'fro'))
checks=[]
assert orth<.5 and assembly>=0

for sector,rec in zip(sectors,receipts):
 p0,p1=sector['retained'];p=np.arange(p0,p1);q=np.setdiff1d(np.arange(n),p);C=A[np.ix_(p,q)];D=A[np.ix_(q,q)];App=A[np.ix_(p,p)];cn=float(norm(C,'fro'))
 dc=D-sector['center']*np.eye(len(q));ev,U=eigh(dc);eta=float(norm(U.T@U-np.eye(len(q)),'fro'));er=float(norm(dc@U-U*ev,'fro'))+2*float(norm(dc,'fro'))*eta+20*gamma*float(norm(dc,'fro'));gap=float(min(abs(ev)))-er-sector['radius']-assembly;assert gap>0;h=1/gap;outside=int(np.count_nonzero(ev<0))
 for rank in rec['ranks']:
  for side,x in [('lower',z['lo'][rank]),('upper',z['hi'][rank])]:
   M=D-x*np.eye(len(q));Z=solve(M,C.T,assume_a='sym');res=float(norm(M@Z-C.T,'fro'));resbudget=res+4*gamma*(float(norm(M,'fro'))*float(norm(Z,'fro'))+cn);S=App-x*np.eye(len(p))-C@Z;S=(S+S.T)/2;vals,U=eigh(S);eta=float(norm(U.T@U-np.eye(len(p)),'fro'));eigenbudget=float(norm(S@U-U*vals,'fro'))+2*float(norm(S,'fro'))*eta+20*gamma*float(norm(S,'fro'));productbudget=4*gamma*(cn*float(norm(Z,'fro'))+float(norm(App,'fro'))+abs(x)*np.sqrt(len(p)));perturb=assembly*(1+cn*h)**2/(1-assembly*h);total=cn*h*resbudget+productbudget+eigenbudget+perturb;assert eta<.5 and assembly*h<1 and gap>0
   nlo=outside+int(np.count_nonzero(vals+total<0));nhi=outside+int(np.count_nonzero(vals-total<0));valid=nhi<=rank if side=='lower' else nlo>rank
   checks.append(dict(rank=rank,side=side,total_budget=total,solve_budget=cn*h*resbudget,eigen_budget=eigenbudget,product_budget=productbudget,assembly_transport_budget=perturb,exterior_gap=gap,transport_ratio=assembly*h,eigen_orthogonality_defect=eta,retained_eigenvalues=vals.tolist(),outside_inertia=outside,lower_inertia=nlo,upper_inertia=nhi,verified=valid))
result=dict(assembly_budget=assembly,orthogonality_defect=orth,maximum_endpoint_budget=max(c['total_budget'] for c in checks),all106_verified=all(c['verified'] for c in checks),checks=checks,classification='residual and standard floating-operation model, not formally outward rounded; verifies endpoints without certifying each series query')
(root/'HH_arithmetic_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))

