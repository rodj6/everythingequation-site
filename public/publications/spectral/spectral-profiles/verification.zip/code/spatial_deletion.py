from pathlib import Path
import numpy as np,json
from scipy.spatial.distance import pdist,squareform
root=Path(__file__).parent;rows=[];C=np.load(root.parent/'inputs/hydrogen/inputs/constants.npy')
def graph(x,sigma=None):
 d=pdist(x);sigma=float(np.median(d)) if sigma is None else sigma;G=np.exp(-squareform(d)**2/(2*sigma*sigma));return np.diag(G.sum(1))-G,G,sigma
def profile(v):
 R=v[:,None]/v[None,:];mask=~np.eye(len(v),dtype=bool);return np.array([[np.count_nonzero(mask&(R>=c*(1-t))&(R<=c*(1+t)))/(len(v)*(len(v)-1)) for c in C] for t in [.03,.01,.005]])
for name in ['embryo','spiral_galaxy','leaf']:
 x=np.load(root.parent/('inputs/spatial/spatial_reconstruction_'+name+'.npz'))['points'];L,G,sigma=graph(x);fixed,_,_=graph(x[1:],sigma);updated,_,sp=graph(x[1:]);identity=float(np.linalg.norm(L[1:,1:]-fixed-np.diag(G[1:,0]),'fro'));assert identity<1e-8;original=profile(np.linalg.eigvalsh(L)[1:]);pf=profile(np.linalg.eigvalsh(fixed)[1:]);pu=profile(np.linalg.eigvalsh(updated)[1:]);rows.append(dict(dataset=name,original_N=len(x),deleted_index=0,identity_residual=identity,removed_edge_diagonal_norm=float(max(G[1:,0])),relative_bandwidth_change=abs(sp/sigma-1),RMS45_fixed_bandwidth=float(np.sqrt(np.mean((pf-original)**2))),RMS45_recomputed_bandwidth=float(np.sqrt(np.mean((pu-original)**2)))))
(root/'spatial_deletion_results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
