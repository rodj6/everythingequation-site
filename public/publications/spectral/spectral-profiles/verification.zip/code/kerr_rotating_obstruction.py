from pathlib import Path
import json,numpy as np
root=Path(__file__).parent;source=json.loads((root/'kerr_overtone_source.json').read_text());rows=[]
for m in [2,-1]:
 for a in sorted({r['spin'] for r in source}):
  family=sorted([r for r in source if r['m']==m and r['spin']==a],key=lambda r:r['n'])
  if len(family)!=4:continue
  omegas=np.array([complex(*r['omega']) for r in family]);frequency=omegas.real;damping=-2*omegas.imag
  for i in range(3):
   rows.append(dict(m=m,spin=a,n_low=i,n_high=i+1,damping_change=float(damping[i+1]-damping[i]),frequency_change=float(frequency[i+1]-frequency[i]),monotone_symbol_inversion=bool(damping[i+1]>damping[i] and frequency[i+1]<frequency[i])))
result=dict(adjacent_comparisons=len(rows),inversions=sum(r['monotone_symbol_inversion'] for r in rows),minimum_damping_increase=min(r['damping_change'] for r in rows),largest_frequency_change=max(r['frequency_change'] for r in rows),rows=rows,classification='source-computed development trajectories; no observed rates used in this comparison')
(root/'kerr_rotating_obstruction.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
