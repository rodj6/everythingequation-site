from pathlib import Path
from fractions import Fraction as F
import numpy as np,json,hashlib
root=Path(__file__).parent;ns={};exec((root.parent/'inputs/radial/radial.py').read_text(),ns);radial=ns['squared_radial'];z=np.load(root.parent/'inputs/hydrogen/inputs/h30_graph.npz');s=z['states'];u=F(1,2**53);binary_far=[F(0) for _ in s];exact_far=[F(0) for _ in s];max_relative=F(0);digest=hashlib.sha256();calls=0
for i0,j0,value in zip(z['edge_i'],z['edge_j'],z['observed_weights']):
 i,j=int(i0),int(j0);n,l=map(int,s[i]);m,k=map(int,s[j]);weight,_=radial(n,l,m,k);stored=F.from_float(float(value));assert weight>0 and float(weight)==value;relative=abs(stored-weight)/weight;assert relative<=u;max_relative=max(max_relative,relative);calls+=1;digest.update((str(i)+','+str(j)+','+str(weight)+'\n').encode())
 if abs(n-m)>=4:
  binary_far[i]+=stored;binary_far[j]+=stored;exact_far[i]+=weight;exact_far[j]+=weight
budget=json.loads((root/'radial_exact_budget.json').read_text());checks=[];beta=F.from_float(budget['binary64_far_beta_upper'])
for i,row in enumerate(budget['rows']):
 b=F(row['far_bound_exact']);assert exact_far[i]<=b;assert binary_far[i]<=b/(1-u);assert 2*binary_far[i]<=beta;checks.append(dict(n=row['n'],ell=row['ell'],exact_far_within_budget=True,binary_far_within_scalar_upper=True))
result=dict(exact_edge_calls=calls,all8990_stored_weights_match=True,all465_row_bounds_verified_exactly=True,maximum_relative_rounding_error=float(max_relative),unit_roundoff=float(u),exact_edge_stream_sha256=digest.hexdigest(),binary64_far_beta_upper=budget['binary64_far_beta_upper'],checks=checks,classification='exact rational scalar/edge certificate for supplied graph; does not certify floating matrix inverses or inertia')
(root/'RADIAL_EDGE_CERTIFICATE.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
