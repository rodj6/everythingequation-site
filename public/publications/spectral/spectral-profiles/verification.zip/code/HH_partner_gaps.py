exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
spec=json.loads((root/'HH_PARTNER_SPEC.json').read_text(encoding='utf-8-sig'));prior=np.load(parent/'results/final_enclosures.npz');lo=prior['natural_lo'];hi=prior['natural_hi'];beta=2*float((W*(lag>=4)).sum(1).max());rows=[]
for start,end in spec['cores']:
 p0=max(0,start-32);p1=min(len(b),end+32);q=np.setdiff1d(np.arange(len(b)),np.arange(p0,p1));left=float(lo[start]);right=float(hi[end-1]);center=(left+right)/2;r=(right-left)/2;D=A0[np.ix_(q,q)]-center*np.eye(len(q));gap=float(abs(eigh(D,eigvals_only=True)).min());available=gap-r
 rows.append(dict(core=[start,end],retained=[p0,p1],dimension=p1-p0,center=center,radius=r,center_gap=gap,uniform_gap_before_far=available,far_graph_bound=beta,uniform_series_ratio=beta/available if available>0 else None,eligible=available>beta))
(root/'HH_partner_gaps.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
