exec((__import__('pathlib').Path(__file__).parent/'kerr_angular.py').read_text().split('for row in csv.DictReader')[0])
from scipy.optimize import root as solve_root
from qnm.radial import leaver_cf_trunc_inversion
import hashlib
seedrows=list(csv.DictReader((root.parent/'inputs/barrier/results/kerr_shape_modes.csv').open()));seeds={}
for r in seedrows:
 if int(r['order'])==3:seeds[(int(r['ell']),int(r['n']))]=float(r['frequency'])-.5j*float(r['rate'])
results=[];failures=[]
for ell in range(2,7):
 for n in range(4):
  for m in range(-ell,ell+1):
   omega=seeds[ell,n];Aprevious=complex(ell*(ell+1)-2)
   for a in np.linspace(0,.9,19):
    def fun(z):
     w=complex(*z);ev=np.linalg.eigvals(angular(m,a*w,20));A=ev[np.argmin(abs(ev-Aprevious))];f=leaver_cf_trunc_inversion(w,a,-2,m,A,n,N=1200);return [f.real,f.imag]
    sol=solve_root(fun,[omega.real,omega.imag],tol=1e-10);res=float(np.linalg.norm(fun(sol.x)));w=complex(*sol.x);accepted=bool(sol.success and res<1e-8)
    if not accepted:failures.append(dict(ell=ell,m=m,n=n,spin=float(a),residual=res,message=str(sol.message)));break
    omega=w;ev=np.linalg.eigvals(angular(m,a*w,20));Aprevious=ev[np.argmin(abs(ev-Aprevious))]
    if min(abs(a-s) for s in [0,.5,.9])<1e-10:results.append(dict(ell=ell,m=m,n=n,spin=float(a),omega=[w.real,w.imag],residual=res))
  (root/'kerr_full_progress.json').write_text(json.dumps(dict(completed_ell=ell,completed_n=n,labels=len(results),failures=failures),indent=2));print('completed',ell,n,'labels',len(results),'failures',len(failures),flush=True)
path=root/'kerr_full_source.json';path.write_text(json.dumps(results,indent=2));(root/'kerr_full_seal.json').write_text(json.dumps(dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),labels=len(results),failures=failures),indent=2))
