from pathlib import Path
import numpy as np,json,csv
root=Path(__file__).parent;parent=root.parent/'inputs/hydrogen';z=np.load(root/'HH_partner_enclosures.npz');lo=z['lo'];hi=z['hi'];a0,a1=json.loads((root/'mixed_residual_budget.json').read_text())['minimum_interval'];C=np.load(parent/'inputs/constants.npy');lows=[];highs=[]
for a in [a0,a1]:
 vl=np.log1p(lo/a);vh=np.log1p(hi/a);lows.append(vl[:,None]/vh[None,:]);highs.append(vh[:,None]/vl[None,:])
rl=np.minimum(*lows);rh=np.maximum(*highs);mask=np.ones(rl.shape,bool);mask[:64,:]=False;mask[:,:64]=False;np.fill_diagonal(mask,False);rows=list(csv.DictReader((root/'natural_signed_after_mixed.csv').open()));result=[]
for t in [.03,.01,.005]:
 for constant in [np.sqrt(2),np.log(2)]:
  k=int(np.argmin(abs(C-constant)));left=C[k]*(1-t);right=C[k]*(1+t);sure=int(np.count_nonzero(mask&(rl>=left)&(rh<=right)));possible=int(np.count_nonzero(mask&(rh>=left)&(rl<=right)));old=next(r for r in rows if float(r['width'])==t and int(r['slot'])==k)
  result.append(dict(width=t,slot=k,HH_lower=sure,HH_upper=possible,HH_width=possible-sure,previous_HH_lower=int(old['focus_HH_lower']),previous_HH_upper=int(old['focus_HH_upper'])))
(root/'HH_count_development.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
