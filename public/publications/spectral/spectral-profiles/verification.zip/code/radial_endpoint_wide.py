exec((__import__('pathlib').Path(__file__).parent/'shell_gap_probe.py').read_text().split('rows=[]')[0])
from scipy.linalg import solve
z=np.load(root/'HH_partner_enclosures.npz');lo=z['lo'].copy();hi=z['hi'].copy();beta=json.loads((root/'radial_external_bound.json').read_text())['beta'];sectors=json.loads((root/'HH_partner_gaps.json').read_text());receipts=json.loads((root/'HH_partner_execution.json').read_text());assembly=json.loads((root/'HH_arithmetic_audit.json').read_text())['assembly_budget'];A=A0+E;gamma=500*np.finfo(float).eps/(1-500*np.finfo(float).eps);checks=[]
for sec,rec in zip(sectors,receipts):
 p0,p1=sec['retained'];p=np.arange(p0,p1);q=np.setdiff1d(np.arange(len(b)),p);D0=A0[np.ix_(q,q)];Eq=E[np.ix_(q,q)];C=A[np.ix_(p,q)];App=A[np.ix_(p,p)];cn=float(norm(C,'fro'));d=sec['uniform_gap_before_far']-1.;h0=1/d;rho=beta/d;h=h0/(1-rho);m=rec['degree'];outside=int(np.count_nonzero(eigh(D0-sec['center']*np.eye(len(q)),eigvals_only=True)<0))
 dc=D0-sec['center']*np.eye(len(q));ev0,U0=eigh(dc);eta0=float(norm(U0.T@U0-np.eye(len(q)),'fro'));gap_error=float(norm(dc@U0-U0*ev0,'fro'))+2*float(norm(dc,'fro'))*eta0+20*gamma*float(norm(dc,'fro'))+assembly
 d=float(min(abs(ev0)))-gap_error-sec['radius']-1.;assert d>beta;h0=1/d;rho=beta/d;h=h0/(1-rho);outside=int(np.count_nonzero(ev0<0))
 for rank in rec['ranks']:
  lo[rank]-=1.;hi[rank]+=1.
  for side,x in [('lower',lo[rank]),('upper',hi[rank])]:
   M=D0-x*np.eye(len(q));G=solve(M,np.eye(len(q)),assume_a='sym');eta=float(norm(M@G-np.eye(len(q)),'fro'))+4*gamma*float(norm(M,'fro'))*float(norm(G,'fro'));inverse_error=h0*eta;word=G@C.T;sig=C@word
   for j in range(m):word=-G@Eq@word;sig+=C@word
   tail=cn*cn*h0*rho**(m+1)/(1-rho);substitution=cn*cn*inverse_error/(1-rho)**2;products=16*gamma*(m+1)*cn*cn*h0/(1-rho)**2;transport=assembly*(1+cn*h)**2/(1-assembly*h);S=App-x*np.eye(len(p))-(sig+sig.T)/2;vals,U=eigh(S);orth=float(norm(U.T@U-np.eye(len(p)),'fro'));eigen=float(norm(S@U-U*vals,'fro'))+2*float(norm(S,'fro'))*orth+20*gamma*float(norm(S,'fro'));error=tail+substitution+products+transport+eigen+.001;nlo=outside+int(np.count_nonzero(vals+error<0));nhi=outside+int(np.count_nonzero(vals-error<0));valid=nhi<=rank if side=='lower' else nlo>rank;assert eta<1 and orth<.5 and eta0<.5 and assembly*h<1;checks.append(dict(rank=rank,side=side,tail=tail,inverse_substitution=substitution,total_error=error,products=products,transport=transport,eigen=eigen,pad=.001,exterior_gap=d,far_beta=beta,series_ratio=rho,inverse_residual=eta,transport_ratio=assembly*h,eigen_orthogonality_defect=orth,retained_eigenvalues=vals.tolist(),outside_inertia=outside,lower_inertia=nlo,upper_inertia=nhi,verified=valid))
result=dict(checks=checks,all106_verified=all(r['verified'] for r in checks),maximum_error=max(r['total_error'] for r in checks),classification='radial external-channel bound plus residual-model arithmetic; widened source endpoints, not formal directed intervals')
(root/'radial_endpoint_wide.json').write_text(json.dumps(result,indent=2));np.savez_compressed(root/'radial_partner_wide.npz',lo=lo,hi=hi);print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))

