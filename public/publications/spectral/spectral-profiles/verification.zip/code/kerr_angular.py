from pathlib import Path
import numpy as np,json,csv
root=Path(__file__).parent
rows=[]
def angular(m,c,L):
 s=-2;ls=np.arange(max(abs(m),2),L+2);X=np.diag(-m*s/(ls*(ls+1)))
 for i,l in enumerate(ls[:-1]):
  f=np.sqrt(((l+1)**2-m*m)/((2*l+3)*(2*l+1)))*np.sqrt(((l+1)**2-s*s)/(l+1)**2);X[i,i+1]=X[i+1,i]=f
 return np.diag(ls[:-1]*(ls[:-1]+1)-s*(s+1))-c*c*(X@X)[:-1,:-1]+2*c*s*X[:-1,:-1]
for row in csv.DictReader((root.parent/'inputs/radial/inputs/kerr_development.csv').open()):
 a=float(row['spin_a_over_M']);m=int(row['m']);ell=int(row['ell']);omega=(float(row['raw_column_2'])+1j*float(row['raw_column_3']))/2;target=float(row['raw_column_4'])+1j*float(row['raw_column_5']);values=[]
 for L in [12,20]:
  A=complex(ell*(ell+1)-2)
  for t in np.linspace(0,1,17)[1:]:
   ev=np.linalg.eigvals(angular(m,t*a*omega,L));A=ev[np.argmin(abs(ev-A))]
  values.append(A)
 rows.append(dict(spin=a,ell=ell,m=m,n=int(row['physical_n']),cutoff_difference=float(abs(values[1]-values[0])),source_difference=float(abs(values[1]-target))))
result=dict(labels=len(rows),maximum_cutoff_difference=max(r['cutoff_difference'] for r in rows),maximum_source_difference=max(r['source_difference'] for r in rows),rotating_labels=sum(r['spin']>0 for r in rows),rows=rows)
(root/'kerr_angular_results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
