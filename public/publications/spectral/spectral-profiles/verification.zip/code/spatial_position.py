from pathlib import Path
import numpy as np,json
from scipy.spatial.distance import pdist,squareform
from scipy.linalg import eigvalsh
root=Path(__file__).parent;spec=json.loads((root/'SPATIAL_POSITION_SPEC.json').read_text(encoding='utf-8-sig'));rows=[]
def graph(x):
 d=pdist(x);sigma=float(np.median(d));G=np.exp(-squareform(d)**2/(2*sigma*sigma));return np.diag(G.sum(1))-G,sigma
for name in spec['datasets']:
 z=np.load(root.parent/('inputs/spatial/spatial_reconstruction_'+name+'.npz'));x=z['points'];L,sigma=graph(x);rng=np.random.default_rng(spec['seed']);directions=rng.standard_normal(x.shape);directions/=np.maximum(np.linalg.norm(directions,axis=1,keepdims=True),1e-30)
 for rel in spec['relative_position_errors']:
  epsilon=rel*sigma;Lp,sp=graph(x+epsilon*directions);delta=2*epsilon*np.exp(-.5)/sigma+2/np.e*abs(np.log1p(-2*epsilon/sigma));bound=2*(len(x)-1)*min(1,delta);ev=eigvalsh(Lp-L);actual=float(max(abs(ev)));rows.append(dict(dataset=name,N=len(x),relative_position_error=rel,relative_bandwidth_change=abs(sp/sigma-1),operator_bound=bound,observed_operator_change=actual,passes=bool(actual<=bound)))
(root/'spatial_position_results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))

