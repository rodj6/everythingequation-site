"""Reconstruct ground/core controls from source edges, including every45-cell vector."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import argparse,json,csv,numpy as np
from scipy.linalg import eigh,helmert,cho_factor,cho_solve
from scipy.optimize import brentq
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out)
if out.exists():raise SystemExit('Use a fresh output directory.')
out.mkdir(parents=True);root=Path(__file__).resolve().parent;z=np.load(root/'inputs/hydrogen/inputs/h30_graph.npz');s=z['states'];C=np.load(root/'inputs/hydrogen/inputs/constants.npy');W=np.zeros((465,465));W[z['edge_i'],z['edge_j']]=z['observed_weights'];W+=W.T
def lap(w):return np.diag(w.sum(1))-w
def profile(v):
 r=v[:,None]/v[None,:];mask=~np.eye(len(v),dtype=bool)
 return np.array([[np.count_nonzero(mask&(r>=c*(1-t))&(r<=c*(1+t))) for c in C] for t in [.03,.01,.005]],dtype=int)
def rms(x):return float(np.sqrt(np.mean(x*x)))
Q=helmert(465,full=False).T;rest=helmert(464,full=False).T;WB=W*(abs(s[:,0,None]-s[None,:,0])<=1);lost=W-WB;ground=lost.copy();ground[1:,1:]=0;core=lost-ground;b,U=eigh(Q.T@lap(WB)@Q);V=Q@U;base=profile(np.log1p(b/b[0]));ref={r['case']:r for r in json.loads((root/'references/control_reference.json').read_text())};records=[];vectors={}
for name,g,c in [('natural',1,1),('ground',1,0),('core',0,1),('half_ground',.5,1),('half_core',1,.5),('new_75g25c',.75,.25)]:
 weights=WB+g*ground+c*core;L=lap(weights);alpha=465/464*weights[0].sum();H=rest.T@L[1:,1:]@rest;coupling=-np.sqrt(465/464)*(rest.T@weights[0,1:]);minimum=brentq(lambda x:alpha-x-coupling@cho_solve(cho_factor(H-x*np.eye(463)),coupling),.5,alpha,xtol=1e-13)
 A=np.diag(b)+V.T@lap(g*ground+c*core)@V;pred=np.sort(np.concatenate([eigh(A[j:j+16,j:j+16],eigvals_only=True) for j in range(0,464,16)]));pred[0]=minimum;actual=eigh(Q.T@L@Q,eigvals_only=True);assert abs(actual[0]-minimum)<1e-7
 target=profile(np.log1p(actual/minimum));prediction=profile(np.log1p(pred/minimum));fixedminbase=profile(np.log1p(b/minimum));spectral=(fixedminbase-target)/214832;normal=(base-fixedminbase)/214832;total=(base-target)/214832;assert np.array_equal((fixedminbase-target)+(base-fixedminbase),base-target)
 den=float(np.linalg.norm(spectral)*np.linalg.norm(normal));cos=float(np.sum(spectral*normal)/den) if den else None
 row={'case':name,'ground_coefficient':g,'core_coefficient':c,'actual_RMS45':rms(total),'predicted_RMS45':rms((prediction-base)/214832),'prediction_error_RMS45':rms((prediction-target)/214832),'spectral_RMS45':rms(spectral),'normalization_RMS45':rms(normal),'actual_signed_cosine':cos,'source_minimum':minimum}
 for new,old in [('actual_RMS45','actual_uncorrected_discrepancy_RMS'),('predicted_RMS45','fixed_predicted_uncorrected_discrepancy'),('prediction_error_RMS45','fixed_prediction_error_RMS')]:assert abs(row[new]-ref[name][old])<1e-12,(name,new,row[new],ref[name][old])
 records.append(row);vectors[name]={'target_counts':target.tolist(),'prediction_counts':prediction.tolist(),'baseline_counts':base.tolist(),'fixed_full_minimum_baseline_counts':fixedminbase.tolist(),'spectral_incidence':spectral.tolist(),'normalization_incidence':normal.tolist()}
(out/'hydrogen_controls.json').write_text(json.dumps({'records':records,'vectors':vectors,'all_reference_metrics_match':True,'definition':'Uncorrected discrepancy is baseline own-minimum profile minus target own-minimum profile. Spectral plus normalization vectors equal this signed discrepancy. Known development controls.'},indent=2))
with (out/'hydrogen_controls.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print(json.dumps(records,indent=2))
