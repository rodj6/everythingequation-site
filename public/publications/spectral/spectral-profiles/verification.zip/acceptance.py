"""Scientific acceptance rules, separate from incidental numerical diagnostics."""
import math

def endpoint_audit(got, reference):
    """Recompute 106 inertia decisions from recomputed spectra and error terms.

    No saved residual/error-budget value is a target. The invariant is that
    every named rank endpoint remains proved by its own positive gap and budget.
    """
    try:
        expected=[(r['rank'],r['side']) for r in reference['checks']]
        rows=got['checks']
        if len(expected)!=106 or [(r['rank'],r['side']) for r in rows]!=expected:return False
        if not 0<=got['orthogonality_defect']<.5:return False
        if not math.isfinite(got['assembly_budget']) or got['assembly_budget']<0:return False
        for r in rows:
            terms=[r[k] for k in ['solve_budget','eigen_budget','product_budget','assembly_transport_budget']]
            if not all(math.isfinite(v) and v>=0 for v in terms):return False
            budget=r['total_budget']
            if not math.isfinite(budget) or budget<0 or not math.isclose(budget,sum(terms),rel_tol=1e-12,abs_tol=1e-15):return False
            if not math.isfinite(r['exterior_gap']) or r['exterior_gap']<=0:return False
            if not 0<=r['transport_ratio']<1 or not 0<=r['eigen_orthogonality_defect']<.5:return False
            vals=r['retained_eigenvalues']
            if not vals or not all(math.isfinite(v) for v in vals):return False
            outside=r['outside_inertia']
            if len(vals) not in (48,96) or type(outside) is not int or not 0<=outside<=464-len(vals):return False
            lower=outside+sum(v+budget<0 for v in vals)
            upper=outside+sum(v-budget<0 for v in vals)
            if lower!=r['lower_inertia'] or upper!=r['upper_inertia']:return False
            valid=upper<=r['rank'] if r['side']=='lower' else lower>r['rank']
            if not valid or r['verified'] is not True:return False
        return got['all106_verified'] is True and math.isclose(got['maximum_endpoint_budget'],max(r['total_budget'] for r in rows),rel_tol=1e-12)
    except (KeyError,TypeError,ValueError,OverflowError):return False

def radial_endpoint_audit(got,reference):
    try:
        for row in got['checks']:
            if not 0<=row['inverse_residual']<1 or not 0<=row['series_ratio']<1:return False
            if not math.isfinite(row['far_beta']) or not 0<=row['far_beta']<row['exterior_gap']:return False
            if not math.isclose(row['series_ratio'],row['far_beta']/row['exterior_gap'],rel_tol=1e-12):return False
            if row['pad']!=.001:return False
        canonical={'checks':[], 'assembly_budget':0.,'orthogonality_defect':0.,'all106_verified':got['all106_verified'],'maximum_endpoint_budget':got['maximum_error']}
        for row in got['checks']:
            r=dict(row);r.update(total_budget=row['total_error'],solve_budget=row['inverse_substitution'],eigen_budget=row['eigen'],product_budget=row['products']+row['tail']+row['pad'],assembly_transport_budget=row['transport']);canonical['checks'].append(r)
        return endpoint_audit(canonical,reference)
    except (KeyError,TypeError,ValueError,ZeroDivisionError):return False

def accept(script,got,reference,equivalent):
    if script=='radial_endpoint_wide':return radial_endpoint_audit(got,reference),'recomputed radial-series endpoint inequalities'
    if script=='HH_arithmetic_audit':return endpoint_audit(got,reference),'recomputed endpoint inequality certificate'
    return equivalent(got,reference),'exact discrete results and unchanged numeric comparison'
