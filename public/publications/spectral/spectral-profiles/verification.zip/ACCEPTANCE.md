# Scientific acceptance and numerical portability

Input integrity is checked before replay. Scripts run in a fresh output workspace. Scientific invariants, discrete results and incidental numerical diagnostics have different acceptance rules.

## Exact and discrete results

Ordered labels, all45 count coordinates, rank/side coverage, multiplicities, exposure counts, fixture Booleans and exact rational/integer identities remain exact checks. Scalar spectra and other numerical predictions retain the original relative2e-8/absolute2e-9 comparison rule unless a named inequality certificate below applies. This revision does not increase those tolerances. Hash fields and timing fields are not numerical prediction targets; the input manifest authenticates content separately.

## Recomputed endpoint inequalities

`HH_arithmetic_audit.py` recalculates the source matrix, assembly transport, exterior gaps, solve residuals, eigen residuals and multiplication allowances. It now retains each endpoint's computed Schur eigenvalues, exterior inertia, gap, denominator ratios and complete error-budget terms. `acceptance.py` independently recomputes the two inertia bounds from those eigenvalues and their total error. It verifies:

- Exactly the original106 rank/side pairs, in their original order.
- Finite nonnegative error terms and agreement of their sum with the total.
- A positive exterior gap, orthogonality defects below1/2 and a transport denominator ratio below1.
- Exact lower and upper inertia counts obtained from the recomputed spectrum shifted by the recomputed error.
- The actual rank inequality: upper inertia at most the rank for a lower endpoint, and lower inertia greater than the rank for an upper endpoint.

The corresponding `radial_endpoint_wide.py` rule additionally requires the far bound to be below the exterior gap, the recorded contraction ratio to equal their quotient and remain below1, the inverse residual below1, and the unchanged0.001 development pad. Tail, inverse-substitution, multiplication, transport and eigen allowances must sum correctly before the106 decisions are accepted. The returned six HH counts still compare exactly in `radial_count_return.py`.

Saved residuals, error magnitudes and maximum-budget diagnostics are not targets in these two stages. A recomputed valid allowance may differ across eigensolvers. A `verified` flag alone is insufficient: the spectrum, error sum, gap/denominator premises and rank inequalities must all agree. The maximum budget is checked against the maximum of the new rows, not against an incidental saved maximum. These are explicit floating-error-model checks, not directed-rounding certificates.

`check_acceptance.py` accepts a valid recomputed certificate even when incidental reference diagnostics are changed. It rejects15 invalid HH/radial certificates, including a falsely successful record with failed gap, denominator, error sum, rank label or inertia inequality. This tests acceptance logic in addition to replaying the scientific calculations.

## Actual environments

Fast replay has been executed with Python3.12.14 and NumPy2.3.5 using SciPy1.18.1 (the pinned environment) and SciPy1.17.0 (an isolated alternative installation on the same Windows host). Both complete all17 stages with the revised rules. This is evidence across two library versions, not a cross-operating-system or clean-install guarantee. The verification records name the actual versions. Additional graph/control/extraction tests and any full regeneration are reported separately; an inherited expensive source result is never labelled a newly executed run.
