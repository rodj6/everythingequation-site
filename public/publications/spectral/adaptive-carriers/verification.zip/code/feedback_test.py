"""Self-consistent memory, independent RK4, and conditional/full responses."""
from pathlib import Path
import json,numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import norm
root=Path(__file__).resolve().parents[1];p=json.loads((root/'specification.json').read_text())['feedback'];out=root/'results';out.mkdir(exist_ok=True)
b=np.array(p['incidence'],float);edges=np.einsum('ei,ej->eij',b,b);mu,g,a,eta,kappa=[p[k] for k in ['mu','gamma','alpha','eta','kappa']];n=3;T=p['T'];times=np.linspace(0,T,p['samples']);initial=np.r_[p['initial_z_real'],p['initial_z_imag'],p['initial_memory']]
def pieces(x):
 z=x[:3]+1j*x[3:6];m=x[6:8];w=np.exp(m);K=mu*np.eye(3)+np.einsum('e,eij->ij',w,edges);grad=kappa*m+.5*w*abs(b@z)**2;return z,m,K,grad
def energy(x):
 z,m,K,_=pieces(x);return float(.5*np.vdot(z,K@z).real+.5*kappa*(m@m))
def rhs(t,x):
 z,m,K,grad=pieces(x);dz=-(g+1j*a)*(K@z);dm=-eta*grad;loss=g*float(np.vdot(K@z,K@z).real)+eta*float(grad@grad);return np.r_[dz.real,dz.imag,dm,loss]
E0=energy(initial);sol=solve_ivp(rhs,[0,T],np.r_[initial,0.],method='DOP853',rtol=p['rtol'],atol=p['atol'],dense_output=True);assert sol.success;sample=sol.sol(times);energies=np.array([energy(x) for x in sample.T]);ledger=max(abs(energies+sample[8]-E0));norms=np.sum(sample[:6]**2,axis=0);norm_bound=np.sum(initial[:6]**2)*np.exp(-2*g*mu*times)
# Separate real gradient evaluation: no complex matrix product or pieces/rhs call.
def real_gradient_rhs(y):
 q=y[:6];m=y[6:8];f=mu*q.copy();gm=kappa*m.copy()
 for e in range(2):
  wr=np.exp(m[e]);dr=float(b[e]@q[:3]);di=float(b[e]@q[3:]);f[:3]+=wr*dr*b[e];f[3:]+=wr*di*b[e];gm[e]+=.5*wr*(dr*dr+di*di)
 dq=np.r_[-g*f[:3]+a*f[3:],-g*f[3:]-a*f[:3]];return np.r_[dq,-eta*gm,g*float(f@f)+eta*float(gm@gm)]
y=np.r_[initial,0.];h=T/p['independent_RK4_steps']
for _ in range(p['independent_RK4_steps']):
 k1=real_gradient_rhs(y);k2=real_gradient_rhs(y+h*k1/2);k3=real_gradient_rhs(y+h*k2/2);k4=real_gradient_rhs(y+h*k3);y+=h*(k1+2*k2+2*k3+k4)/6
agreement=float(max(abs(y-sol.y[:,-1])));independent_ledger=abs(energy(y)+y[8]-E0)
J=np.block([[np.zeros((3,3)),-np.eye(3)],[np.eye(3),np.zeros((3,3))]]);G=g*np.eye(6)+a*J
def tangent_matrix(t):
 x=sol.sol(t);z,m,K,_=pieces(x);KR=np.kron(np.eye(2),K);B=np.array([np.r_[np.exp(m[e])*b[e]*(b[e]@z).real,np.exp(m[e])*b[e]*(b[e]@z).imag] for e in range(2)]).T;H=np.diag(kappa+.5*np.exp(m)*abs(b@z)**2);return np.block([[-G@KR,-G@B],[-eta*B.T,-eta*H]]),-G@KR
def tangent_rhs(t,v):
 A,C=tangent_matrix(t);return np.r_[(A@v[:64].reshape(8,8)).ravel(),(C@v[64:].reshape(6,6)).ravel()]
tangent=solve_ivp(tangent_rhs,[0,T],np.r_[np.eye(8).ravel(),np.eye(6).ravel()],method='DOP853',rtol=p['rtol'],atol=p['atol']);assert tangent.success;full=tangent.y[:64,-1].reshape(8,8);clamp=tangent.y[64:,-1].reshape(6,6);direction=np.array(p['perturbation_direction']);gap=float(norm((full@direction)[:6]-clamp@direction[:6]));eps=p['perturbation_size'];pert=[]
for sign in [-1,1]:
 q=solve_ivp(rhs,[0,T],np.r_[initial+sign*eps*direction,0.],method='DOP853',rtol=p['rtol'],atol=p['atol']);assert q.success;pert.append(q.y[:8,-1])
finite=(pert[1]-pert[0])/(2*eps);tangent_error=float(norm(finite-full@direction))
# Conditional propagators along this same realized memory history.
def propagators(t,v):
 K=pieces(sol.sol(t))[2];U,D,V,R=v.reshape(4,3,3);return np.array([-(g+1j*a)*K@U,-g*K@D,-1j*a*K@V,-g*(V.conj().T@K@V)@R]).ravel()
pr=solve_ivp(propagators,[0,T],np.tile(np.eye(3,dtype=complex).ravel(),4),method='DOP853',rtol=p['rtol'],atol=p['atol']);assert pr.success;U,D,V,R=pr.y[:,-1].reshape(4,3,3)
passed=agreement<p['solver_agreement_max'] and ledger<p['energy_ledger_error_max'] and independent_ledger<p['energy_ledger_error_max'] and gap>p['full_vs_clamped_response_min'] and tangent_error<p['tangent_finite_difference_max'] and max(norms-norm_bound)<1e-9
result={'all_frozen_conditions_pass':bool(passed),'energy_initial':E0,'energy_final':float(energies[-1]),'energy_balance_residual':float(ledger),'RK4_energy_balance_residual':float(independent_ledger),'independent_solver_max_error':agreement,'norm_decay_bound_max_excess':float(max(norms-norm_bound)),'full_vs_clamped_response_difference':gap,'tangent_central_difference_error':tangent_error,'conditional_static_factorization_error':float(norm(U-D@V,2)),'exact_interaction_picture_residual':float(norm(U-V@R,2)),'coherent_unitarity_defect':float(norm(V.conj().T@V-np.eye(3),2)),'conditional_propagator_norm':float(norm(U,2)),'final_state':sol.y[:8,-1].tolist(),'evidence':'synthetic equations with independent real-gradient RK4 and finite-difference tangent checks, not experiment'}
(out/'feedback_test.json').write_text(json.dumps(result,indent=2));np.savez_compressed(out/'feedback_trajectory.npz',times=times,state=sample,energy=energies,norm_squared=norms,norm_bound=norm_bound,full_tangent=full,clamped_tangent=clamp,U=U,D=D,V=V,R=R);print(json.dumps(result,indent=2));assert passed
