"""Independent rational fixtures: partial curvature does not certify full feedback."""
from fractions import Fraction as F
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];out=root/'results';out.mkdir(exist_ok=True)
# Scalar amplitude at m=0: full real (q,m) Hessian at q=3.
mu=F(2,5);kappa=F(1);q=F(3);K=mu+1;Hmm=kappa+q*q/2;cross=q;det=K*Hmm-cross*cross;assert K>0 and det<0
variation=K+2*cross*F(-1,2)+Hmm*F(1,4);tangent_norm_derivative=-2*variation;assert variation==F(-9,40) and tangent_norm_derivative==F(9,20)
# Two real amplitude coordinates plus memory, q=(1/10,0).
q=F(1,10);H=[[K,F(0),q],[F(0),K,F(0)],[q,F(0),kappa+q*q/2]];J=[[F(0),F(-1),F(0)],[F(1),F(0),F(0)],[F(0),F(0),F(0)]]
def mat(A,B):return [[sum(A[i][k]*B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
comm=[[a-b for a,b in zip(x,y)] for x,y in zip(mat(H,J),mat(J,H))];positive=K>0 and K*K>0 and K*(K*(kappa+q*q/2)-q*q)>0;assert positive and any(v for row in comm for v in row)
result={'positive_partial_carrier':str(K),'large_amplitude_full_hessian_determinant':str(det),'large_amplitude_full_hessian_not_positive':True,'full_tangent_norm_squared_derivative':str(tangent_norm_derivative),'full_tangent_contraction_obstruction':True,'small_amplitude_full_hessian_positive':positive,'small_amplitude_reactive_alignment_commutator':[[str(v) for v in row] for row in comm],'full_hessian_alignment_fails':True,'evidence':'exact rational finite fixtures, not physical observations'};(out/'exact_obstructions.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
