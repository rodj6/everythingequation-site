"""Return checks for the response error theorem and invariant collective mode."""
from pathlib import Path
import json,numpy as np
from scipy.linalg import norm
root=Path(__file__).resolve().parents[1];out=root/'results';p=json.loads((root/'specification.json').read_text())['feedback'];z=np.load(out/'feedback_trajectory.npz');initial=np.array(p['initial_z_real'])+1j*np.array(p['initial_z_imag']);trajectory=z['state'][:3]+1j*z['state'][3:6];expected=np.mean(initial)*np.exp(-(p['gamma']+1j*p['alpha'])*p['mu']*z['times']);mean_error=float(max(abs(np.mean(trajectory,axis=0)-expected)));assert mean_error<1e-9
g=.7;a=1.1;c=g+1j*a;A0=c*np.diag([1.,2.]);slope=np.array([1.,.5]);rows=[];epsilon=1e-10;N=np.diag([1.,1j])
for h in [.04,.02,.01]:
 def Phi(t):return np.diag(np.exp(-c*(np.array([1.,2.])*t+.5*slope*t*t)))
 L=lambda t:(np.eye(2)-Phi(t))/t
 estimate=2*L(h/2)-L(h);bias=float(norm(estimate-A0,2));a0=abs(c)*max(np.array([1.,2.])+slope*h);a1=abs(c)*max(slope);B3=3*a0*a1+a0**3;bound=h*h*B3/4
 noisy=2*(np.eye(2)-(Phi(h/2)-epsilon*N))/(h/2)-(np.eye(2)-(Phi(h)+epsilon*N))/h;noise=float(norm(noisy-estimate,2));total=float(norm(noisy-A0,2));assert bias<=bound+1e-12 and noise<=5*epsilon/h+1e-12 and total<=bound+5*epsilon/h+1e-12
 rows.append({'duration':h,'generator_bias':bias,'bias_bound':float(bound),'noise_error':noise,'noise_bound':5*epsilon/h,'total_error':total,'total_bound':float(bound+5*epsilon/h)})
result={'collective_mode_max_error':mean_error,'response_remainder_fixtures':rows,'all_checks_pass':True,'scope':'Independent exact diagonal propagator fixtures and a development check of a source-derived invariant; no experiment'};(out/'structural_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
