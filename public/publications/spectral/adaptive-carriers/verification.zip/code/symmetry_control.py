from pathlib import Path
import json,numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import norm
root=Path(__file__).resolve().parents[1];out=root/'results';p=json.loads((root/'specification.json').read_text())['feedback'];s=json.loads((root/'control_specification.json').read_text());b=np.array(p['incidence']);edges=np.einsum('ei,ej->eij',b,b);g=p['gamma'];a=p['alpha'];eta=p['eta'];mu=p['mu'];kappa=p['kappa']
def carrier(m):return mu*np.eye(3)+np.einsum('e,eij->ij',np.exp(m),edges)
def rhs(t,x):
 z=x[:3]+1j*x[3:6];m=x[6:];dz=-(g+1j*a)*carrier(m)@z;dm=-eta*(kappa*m+.5*np.exp(m)*abs(b@z)**2);return np.r_[dz.real,dz.imag,dm]
initial=np.r_[s['initial_z_real'],s['initial_z_imag'],s['initial_memory']];sol=solve_ivp(rhs,[0,s['T']],initial,method='DOP853',rtol=1e-11,atol=1e-13,dense_output=True);assert sol.success;grid=np.linspace(0,s['T'],401);x=sol.sol(grid)
def prop_rhs(t,v):
 K=carrier(sol.sol(t)[6:]);U,D,V=v.reshape(3,3,3);return np.array([-(g+1j*a)*K@U,-g*K@D,-1j*a*K@V]).ravel()
pr=solve_ivp(prop_rhs,[0,s['T']],np.tile(np.eye(3,dtype=complex).ravel(),3),method='DOP853',rtol=1e-11,atol=1e-13);assert pr.success;U,D,V=pr.y[:,-1].reshape(3,3,3);error=float(norm(U-D@V,2));difference=float(max(abs(x[6]-x[7])));motion=float(max(abs(x[6]-initial[6])))
# Source formula for asymmetric history: ||[K(t),K(s)]||=sqrt3*|w1(t)w2(s)-w2(t)w1(s)|.
z=np.load(out/'feedback_trajectory.npz');t=z['times'];w=np.exp(z['state'][6:8]);kernel=np.sqrt(3)*abs(w[0,:,None]*w[1,None,:]-w[1,:,None]*w[0,None,:]);inner=np.array([np.trapezoid(kernel[j,:j+1],t[:j+1]) for j in range(len(t))]);quadrature=float(g*a*np.trapezoid(inner,t));actual=json.loads((out/'feedback_test.json').read_text())['conditional_static_factorization_error']
passed=difference<s['memory_difference_max'] and error<s['factorization_error_max'] and motion>s['memory_motion_min'];result={'symmetric_memory_difference':difference,'symmetric_memory_motion':motion,'symmetric_factorization_error':error,'asymmetric_factorization_error':actual,'asymmetric_commutator_integral_quadrature':quadrature,'all_frozen_conditions_pass':bool(passed),'scope':'Symmetric source control and numerical trapezoidal evaluation of an analytic commutator formula; quadrature is not a directed bound certificate'};(out/'symmetry_control.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert passed
