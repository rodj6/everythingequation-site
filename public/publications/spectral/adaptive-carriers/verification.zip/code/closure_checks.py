"""Static closure diagnostics do not transfer unchanged to nonautonomous flow."""
from pathlib import Path
from fractions import Fraction as F
import json,numpy as np
from scipy.linalg import expm,norm
root=Path(__file__).resolve().parents[1];out=root/'results';A=np.array([[2.,1.],[1.,2.]]);B=np.array([[2.,-1.],[-1.,2.]]);P=np.diag([1.,0.]);Q=np.eye(2)-P;D=expm(-B)@expm(-A);leak=float(norm(Q@D@P));comm=float(norm(P@A-A@P));defect=float(np.exp(-3)-np.exp(-2));assert defect<0 and leak<1e-12 and comm>1
result={'scalar_static_Gram_defect':defect,'scalar_defect_negative_with_no_hidden_sector':True,'two_pulse_endpoint_leakage':leak,'instantaneous_projector_commutator':comm,'positive_pulse_eigenvalues':np.linalg.eigvalsh(A).tolist(),'pulse_sum_is_4I':bool(np.array_equal(A+B,4*np.eye(2))),'all_checks_pass':True,'scope':'Analytic scalar sign and exact integer pulse identities, with numerical endpoint check; not experiment'};(out/'closure_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
