"""Matrix response discriminates a linked carrier from isospectral phase rotation."""
from pathlib import Path
import json,numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.linalg import norm
root=Path(__file__).resolve().parents[1];out=root/'results';p=json.loads((root/'specification.json').read_text())['feedback'];spec=json.loads((root/'response_specification.json').read_text());z=np.load(out/'feedback_trajectory.npz');memory=CubicSpline(z['times'],z['state'][6:8].T);b=np.array(p['incidence']);edges=np.einsum('ei,ej->eij',b,b);S=np.array(spec['tomography']['alternative_rotation']);g=p['gamma'];a=p['alpha'];rows=[]
def K(t):return p['mu']*np.eye(3)+np.einsum('e,eij->ij',np.exp(memory(t)),edges)
def estimate(t,h,alternative):
 def rhs(u,v):
  k=K(u);phase=S@k@S.T if alternative else k;return (-(g*k+1j*a*phase)@v.reshape(3,3)).ravel()
 vals=[]
 for step in [h,h/2]:
  sol=solve_ivp(rhs,[t,t+step],np.eye(3,dtype=complex).ravel(),method='DOP853',rtol=1e-12,atol=1e-14);assert sol.success;vals.append(-(sol.y[:,-1].reshape(3,3)-np.eye(3))/step)
 return 2*vals[1]-vals[0]
for t in spec['tomography']['times']:
 for alternative in [False,True]:
  A=estimate(t,spec['tomography']['probe_duration'],alternative);H=(A+A.conj().T)/2;C=(A-A.conj().T)/(2j);res=float(norm(C-a/g*H,'fro')/norm(C,'fro'));ratio=float(np.vdot(H,C).real/np.vdot(H,H).real);passed=res>spec['tomography']['alternative_residual_min'] if alternative else res<spec['tomography']['relative_link_residual_max'];rows.append({'time':t,'alternative':alternative,'relative_link_residual':res,'least_squares_ratio':ratio,'passes_frozen_condition':bool(passed)})
m=spec['metric'];t=m['T'];r=m['r'];c=m['gamma']+1j*m['alpha'];source=np.exp(-c*(1-np.exp(-2*r*t))/r);whitened=np.exp(r*t)*source;omitted=source;metric={'source_norm':float(abs(source)),'whitened_norm':float(abs(whitened)),'connection_omission_difference':float(abs(whitened-omitted))};metric['passes_frozen_conditions']=metric['source_norm']<=m['source_contraction_max'] and metric['whitened_norm']>m['whitened_norm_min'] and metric['connection_omission_difference']>m['connection_omission_difference_min'];result={'tomography':rows,'metric':metric,'all_frozen_conditions_pass':all(r['passes_frozen_condition'] for r in rows) and metric['passes_frozen_conditions'],'evidence':'Synthetic conditional memory-replay operator probes and exact metric fixture; no physical measurement'};(out/'response_test.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert result['all_frozen_conditions_pass']
