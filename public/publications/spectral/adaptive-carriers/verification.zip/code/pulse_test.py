"""Finite positive pulses: ordered response and a gap-free factorization bound."""
from pathlib import Path
import json,cmath,numpy as np
from scipy.linalg import expm,norm
root=Path(__file__).resolve().parents[1];spec=json.loads((root/'specification.json').read_text())['pulse'];out=root/'results';out.mkdir(exist_ok=True)
def exponential_2x2(M):
 tr=np.trace(M)/2;N=M-tr*np.eye(2);d=cmath.sqrt(-np.linalg.det(N));return cmath.exp(tr)*(cmath.cosh(d)*np.eye(2)+(cmath.sinh(d)/d if abs(d)>1e-14 else 1+d*d/6)*N)
A=np.array(spec['K1'],float);B=np.array(spec['K2'],float);g=spec['gamma'];a=spec['alpha'];c=g+1j*a;comm=B@A-A@B;cn=norm(comm,2);rows=[]
for t in spec['durations']:
 U=expm(-c*t*B)@expm(-c*t*A);D=expm(-g*t*B)@expm(-g*t*A);V=expm(-1j*a*t*B)@expm(-1j*a*t*A);reverse=expm(-c*t*A)@expm(-c*t*B);naive=expm(-c*t*(A+B));independent=exponential_2x2(-c*t*B)@exponential_2x2(-c*t*A);independent_error=norm(U-independent,2);assert independent_error<1e-12;error=norm(U-D@V,2);bound=g*a*t*t*cn;leading=norm((U-D@V)/(1j*g*a*t*t)-comm,2)/cn;order_leading=norm((U-reverse)/(c*c*t*t)-comm,2)/cn
 rows.append({'duration':t,'independent_closed_form_error':float(independent_error),'factorization_error':float(error),'commutator_bound':float(bound),'within_bound':bool(error<=bound+spec['bound_slack']),'leading_relative_error':float(leading),'order_leading_relative_error':float(order_leading),'reverse_order_difference':float(norm(U-reverse,2)),'naive_integrated_error':float(norm(U-naive,2)),'unitary_defect':float(norm(V.conj().T@V-np.eye(2),2)),'propagator_norm':float(norm(U,2))})
passed=all(r['within_bound'] and r['unitary_defect']<1e-12 and r['propagator_norm']<=1+1e-12 for r in rows) and rows[-1]['leading_relative_error']<spec['last_leading_relative_error_max'] and rows[-1]['order_leading_relative_error']<spec['last_leading_relative_error_max'] and rows[-1]['leading_relative_error']/rows[0]['leading_relative_error']<spec['leading_error_reduction_ratio_max']
result={'rows':rows,'commutator_norm':float(cn),'all_frozen_conditions_pass':bool(passed),'evidence':'matrix exponential numerical check of proved expansions/bound, not experiment'};(out/'pulse_test.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert passed
