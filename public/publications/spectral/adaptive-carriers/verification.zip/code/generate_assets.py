"""Generate all numerical manuscript tables and figures from recorded results."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def generate(results, assets):
    results=Path(results);assets=Path(assets)
    figures=assets/'figures';tables=assets/'tables'
    figures.mkdir(parents=True,exist_ok=True);tables.mkdir(parents=True,exist_ok=True)
    read=lambda name:json.loads((results/(name+'.json')).read_text())
    f=read('feedback_test');p=read('pulse_test');r=read('response_test')
    z=np.load(results/'feedback_trajectory.npz');t=z['times']
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
        'pdf.fonttype':42,'savefig.bbox':'tight'})
    fig,ax=plt.subplots(2,2,figsize=(9.4,5.7),layout='constrained')
    ax[0,0].semilogy(t,z['energy'],color='#185575');ax[0,0].set(ylabel='Energy F',title='(a) Dissipating source')
    ax[0,1].semilogy(t,z['norm_squared'],label='Squared amplitude',color='#185575')
    ax[0,1].semilogy(t,z['norm_bound'],'--',label='Decay upper bound',color='#bd6928');ax[0,1].legend(fontsize=8)
    ax[0,1].set(ylabel='Squared amplitude',title='(b) Amplitude envelope')
    for e,color in enumerate(['#185575','#bd6928']):
        ax[1,0].plot(t,z['state'][6+e],label=f'Edge {e+1}',color=color)
        ax[1,1].plot(t,np.exp(z['state'][6+e]),label=f'Edge {e+1}',color=color)
    ax[1,0].set(ylabel='Memory m',title='(c) Reciprocal memory');ax[1,0].legend(fontsize=8)
    ax[1,1].set(ylabel='Stiffness exp(m)',title='(d) Evolving carrier weights')
    for a in ax.flat:a.set_xlabel('Normalized time');a.grid(alpha=.18)
    fig.savefig(figures/'trajectory.pdf');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(9.4,3.4),layout='constrained')
    duration=[v['duration'] for v in p['rows']]
    ax[0].loglog(duration,[v['factorization_error'] for v in p['rows']],'o-',label='Factorization error',color='#185575')
    ax[0].loglog(duration,[v['commutator_bound'] for v in p['rows']],'s--',label='Commutator bound',color='#bd6928',markerfacecolor='none')
    ax[0].set(xlabel='Individual pulse duration',ylabel='Operator norm',title='(a) Ordered positive pulses');ax[0].legend(fontsize=8)
    from matplotlib.ticker import FixedLocator,FixedFormatter,NullFormatter
    ax[0].xaxis.set_major_locator(FixedLocator([.005,.01,.02,.04]))
    ax[0].xaxis.set_major_formatter(FixedFormatter(['0.005','0.01','0.02','0.04']))
    ax[0].xaxis.set_minor_formatter(NullFormatter())
    for alt,color,label in [(False,'#185575','Linked'),(True,'#bd6928','Rotated alternative')]:
        rows=[v for v in r['tomography'] if v['alternative']==alt]
        ax[1].semilogy([v['time'] for v in rows],[v['relative_link_residual'] for v in rows],'o-',label=label,color=color)
    ax[1].set(xlabel='Probe time',ylabel='Relative Frobenius residual',title='(b) Same-history operator response');ax[1].legend(fontsize=8)
    for a in ax:a.grid(alpha=.18)
    fig.savefig(figures/'ordering_response.pdf');plt.close(fig)
    def sci(x):
        if x==0:return '$0$'
        a,b=f'{x:.3e}'.split('e');return f'${a}\\times10^{{{int(b)}}}$'
    def table(name,caption,label,cols,head,rows):
        text='\\begin{table}[H]\n\\centering\\small\n\\begin{tabular}{'+cols+'}\n\\toprule\n'+head+' \\\\\n\\midrule\n'
        text+=''.join(' & '.join(row)+' \\\\\n' for row in rows)
        text+='\\bottomrule\n\\end{tabular}\n\\caption{'+caption+'}\\label{'+label+'}\n\\end{table}\n'
        (tables/(name+'.tex')).write_text(text,encoding='utf-8',newline='\n')
    fields=[('Initial energy','energy_initial'),('Final energy','energy_final'),
        ('DOP853 energy-balance residual','energy_balance_residual'),('RK4 energy-balance residual','RK4_energy_balance_residual'),
        ('Independent endpoint maximum error','independent_solver_max_error'),('Norm-bound maximum excess','norm_decay_bound_max_excess'),
        ('Full versus clamped response difference','full_vs_clamped_response_difference'),('Central-difference tangent error','tangent_central_difference_error'),
        ('Static factorization error','conditional_static_factorization_error'),('Interaction-picture residual','exact_interaction_picture_residual'),
        ('Coherent unitarity defect','coherent_unitarity_defect')]
    table('feedback','Computed feedback and propagation checks in normalized units. Scalar residuals use the definitions and norms stated in the text; they are floating evaluations, not interval enclosures.','tab:feedback','lr','Quantity & Value',[[label,sci(f[key])] for label,key in fields])
    table('pulse','Two-pulse propagation. The last column is the relative discrepancy of the scaled matrix in equation~\\eqref{eq:pulseleading} from its leading commutator.','tab:pulse','rrrr',
        '$\\tau$ & $\\|U-DV\\|$ & Bound & Leading discrepancy',
        [[f"{v['duration']:g}",sci(v['factorization_error']),sci(v['commutator_bound']),f"{v['leading_relative_error']:.5f}"] for v in p['rows']])
    rows=[]
    for v in r['tomography']:
        rows.append([f"{v['time']:g}",'Rotated' if v['alternative'] else 'Linked',sci(v['relative_link_residual']),f"{v['least_squares_ratio']:.7f}"])
    table('response','Same-history response reconstruction. Residuals use the independently stipulated model ratio $r=2$; the fitted ratio is a diagnostic from the same response.','tab:response','rlrr',
        'Time & Model & Relative residual & Fitted ratio',rows)
    (assets/'asset_values.json').write_text(json.dumps({'feedback_fields':fields,'pulse_rows':p['rows'],'response_rows':r['tomography']},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--results',type=Path,required=True);parser.add_argument('--assets',type=Path,required=True)
    args=parser.parse_args();generate(args.results,args.assets)
