"""Targeted portability and rejection regressions; no new scientific holdout."""
from pathlib import Path
from copy import deepcopy
import json
from validation import scientific_compare,scientific_acceptance,verify_specifications,validate_table,normalize_text
R=Path(__file__).resolve().parent
ref={p.stem:json.loads(p.read_text()) for p in (R/'results').glob('*.json')}
spec=json.loads((R/'frozen_contracts.json').read_text())
contracts=json.loads((R/'table_contract.json').read_text())
passed=[]
def rejects(name,fn):
    try:fn()
    except (AssertionError,ValueError,KeyError):passed.append(name);return
    raise AssertionError(name+' did not reject')
text=(R/'reference_assets'/'tables'/'feedback.tex').read_text()
lf=normalize_text(text);crlf=lf.replace('\n','\r\n')
for sample in [lf,crlf]:validate_table(sample,contracts['feedback'],ref)
passed.append('CRLF and LF pass identical semantic table checks')
actual=deepcopy(ref);actual['feedback_test']['tangent_central_difference_error']=1.803e-11
scientific_compare(ref['feedback_test'],actual['feedback_test']);scientific_acceptance(actual,spec)
changed=lf.replace('2.947\\times10^{-11}','1.803\\times10^{-11}')
assert changed!=lf
validate_table(changed,contracts['feedback'],actual)
passed.append('Reviewer diagnostic variation passes, with table faithful to changed run')
rejects('Changed table energy fails',lambda:validate_table(lf.replace('2.279\\times10^{0}','3.279\\times10^{0}'),contracts['feedback'],ref))
rejects('Changed table label fails',lambda:validate_table(lf.replace('Initial energy','Initial entropy'),contracts['feedback'],ref))
rejects('Changed table structure fails',lambda:validate_table(lf.replace('{lr}','{rr}'),contracts['feedback'],ref))
actual=deepcopy(ref);actual['feedback_test']['energy_final']*=1.01
rejects('Meaningful scientific quantity change fails',lambda:scientific_compare(ref,actual))
actual=deepcopy(ref);actual['feedback_test']['tangent_central_difference_error']=3e-7
rejects('Failed tangent acceptance ceiling fails',lambda:scientific_compare(ref,actual))
actual=deepcopy(ref);actual['response_test']['tomography'][1]['relative_link_residual']=.001
rejects('Lost alternative separation fails',lambda:scientific_acceptance(actual,spec))
mutated=deepcopy(spec);mutated['specification']['feedback']['tangent_finite_difference_max']=1.
rejects('Loosened scientific acceptance condition fails',lambda:verify_specifications(mutated,spec))
actual=deepcopy(ref);actual['closure_checks']['pulse_sum_is_4I']=False
rejects('Changed exact discrete result fails',lambda:scientific_compare(ref,actual))
rejects('Table value must match its own run',lambda:validate_table(changed,contracts['feedback'],ref))
print(json.dumps({'all_checks_pass':True,'checks':passed,'count':len(passed),
    'scope':'Synthetic mutations and text normalization, not cross-platform execution'},indent=2))
