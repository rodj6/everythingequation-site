"""Typed scientific and table validation, independent of text line endings."""
from pathlib import Path
import hashlib,json,math,re

SCI_RTOL=2e-8
SCI_ATOL=2e-10
# These are existing scientific ceilings, not matching tolerances for digits.
CEILINGS={
 'energy_balance_residual':1e-8,'RK4_energy_balance_residual':1e-8,
 'independent_solver_max_error':1e-7,'norm_decay_bound_max_excess':1e-9,
 'tangent_central_difference_error':2e-7,
 'exact_interaction_picture_residual':1e-8,'coherent_unitarity_defect':1e-8,
 'independent_closed_form_error':1e-12,'unitary_defect':1e-12,
 'collective_mode_max_error':1e-9,'symmetric_memory_difference':1e-10,
 'symmetric_factorization_error':1e-9,'two_pulse_endpoint_leakage':1e-12}

def scientific_compare(reference,actual,path='',key=''):
    if isinstance(reference,dict):
        assert isinstance(actual,dict) and reference.keys()==actual.keys(),path
        for k in reference:scientific_compare(reference[k],actual[k],path+'/'+k,k)
    elif isinstance(reference,list):
        assert isinstance(actual,list) and len(reference)==len(actual),path
        for i,(a,b) in enumerate(zip(reference,actual)):scientific_compare(a,b,path+'/'+str(i),key)
    elif isinstance(reference,bool) or isinstance(reference,str) or reference is None:
        assert type(reference)==type(actual) and reference==actual,(path,reference,actual)
    elif isinstance(reference,int):
        assert type(actual)==int and reference==actual,(path,reference,actual)
    else:
        assert isinstance(actual,(int,float)) and not isinstance(actual,bool) and math.isfinite(actual),(path,actual)
        if key in CEILINGS:
            assert 0<=actual<CEILINGS[key],(path,actual,CEILINGS[key])
        elif key in ['time','duration']:
            assert reference==actual,(path,reference,actual)
        else:
            assert math.isclose(reference,actual,rel_tol=SCI_RTOL,abs_tol=SCI_ATOL),(path,reference,actual)

def scientific_acceptance(results,specs):
    """Recheck coupled inequalities, rather than trusting saved PASS flags."""
    f=results['feedback_test'];p=specs['specification']['feedback']
    assert f['full_vs_clamped_response_difference']>p['full_vs_clamped_response_min']
    assert f['tangent_central_difference_error']<p['tangent_finite_difference_max']
    assert f['independent_solver_max_error']<p['solver_agreement_max']
    assert f['energy_balance_residual']<p['energy_ledger_error_max']
    assert f['RK4_energy_balance_residual']<p['energy_ledger_error_max']
    assert f['conditional_static_factorization_error']>1e-4
    assert abs(f['conditional_propagator_norm']-math.exp(-.48))<1e-8
    pulse=results['pulse_test'];s=specs['specification']['pulse'];rows=pulse['rows']
    for row in rows:
        assert row['factorization_error']<=row['commutator_bound']+s['bound_slack']
        assert row['propagator_norm']<=1+1e-12
    assert rows[-1]['leading_relative_error']<s['last_leading_relative_error_max']
    assert rows[-1]['order_leading_relative_error']<s['last_leading_relative_error_max']
    assert rows[-1]['leading_relative_error']/rows[0]['leading_relative_error']<s['leading_error_reduction_ratio_max']
    for row in results['response_test']['tomography']:
        s=specs['response_specification']['tomography']
        if row['alternative']:assert row['relative_link_residual']>s['alternative_residual_min']
        else:assert row['relative_link_residual']<s['relative_link_residual_max']
    for row in results['structural_checks']['response_remainder_fixtures']:
        assert row['generator_bias']<=row['bias_bound']+1e-12
        assert row['noise_error']<=row['noise_bound']+1e-12
        assert row['total_error']<=row['total_bound']+1e-12
    s=specs['control_specification'];row=results['symmetry_control']
    assert row['symmetric_memory_motion']>s['memory_motion_min']
    assert row['symmetric_memory_difference']<s['memory_difference_max']
    assert row['symmetric_factorization_error']<s['factorization_error_max']

def verify_specifications(actual,frozen):
    # Exact parsed definitions, including every acceptance condition.
    assert actual==frozen,'Scientific specification/acceptance condition changed'

def normalize_text(text):
    return text.replace('\r\n','\n').replace('\r','\n')

def table_cells(text):
    text=normalize_text(text)
    head,rest=text.split('\\midrule\n',1);body,tail=rest.split('\\bottomrule',1)
    rows=[]
    for line in body.splitlines():
        assert line.endswith(' \\\\'),line
        rows.append(line[:-3].split(' & '))
    return head,rows,tail

def skeleton(text,bindings):
    head,rows,tail=table_cells(text)
    for binding in bindings:
        i,j=binding['row'],binding['column']
        rows[i][j]='<NUMERIC>'
    return head+'\n'.join(' & '.join(row)+' \\\\' for row in rows)+'\n\\bottomrule'+tail

def resolve(results,binding):
    value=results[binding['result']]
    for part in binding['path']:value=value[part]
    return value

def printed_value(cell):
    token=cell.strip().strip('$')
    match=re.fullmatch(r'([+-]?[\d.]+)\\times10\^\{([+-]?\d+)\}',token)
    if match:mantissa,exponent=match.group(1),int(match.group(2))
    else:mantissa,exponent=token,0
    assert re.fullmatch(r'[+-]?\d+(?:\.\d+)?',mantissa),cell
    places=len(mantissa.split('.')[1]) if '.' in mantissa else 0
    value=float(mantissa)*10**exponent
    return value,(0.0 if value==0 else .500001*10**(exponent-places))

def validate_table(text,contract,results):
    bindings=contract['bindings']
    assert hashlib.sha256(skeleton(text,bindings).encode()).hexdigest()==contract['skeleton_sha256'],'Table labels, definitions or structure changed'
    _,rows,_=table_cells(text)
    for binding in bindings:
        printed,rounding=printed_value(rows[binding['row']][binding['column']])
        true=resolve(results,binding)
        if binding.get('exact'):assert printed==true,(binding,printed,true)
        else:assert abs(printed-true)<=rounding+4*math.ulp(float(true)),(binding,printed,true)

def validate_tables(reference_dir,generated_dir,contract,reference,actual):
    for name,schema in contract.items():
        # Each table must be faithful to its OWN run. Scientific agreement is
        # checked on unrounded values separately, never by matching tiny digits.
        validate_table((Path(reference_dir)/(name+'.tex')).read_text(),schema,reference)
        validate_table((Path(generated_dir)/(name+'.tex')).read_text(),schema,actual)
