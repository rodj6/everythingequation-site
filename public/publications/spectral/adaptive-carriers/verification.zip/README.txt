Adaptive Spectral Carriers: public verification
Jeremy Rodgers | Reserved paper DOI: 10.5281/zenodo.23924603
https://doi.org/10.5281/zenodo.23924603 | https://everythingequation.com
The reserved identifier does not establish that this paper has been published.

Use this package alongside the paper PDF. Complete proofs and definitions are
in PDF Sections 2-5; the editable manuscript and bibliography are private and
are not required to execute any verification command.

Install Python 3.12 and the requirements in requirements.txt, then run:

  python run_all.py --output-dir ../adaptive_verified_results

The output directory must be new and outside the extracted package. Run ordinary
Python, without -O: scientific stages use assertions. No network is used by the
runner after dependencies are installed. No TeX installation is required.

The seven scientific scripts and original specifications are unchanged. All
retained numerical references, including the original three table fragments,
remain byte-identical to the reference run. The manifest checks packaged bytes
with SHA256. Nothing in results/ or reference_assets/ is overwritten by replay.

Portable verification has separate layers:
1. Every packaged file is checked against manifest.json. Specifications are also
   compared exactly, as parsed definitions, to frozen_contracts.json. This
   preserves every acceptance threshold rather than silently changing a test.
2. The seven scientific stages execute their original assertions. validation.py
   rechecks key coupled acceptance inequalities using recomputed values.
3. Booleans, integers, strings, rational fixtures, durations and probe times are
   exact. Other scientific quantities and all eleven trajectory arrays use
   rtol=2e-8,atol=2e-10. These comparison tolerances are tighter than the previous
   runner's 2e-5,1e-9; they are not mathematical error certificates.
4. Roundoff/solver/finite-difference diagnostics are checked against their existing
   scientific ceilings, not their reference digits. The named list is CEILINGS
   in validation.py. In particular tangent error must remain below 2e-7; energy
   ledgers below 1e-8; independent endpoint error below 1e-7; interaction/unitarity
   residuals below 1e-8; pulse closed-form/unitarity defects below 1e-12; collective
   mode error below 1e-9; symmetric factorization error below 1e-9. The original
   specifications and stage code continue to enforce their full criteria.
5. Every generated table must retain its exact nonnumeric skeleton, including
   labels, captions, column definitions and row structure, after CRLF/LF
   normalization. table_contract.json fixes the skeleton hash and binds every
   numeric cell to its source JSON field. Each cell must equal the value rounded
   from its OWN run to the printed precision. Numeric time/duration cells are
   exact. Scientific agreement is checked on unrounded values in layers 2-4.

Thus the published table's 2.947e-11 tangent diagnostic and an independently
regenerated 1.803e-11 diagnostic can both pass, without claiming digit equality
or changing the reference. A changed energy, label, table structure, exact
result or acceptance threshold fails. Eleven targeted regressions exercise
these cases, including rejection when a table does not match its own run:

  python regression_checks.py

These mutations simulate line-ending and numerical differences. They are not
execution on another OS. verification_environments.json records the actual
clean-directory environments tested, separately from the simulated regressions.

Contents
  code/                     Seven stages and the figure/table generator
  results/                  Unchanged reference JSON and trajectory NPZ
  reference_assets/tables/   Three generated fragments only, not manuscript source
  *specification.json       Original deterministic settings and frozen criteria
  frozen_contracts.json      Exact parsed specification baseline
  table_contract.json       Exact table structure and numeric-cell source map
  validation.py             Quantity-aware acceptance and table validation
  regression_checks.py      Targeted accept/reject regressions
  provenance.json           Origins and reference-run identities
  claim_map.txt             PDF-to-code/result mapping
  requirements.txt          Reference versions
  manifest.json             Cryptographic integrity inventory

Reference run: Python 3.12.14, NumPy 2.3.5, SciPy 1.18.1, Matplotlib 3.10.8.
Published numerical tables remain traceable to that run. Regenerated figures
and tables are saved under the chosen output directory. Figure PDF bytes may
differ because of plotting metadata; data and scientific results are checked.
The generator writes canonical LF tables. No random sampling occurs, so there
is no seed. DOP853 tolerances, RK4 step count and all preparations are supplied.

Independent numerical checks are real-gradient RK4 versus DOP853 and the closed
2x2 pulse exponential versus SciPy expm. A same-code replay is repeatability.
Exact Fraction fixtures are separate from floating checks. The commutator
quadrature is not an interval enclosure. No physical experiment, formal full
interval certificate or cross-platform execution is inferred from simulations
of platform differences. See the paper's stated finite-dimensional hypotheses.
