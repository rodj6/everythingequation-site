"""Clean-output scientific replay with portable semantic table checks."""
from pathlib import Path
import argparse,hashlib,json,platform,shutil,subprocess,sys
import numpy as np
import scipy
from validation import scientific_compare,scientific_acceptance,verify_specifications,validate_tables,SCI_RTOL,SCI_ATOL

ROOT=Path(__file__).resolve().parent
STAGES=['pulse_test','exact_obstructions','feedback_test','response_test','structural_checks','symmetry_control','closure_checks']

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();dest=args.output_dir.resolve()
    assert dest!=ROOT and ROOT not in dest.parents,'Output must be outside package'
    dest.mkdir(parents=True,exist_ok=False)
    for row in json.loads((ROOT/'manifest.json').read_text())['files']:
        assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    specs={p.stem:json.loads(p.read_text()) for p in ROOT.glob('*specification.json')}
    verify_specifications(specs,json.loads((ROOT/'frozen_contracts.json').read_text()))
    shutil.copytree(ROOT/'code',dest/'code',ignore=shutil.ignore_patterns('__pycache__'))
    for p in ROOT.glob('*specification.json'):shutil.copy2(p,dest/p.name)
    (dest/'logs').mkdir();stages=[]
    for name in STAGES:
        proc=subprocess.run([sys.executable,str(dest/'code'/(name+'.py'))],capture_output=True,text=True)
        (dest/'logs'/(name+'.txt')).write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8',newline='\n')
        stages.append({'stage':name,'exit_code':proc.returncode});assert proc.returncode==0,name
    reference={name:json.loads((ROOT/'results'/(name+'.json')).read_text()) for name in STAGES}
    actual={name:json.loads((dest/'results'/(name+'.json')).read_text()) for name in STAGES}
    for name in STAGES:scientific_compare(reference[name],actual[name],name)
    scientific_acceptance(actual,specs)
    with np.load(ROOT/'results'/'feedback_trajectory.npz') as ref,np.load(dest/'results'/'feedback_trajectory.npz') as new:
        assert ref.files==new.files;count=len(ref.files)
        for name in ref.files:assert np.allclose(ref[name],new[name],rtol=SCI_RTOL,atol=SCI_ATOL),name
    proc=subprocess.run([sys.executable,str(dest/'code'/'generate_assets.py'),'--results',str(dest/'results'),'--assets',str(dest/'assets')],capture_output=True,text=True)
    (dest/'logs'/'assets.txt').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8');assert proc.returncode==0
    contract=json.loads((ROOT/'table_contract.json').read_text())
    validate_tables(ROOT/'reference_assets'/'tables',dest/'assets'/'tables',contract,reference,actual)
    regression=subprocess.run([sys.executable,str(ROOT/'regression_checks.py')],capture_output=True,text=True)
    (dest/'logs'/'regression.txt').write_text(regression.stdout+'\n'+regression.stderr);assert regression.returncode==0,regression.stderr
    receipt={'all_checks_pass':True,'stages':stages,'json_reference_comparisons':7,'trajectory_arrays_compared':count,
        'table_semantic_and_run_traceability_checks':'PASS','regression_checks':'PASS','input_hashes':'PASS',
        'scientific_comparison_rtol':SCI_RTOL,'scientific_comparison_atol':SCI_ATOL,
        'diagnostics':'Existing scientific ceilings; exact diagnostic digits are not required',
        'python':platform.python_version(),'system':platform.system(),'machine':platform.machine(),
        'numpy':np.__version__,'scipy':scipy.__version__,
        'scope':'Actual clean-directory replay in this environment; CRLF/LF mutation tests simulate text platform differences and do not establish another OS run.'}
    (dest/'verification_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8',newline='\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
