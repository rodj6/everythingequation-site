SHARP UNIQUENESS AND BISTABILITY: PUBLIC VERIFICATION
Companion to Sharp Uniqueness and Bistability in Driven Adaptive Spectral
Carriers, by Jeremy Rodgers, 2026.
Reserved DOI: 10.5281/zenodo.23932350
https://doi.org/10.5281/zenodo.23932350
The reserved identifier does not establish that publication has occurred.

Python 3.12, NumPy, SciPy and Matplotlib are required; see requirements.txt.
From a clean extraction, run:
  python run_all.py --output ../new_empty_replay
  python regression_checks.py
  python code/check_saved_identities.py
The output directory must be new or empty. The full integration can take
approximately half an hour. Do not restart a quiet integration: progress is
recorded in its results/progress.json; stage logs appear on completion.
No dependency installation is performed by these commands.

The runner verifies the manifest, frozen executable inputs, 114 scientific
conditions, 20 trajectory arrays, exact-rational and Decimal scalar checks,
six modal-cubic spectra and own-run CSV tables. It additionally generates
seven paper table fragments from its OWN calculations, not saved references.
The eight regression checks test scientific mutations, accepted numerical
diagnostic variation and irrelevant CSV line endings. All scientific
thresholds and reference numerical outputs are retained unchanged.

FROZEN.json and BLOCK_FROZEN.json are unchanged historical records. Their
DERIVATIONS.txt and BLOCK_ANALYSIS.txt entries identify proof notes in the
parent research archive, not public executable dependencies. The runner
explicitly skips only those two ancestry entries. The self-contained PDF
contains the proofs; no private research handovers or manuscript sources
are required for replay. The generated paper_*.tex files are small table
fragments, not manuscript sources.

Parent research archive SHA256:
4e59cb3ad8fa5db9335ebc3dd94b67b6995796afbc2ae043149b35f2e7ed41f3
The retained low-mode candidate is a full-state instability counterexample,
not a failed numerical check and not an impossibility theorem for that mode.
These are deterministic analytic examples and numerical checks, not unseen
empirical validation. Decimal, rational, real-gradient RK4 and cubic blocks
use separate formulations; cubic and full-matrix eigenvalues share NumPy.
Same-code clean replay is distinct from independent mathematical evidence.

Independent review is user-reported, with no review logs supplied. It found
the preceding release's 42 manifest hashes, eight checker regressions, saved
identities and seven table contracts consistent. Its numerical/table check
reused the completed Linux/SciPy 1.17.0 calculation, rather than repeating the
unchanged long integration. That reported review is not an author-side run.
PREVIOUS_RELEASE_REPLAY.json records the actual preceding Windows replay.
No second OS, fresh installation, directed trajectory certificate, physical
experiment, dynamic quasistatic limit or minimum switching-work theorem is
claimed. Physical supplied work and the tilted Lyapunov barrier differ.

CLAIM_MAP.json maps claims to code, outputs and manuscript sections.
CLEAN_REPLAY_RECEIPT.json is the retained parent-research replay record.
RELEASE.json records DOI metadata and scientific ancestry. The private
revision note reports the current final-package execution separately.
