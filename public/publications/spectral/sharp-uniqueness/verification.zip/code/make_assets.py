"""Tables and figures from actual outputs, with raw table bindings retained."""
from pathlib import Path
import json,argparse,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def generate(base):
    base=Path(base);d=json.loads((base/'results/calculations.json').read_text());sp=json.loads((base/'specification.json').read_text());out=base/'assets';out.mkdir(exist_ok=True)
    tables={
      'branches':{'columns':['branch','memory_s','amplitude_norm','stored_energy','tilted_energy','power','negative_H','unstable_A','clamped_static_norm','full_static_norm'],'rows':[[r['label'],r['s'],r['amplitude_norm'],r['energy'],r['tilt'],r['steady_power'],r['negative_H'],r['unstable_A'],r['clamped_static_norm'],r['full_static_norm']] for r in d['roots']]},
      'folds':{'columns':['fold','memory_s','drive_amplitude','transversality','quadratic_coefficient'],'rows':[[label,r['s'],r['drive_amplitude'],r['transversality'],r['quadratic_coefficient']] for label,r in zip(['upper_drive','lower_drive'],d['folds'])]},
      'switching':{'columns':['switch','target','terminal_error','final_basin_margin','supplied_work','dissipation','stored_energy_change','physical_ledger'],'rows':[[name,sw['schedule']['target'],sw['terminal_error'],sw['final_basin_margin'],sw['supplied_work'],sw['dissipation'],sw['stored_energy_change'],sw['physical_ledger']] for name,sw in d['switching'].items()]},
      'basins':{'columns':['preparation','target','terminal_error','initial_basin_margin','physical_ledger','tilted_ledger','convergence_max'],'rows':[[name,r['target'],r['terminal_error'],r['initial_basin_margin'],r['physical_ledger'],r['tilted_ledger'],r['convergence_max']] for name,r in d['trajectories'].items()]}}
    for name,t in tables.items():
        with (out/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f,lineterminator='\n');w.writerow(t['columns']);w.writerows(t['rows'])
    (out/'table_data.json').write_text(json.dumps(tables,indent=2),encoding='utf-8')
    plt.rcParams.update({'font.size':11,'axes.titlesize':12,'legend.fontsize':9,'pdf.fonttype':42})
    mu=sp['parameters']['mu'];kap=sp['parameters']['kappa'];c=complex(sp['parameters']['gamma'],sp['parameters']['alpha']);v=np.array([1.,-2.,1.])/np.sqrt(6)
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained');bounds=[0,d['folds'][0]['s'],d['folds'][1]['s'],4.5]
    for i in range(3):
        ss=np.linspace(bounds[i],bounds[i+1],301);R=np.sqrt(4*kap/3*ss*np.exp(ss));aa=abs(c)*np.sqrt(4*kap/3*ss*np.exp(ss)*(mu+3*np.exp(-ss))**2)
        axs[0].plot(aa,R,color=['#267c64','#bb4a4a','#267c64'][i],ls='--' if i==1 else '-',label=['Fully stable','Index-one saddle',None][i])
    axs[0].axvline(sp['drive_amplitude'],color='#777',lw=1,label='Same input a=3')
    for r in d['roots']:axs[0].scatter([sp['drive_amplitude']],[r['amplitude_norm']],color='#27384c',s=40)
    axs[0].set(xlim=(2.65,3.45),ylim=(0,18),xlabel='Constant input amplitude a',ylabel='Stationary amplitude norm',title='Complete path branch classification');axs[0].legend();axs[0].grid(alpha=.2)
    data=np.load(base/'results/trajectories.npz')
    for name in d['trajectories']:
        ts=data[name+'_times'];x=data[name+'_state_ledgers'];R=abs(v@(x[:3]+1j*x[3:6]));axs[1].plot(ts,R,label=name)
    axs[1].axhline(d['roots'][1]['amplitude_norm'],color='gray',ls=':',label='Saddle radius');axs[1].set(xlabel='Time',ylabel='Retained mode radius',title='Full-state basin tests');axs[1].legend(ncol=2,fontsize=8);axs[1].grid(alpha=.2)
    fig.savefig(out/'branches_and_basins.png',dpi=170);fig.savefig(out/'branches_and_basins.pdf');plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(10,7),layout='constrained')
    for col,name in enumerate(['up','down']):
        sw=d['switching'][name];t=data['switch_'+name+'_times'];x=data['switch_'+name+'_state_ledgers'];R=abs(v@(x[:3]+1j*x[3:6]));ax=axs[0,col];ax.plot(t,R,color='#267c64',label='Adaptive amplitude');ax.axhline(d['roots'][1]['amplitude_norm'],color='gray',ls=':',label='Base saddle radius');ax.axvline(sw['schedule']['pulse_duration'],color='#bb4a4a',ls='--',label='Return to same input');ax.set(xlabel='Time',ylabel='Mode radius',title=name.capitalize()+' switching');ax.legend(fontsize=8);ax.grid(alpha=.2)
        ax=axs[1,col];ax.plot(t,x[9],label='Supplied work');ax.plot(t,x[8],ls='--',label='Internal dissipation');ax.plot(t,x[9]-x[8],label='Stored energy change');ax.axvline(sw['schedule']['pulse_duration'],color='#bb4a4a',ls='--');ax.set(xlabel='Time',ylabel='Energy / cumulative work',title='Physical energy accounting');ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.savefig(out/'switching_and_work.png',dpi=170);fig.savefig(out/'switching_and_work.pdf');plt.close(fig)
    (out/'GENERATION.json').write_text(json.dumps({'inputs':['results/calculations.json','results/trajectories.npz','specification.json'],'table_bindings':'table_data.json contains each printed table raw value from this run','branch_curve':'Analytic H3(s) and R(s), deterministic 301-point plotting per proved branch; display sampling is not a root search or a new empirical test','scope':'Diagrams of proved branch classification and executed full trajectories; no ramp or interval-flow certification'},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);generate(p.parse_args().base)
