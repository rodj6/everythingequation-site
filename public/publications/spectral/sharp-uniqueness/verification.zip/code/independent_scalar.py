"""Independent Decimal roots and exact rational scalar certificates."""
from pathlib import Path
from decimal import Decimal,localcontext
from fractions import Fraction as F
from math import factorial
import argparse,json
def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());out=base/'results';out.mkdir(exist_ok=True)
    with localcontext() as ctx:
        ctx.prec=sp['decimal_precision'];D=Decimal;mu=D(1)/10;kap=D(1);lam=D(3);load=D(5)
        def H(s):return 4*kap/lam*s*s.exp()*(mu+lam*(-s).exp())**2
        def Q(s):return (-s).exp()*(s-1)/(s+1)
        def bis(fun,lo,hi):
            lo=D(lo);hi=D(hi);fl=fun(lo);assert fl*fun(hi)<0
            for _ in range(sp['decimal_bisections']):
                mid=(lo+hi)/2;fm=fun(mid)
                if fl*fm>0:lo=mid;fl=fm
                else:hi=mid
            return (lo+hi)/2
        roots=[bis(lambda s:H(s)-load,*r) for r in sp['root_brackets']];folds=[bis(lambda s:Q(s)-mu/3,D(1),D(3).sqrt()),bis(lambda s:Q(s)-mu/3,D(3).sqrt(),D(50))]
        residual=max(abs(H(s)-load) for s in roots);assert residual<D('1e-55')
        dec={'precision':ctx.prec,'bisections':sp['decimal_bisections'],'roots':[str(v) for v in roots],'folds':[str(v) for v in folds],'root_residual':str(residual),'scope':'Rounded high-precision arithmetic independent of SciPy and Lambert-W; not a directed interval root certificate'}
    N=sp['rational_exponential_order']
    def enclosure(x):
        x=F(x);lower=sum((x**k/F(factorial(k)) for k in range(N+1)),F(0));upper=lower+x**(N+1)/F(factorial(N+1))/(1-x/F(N+2));return lower,upper
    e3lo,e3hi=enclosure(3);assert F(502,25)<e3lo<e3hi<F(2009,100)
    # H3(3) upper bound at the two independent monotone endpoints.
    h3upper=F(1,25)*e3hi+F(12,5)+F(36)/e3lo;assert h3upper<5
    e1lo,e1hi=enclosure(1);assert e1hi<F(11,4)
    h1lower=F(1,75)*e1lo+F(4,5)+F(12)/e1hi;assert h1lower>5
    e4lo,e4hi=enclosure(4);h4lower=F(4,75)*e4lo+F(16,5)+F(48)/e4hi;assert h4lower>5
    e5lo,e5hi=enclosure(5);q5lo=F(2,3)/e5hi;q5hi=F(2,3)/e5lo;assert F(1,300)<q5lo<q5hi<F(1,100)
    rational={'order':N,'H3(1)_strict_lower':str(h1lower),'H3(3)_strict_upper':str(h3upper),'H3(4)_strict_lower':str(h4lower),'exp3_lower':str(e3lo),'exp3_upper':str(e3hi),'q5_lower':str(q5lo),'q5_upper':str(q5hi),'all_exact_inequalities_pass':True,'scope':'Exact rational exponential Taylor/tail inequalities; no full matrix or flow enclosure'}
    result={'decimal':dec,'rational':rational,'all_checks_pass':True}
    if (out/'calculations.json').exists():
        actual=json.loads((out/'calculations.json').read_text());diff=max(abs(float(s)-r['s']) for s,r in zip(roots,actual['roots']));assert diff<sp['criteria']['decimal_root_difference_max'];result['difference_from_complete_calculation']=diff
    (out/'independent_scalar.json').write_text(json.dumps(result,indent=2));print(json.dumps({'independent_scalar':'PASS','roots':dec['roots'],'exact_scalar_inequalities':'PASS'},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(p.parse_args().base)
