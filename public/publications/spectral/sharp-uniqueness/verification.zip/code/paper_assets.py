"""Generate publication table fragments from this run, never a reference run."""
from pathlib import Path
import json,argparse,hashlib
def generate(base):
    base=Path(base);a=base/'assets';d=json.loads((base/'results/calculations.json').read_text());sp=json.loads((base/'specification.json').read_text())
    def table(name,heads,rows,formats):
        lines=['\\begin{tabular}{'+'l'+'r'*(len(heads)-1)+'}','\\toprule',' & '.join(heads)+r' \\',r'\midrule']
        for row in rows:
            lines.append(' & '.join(str(v).replace('_',r'\_') if f is None else format(v,f) for v,f in zip(row,formats))+r' \\')
        lines += [r'\bottomrule',r'\end{tabular}']
        (a/(name+'.tex')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    rr=d['roots']
    table('paper_branches',['Branch','$s$','$R$','$F$','$V$','$n_+$'],[[r['label'],r['s'],r['amplitude_norm'],r['energy'],r['tilt'],r['unstable_A']] for r in rr],[None,'.6f','.6f','.6f','.6f','d'])
    table('paper_response',['Branch','$e^{-s}$','$P_*$','$\\|\\chi_{\\rm clamp}\\|$','$\\|\\chi_{\\rm full}\\|$'],[[r['label'],__import__('math').exp(-r['s']),r['steady_power'],r['clamped_static_norm'],r['full_static_norm']] for r in rr],[None,'.6f','.6f','.6f','.6f'])
    table('paper_folds',['Fold','$s$','$a$','$l^TX_a$','$\\frac12 l^TX_{xx}[r,r]$'],[[n,r['s'],r['drive_amplitude'],r['transversality'],r['quadratic_coefficient']] for n,r in zip(['Upper input','Lower input'],d['folds'])],[None,'.6f','.6f','.6f','.6f'])
    table('paper_basins',['Preparation','Target','$V_M-V(0)$','Final error','Ledger error'],[[n,r['target'],r['initial_basin_margin'],r['terminal_error'],r['physical_ledger']] for n,r in d['trajectories'].items()],[None,None,'.3e','.2e','.2e'])
    table('paper_switching',['Pulse','Work','Dissipation','$\\Delta F$','Final margin'],[[n,r['supplied_work'],r['dissipation'],r['stored_energy_change'],r['final_basin_margin']] for n,r in d['switching'].items()],[None,'.6f','.6f','.6f','.6f'])
    table('paper_schedule',['Pulse','Initial','$a_{\\rm pulse}$','$T_{\\rm pulse}$','$a_{\\rm return}$','$T_{\\rm return}$'],[[r['name'],r['start'],r['pulse_amplitude'],r['pulse_duration'],r['return_amplitude'],r['return_duration']] for r in sp['switches']],[None,None,'.1f','.0f','.1f','.0f'])
    table('paper_controls',['Control','Quantity','Value'],[['Fixed carrier','Stored energy',d['fixed_carrier']['stored_energy']],['Fixed carrier','Stationary power',d['fixed_carrier']['steady_power']],['Unique adaptive','$\\mu$',d['unique_control']['mu']],['Unique adaptive','Final error',d['unique_control']['terminal_error']],['Real-gradient RK4','Difference',d['independent_RK4']['difference']]],[None,None,'.6g'])
    receipt={'inputs':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['results/calculations.json','specification.json']},'tables':[p.name for p in sorted(a.glob('paper_*.tex'))],'contract':'All fragments generated from this run; diagnostic digits are display only. Original scientific criteria unchanged.'}
    (a/'PAPER_ASSETS.json').write_text(json.dumps(receipt,indent=2))
    print('Seven publication tables generated from own-run outputs',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);generate(p.parse_args().base)
