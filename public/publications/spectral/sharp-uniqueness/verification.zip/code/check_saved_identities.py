"""Read-only post-result identity audit, not a new predictive/holdout test."""
from pathlib import Path
import argparse,json,math
import numpy as np
def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());d=json.loads((base/'results/calculations.json').read_text());p=sp['parameters'];mu=p['mu'];kap=p['kappa'];g=p['gamma'];al=p['alpha'];c=complex(g,al);a=sp['drive_amplitude'];tol=sp['criteria']['mean_error_max'];b=np.array(sp['graph'],float);L=b.T@b
    fixed=np.array(d['fixed_carrier']['state_real'])+1j*np.array(d['fixed_carrier']['state_imag']);maximum=0.;static_error=0.;energy_error=0.
    with np.load(base/'results/trajectories.npz') as data:
        for name in ['fixed_low','fixed_high']:
            err=float(np.linalg.norm(data[name][:,-1]-fixed));assert err<tol;maximum=max(maximum,err)
        assert len(data.files)==20
        for name in data.files:assert np.all(np.isfinite(data[name])),name
    for row in d['roots']:
        x=np.array(row['state']);assert abs(np.mean(x[:3]+1j*x[3:6]))<tol
        s=row['s'];R=row['amplitude_norm'];w=math.exp(-s);q=w*(s-1)/(s+1);expected=.5*mu*R*R+kap*(2*s+s*s);ee=abs(expected-row['energy']);assert ee<tol;energy_error=max(energy_error,ee)
        expected_clamp=1/(abs(c)*mu);eigs=[mu,mu-q,mu-3*q,mu,mu+w,mu+3*w];expected_full=1/(abs(c)*min(abs(v) for v in eigs));se=max(abs(expected_clamp-row['clamped_static_norm']),abs(expected_full-row['full_static_norm']));assert se<tol;static_error=max(static_error,se)
        assert abs(row['steady_power']-g*a*a/abs(c)**2)<sp['criteria']['power_error_max']
    expected_fixed_energy=a*a/(2*abs(c)**2*(mu+3));assert abs(d['fixed_carrier']['stored_energy']-expected_fixed_energy)<tol
    result={'status':'PASS','scope':'Read-only identities on already inspected reference data, not unseen outcomes or a replacement for full replay','fixed_control_terminal_difference':maximum,'closed_energy_identity_max':energy_error,'closed_static_norm_identity_max':static_error,'finite_trajectory_arrays':20,'comparison_ceiling':tol,'fixed_carrier_energy':expected_fixed_energy,'stable_mean_power_and_clamped_norm_identical':True,'stable_full_norm_difference':d['roots'][2]['full_static_norm']-d['roots'][0]['full_static_norm']}
    print(json.dumps(result,indent=2));return result
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
