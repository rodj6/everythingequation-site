"""Independent cubic rather than complete-Hessian eigenvalue calculation."""
from pathlib import Path
import argparse,json,math
import numpy as np
from scipy.optimize import linear_sum_assignment
def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());bs=json.loads((base/'BLOCK_SPECIFICATION.json').read_text());ind=json.loads((base/'results/independent_scalar.json').read_text());p=sp['parameters'];g=p['gamma'];al=p['alpha'];eta=p['eta'];kap=p['kappa'];c2=g*g+al*al
    roots=[float(s) for s in ind['decimal']['roots']];folds=[float(s) for s in ind['decimal']['folds']];cases=list(zip(bs['cases'],roots+folds+[sp['counterexample']['s']]));result=[]
    full=json.loads((base/'results/calculations.json').read_text()) if (base/'results/calculations.json').exists() else None
    for i,(name,s) in enumerate(cases):
        mu=sp['counterexample']['mu'] if name=='transverse_failure' else p['mu'];w=math.exp(-s);h=kap*(1+s);ev=[complex(-mu*g,mu*al),complex(-mu*g,-mu*al)];blocks=[]
        for lam in [1,3]:
            k=mu+lam*w;beta2=2*kap*lam*s*w;A2=2*g*k+eta*h;A1=c2*k*k+eta*g*(2*h*k-beta2);A0=eta*c2*k*(h*k-beta2);rh=A2*A1-A0;assert A2>0 and A1>0 and rh>0
            zz=np.roots([1.,A2,A1,A0]);ev.extend(zz);blocks.append({'lambda':lam,'coefficients':[1.,A2,A1,A0],'rho':k-beta2/h,'routh_margin':rh})
        ev=np.array(ev);unstable=int(sum(ev.real>bs['eigenvalue_zero_tolerance']));zero=int(sum(abs(ev)<bs['eigenvalue_zero_tolerance']));assert unstable==bs['expected_unstable_counts'][i] and zero==bs['expected_zero_counts'][i]
        row={'case':name,'s':s,'blocks':blocks,'eigenvalues':np.c_[ev.real,ev.imag].tolist(),'unstable':unstable,'zero':zero}
        if full:
            ff=full['roots'][i]['A_eigenvalues'] if i<3 else full['folds'][i-3]['A_eigenvalues'] if i<5 else full['counterexample']['A_eigenvalues'];ff=np.array(ff);vv=np.c_[ev.real,ev.imag];dist=np.linalg.norm(vv[:,None]-ff[None,:],axis=2);ii,jj=linear_sum_assignment(dist);difference=float(max(dist[ii,jj]));assert difference<bs['full_spectrum_comparison_max'];row['difference_from_complete_spectrum']=difference
        result.append(row)
    (base/'results/block_fixture.json').write_text(json.dumps({'all_checks_pass':True,'cases':result,'scope':bs['limits']},indent=2));print(json.dumps({'independent_cubic_fixture':'PASS','cases':len(result),'complete_spectrum_comparison':bool(full)}))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
