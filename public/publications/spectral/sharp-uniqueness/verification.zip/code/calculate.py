"""Frozen bounded full-state bifurcation and switching checks."""
from pathlib import Path
import argparse,json,math
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq,root
from scipy.linalg import expm

def run(base):
    base=Path(base);sp=json.loads((base/'specification.json').read_text());p=sp['parameters'];cr=sp['criteria'];out=base/'results';out.mkdir(exist_ok=True)
    b=np.array(sp['graph'],float);E=np.einsum('ei,ej->eij',b,b);L=E.sum(0);mu=p['mu'];kap=p['kappa'];g=p['gamma'];al=p['alpha'];eta=p['eta'];c=g+1j*al
    v=np.array([1.,-2.,1.])/np.sqrt(6);v1=np.array([1.,0.,-1.])/np.sqrt(2);a=sp['drive_amplitude'];f=a*v;phase=abs(c)/c
    J=np.block([[np.zeros((3,3)),-np.eye(3)],[np.eye(3),np.zeros((3,3))]]);G=g*np.eye(6)+al*J;D=np.block([[G,np.zeros((6,2))],[np.zeros((2,6)),eta*np.eye(2)]])
    checks=[];arrays={}
    def check(name,value,relation,limit):
        value=float(value);limit=float(limit);passed=math.isfinite(value) and {'lt':value<limit,'gt':value>limit,'eq':value==limit}[relation]
        checks.append(dict(name=name,value=value,relation=relation,threshold=limit,passed=bool(passed)))
    def q(s):return math.exp(-s)*(s-1)/(s+1)
    def curve(s,lam=3,mm=mu):return 4*kap/lam*s*math.exp(s)*(mm+lam*math.exp(-s))**2
    def state(s,lam=3,mode=v):
        z=phase*math.sqrt(4*kap/lam*s*math.exp(s))*mode;return np.r_[z.real,z.imag,-s,-s]
    def parts(x,mm=mu):
        z=x[:3]+1j*x[3:6];m=x[6:8];w=np.exp(m);K=mm*np.eye(3)+np.einsum('e,eij->ij',w,E);force=K@z;fm=kap*m+.5*w*abs(b@z)**2
        return z,m,w,K,force,fm
    def energy(x,mm=mu):
        z,m,w,K,force,fm=parts(x,mm);return float(.5*np.vdot(z,force).real+.5*kap*m@m)
    def tilt(x,ff=f,mm=mu):return energy(x,mm)-float(np.vdot(ff/c,x[:3]+1j*x[3:6]).real)
    def hessian(x,mm=mu):
        z,m,w,K,force,fm=parts(x,mm);KR=np.kron(np.eye(2),K);B=np.column_stack([w[e]*np.r_[E[e]@z.real,E[e]@z.imag] for e in range(2)]);Hm=np.diag(kap+.5*w*abs(b@z)**2)
        return np.block([[KR,B],[B.T,Hm]]),KR,B,Hm
    def rhs(ff,mm=mu,ledger=True):
        def fun(t,x):
            z,m,w,K,force,fm=parts(x,mm);dz=-c*force+ff;dx=np.r_[dz.real,dz.imag,-eta*fm]
            if ledger:dx=np.r_[dx,g*np.vdot(force,force).real+eta*(fm@fm),np.vdot(force,ff).real,g*np.vdot(force-ff/c,force-ff/c).real+eta*(fm@fm)]
            return dx
        return fun
    def integrate(x0,ff,T,mm=mu,tight=False,samples=None):
        cap=1/(8*abs(c)*(mm+math.exp(max(0.,*x0[6:8]))*np.linalg.norm(L,2)))
        sol=solve_ivp(rhs(ff,mm),[0,T],np.r_[x0,0.,0.,0.],method='DOP853',rtol=sp['tight_rtol'] if tight else sp['rtol'],atol=sp['tight_atol'] if tight else sp['atol'],max_step=cap,dense_output=True);assert sol.success
        times=np.linspace(0,T,samples or sp['samples']);xx=sol.sol(times);en=np.array([energy(y,mm) for y in xx.T]);vv=np.array([tilt(y,ff,mm) for y in xx.T])
        physical=float(np.max(abs(en-en[0]+xx[8]-xx[9])));tilted=float(np.max(abs(vv-vv[0]+xx[10])))
        return sol,times,xx,physical,tilted
    ss=[brentq(lambda s:curve(s)-sp['analytic_load_squared'],*bracket,xtol=sp['root_xtol']) for bracket in sp['root_brackets']];eq=[state(s) for s in ss];rows=[]
    for i,(s,x) in enumerate(zip(ss,eq)):
        H,KR,B,Hm=hessian(x);S=KR-B@np.linalg.solve(Hm,B.T);A=-D@H;ev=np.linalg.eigvals(A);he=np.linalg.eigvalsh(H);nneg=int(np.sum(he<-cr['zero_eigenvalue_tolerance']));nrhp=int(np.sum(ev.real>cr['zero_eigenvalue_tolerance']))
        fun=lambda y:np.r_[(parts(y)[4]-f/c).real,(parts(y)[4]-f/c).imag,parts(y)[5]]
        direct=root(fun,x+np.array(sp['perturbation'])*.01,jac=lambda y:hessian(y)[0],tol=1e-11)
        residual=np.linalg.norm(rhs(f,ledger=False)(0,x));diff=np.linalg.norm(x-direct.x);check(f'root/{i}',residual,'lt',cr['root_residual_max']);check(f'direct/{i}',diff,'lt',cr['direct_reduced_difference_max']);check(f'negative_H/{i}',nneg,'eq',sp['expected_hessian_negative_counts'][i]);check(f'positive_A/{i}',nrhp,'eq',sp['expected_unstable_eigenvalue_counts'][i])
        expected=np.sort([mu,mu-q(s),mu-3*q(s),mu,mu+math.exp(-s),mu+3*math.exp(-s)]);scherr=np.max(abs(np.linalg.eigvalsh(S)-expected));check(f'schur/{i}',scherr,'lt',cr['schur_spectrum_difference_max'])
        eps=sp['finite_difference_step'];fd=np.column_stack([(rhs(f,ledger=False)(0,x+eps*np.eye(8)[:,j])-rhs(f,ledger=False)(0,x-eps*np.eye(8)[:,j]))/(2*eps) for j in range(8)]);fderr=np.linalg.norm(fd-A,2);check(f'jacobian/{i}',fderr,'lt',cr['jacobian_difference_max'])
        if i!=1:check(f'stable/{i}',max(ev.real),'lt',cr['stable_abscissa_max'])
        else:check('middle_unstable',max(ev.real),'gt',cr['unstable_abscissa_min'])
        power=float(np.vdot(parts(x)[4],f).real);check(f'power/{i}',abs(power-g*a*a/abs(c)**2),'lt',cr['power_error_max'])
        mobility=[]
        for aa in sp['reactive_fixture_alphas']:
            GG=g*np.eye(6)+aa*J;DD=np.block([[GG,np.zeros((6,2))],[np.zeros((2,6)),eta*np.eye(2)]]);e=np.linalg.eigvals(-DD@H);cnt=int(np.sum(e.real>cr['zero_eigenvalue_tolerance']));check(f'inertia_alpha/{i}/{aa}',cnt,'eq',nneg);mobility.append({'alpha':aa,'positive_count':cnt,'abscissa':float(max(e.real))})
        rows.append({'label':['low','middle','high'][i],'s':s,'state':x.tolist(),'amplitude_norm':float(np.linalg.norm(x[:6])),'weights':np.exp(x[6:8]).tolist(),'energy':energy(x),'tilt':tilt(x),'steady_power':power,'H_eigenvalues':he.tolist(),'A_eigenvalues':np.c_[ev.real,ev.imag].tolist(),'negative_H':nneg,'unstable_A':nrhp,'root_residual':float(residual),'direct_difference':float(diff),'schur_error':float(scherr),'jacobian_error':float(fderr),'clamped_static_norm':float(np.linalg.norm(np.linalg.solve(KR,np.linalg.inv(G)),2)),'full_static_norm':float(np.linalg.norm(np.linalg.solve(S,np.linalg.inv(G)),2)),'mobility_checks':mobility})
    check('stable_state_separation',np.linalg.norm(eq[0]-eq[2]),'gt',cr['state_separation_min']);check('static_response_separation',abs(rows[0]['full_static_norm']-rows[2]['full_static_norm']),'gt',cr['response_separation_min'])
    fold_s=[brentq(lambda s:q(s)-mu/3,1,math.sqrt(3),xtol=sp['root_xtol']),brentq(lambda s:q(s)-mu/3,math.sqrt(3),50,xtol=sp['root_xtol'])];folds=[]
    for s in fold_s:
        x=state(s);aa=abs(c)*math.sqrt(curve(s));H,KR,B,Hm=hessian(x);A=-D@H;ev=np.linalg.eigvals(A);R=np.linalg.norm(x[:6]);rp=R*(1+s)/(2*s);r=np.r_[(phase*rp*v).real,(phase*rp*v).imag,-1.,-1.];h=np.r_[(v/c).real,(v/c).imag,0.,0.];den=r@np.linalg.solve(D,r);left=np.linalg.solve(D.T,r)/den
        hpp=4*kap/3*(mu*mu*math.exp(s)*(s+2)+9*math.exp(-s)*(s-2));app=abs(c)*hpp/(2*math.sqrt(curve(s)));trans=r@h/den;quad=-trans*app/2
        eps=sp['fold_second_difference_step'];ff=aa*v;fd2=(rhs(ff,ledger=False)(0,x+eps*r)-2*rhs(ff,ledger=False)(0,x)+rhs(ff,ledger=False)(0,x-eps*r))/eps**2;quadratic_fd=.5*left@fd2
        check('fold_kernel/'+str(s),np.linalg.norm(H@r),'lt',cr['fold_kernel_residual_max']);check('fold_zero/'+str(s),sum(abs(ev)<cr['zero_eigenvalue_tolerance']),'eq',1);check('fold_positive/'+str(s),sum(ev.real>cr['zero_eigenvalue_tolerance']),'eq',0);check('fold_trans/'+str(s),abs(trans),'gt',cr['nondegeneracy_min']);check('fold_quad/'+str(s),abs(quad),'gt',cr['nondegeneracy_min']);check('fold_FD/'+str(s),abs(quad-quadratic_fd),'lt',cr['fold_coefficient_difference_max'])
        folds.append({'s':s,'drive_amplitude':aa,'load_squared':curve(s),'a_second_derivative':app,'transversality':float(trans),'quadratic_coefficient':float(quad),'quadratic_finite_difference':float(quadratic_fd),'A_eigenvalues':np.c_[ev.real,ev.imag].tolist()})
    check('base_inside_folds_lower',a-folds[1]['drive_amplitude'],'gt',0);check('base_inside_folds_upper',folds[0]['drive_amplitude']-a,'gt',0)
    chi=(2-math.sqrt(3))*math.exp(-math.sqrt(3));endmu=3*chi;ends=math.sqrt(3);endx=state(ends);endH=hessian(endx,endmu)[0];endA=-D@endH;endev=np.linalg.eigvals(endA)
    check('endpoint_one_zero',sum(abs(endev)<cr['zero_eigenvalue_tolerance']),'eq',1);check('endpoint_no_positive',sum(endev.real>cr['zero_eigenvalue_tolerance']),'eq',0)
    # Retain the tempting scalar-stable but full-unstable fixture.
    cx=sp['counterexample'];cs=cx['s'];cmu=cx['mu'];cstate=state(cs,1,v1);ch=hessian(cstate,cmu)[0];cev=np.linalg.eigvals(-D@ch);cn=int(sum(cev.real>cr['zero_eigenvalue_tolerance']));check('counterexample_full',cn,'eq',cx['expected_full_unstable_count']);check('counterexample_sector_curvature',cmu-q(cs),'gt',0);check('counterexample_transverse_curvature',cmu-3*q(cs),'lt',0)
    counter={'s':cs,'mu':cmu,'state':cstate.tolist(),'drive_amplitude':abs(c)*math.sqrt(curve(cs,1,cmu)),'sector_curvature':cmu-q(cs),'transverse_curvature':cmu-3*q(cs),'full_unstable_count':cn,'A_eigenvalues':np.c_[cev.real,cev.imag].tolist()}
    # Full-coordinate basin tests. No state or energy coordinate is discarded.
    pert=np.array(sp['perturbation']);inits={}
    for i,label in [(0,'low'),(2,'high')]:
        for sign in [-1,1]:inits[f'{label}_{sign:+d}']=(eq[i]+sign*pert,i)
    A=-D@hessian(eq[1])[0];vals,vecs=np.linalg.eig(A);unstable=vecs[:,np.argmax(vals.real)].real;unstable/=np.linalg.norm(unstable)
    if np.vdot(phase*v,unstable[:3]+1j*unstable[3:6]).real<0:unstable=-unstable
    for sign,target in [(-1,0),(1,2)]:inits[f'saddle_{sign:+d}']=(eq[1]+sign*sp['saddle_perturbation']*unstable,target)
    trajectories={};vm=rows[1]['tilt'];rm=rows[1]['amplitude_norm']
    for name,(x0,target) in inits.items():
        (out/'progress.json').write_text(json.dumps({'stage':name}))
        sol,t,x,pe,ve=integrate(x0,f,sp['T']);tight=integrate(x0,f,sp['T'],tight=True)[0];conv=float(np.max(abs(x-tight.sol(t))));error=float(np.linalg.norm(x[:8,-1]-eq[target]));mean=(x[:3]+1j*x[3:6]).mean(0);meanerr=float(np.max(abs(mean-mean[0]*np.exp(-c*mu*t))))
        margin=vm-tilt(x0);rad=abs(v@(x0[:3]+1j*x0[3:6]));check(name+'/initial_basin_energy',margin,'gt',cr['basin_energy_margin_min']);check(name+'/initial_basin_side',(rm-rad) if target==0 else (rad-rm),'gt',0);check(name+'/terminal',error,'lt',cr['terminal_error_max']);check(name+'/convergence',conv,'lt',cr['convergence_max']);check(name+'/physical_ledger',pe,'lt',cr['ledger_max']);check(name+'/tilted_ledger',ve,'lt',cr['ledger_max']);check(name+'/mean',meanerr,'lt',cr['mean_error_max'])
        trajectories[name]={'target':rows[target]['label'],'terminal_error':error,'convergence_max':conv,'physical_ledger':pe,'tilted_ledger':ve,'mean_error':meanerr,'initial_basin_margin':margin,'initial_radius':float(rad)};arrays[name+'_times']=t;arrays[name+'_state_ledgers']=x
    # Previously proved unique regime and matched no-feedback controls.
    um=sp['unique_control_mu'];us=brentq(lambda s:curve(s,3,um)-5,0,20,xtol=sp['root_xtol']);ux=state(us);sol,t,x,pe,ve=integrate(eq[2]+pert,f,sp['T'],mm=um);ue=float(np.linalg.norm(x[:8,-1]-ux));check('unique_control_endpoint',ue,'lt',cr['terminal_error_max']);check('unique_control_physical',pe,'lt',cr['ledger_max']);arrays['unique_times']=t;arrays['unique_state_ledgers']=x
    K0=mu*np.eye(3)+L;fixedstar=np.linalg.solve(K0,f/c)
    for i,label in [(0,'low'),(2,'high')]:
        z0=eq[i][:3]+1j*eq[i][3:6];fixed=np.column_stack([fixedstar+expm(-c*K0*tt)@(z0-fixedstar) for tt in t]);arrays['fixed_'+label]=fixed
    # Independent real-gradient RK4, both physical ledgers, no shared complex RHS.
    rksp=sp['independent_RK4'];x0=eq[0]+pert;yy=np.r_[x0,0.,0.];fr=np.r_[f,np.zeros(3)]
    def real_rhs(y):
        qq=y[:6];mm=y[6:8];force=mu*qq.copy();fm=kap*mm.copy()
        for e in range(2):
            w=math.exp(mm[e]);dr=b[e]@qq[:3];di=b[e]@qq[3:];force[:3]+=w*dr*b[e];force[3:]+=w*di*b[e];fm[e]+=.5*w*(dr*dr+di*di)
        return np.r_[-g*force[:3]+al*force[3:]+f,-g*force[3:]-al*force[:3],-eta*fm,g*(force@force)+eta*(fm@fm),force@fr]
    dt=rksp['dt'];steps=round(rksp['T']/dt)
    for _ in range(steps):
        k1=real_rhs(yy);k2=real_rhs(yy+dt*k1/2);k3=real_rhs(yy+dt*k2/2);k4=real_rhs(yy+dt*k3);yy+=dt*(k1+2*k2+2*k3+k4)/6
    dop=integrate(x0,f,rksp['T'],tight=True,samples=2)[2][:10,-1];rkerr=float(np.max(abs(dop-yy)));check('independent_RK4',rkerr,'lt',cr['independent_RK4_difference_max'])
    switching={}
    for sw in sp['switches']:
        name=sw['name'];(out/'progress.json').write_text(json.dumps({'stage':'switch_'+name}));start=0 if sw['start']=='low' else 2;target=0 if sw['target']=='low' else 2;x0=eq[start];physical=[];tilted=[];cur=x0.copy();offset=np.zeros(3);xx=[];tt=[];T0=0.
        for aa,duration in [(sw['pulse_amplitude'],sw['pulse_duration']),(sw['return_amplitude'],sw['return_duration'])]:
            sol,ts,x,pe,ve=integrate(cur,aa*v,duration,samples=sp['switch_samples_per_segment']);physical.append(pe);tilted.append(ve);cur=x[:8,-1].copy();x[8:]+=offset[:,None];offset=x[8:,-1].copy();xx.append(x);tt.append(ts+T0);T0+=duration
        merged=np.concatenate([xx[0],xx[1][:,1:]],axis=1);times=np.r_[tt[0],tt[1][1:]];end=merged[:8,-1];error=float(np.linalg.norm(end-eq[target]));margin=vm-tilt(end);rad=abs(v@(end[:3]+1j*end[3:6]));check('switch_'+name+'/target',error,'lt',cr['terminal_error_max']);check('switch_'+name+'/energy_basin',margin,'gt',cr['basin_energy_margin_min']);check('switch_'+name+'/side',(rm-rad) if target==0 else (rad-rm),'gt',0);check('switch_'+name+'/physical',max(physical),'lt',cr['ledger_max']);check('switch_'+name+'/tilt_segments',max(tilted),'lt',cr['ledger_max'])
        # Whole-trajectory physical ledger, with no fictitious state jump.
        ens=np.array([energy(y) for y in merged.T]);whole=float(np.max(abs(ens-ens[0]+merged[8]-merged[9])));check('switch_'+name+'/whole_work_ledger',whole,'lt',cr['ledger_max'])
        # Repeat tight by segment for state and integrated-work agreement.
        cur=x0.copy();last=None
        for aa,dur in [(sw['pulse_amplitude'],sw['pulse_duration']),(3.,sw['return_duration'])]:last=integrate(cur,aa*v,dur,tight=True,samples=2)[2];cur=last[:8,-1]
        tightdiff=float(np.linalg.norm(end-cur));check('switch_'+name+'/tight_endpoint',tightdiff,'lt',cr['convergence_max'])
        switching[name]={'schedule':sw,'terminal_error':error,'final_basin_margin':margin,'final_radius':float(rad),'physical_ledger':whole,'segment_tilt_ledger':max(tilted),'tight_endpoint_difference':tightdiff,'supplied_work':float(merged[9,-1]),'dissipation':float(merged[8,-1]),'stored_energy_change':float(ens[-1]-ens[0]),'final_state':end.tolist()};arrays['switch_'+name+'_times']=times;arrays['switch_'+name+'_state_ledgers']=merged
    check('returned_same_input_distinct_states',np.linalg.norm(np.array(switching['up']['final_state'])-switching['down']['final_state']),'gt',cr['state_separation_min'])
    result={'all_checks_pass':all(c['passed'] for c in checks),'chi':chi,'original_margin':mu-3*chi,'roots':rows,'folds':folds,'endpoint':{'mu':endmu,'s':ends,'A_eigenvalues':np.c_[endev.real,endev.imag].tolist()},'counterexample':counter,'trajectories':trajectories,'unique_control':{'mu':um,'s':us,'terminal_error':ue},'fixed_carrier':{'state_real':fixedstar.real.tolist(),'state_imag':fixedstar.imag.tolist(),'stored_energy':float(.5*np.vdot(fixedstar,K0@fixedstar).real),'steady_power':float(g*a*a/abs(c)**2)},'independent_RK4':{'steps':steps,'difference':rkerr},'switching':switching,'checks':checks,'evidence':'Proved branch counts and inertia theorems; floating roots/eigenvalues/trajectories; independent real-gradient RK4; not physical or directed flow certification'}
    (out/'calculations.json').write_text(json.dumps(result,indent=2));np.savez_compressed(out/'trajectories.npz',**arrays);(out/'progress.json').write_text(json.dumps({'stage':'complete','all_checks_pass':result['all_checks_pass']}));print(json.dumps({'checks':len(checks),'all_pass':result['all_checks_pass'],'failed':[v for v in checks if not v['passed']],'roots':[r['s'] for r in rows],'folds':[r['drive_amplitude'] for r in folds]},indent=2));assert result['all_checks_pass'],'Preserve this failed run and diagnose without changing frozen thresholds'
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);run(ap.parse_args().base)
