"""Meaningful verifier mutations, without duplicating the source integration."""
from pathlib import Path
import json,copy,tempfile,shutil
from validation import acceptance,tables
def run():
    base=Path(__file__).resolve().parent;d=json.loads((base/'results/calculations.json').read_text());sp=json.loads((base/'specification.json').read_text());count=0
    def reject(x):
        nonlocal count
        try:acceptance(x,d,sp)
        except AssertionError:count+=1;return
        raise AssertionError('Scientific mutation accepted')
    x=copy.deepcopy(d);x['checks'][0]['threshold']*=10;reject(x)
    x=copy.deepcopy(d);x['roots'][0]['state'][0]+=.1;reject(x)
    x=copy.deepcopy(d);x['roots'][1]['unstable_A']=0;reject(x)
    x=copy.deepcopy(d);x['checks'][0]['name']='wrong scientific label';reject(x)
    x=copy.deepcopy(d);x['checks'][0]['passed']=False;reject(x)
    # Legitimate numerical residual change stays below its original criterion.
    x=copy.deepcopy(d);x['roots'][0]['root_residual']=sp['criteria']['root_residual_max']/2;acceptance(x,d,sp);count+=1
    with tempfile.TemporaryDirectory() as tmp:
        folder=Path(tmp)/'assets';shutil.copytree(base/'assets',folder)
        for p in folder.glob('*.csv'):p.write_bytes(p.read_bytes().replace(b'\n',b'\r\n'))
        tables(folder);count+=1
        p=folder/'branches.csv';p.write_text(p.read_text().replace('memory_s','wrong_column'))
        try:tables(folder)
        except AssertionError:count+=1
        else:raise AssertionError('Table label mutation accepted')
    print(json.dumps({'verifier_regressions':'PASS','checks':count}))
if __name__=='__main__':run()
