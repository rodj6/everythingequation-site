"""Clean extracted-package replay into a new directory; references stay intact."""
from pathlib import Path
import argparse,json,hashlib,tempfile,shutil,subprocess,sys,platform
import numpy as np
import scipy
from validation import acceptance,tables
def run(output=None):
    base=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    for e in json.loads((base/'MANIFEST.json').read_text())['files']:assert sha(base/e['path'])==e['sha256'],e['path']
    for freeze in ['FROZEN.json','BLOCK_FROZEN.json']:
        for n,h in json.loads((base/freeze).read_text())['files'].items():
            if n in {'DERIVATIONS.txt','BLOCK_ANALYSIS.txt'}:continue # ancestry-only proof notes, see README
            assert sha(base/n)==h,n
    sp=json.loads((base/'specification.json').read_text());ref=json.loads((base/'results/calculations.json').read_text());acceptance(ref,ref,sp);tables(base/'assets')
    out=Path(output).resolve() if output else Path(tempfile.mkdtemp(prefix='multistability_replay_'));assert not out.exists() or not any(out.iterdir()),'Choose a new empty output directory'
    out.mkdir(exist_ok=True,parents=True);shutil.copytree(base/'code',out/'code')
    for n in ['specification.json','BLOCK_SPECIFICATION.json']:shutil.copy2(base/n,out/n)
    for script in ['calculate.py','independent_scalar.py','block_fixture.py','make_assets.py']:
        proc=subprocess.run([sys.executable,str(out/'code'/script),'--base',str(out)],capture_output=True,text=True);(out/(script+'.log')).write_text(proc.stdout+proc.stderr,encoding='utf-8')
        if proc.returncode:raise RuntimeError(script+' failed; preserve output and inspect its log')
        print(script+': PASS',flush=True)
    actual=json.loads((out/'results/calculations.json').read_text());count=acceptance(actual,ref,sp)
    with np.load(base/'results/trajectories.npz') as a,np.load(out/'results/trajectories.npz') as b:
        assert set(a.files)==set(b.files)
        for n in a.files:np.testing.assert_allclose(a[n],b[n],rtol=sp['criteria']['replay_rtol'],atol=sp['criteria']['replay_atol'],err_msg=n)
        arrays=len(a.files)
    independent=json.loads((out/'results/independent_scalar.json').read_text());assert independent['all_checks_pass'] is True and independent['rational']['all_exact_inequalities_pass'] is True
    for s,row in zip(independent['decimal']['folds'],actual['folds']):assert abs(float(s)-row['s'])<sp['criteria']['decimal_root_difference_max']
    blocks=json.loads((out/'results/block_fixture.json').read_text());assert blocks['all_checks_pass'] is True and len(blocks['cases'])==6
    assert all(row['difference_from_complete_spectrum']<2e-8 for row in blocks['cases'])
    tables(out/'assets')
    subprocess.run([sys.executable,str(base/'code/paper_assets.py'),'--base',str(out)],check=True)
    receipt={'status':'PASS','frozen_numerical_conditions':count,'trajectory_arrays':arrays,'independent_decimal_and_exact_rational_checks':'PASS','independent_cubic_spectra':6,'reference_and_own_run_tables':'PASS','python':platform.python_version(),'system':platform.system(),'numpy':np.__version__,'scipy':scipy.__version__,'scope':'Actual clean extracted replay with installed dependencies. RK4, Decimal and cubic characteristics are separate formulations; full-matrix and polynomial eigenvalue checks share the NumPy backend. Same-code replay is separate. No physical experiment, second OS, fresh installation or directed trajectory certification.'}
    (out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);run(ap.parse_args().output)
