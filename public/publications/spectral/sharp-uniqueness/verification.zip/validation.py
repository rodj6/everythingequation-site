"""Scientific comparison and own-run table validation, portable across roundoff."""
from pathlib import Path
import json,csv,math
import numpy as np
from scipy.optimize import linear_sum_assignment

CEILINGS={'root_residual':'root_residual_max','direct_difference':'direct_reduced_difference_max','schur_error':'schur_spectrum_difference_max','jacobian_error':'jacobian_difference_max','terminal_error':'terminal_error_max','convergence_max':'convergence_max','physical_ledger':'ledger_max','tilted_ledger':'ledger_max','mean_error':'mean_error_max','segment_tilt_ledger':'ledger_max','tight_endpoint_difference':'convergence_max','difference':'independent_RK4_difference_max'}
def acceptance(d,ref,sp):
    assert d['all_checks_pass'] is True;assert len(d['checks'])==len(ref['checks'])
    def label(check,data):
        # A floating fold coordinate in a diagnostic name is not a discrete
        # label. Preserve the named check and exact fold ordinal, verifying its
        # coordinate separately against that run's own fold record.
        name=check['name'];prefix,sep,suffix=name.partition('/')
        if prefix in ['fold_kernel','fold_zero','fold_positive','fold_trans','fold_quad','fold_FD']:
            assert sep
            matches=[i for i,row in enumerate(data['folds']) if abs(float(suffix)-row['s'])<1e-12]
            assert len(matches)==1,name
            return prefix+'/fold_'+str(matches[0])
        return name
    for a,r in zip(d['checks'],ref['checks']):
        assert label(a,d)==label(r,ref),(a,r)
        for k in ['relation','threshold']:assert a[k]==r[k],a
        val=a['value'];t=a['threshold'];assert math.isfinite(val)
        assert {'lt':val<t,'gt':val>t,'eq':val==t}[a['relation']] and a['passed'] is True,a
    def compare(r,a,key='',path=''):
        if key=='checks':return
        if key=='A_eigenvalues':
            xx=np.array(r);yy=np.array(a);assert xx.shape==yy.shape
            dist=np.linalg.norm(xx[:,None]-yy[None,:],axis=2);ii,jj=linear_sum_assignment(dist);assert max(dist[ii,jj])<2e-8,path;return
        if isinstance(r,dict):
            assert r.keys()==a.keys(),path
            for k in r:
                if k=='quadratic_finite_difference':
                    assert abs(a[k]-a['quadratic_coefficient'])<sp['criteria']['fold_coefficient_difference_max'],path
                else:compare(r[k],a[k],k,path+'/'+k)
        elif isinstance(r,list):
            assert len(r)==len(a),path
            for i,(x,y) in enumerate(zip(r,a)):compare(x,y,key,path+'/'+str(i))
        elif isinstance(r,(str,bool,int)) or r is None:assert type(r)==type(a) and r==a,(path,r,a)
        elif key in CEILINGS:assert math.isfinite(a) and 0<=a<sp['criteria'][CEILINGS[key]],(path,a)
        else:assert math.isclose(r,a,rel_tol=sp['criteria']['replay_rtol'],abs_tol=sp['criteria']['replay_atol']),(path,r,a)
    compare(ref,d)
    assert [r['negative_H'] for r in d['roots']]==sp['expected_hessian_negative_counts']
    assert [r['unstable_A'] for r in d['roots']]==sp['expected_unstable_eigenvalue_counts']
    return len(d['checks'])

def tables(folder):
    folder=Path(folder);d=json.loads((folder/'table_data.json').read_text())
    for name,t in d.items():
        with (folder/(name+'.csv')).open(newline='',encoding='utf-8') as f:rows=list(csv.reader(f))
        assert rows[0]==t['columns'] and len(rows)==len(t['rows'])+1,name
        for row,expected in zip(rows[1:],t['rows']):
            assert len(row)==len(expected)
            for token,v in zip(row,expected):
                if isinstance(v,str):assert token==v,(name,token,v)
                else:assert math.isfinite(float(token)) and math.isclose(float(token),v,rel_tol=4e-15,abs_tol=4*math.ulp(v)),(name,token,v)
