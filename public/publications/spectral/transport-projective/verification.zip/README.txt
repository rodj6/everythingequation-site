TRANSPORT AND PROJECTIVE REDUCTION IN A SOURCE-READOUT DERIVATION
OF EINSTEIN GRAVITY
Jeremy Rodgers, 4 November 2026
DOI: https://doi.org/10.5281/zenodo.23954887
Public activation of the reserved identifier is not asserted.

REPRODUCE
Python 3.12.14 was used, with pinned dependencies:
  python -m pip install -r requirements.txt
From this extracted directory, choose a new or empty sibling directory:
  python run_all.py --output ../new_replay

The runner verifies SHA-256 file hashes, executes ten suites, checks every
pass flag/count and compares complete saved scientific result objects.
Exact symbolic strings must match; floats use relative tolerance 1e-10 and
absolute tolerance 1e-12. Environment metadata is reported separately.
It also regenerates and compares the two verification tables used in the
paper. Output logs retain errors. A successful run writes CLEAN_RUN.json.

EXPECTED RESULTS
99 checks: 91 exact finite-algebra checks and eight numerical estimates.
All 99 scientific checks, including the coordinate/density controls,
and their saved scientific outputs are unchanged in this release.

The final package was replayed on Windows with Python 3.12.14, SymPy 1.14.0
and mpmath 1.3.0. The actual receipt is in receipts/. No new Linux execution
is claimed for this revision.

FILES
code/: mathematical verification implementations.
inputs/: numerical settings and acceptance criteria.
results/: complete saved mathematical outputs.
tables/: tables generated directly from those outputs.
CLAIM_EVIDENCE.csv: paper labels, implementation/result paths and claim scope.
PROVENANCE.txt: academic sources and attribution.
MANIFEST_SHA256.json: hashes for distributed files other than itself.

No network access is needed after dependencies are installed. The numerical
transport fixture uses 60-digit arithmetic; the reference variation fixture
uses 70 digits. No environment, source archive or other dataset is required.
Finite checks support implementations and fixtures; the paper supplies the
general mathematical proofs. A successful run is not empirical validation
of the source realization or a formal global Einstein-evolution certificate.

TABLE PORTABILITY
Both table files are canonical UTF-8/LF. Comparison ignores only CRLF versus
LF, preserving all other content bytes. Three regressions test equivalent
line endings, reject content/numeric/whitespace/bare-CR mutations and verify
deterministic UTF-8/LF generation. The 99 scientific checks (91 exact, eight
numerical) are unchanged; the three portability regressions give 102 checks
including software regressions. Scientific JSON comparison is unchanged.
Windows was tested for this release. Linux was unavailable and was not
executed; the line-ending regressions are not described as a Linux replay.
