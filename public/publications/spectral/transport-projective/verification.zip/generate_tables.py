"""Generate the manuscript's verification tables from saved result receipts."""
from pathlib import Path
import json,sys

def compare_table_bytes(actual,expected):
    """Ignore only CRLF versus LF; preserve every other content byte."""
    actual.decode('utf-8');expected.decode('utf-8')
    if actual.replace(b'\r\n',b'\n')!=expected.replace(b'\r\n',b'\n'):
        raise ValueError('Generated table content mismatch')

def generate(base):
    base=Path(base)
    suites=[('Reference source realization',['reference/STRESS_CHECKS.json','reference/ENDPOINT_CHECKS.json','reference/TRANSPORT_CHECKS.json','reference/CONTROL_CHECKS.json']),
            ('General affine/projective algebra',['PROJECTIVE_CHECKS.json']),
            ('General horizontal stress',['GENERAL_STRESS_CHECKS.json']),
            ('Transport, matter and competitors',['TRANSPORT_SELECTION_CHECKS.json']),
            ('Independent off-shell residual',['RESIDUAL_CHECKS.json']),
            ('Regularity and scalar controls',['ASSUMPTION_CONTROL_CHECKS.json']),
            ('Coordinate and density controls',['PUBLICATION_CONTROL_CHECKS.json'])]
    lines=[r'\begin{tabular}{@{}lrrr@{}}\toprule',r'Suite & Exact & Numerical & Total\\\midrule']
    total_exact=total_numeric=0
    for label,names in suites:
        exact=numeric=0
        for name in names:
            receipt=base/'results'/name
            if not receipt.exists() and name.startswith('reference/'):
                receipt=base/'reference/results'/Path(name).name
            doc=json.loads(receipt.read_text())
            assert doc['status']=='PASS' and doc['count']==len(doc['checks'])
            for row in doc['checks']:
                assert row['passed'] is True
                if 'numerical' in row.get('kind','').lower():numeric+=1
                else:exact+=1
        total_exact+=exact;total_numeric+=numeric
        lines.append(f'{label} &{exact}&{numeric}&{exact+numeric}'+r'\\')
    assert (total_exact,total_numeric)==(91,8)
    lines.append(r'\midrule')
    lines.append(f'Total &{total_exact}&{total_numeric}&{total_exact+total_numeric}'+r'\\\bottomrule')
    lines.append(r'\end{tabular}')
    target=base/'tables';target.mkdir(exist_ok=True)
    (target/'check_counts.tex').write_bytes(('\n'.join(lines)+'\n').encode('utf-8'))
    doc=json.loads((base/'results/TRANSPORT_SELECTION_CHECKS.json').read_text())
    lines=[r'\begin{tabular}{@{}rrr@{}}\toprule',r'$N$&Transport error&Analytic upper bound\\\midrule']
    for row in doc['reconstruction']:
        lines.append(f"{row['N']}&{row['error']:.11f}&{row['bound']:.8f}"+r'\\')
    lines.extend([r'\bottomrule',r'\end{tabular}'])
    (target/'reconstruction.tex').write_bytes(('\n'.join(lines)+'\n').encode('utf-8'))

if __name__=='__main__':generate(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent)
