"""Reproduce finite checks; universal proofs remain in the manuscript."""
from pathlib import Path
import argparse, hashlib, json, math, os, platform, shutil, subprocess, sys

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def compare(a,b,path=''):
    if isinstance(b,dict):
        if not isinstance(a,dict) or set(a)!=set(b): raise ValueError('Different keys '+path)
        for k in b: compare(a[k],b[k],path+'/'+k)
    elif isinstance(b,list):
        if not isinstance(a,list) or len(a)!=len(b): raise ValueError('Different count '+path)
        for i,(x,y) in enumerate(zip(a,b)): compare(x,y,path+'/'+str(i))
    elif isinstance(b,float):
        if not isinstance(a,(float,int)) or not math.isfinite(a) or not math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12): raise ValueError('Numerical mismatch '+path)
    elif a!=b: raise ValueError('Exact mismatch '+path)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);args=p.parse_args()
    base=Path(__file__).resolve().parent;out=Path(args.output).resolve()
    if out==base or base in out.parents: raise SystemExit('Choose output outside the extracted package')
    if out.exists() and (not out.is_dir() or any(out.iterdir())): raise SystemExit('Output must be new or empty')
    manifest=json.loads((base/'MANIFEST_SHA256.json').read_text())
    for name,value in manifest.items():
        item=(base/name).resolve()
        if base not in item.parents or digest(item)!=value: raise SystemExit('Integrity failure: '+name)
    import sympy,mpmath
    if sympy.__version__!='1.14.0' or mpmath.__version__!='1.3.0': raise SystemExit('Install versions in requirements.txt')
    out.mkdir(parents=True,exist_ok=True);refout=out/'reference';refout.mkdir()
    shutil.copy2(base/'inputs/reference_SPECIFICATION.json',refout/'SPECIFICATION.json')
    jobs=[('reference/verify_stress.py','STRESS_CHECKS.json',6,True),
          ('reference/verify_endpoint.py','ENDPOINT_CHECKS.json',16,True),
          ('reference/verify_transport.py','TRANSPORT_CHECKS.json',14,True),
          ('reference/verify_controls.py','CONTROL_CHECKS.json',7,True),
          ('verify_projective.py','PROJECTIVE_CHECKS.json',20,False),
          ('verify_general_stress.py','GENERAL_STRESS_CHECKS.json',9,False),
          ('verify_transport_selection.py','TRANSPORT_SELECTION_CHECKS.json',18,False),
          ('verify_residual.py','RESIDUAL_CHECKS.json',3,False),
          ('verify_assumption_controls.py','ASSUMPTION_CONTROL_CHECKS.json',3,False),
          ('verify_publication_controls.py','PUBLICATION_CONTROL_CHECKS.json',3,False)]
    records=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    for i,(script,receipt,count,reference) in enumerate(jobs,1):
        target=refout if reference else out
        result=subprocess.run([sys.executable,str(base/'code'/script),str(target)],capture_output=True,text=True,env=env)
        log=out/f'run_{i:02}.log';log.write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        if result.returncode: raise SystemExit('Verification failed; inspect '+str(log))
        a=json.loads((target/'results'/receipt).read_text())
        b=json.loads((base/'results'/('reference' if reference else '')/receipt).read_text())
        if a.get('status')!='PASS' or a.get('count')!=count or any(r.get('passed') is not True for r in a['checks']): raise ValueError('Invalid receipt '+receipt)
        for record in (a,b):
            for key in ('python','sympy'): record.pop(key,None)
        compare(a,b,receipt);records.append({'suite':script,'checks':count,'saved_result_match':True})
    compare(json.loads((refout/'results/SOURCE_FAN17.json').read_text()),json.loads((base/'results/reference/SOURCE_FAN17.json').read_text()),'source support')
    from generate_tables import generate,compare_table_bytes
    generate(out)
    for table in ('check_counts.tex','reconstruction.tex'):
        compare_table_bytes((out/'tables'/table).read_bytes(),(base/'tables'/table).read_bytes())
    from verify_table_portability import verify
    portability=verify(out)
    compare(portability,json.loads((base/'results/TABLE_PORTABILITY_CHECKS.json').read_text()),'table portability regressions')
    payload={name:value for name,value in manifest.items() if not name.startswith('receipts/')}
    payload_hash=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    receipt={'status':'PASS','checks':sum(r['checks'] for r in records),'exact_finite_checks':91,'numerical_estimates':8,'suites':records,
             'portability_regressions':portability['count'],'total_checks_including_portability':99+portability['count'],
             'payload_sha256':payload_hash,
             'manifest_sha256':digest(base/'MANIFEST_SHA256.json'),
             'environment':{'python':platform.python_version(),'system':platform.system(),'sympy':sympy.__version__,'mpmath':mpmath.__version__},
             'scope':'Finite exact-algebra and numerical replay. Universal proofs are in the manuscript; no empirical validation or formal PDE certificate.'}
    if receipt['checks']!=99: raise ValueError('Unexpected total')
    (out/'CLEAN_RUN.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))

if __name__=='__main__': main()
