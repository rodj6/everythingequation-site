"""Regressions of text portability; separate from the 99 scientific checks."""
from pathlib import Path
import json,sys
from generate_tables import generate,compare_table_bytes

def verify(out):
    out=Path(out);names=('check_counts.tex','reconstruction.tex')
    first={n:(out/'tables'/n).read_bytes() for n in names}
    rows=[]
    def check(name,condition):
        if not condition:raise AssertionError(name)
        rows.append({'name':name,'passed':True,'kind':'portability regression'})
    # Check both conversion directions, never strip spaces, tabs or other bytes.
    for data in first.values():
        lf=data.replace(b'\r\n',b'\n');crlf=lf.replace(b'\n',b'\r\n')
        compare_table_bytes(lf,crlf);compare_table_bytes(crlf,lf)
    check('LF and CRLF versions of both tables compare equal',True)
    rejected=0
    for data in first.values():
        for changed in [data+b'% altered content\n',data.replace(b'1',b'9',1),data.replace(b'&',b' &',1),data.replace(b'\n',b'\r',1)]:
            try:compare_table_bytes(changed,data)
            except ValueError:rejected+=1
    check('content numeric whitespace and bare-CR mutations are rejected for both tables',rejected==8)
    generate(out)
    check('repeat generation is deterministic UTF-8 LF for both tables',all(
        data==(out/'tables'/n).read_bytes() and b'\r' not in data and not data.startswith(b'\xef\xbb\xbf')
        and data.decode('utf-8').encode('utf-8')==data for n,data in first.items()))
    receipt={'status':'PASS','count':len(rows),'checks':rows,'scope':'Text comparison and deterministic encoding regressions; separate from scientific result comparisons.'}
    (out/'results/TABLE_PORTABILITY_CHECKS.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    return receipt

if __name__=='__main__':print(json.dumps(verify(Path(sys.argv[1])),indent=2))
