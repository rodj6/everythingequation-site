ACTUAL REPLAY RECEIPT
windows_replay.json reports the actual clean-extraction run for this release:
99 scientific checks plus three separate portability regressions.
payload_sha256 hashes the sorted compact JSON manifest map with receipts/
entries excluded; all other payload files are bound without a receipt cycle.
The manifest separately hashes the distributed receipt. Full logs and the
complete manifest-bound receipt are delivered separately with private files.
No Linux execution is claimed for this release.
