from pathlib import Path
import json,sys,math
import sympy as s
import mpmath as mp

out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
rows=[]
def check(name,condition,kind='exact finite algebra',**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind=kind,**detail))
def zero(M):return all(s.simplify(z)==0 for z in M)

def connection_from_metric(g,x):
    inverse=g.inv();n=len(x)
    return [s.Matrix(n,n,lambda a,b:s.simplify(sum(inverse[a,c]*(s.diff(g[c,b],x[mu])+s.diff(g[c,mu],x[b])-s.diff(g[mu,b],x[c])) for c in range(n))/2)) for mu in range(n)]
def matrix_ricci(A,x):
    n=len(x);F={}
    for mu in range(n):
        for nu in range(n):F[mu,nu]=A[nu].diff(x[mu])-A[mu].diff(x[nu])+A[mu]*A[nu]-A[nu]*A[mu]
    return s.Matrix(n,n,lambda m,k:s.simplify(sum(F[a,k][a,m] for a in range(n))))

t=s.Symbol('t',positive=True);x,y,z=s.symbols('x y z',real=True);coords=[t,x,y,z]
g=s.diag(-1,t**s.Rational(-2,3),t**s.Rational(4,3),t**s.Rational(4,3))
LC=connection_from_metric(g,coords);V=[t,t,0,0];A=[LC[mu]+s.eye(4)*V[mu] for mu in range(4)]
Ricci=matrix_ricci(A,coords)
check('unrestricted projective Kasner connection solves symmetric vacuum equations',zero(Ricci+Ricci.T))
check('projective curvature can remain nonzero and antisymmetric',s.simplify(Ricci[0,1]-1)==0 and s.simplify(Ricci[1,0]+1)==0,antisymmetric_R01=str(Ricci[0,1]))
volume=s.sqrt(-g.det());Avol=[s.simplify(A[mu]-s.eye(4)*s.trace(A[mu])/4+s.eye(4)*s.diff(s.log(volume),coords[mu])/4) for mu in range(4)]
check('volume-gauge generator recovers LC without imposing torsion kinematically',all(zero(U-W) for U,W in zip(Avol,LC)))
check('raw connection has projective torsion',s.simplify(A[0][1,1]-A[1][1,0])!=0)
Tlc=s.diag(1,2**s.Rational(1,3),2**s.Rational(-2,3),2**s.Rational(-2,3));T=s.exp(-s.Rational(3,2))*Tlc
restored=s.simplify((1/(2*T.det()))**s.Rational(1,4))*T
check('finite source transport restores the exact metric transport',zero(restored-Tlc) and not zero(T-Tlc),metric_volume_ratio='1/2',projective_factor='exp(-3/2)')
U=s.eye(4);U[0,1]=1;W=s.diag(2,3,1,1);W[1,2]=2
restore=lambda Q,vin,vout:s.simplify((vin/(vout*Q.det()))**s.Rational(1,4))*Q
check('volume-restored readout preserves path composition',zero(restore(W*U,2,5)-restore(W,3,5)*restore(U,2,3)))

# Nontrivial scalar matter in the same unrestricted, projectively reduced parent.
amp,lam=s.symbols('a lambda',positive=True);kE=lam**2/2
H=-kE*amp**2*(y*y+z*z)/2
gp=s.Matrix([[H,-1,0,0],[-1,0,0,0],[0,0,1,0],[0,0,0,1]])
Lp=connection_from_metric(gp,coords);Ap=[Lp[mu]+s.eye(4)*V[mu] for mu in range(4)]
Rp=matrix_ricci(Ap,coords);Rs=(Rp+Rp.T)/2;Bp=gp.inv();phi=amp*t
dphi=s.Matrix([s.diff(phi,q) for q in coords]);stress=dphi*dphi.T-gp*((dphi.T*Bp*dphi)[0])/2
check('independent matrix-curvature implementation recovers nonlinear Einstein scalar equations',zero(Rs/lam**2-(stress-gp*s.trace(Bp*stress)/2)/2),components=10)
KG=sum(s.diff(Bp[m,n]*s.diff(phi,coords[n]),coords[m]) for m in range(4) for n in range(4))
check('the same source scalar solves its matter equation',s.simplify(KG)==0)

# Quantitative transport reconstruction, with an independent analytic solution.
mp.mp.dps=60
exact=mp.matrix([[mp.exp(-mp.mpf('.5')),-mp.exp(-mp.mpf('.5'))*mp.sqrt(mp.pi/2)*mp.erf(1/mp.sqrt(2))],[0,mp.exp(-1)]])
data=[]
for count in [10,20,40,80]:
    hh=mp.mpf(1)/count;U=mp.eye(2)
    for j in range(count):
        tj=j*hh;AA=mp.matrix([[tj,1],[0,2*tj]])
        U=(mp.eye(2)-hh*AA)*U
    error=max(sum(abs(U[i,j]-exact[i,j]) for j in range(2)) for i in range(2))
    bound=3*mp.exp(mp.mpf('2.2'))*hh
    check(f'finite reconstruction obeys its analytic bound N={count}',error<=bound,'numerical estimate')
    data.append({'N':count,'h':float(hh),'error':float(error),'bound':float(bound)})
rates=[math.log(a['error']/b['error'])/math.log(2) for a,b in zip(data,data[1:])]
check('source reconstruction has declared first-order convergence',all(.85<r<1.15 for r in rates[-2:]) and data[-1]['error']<.03,'numerical estimate',rates=rates,finest_error=data[-1]['error'])

# C0 closeness of full transport does not certify a curvature/Euler residual.
k=s.Symbol('k',positive=True);a=s.sin(k*t)/k
Ac=[s.zeros(4) for _ in range(4)];Ac[1][0,1]=a
Rc=matrix_ricci(Ac,coords)
check('arbitrarily small generator can retain order-one curvature residual',s.simplify(Rc[1,1].subs(t,0)-1)==0,source_generator_bound='1/k',probe_transport_bound='2/k^2',curvature_at_origin='1')

# Added constitutive inputs are not consequences of bare source admission.
alpha,kappa,rho=s.symbols('alpha kappa rho',positive=True);R=kappa*rho;f=R+alpha*R**2;fR=1+2*alpha*R
R00=(kappa*rho-f/2)/fR;GR00=kappa*rho/2
expected=-3*alpha*kappa**2*rho**2/(2*(1+2*alpha*kappa*rho))
check('covariant higher-curvature competitor has a different matter response',s.simplify(R00-GR00-expected)==0 and expected!=0,scope='Pointwise constant-trace algebraic response; not a claimed global dust solution',difference=str(expected))
Lambda=s.Symbol('Lambda',real=True);eta=s.diag(-1,1,1,1)
check('flat vacuum fixes Lambda within the declared EH plus Lambda family',zero((Lambda*eta).subs(Lambda,0)) and not zero(Lambda*eta))
xi=s.Symbol('xi',nonzero=True);conformal=s.exp(2*t*t)*eta
Rc=matrix_ricci(connection_from_metric(conformal,coords),coords)
scalar=s.simplify(s.trace(conformal.inv()*Rc))
check('common-density coupling alone permits a distinct nonminimal scalar law',s.simplify(scalar-12*(1+2*t*t)*s.exp(-2*t*t))==0 and xi*scalar!=0,minimal_constant_scalar_equation='0',nonminimal_constant_scalar_residual=str(-xi*scalar))
eps=s.Symbol('epsilon',positive=True);B=s.diag(-eps,1,1,1)
check('nondegeneracy is needed for bounded metric readout',s.simplify((B/s.sqrt(-B.det()))[1,1]-1/s.sqrt(eps))==0)

result={'status':'PASS','count':len(rows),'checks':rows,'reconstruction':data,'rates':rates,'scope':'Exact off-shell/on-shell constructed gravity and source-readout checks, plus finite numerical reconstruction estimates. No physical observations or formal PDE certificate.'}
(out/'results/TRANSPORT_SELECTION_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','checks':len(rows),'reconstruction':data,'rates':rates},indent=2))
