"""Retained failed-bootstrap, gauge, degeneracy and weak-limit controls."""
from pathlib import Path
import json,sys
import sympy as s
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,**detail))
eta=s.diag(-1,1,1,1);pairs=[(m,n) for m in range(4) for n in range(m,4)]
ids=[(a,m,n) for a in range(4) for m,n in pairs];zs=s.Matrix(s.symbols('z:40'));lookup={i:k for k,i in enumerate(ids)}
idx=lambda a,m,n:lookup[a,min(m,n),max(m,n)]
C=lambda a,m,n:zs[idx(a,m,n)]
def Q(m,n):return sum(C(a,m,n)*C(b,a,b)-C(a,b,m)*C(b,a,n) for a in range(4) for b in range(4))
H=s.hessian(sum(eta[m,n]*Q(m,n) for m in range(4) for n in range(4)),zs)
t=s.Symbol('t',real=True);f=s.Function('f')(t);g=s.Function('g')(t)
h=s.zeros(4);h[0,0]=f
Hh=s.hessian(f*Q(0,0),zs)
vec=s.zeros(40,1);vec[idx(0,0,0)]=g
b=H.inv()*Hh*vec
sigma00=s.diff(b[idx(0,0,0)]-sum(b[idx(a,0,a)] for a in range(4)),t)
extra=s.expand(f*sigma00)
euler_g=s.simplify(s.diff(extra,g)-s.diff(s.diff(extra,s.diff(g,t)),t))
check('naive h times total stress changes an actual Euler derivative',euler_g!=0,extra_density=str(extra),Euler_g=str(euler_g),scope='Difference h*D(b) in the action; not just a nonzero boundary density')

# Fixed physical transport under auxiliary psi changes the relative tensor c.
# Isolate the actual off-shell defect, rather than confusing it with Q-only.
testpsi=s.Function('psi')(t);E=s.zeros(4);E[1,1]=testpsi
phi=-eta*E*eta+eta*s.trace(eta*E)/2
dCL=s.Matrix([s.Rational(1,2)*eta[a,a]*((s.diff(phi[a,n],t) if m==0 else 0)+(s.diff(phi[a,m],t) if n==0 else 0)-(s.diff(phi[m,n],t) if a==0 else 0)) for a,m,n in ids])
off=s.zeros(40,1);off[idx(0,1,1)]=t
wrong_density=s.expand(-(H*off).dot(dCL))
wrong_euler=s.simplify(s.diff(wrong_density,testpsi)-s.diff(s.diff(wrong_density,s.diff(testpsi,t)),t))
check('fixed transport gives its calculated off-shell current defect',wrong_euler==1,fixed_transport_defect_11_at_lambda_one=str(wrong_euler),correct_current_11='0')

# All infinitesimal free-gauge equations in a nontrivial polynomial fixture.
coords=s.symbols('t x y z',real=True);xi=[coords[0]*coords[1]**2,coords[0]**2*coords[2],coords[2]*coords[3]**2,coords[0]*coords[1]*coords[3]]
div=sum(s.diff(xi[a],coords[a]) for a in range(4))
dh=s.Matrix(4,4,lambda m,n:eta[m,n]*div-eta[m,m]*s.diff(xi[n],coords[m])-eta[n,n]*s.diff(xi[m],coords[n]))
dc=s.Matrix([s.diff(xi[a],coords[m],coords[n]) for a,m,n in ids])
kin=sum(dh[m,n]*(sum(s.diff(C(a,m,n),coords[a]) for a in range(4))-(sum(s.diff(C(a,m,a),coords[n])+s.diff(C(a,n,a),coords[m]) for a in range(4)))/2) for m in range(4) for n in range(4))
# zs are constant placeholders: compute D^* dh explicitly by integration by parts.
J=s.zeros(40,1)
for a,m,n in ids:
    j=idx(a,m,n);factor=1 if m==n else 2
    J[j]-=factor*s.diff(dh[m,n],coords[a])
    # Trace terms collect from the full symmetric density contraction.
for m in range(4):
    for n in range(4):
        for a in range(4):J[idx(a,m,a)]+=s.diff(dh[m,n],coords[n])
check('free gauge preserves all forty connection equations',all(s.simplify(v)==0 for v in H*dc+J),components=40)
ric=[]
for m,n in pairs:
    ric.append(sum(s.diff(dc[idx(a,m,n)],coords[a])-(s.diff(dc[idx(a,m,a)],coords[n])+s.diff(dc[idx(a,n,a)],coords[m]))/2 for a in range(4)))
check('free gauge preserves all ten curvature equations',all(s.simplify(v)==0 for v in ric),components=10)

lam=s.Symbol('lambda',positive=True);z=s.Symbol('z',real=True)
B=s.eye(4);B[0,0]=z
check('density inversion excludes its actual singular surface',B.det().subs(z,0)==0)
check('naive zero coupling loses canonical source states',(1+lam*2).subs(lam,0)==(1+lam*5).subs(lam,0) and s.simplify(((1+lam*2)-1)/lam)==2 and s.simplify(((1+lam*5)-1)/lam)==5)

# A Riemann-symmetry superpotential improvement has identically zero divergence.
x=coords[1];F=coords[0]**2*x**3
Delta=s.zeros(4);Delta[0,0]=s.diff(F,x,2);Delta[0,1]=Delta[1,0]=-s.diff(F,coords[0],x);Delta[1,1]=s.diff(F,coords[0],2)
check('retained symmetric stress improvement is identically conserved',all(s.simplify(sum(s.diff(Delta[m,n],coords[m]) for m in range(4)))==0 for n in range(4)) and any(v!=0 for v in Delta))
out={'status':'PASS','count':len(rows),'checks':rows,'scope':'Exact finite control/gauge fixtures. No global claim that every stress improvement admits a local invertible field redefinition.'}
(base/'results/CONTROL_CHECKS.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':'PASS','checks':len(rows),'naive_Euler_defect':str(euler_g)},indent=2))
