"""Exact nonlinear gravity/matter and action/density recovery fixtures."""
from pathlib import Path
import json,sys
import sympy as s
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(base/'results').mkdir(parents=True,exist_ok=True)
u,v,x,y=s.symbols('u v x y',real=True);coords=[u,v,x,y]
amp,kE=s.symbols('a kappa_E',positive=True);lam=s.symbols('lambda',positive=True)
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,**detail))
def zero(M):return all(s.simplify(z)==0 for z in M)

def geometry(H):
    g=s.Matrix([[H,-1,0,0],[-1,0,0,0],[0,0,1,0],[0,0,0,1]])
    inv=g.inv();G={}
    for a in range(4):
        for m in range(4):
            for n in range(4):
                G[a,m,n]=s.simplify(sum(inv[a,b]*(s.diff(g[b,n],coords[m])+s.diff(g[b,m],coords[n])-s.diff(g[m,n],coords[b])) for b in range(4))/2)
    R=s.zeros(4)
    for m in range(4):
        for n in range(4):
            R[m,n]=s.simplify(sum(s.diff(G[a,m,n],coords[a])-s.diff(G[a,m,a],coords[n]) for a in range(4))+sum(G[a,m,n]*G[b,a,b]-G[a,b,m]*G[b,a,n] for a in range(4) for b in range(4)))
    return g,inv,G,R

g,B,A,R=geometry(x*x-y*y)
check('nonlinear vacuum pp-wave all ten Einstein equations',zero(R),symmetric_components=10)
riemann=s.diff(A[2,0,0],x)-s.diff(A[2,2,0],u)+sum(A[2,2,b]*A[b,0,0]-A[2,0,b]*A[b,2,0] for b in range(4))
check('vacuum endpoint is a nonflat geometry',s.simplify(riemann)!=0,curvature_component=str(s.simplify(riemann)))
check('density reconstructs full metric exactly',g.det()==-1 and zero(B*g-s.eye(4)))

g,B,A,R=geometry(-kE*amp**2*(x*x+y*y)/2);phi=amp*u;dphi=s.Matrix([s.diff(phi,z) for z in coords])
kin=(dphi.T*B*dphi)[0];T=dphi*dphi.T-g*kin/2
scalar=s.simplify(sum(s.diff(B[m,n]*s.diff(phi,coords[n]),coords[m]) for m in range(4) for n in range(4)))
Einstein=R-g*s.trace(B*R)/2
check('nonlinear scalar matter endpoint all ten Einstein equations',zero(Einstein-kE*T),symmetric_components=10,null_stress=str(T[0,0]),Ricci_uu=str(R[0,0]))
check('same metric scalar solves its matter equation',scalar==0)
div=[]
for n in range(4):
    val=0
    for m in range(4):
        for a in range(4):
            cov=s.diff(T[m,n],coords[a])-sum(A[r,a,m]*T[r,n]+A[r,a,n]*T[m,r] for r in range(4))
            val+=B[m,a]*cov
    div.append(s.simplify(val))
check('same-witness matter stress is covariantly conserved',all(z==0 for z in div))

# Density-compatibility with physical source transport A=LC(g).
compat=[]
for a in range(4):
    for m in range(4):
        for n in range(m,4):
            compat.append(s.simplify(s.diff(B[m,n],coords[a])+sum(A[m,a,r]*B[r,n]+A[n,a,r]*B[m,r] for r in range(4))-sum(A[r,a,r] for r in range(4))*B[m,n]))
check('all forty physical density-compatibility equations',all(z==0 for z in compat),components=40)

# Exact action completion, including the boundary divergence, on this curved jet.
eta=s.Matrix([[0,-1,0,0],[-1,0,0,0],[0,0,1,0],[0,0,0,1]])
h=(B-eta)/lam;c={key:value/lam for key,value in A.items()}
R0=s.zeros(4);Q=s.zeros(4)
for m in range(4):
    for n in range(4):
        R0[m,n]=sum(s.diff(c[a,m,n],coords[a])-(s.diff(c[a,m,a],coords[n])+s.diff(c[a,n,a],coords[m]))/2 for a in range(4))
        Q[m,n]=sum(c[a,m,n]*c[b,a,b]-c[a,b,m]*c[b,a,n] for a in range(4) for b in range(4))
pair=lambda M,N:sum(M[m,n]*N[m,n] for m in range(4) for n in range(4))
full=pair(B,R)/lam**2
expanded=pair(eta,R0)/lam+pair(h,R0)+pair(eta,Q)+lam*pair(h,Q)
check('complete coupling-normalized action recovery',s.simplify(full-expanded)==0)

# The pp-wave scalar action vanishes; add an off-shell metric whose derivative,
# quadratic and total-density pieces are nonzero, so that check cannot mask them.
etaD=s.diag(-1,1,1,1);f=u*u;df=[s.diff(f,z) for z in coords]
AC={(a,m,n):(df[n] if a==m else 0)+(df[m] if a==n else 0)-etaD[m,n]*etaD[a,a]*df[a]
    for a in range(4) for m in range(4) for n in range(4)}
DC=s.zeros(4);QC=s.zeros(4)
for m in range(4):
    for n in range(4):
        DC[m,n]=sum(s.diff(AC[a,m,n],coords[a])-(s.diff(AC[a,m,a],coords[n])+s.diff(AC[a,n,a],coords[m]))/2 for a in range(4))
        QC[m,n]=sum(AC[a,m,n]*AC[b,a,b]-AC[a,b,m]*AC[b,a,n] for a in range(4) for b in range(4))
BC=s.exp(2*f)*etaD;HC=(BC-etaD)/lam
left=pair(BC,DC+QC)/lam**2
right=pair(etaD,DC)/lam**2+pair(HC,DC)/lam+pair(etaD,QC)/lam**2+pair(HC,QC)/lam
check('nonzero off-shell conformal action recovery',s.simplify(left-right)==0 and s.simplify(pair(etaD,DC))!=0 and s.simplify(pair(etaD,QC))!=0)
check('independent conformal curvature scalar contraction',s.simplify(left-12*(1+2*u*u)*s.exp(2*u*u)/lam**2)==0)

# Nonlinear vacuum fixture with nonzero derivative and quadratic affinity terms.
tk=s.Symbol('tK',positive=True);ck=[tk,v,x,y]
gK=s.diag(-1,tk**s.Rational(-2,3),tk**s.Rational(4,3),tk**s.Rational(4,3));gKi=gK.inv()
AK={(a,m,n):s.simplify(sum(gKi[a,b]*(s.diff(gK[b,n],ck[m])+s.diff(gK[b,m],ck[n])-s.diff(gK[m,n],ck[b])) for b in range(4))/2)
    for a in range(4) for m in range(4) for n in range(4)}
DK=s.zeros(4);QK=s.zeros(4)
for m in range(4):
    for n in range(4):
        DK[m,n]=s.simplify(sum(s.diff(AK[a,m,n],ck[a])-s.diff(AK[a,m,a],ck[n]) for a in range(4)))
        QK[m,n]=s.simplify(sum(AK[a,m,n]*AK[b,a,b]-AK[a,b,m]*AK[b,a,n] for a in range(4) for b in range(4)))
check('full nonlinear Kasner vacuum all ten Ricci equations',zero(DK+QK),symmetric_components=10)
check('Kasner tests nonzero nonlinear cancellation',DK[0,0]!=0 and QK[0,0]!=0 and s.simplify(DK[0,0]+QK[0,0])==0,derivative_00=str(DK[0,0]),quadratic_00=str(QK[0,0]))

# General independent nondegenerate density variation at a rational Lorentzian point.
g0=s.diag(-2,3,5,7);inv=g0.inv();sqrtg=s.sqrt(-g0.det());B0=sqrtg*inv
check('four-dimensional determinant density identity',s.simplify(B0.det()-g0.det())==0)
mass=s.Rational(3,7);phi0=s.Rational(2,5);d=s.Matrix([s.Rational(1,3),s.Rational(2,7),-s.Rational(4,5),s.Rational(3,2)])
T0=d*d.T-g0*((d.T*inv*d)[0]+mass**2*phi0**2)/2
trace=s.trace(inv*T0);density_gradient=-d*d.T/2-mass**2*phi0**2*sqrtg*B0.inv()/4
check('matter density derivative recovers trace-adjusted stress',zero(density_gradient+(T0-g0*trace/2)/2))
source_density_equation=R/lam**2-(T-g*s.trace(B*T)/2)/2
check('coupling normalization is kappaE=lambda squared over two',zero(source_density_equation.subs(kE,lam**2/2)),same_source_density_components=10,scope='Actual nonlinear scalar/metric density equations, with the declared coupling relation imposed')

# A boundary divergence is not zero just because it is a divergence.
z=s.Symbol('z',real=True);test=s.diff(z*z,z)
check('boundary term cannot be deleted for arbitrary boundary data',s.integrate(test,(z,0,1))==1)
out={'status':'PASS','count':len(rows),'checks':rows,'scope':'Exact nonlinear local metric/matter fixtures and algebraic action/density checks. Not a general PDE existence proof or a global asymptotic-flatness example.'}
(base/'results/ENDPOINT_CHECKS.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':'PASS','checks':len(rows)},indent=2))
