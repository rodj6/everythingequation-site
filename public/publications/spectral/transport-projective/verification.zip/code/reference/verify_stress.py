"""Independent exact auxiliary-covariant stress versus source Hessian construction."""
from pathlib import Path
import json,sys,random,platform
import sympy as s

base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(base/'results').mkdir(parents=True,exist_ok=True)
spec=json.loads((base/'SPECIFICATION.json').read_text())
n=4;eta=[-1,1,1,1];pairs=[(m,k) for m in range(n) for k in range(m,n)]
indices=[(a,m,k) for a in range(n) for m,k in pairs];cv=s.Matrix(s.symbols('c:40'))
index={key:i for i,key in enumerate(indices)}
def ix(a,m,k):return index[a,min(m,k),max(m,k)]
def tensor(v):return {(a,m,k):v[ix(a,m,k)] for a in range(n) for m in range(n) for k in range(n)}
c=tensor(cv)
def Q(m,k,C):return sum(C[a,m,k]*C[b,a,b]-C[a,b,m]*C[b,a,k] for a in range(n) for b in range(n))
hs=s.symbols('h:10');density=s.zeros(n)
for z,(m,k) in zip(hs,pairs):density[m,k]=density[k,m]=z
q=s.expand(sum(density[m,k]*Q(m,k,c) for m in range(n) for k in range(n)))
H=s.hessian(q,cv);basis=[H.diff(z) for z in hs]
def Hz(z):return sum((z[m,k]*B for (m,k),B in zip(pairs,basis)),s.zeros(40))
etaM=s.diag(*eta);Heta=Hz(etaM);Hinv=Heta.inv()
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,**detail))
check('full 40-component torsion-free Hessian inverse',Heta*Hinv==s.eye(40))
dens=[]
for a in range(n):
    for m,k in pairs:
        dens.append(eta[k]*c[m,a,k]+eta[m]*c[k,a,m]-(eta[m] if m==k else 0)*sum(c[r,a,r] for r in range(n)))
N=s.Matrix(dens).jacobian(cv)
check('independent metric-density compatibility has rank 40',N.rank()==40)

# Auxiliary delta C from the linearized Levi-Civita formula, not the Hessian.
def deltaC(E,d):
    phi=-etaM*E*etaM+etaM*s.trace(etaM*E)/2
    return {(a,m,k):s.Rational(1,2)*eta[a]*((phi[a,k] if d==m else 0)+(phi[a,m] if d==k else 0)-(phi[m,k] if d==a else 0))
            for a in range(n) for m in range(n) for k in range(n)}
aux={}
for m,k in pairs:
    E=s.zeros(n);E[m,k]=E[k,m]=1
    for d in range(n):aux[m,k,d]=deltaC(E,d)

# Direct connection part of covariant h*(nabla C - nabla trace C).
def kinetic_connection(h,C,K):
    return sum(h[m,k]*(K[a,a,r]*C[r,m,k]-K[r,a,m]*C[a,r,k]-K[r,a,k]*C[a,m,r]+K[r,k,m]*C[a,r,a])
               for m in range(n) for k in range(n) for a in range(n) for r in range(n))

rng=random.Random(spec['stress_jets']['seed']);fixtures=[]
def rational():return s.Rational(rng.randint(-3,3),7)
def symmetric():
    M=s.zeros(n)
    for m,k in pairs:M[m,k]=M[k,m]=rational()
    return M
for number in range(spec['stress_jets']['fixtures']):
    h0=symmetric();dh=[symmetric() for _ in range(n)];c0=s.Matrix([rational() for _ in indices]);dc=[s.Matrix([rational() for _ in indices]) for _ in range(n)]
    Hh=Hz(h0);db=[Hinv*(Hz(dh[d])*c0+Hh*dc[d]) for d in range(n)]
    C0=tensor(c0);dC=[tensor(v) for v in dc];sigmas=[];residuals=[]
    for m,k in pairs:
        source=sum(db[a][ix(a,m,k)] for a in range(n))-sum(db[m][ix(a,k,a)]+db[k][ix(a,m,a)] for a in range(n))/2
        independent=sum(kinetic_connection(dh[d],C0,aux[m,k,d])+kinetic_connection(h0,dC[d],aux[m,k,d]) for d in range(n))/(1 if m==k else 2)
        residuals.append(s.simplify(source-independent));sigmas.append(source)
    check(f'complete derivative stress recovery all ten components fixture {number}',all(v==0 for v in residuals),components=10)
    check(f'naive quadratic-only stress misses nonzero derivative fixture {number}',any(v!=0 for v in sigmas),sigma=[str(x) for x in sigmas])
    fixtures.append({'h0':[[str(x) for x in row] for row in h0.tolist()],'dh':[[[str(x) for x in row] for row in mat.tolist()] for mat in dh],
                     'c0':[str(x) for x in c0],'dc':[[str(x) for x in vec] for vec in dc],'sigma':[str(x) for x in sigmas],'residuals':[str(x) for x in residuals]})

out={'status':'PASS','count':len(rows),'checks':rows,'fixtures':fixtures,'python':platform.python_version(),'sympy':s.__version__,
     'scope':'Exact rational off-shell jet fixtures; independent auxiliary-covariant derivative implementation versus source Hessian construction. The general off-shell stress proof is in the accompanying manuscript.'}
(base/'results/STRESS_CHECKS.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'status':'PASS','checks':len(rows),'stress_components':20},indent=2))
