from pathlib import Path
import json,sys
import sympy as s
from affine import algebra,independent_euler_matrix

out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind='exact finite algebra',**detail))
def zero(M):return all(s.simplify(x)==0 for x in M)

rank_table=[]
for n,signature in [(2,[-1,1]),(3,[-1,1,1]),(4,[-1,1,1,1]),(4,[1,1,1,1])]:
    model=algebra(n);eta=s.diag(*signature);H=model['Hz'](eta);P=model['P'];Pi=model['Pi']
    rank=H.rank();expected=4 if n==2 else n**3-n
    check(f'general connection Hessian rank n={n} signature={signature}',rank==expected,dimension=n**3,rank=rank,nullity=n**3-rank)
    check(f'independent component Euler equation agrees n={n} signature={signature}',H==independent_euler_matrix(model,eta))
    check(f'projective null vectors n={n} signature={signature}',zero(H*P) and P.rank()==n)
    rank_table.append({'n':n,'signature':signature,'rank':rank,'dimension':n**3})
    if n>2:
        G=(H+Pi).inv()-Pi
        check(f'quotient inverse identities n={n} signature={signature}',zero(H*G-(s.eye(n**3)-Pi)) and zero(G*H-(s.eye(n**3)-Pi)) and G==G.T)
    if n==4 and signature[0]<0:
        check('arbitrary symmetric density preserves projective nulls',zero(model['H']*P))
        # Faithful restriction to the original 40-component torsion-free parent.
        pairs=model['pairs'];oldids=[(a,m,k) for a in range(n) for m,k in pairs]
        z=s.Matrix(s.symbols('z:40'));S=s.zeros(64,40)
        for j,(a,m,k) in enumerate(oldids):
            S[model['index'][a,m,k],j]=1;S[model['index'][a,k,m],j]=1
        check('restricted unrestricted Hessian recovers old invertible 40-component parent',(S.T*H*S).rank()==40)
        V=s.Matrix(s.symbols('v:4'));projective=P*V;C0={key:projective[i] for i,key in enumerate(model['indices'])}
        naive=s.Matrix(4,4,lambda m,k:sum(C0[a,m,k]*C0[b,a,b]-C0[a,b,m]*C0[b,a,k] for a in range(4) for b in range(4)))
        check('naive symmetric-index extension fails projective invariance',zero(naive-3*V*V.T) and not zero(naive),naive_quadratic_result='3 V_mu V_nu; correct general quadratic result is zero')
        Qprojective=model['Q'].subs(dict(zip(model['variables'],projective)))
        check('matrix-curvature quadratic term passes the same control',zero(Qprojective))
        # Projective trace Ward identity forces a nonzero trace source to vanish.
        check('connection-only matter trace is an obstruction',(P.T*P)==4*s.eye(4),matter_term='j^mu tr(A_mu-LC(g)_mu)',trace_equation='4 j^mu=0')

result={'status':'PASS','count':len(rows),'checks':rows,'rank_table':rank_table,
        'scope':'Exact finite algebra and independent Euler implementation. General kernel, quotient and Einstein recovery are proved analytically; no physical observation.'}
(out/'results/PROJECTIVE_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','checks':len(rows),'ranks':rank_table},indent=2))
