"""Independent off-shell stress check for 64-component projective parent."""
from pathlib import Path
import json,sys,random
import sympy as s
from affine import algebra,linear_ricci_derivative

out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
model=algebra(4);ix=model['index'];ids=model['indices'];pairs=model['pairs'];Hz=model['Hz']
eta=s.diag(-1,1,1,1);H=Hz(eta);Pi=model['Pi'];G=(H+Pi).inv()-Pi
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind='exact finite algebra',**detail))
def tensor(vec):return {key:vec[j] for key,j in ix.items()}
def CL(E,d):
    phi=-eta*E*eta+eta*s.trace(eta*E)/2
    return {(a,m,k):s.Rational(1,2)*eta[a,a]*((phi[a,k] if m==d else 0)+(phi[a,m] if k==d else 0)-(phi[m,k] if a==d else 0)) for a,m,k in ids}
def kinetic_variation(h,C,K):
    # Covariant derivative of the unrestricted (1,2) tensor and its first trace.
    return sum(h[m,n]*(K[a,a,r]*C[r,n,m]-K[r,a,n]*C[a,r,m]-K[r,a,m]*C[a,n,r]+K[r,n,m]*C[a,a,r])
               for m in range(4) for n in range(4) for a in range(4) for r in range(4))
aux={}
for m,n in pairs:
    E=s.zeros(4);E[m,n]=E[n,m]=1
    for d in range(4):aux[m,n,d]=CL(E,d)
rng=random.Random(271049)
def rational():return s.Rational(rng.randint(-3,3),7)
def symmetric():
    M=s.zeros(4)
    for m,n in pairs:M[m,n]=M[n,m]=rational()
    return M
fixtures=[]
for fixture in range(2):
    h=symmetric();dh=[symmetric() for _ in range(4)]
    c=s.Matrix([rational() for _ in ids]);dc=[s.Matrix([rational() for _ in ids]) for _ in range(4)]
    if fixture==1:
        for a,m,n in ids:
            if m>n:
                c[ix[a,m,n]]=c[ix[a,n,m]]
                for d in range(4):dc[d][ix[a,m,n]]=dc[d][ix[a,n,m]]
    Hh=Hz(h);db=[G*(Hz(dh[d])*c+Hh*dc[d]) for d in range(4)]
    sigma=linear_ricci_derivative(model,db)
    C=tensor(c);dC=[tensor(v) for v in dc];residual=[]
    for m,n in pairs:
        independent=sum(kinetic_variation(dh[d],C,aux[m,n,d])+kinetic_variation(h,dC[d],aux[m,n,d]) for d in range(4))/(1 if m==n else 2)
        residual.append(s.simplify(sigma[m,n]-independent))
    check(f'quotient stress equals direct auxiliary variation all ten components fixture {fixture}',all(x==0 for x in residual),components=10)
    check(f'derivative stress is nonzero fixture {fixture}',any(v!=0 for v in sigma))
    # Linearized LC is a full unconstrained free solution, up to projective gauge.
    lc=s.Matrix([sum(CL(dh[d],d)[key] for d in range(4)) for key in ids])
    J=s.Matrix([-dh[ell][q,p]+(sum(dh[n][q,n] for n in range(4)) if p==ell else 0) for ell,p,q in ids])
    check(f'full linearized LC equation and quotient section fixture {fixture}',H*lc+J==s.zeros(64,1) and lc+G*J==Pi*lc)
    if fixture==1:
        oldids=[(a,m,n) for a in range(4) for m,n in pairs];S=s.zeros(64,40)
        for j,(a,m,n) in enumerate(oldids):S[ix[a,m,n],j]=1;S[ix[a,n,m],j]=1
        oldc=s.Matrix([c[ix[key]] for key in oldids]);olddc=[s.Matrix([dc[d][ix[key]] for key in oldids]) for d in range(4)]
        oldH=S.T*H*S;oldHh=S.T*Hh*S
        olddb=[S*oldH.inv()*(S.T*Hz(dh[d])*S*oldc+oldHh*olddc[d]) for d in range(4)]
        check('symmetric restriction recovers original 40-component stress',linear_ricci_derivative(model,olddb)==sigma)
    fixtures.append({'h':[[str(v) for v in row] for row in h.tolist()],'dh':[[[str(v) for v in row] for row in M.tolist()] for M in dh],
                     'c':[str(v) for v in c],'dc':[[str(v) for v in V] for V in dc],'sigma':[str(sigma[m,n]) for m,n in pairs],'residual':[str(v) for v in residual]})

# Exact generic quotient closure, using a deliberately nonsymmetric connection.
h=symmetric();Hh=Hz(h);lam=s.Rational(2,5);c=s.Matrix([rational() for _ in ids])
E=H*c+lam*Hh*c
check('quotient closure returns source connection modulo its projective mode',G*E-lam*G*Hh*c==c-Pi*c)
P=model['P'];V=s.Matrix([s.Rational(1,3),-2,s.Rational(4,7),1]);dcproj=[P*V*(d+1) for d in range(4)]
check('linearized symmetric Ricci annihilates local projective shifts',linear_ricci_derivative(model,dcproj)==s.zeros(4))
result={'status':'PASS','count':len(rows),'checks':rows,'fixtures':fixtures,'scope':'Exact rational off-shell 64-component stress and recovery tests. Direct covariant derivative implementation is independent of the Hessian current. No formal field-theory certificate.'}
(out/'results/GENERAL_STRESS_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','checks':len(rows),'stress_components':20},indent=2))
