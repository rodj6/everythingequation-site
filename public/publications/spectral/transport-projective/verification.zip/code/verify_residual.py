from pathlib import Path
import json,sys,random
import sympy as s
from affine import algebra,linear_ricci_derivative

out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
M=algebra(4);ix=M['index'];ids=M['indices'];eta=s.diag(-1,1,1,1);H=M['Hz'](eta);Pi=M['Pi'];P=M['P'];G=(H+Pi).inv()-Pi
rng=random.Random(271050)
def rat():return s.Rational(rng.randint(-3,3),11)
def sym():
    B=s.zeros(4)
    for m,n in M['pairs']:B[m,n]=B[n,m]=rat()
    return B
h=sym();dh=[sym() for _ in range(4)];ddh=[[None]*4 for _ in range(4)]
for a in range(4):
    for b in range(a,4):ddh[a][b]=ddh[b][a]=sym()
c=s.Matrix([rat() for _ in ids]);dc=[s.Matrix([rat() for _ in ids]) for _ in range(4)];lam=s.Rational(2,5);Hh=M['Hz'](h)
J=s.Matrix([-dh[ell][q,p]+(sum(dh[n][q,n] for n in range(4)) if p==ell else 0) for ell,p,q in ids])
dJ=[s.Matrix([-ddh[d][ell][q,p]+(sum(ddh[d][n][q,n] for n in range(4)) if p==ell else 0) for ell,p,q in ids]) for d in range(4)]
Ec=J+H*c+lam*Hh*c
dEc=[dJ[d]+H*dc[d]+lam*(M['Hz'](dh[d])*c+Hh*dc[d]) for d in range(4)]
Q=M['Q'].subs(dict(zip(M['variables'],c)));Q=(Q+Q.T)/2
sigma=linear_ricci_derivative(M,[G*(M['Hz'](dh[d])*c+Hh*dc[d]) for d in range(4)])
tau=Q-sigma;Eh=linear_ricci_derivative(M,dc)+lam*Q
metric_r=s.zeros(4);boxtrace=sum(eta[d,d]*eta[a,a]*ddh[d][d][a,a] for d in range(4) for a in range(4))
for m in range(4):
    for n in range(4):
        box=sum(eta[a,a]*ddh[a][a][m,n] for a in range(4))
        metric_r[m,n]=(eta[m,m]*eta[n,n]*box-eta[n,n]*sum(ddh[m][a][a,n] for a in range(4))-eta[m,m]*sum(ddh[n][a][a,m] for a in range(4))-eta[m,n]*boxtrace/2)/2
left=metric_r+lam*tau;right=Eh-linear_ricci_derivative(M,[G*v for v in dEc])
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind='exact finite algebra',**detail))
check('complete off-shell bootstrap residual recovery against independent metric operator',left==right,components=10)
check('residual identity is checked away from solutions',any(v!=0 for v in left) and any(v!=0 for v in Ec))
check('projective trace Ward identity holds off shell',P.T*Ec==s.zeros(4,1))
result={'status':'PASS','count':len(rows),'checks':rows,'recovered_residual':[str(left[m,n]) for m,n in M['pairs']],
        'scope':'Exact rational quadratic-density/affine-connection jet fixture. Independent explicit metric operator versus first-order source residuals; general identity proved in manuscript.'}
(out/'results/RESIDUAL_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','checks':len(rows)},indent=2))
