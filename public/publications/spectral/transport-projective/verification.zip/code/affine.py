"""Unrestricted affine connection algebra; direction is the first lower index."""
import sympy as s

def algebra(n):
    indices=[(a,mu,b) for a in range(n) for mu in range(n) for b in range(n)]
    variables=s.Matrix(s.symbols(f'c:{n**3}'))
    lookup={key:i for i,key in enumerate(indices)}
    C=lambda a,mu,b:variables[lookup[a,mu,b]]
    pairs=[(mu,nu) for mu in range(n) for nu in range(mu,n)]
    hs=s.symbols(f'h:{len(pairs)}');B=s.zeros(n)
    for h,(mu,nu) in zip(hs,pairs):B[mu,nu]=B[nu,mu]=h
    # Ricci from F^a_b mu nu, with Ricci_mn=F^a_m a n.
    Q=s.Matrix(n,n,lambda mu,nu:sum(C(a,a,r)*C(r,nu,mu)-C(a,nu,r)*C(r,a,mu) for a in range(n) for r in range(n)))
    q=s.expand(sum(B[mu,nu]*Q[mu,nu] for mu in range(n) for nu in range(n)))
    H=s.hessian(q,variables)
    basis=[H.diff(h) for h in hs]
    def Hz(value):return sum((value[mu,nu]*mat for (mu,nu),mat in zip(pairs,basis)),s.zeros(n**3))
    P=s.zeros(n**3,n)
    for mu in range(n):
        for a in range(n):P[lookup[a,mu,a],mu]=1
    Pi=P*P.T/n
    return dict(n=n,indices=indices,variables=variables,index=lookup,C=C,Q=Q,H=H,Hz=Hz,P=P,Pi=Pi,pairs=pairs)

def linear_ricci_derivative(model,derivatives):
    """derivatives[mu] contains partial_mu C in the full-component basis."""
    n=model['n'];ix=model['index']
    raw=s.Matrix(n,n,lambda m,k:sum(derivatives[a][ix[a,k,m]]-derivatives[k][ix[a,a,m]] for a in range(n)))
    return (raw+raw.T)/2

def independent_euler_matrix(model,B):
    n=model['n'];C=model['C'];v=model['variables']
    equations=[]
    for ell,p,q in model['indices']:
        equations.append((sum(B[m,k]*C(q,k,m) for m in range(n) for k in range(n)) if ell==p else 0)
                         +B[p,q]*sum(C(a,a,ell) for a in range(n))
                         -sum(B[m,p]*C(q,ell,m)+B[q,m]*C(p,m,ell) for m in range(n)))
    return s.Matrix(equations).jacobian(v)
