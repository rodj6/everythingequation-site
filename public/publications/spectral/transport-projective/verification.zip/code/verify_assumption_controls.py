from pathlib import Path
import json,sys
import sympy as s
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
rows=[]
def check(name,condition,**detail):
    if not bool(condition):raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind='exact finite algebra',**detail))

v,w=s.symbols('v w',real=True);a=s.Symbol('a',positive=True)
F=lambda p,q:s.sympify(p)**3/(s.sympify(p)**2+s.sympify(q)**2)
check('reversible homogeneous path functional need not have a linear first jet',
      s.simplify(F(-v,-w)+F(v,w))==0 and s.simplify(F(a*v,a*w)-a*F(v,w))==0 and F(1,1)-F(1,0)-F(0,1)==-s.Rational(1,2),
      functional='exp(-integral F(gamma_dot) dt), F(v,w)=v^3/(v^2+w^2), F(0)=0',
      scope='Composition/reversal/reparameterization hold, but Frechet differentiability at constant paths fails')

eta=s.diag(-1,1,1,1);generators=[]
for i in range(1,4):
    K=s.zeros(4);K[0,i]=K[i,0]=1;generators.append(K)
for i in range(1,4):
    for j in range(i+1,4):
        K=s.zeros(4);K[i,j]=1;K[j,i]=-1;generators.append(K)
hs=s.symbols('h:10');pairs=[(m,n) for m in range(4) for n in range(m,4)];H=s.zeros(4)
for z,(m,n) in zip(hs,pairs):H[m,n]=H[n,m]=z
constraints=[]
for K in generators:constraints+=list(K.T*H+H*K)
mat,_=s.linear_eq_to_matrix(constraints,hs)
check('ultralocal natural scalar kinetic tensor has only the metric invariant',mat.rank()==9 and all(K.T*eta+eta*K==s.zeros(4) for K in generators),symmetric_unknowns=10,invariant_dimension=1)
vec=s.Matrix(s.symbols('w:4'));constraints=[]
for K in generators:constraints+=list(K*vec)
mat,_=s.linear_eq_to_matrix(constraints,list(vec))
check('no natural vector supports a scalar first-derivative cross term',mat.rank()==4)
result={'status':'PASS','count':len(rows),'checks':rows,'scope':'Exact representation/regularity controls. Conditional scalar naturality selection and path smoothness claims are proved analytically, not inferred from these finite fixtures.'}
(out/'results/ASSUMPTION_CONTROL_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','checks':len(rows)},indent=2))
