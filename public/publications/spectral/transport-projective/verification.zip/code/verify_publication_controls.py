"""Exact coordinate-naturality and density-response controls."""
from pathlib import Path
import json, sys
import sympy as s

out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
(out/'results').mkdir(parents=True,exist_ok=True)
rows=[]
def zero(M): return all(s.simplify(v)==0 for v in M)
def check(name,condition,**detail):
    if not bool(condition): raise AssertionError((name,detail))
    rows.append(dict(name=name,passed=True,kind='exact finite algebra',**detail))

def restore(T,vin,vout):
    return s.simplify((vin/(vout*T.det()))**s.Rational(1,4))*T

T=2*s.eye(4);T[0,1]=1
finite=[]
for sign in [1,-1]:
    Jx=s.diag(sign*3,1,1,1);Jy=s.diag(sign*5,1,1,1)
    pulled=Jy.inv()*T*Jx
    finite.append(zero(restore(pulled,s.Integer(3),s.Integer(5))-Jy.inv()*restore(T,s.Integer(1),s.Integer(1))*Jx))
check('finite volume restoration is natural for both coordinate orientations',all(finite),orientations=[1,-1],transport_determinant=str(T.det()))

t=s.Symbol('t',positive=True)
J=s.diag(2*t,1,1,1)
A=[s.Matrix(4,4,lambda a,b:(mu+1)*(a+1)-2*(b+1)+(1 if a==b else 0)) for mu in range(4)]
pull=[(2*t if mu==0 else 1)*J.inv()*A[mu]*J+(J.inv()*J.diff(t) if mu==0 else s.zeros(4)) for mu in range(4)]
normalized=[s.simplify(pull[mu]-s.eye(4)*s.trace(pull[mu])/4+s.eye(4)*(1/t if mu==0 else 0)/4) for mu in range(4)]
oldnorm=[q-s.eye(4)*s.trace(q)/4 for q in A]
expected=[(2*t if mu==0 else 1)*J.inv()*oldnorm[mu]*J+(J.inv()*J.diff(t) if mu==0 else s.zeros(4)) for mu in range(4)]
check('volume-restored generator is natural under a nonlinear coordinate map',all(zero(a-b) for a,b in zip(normalized,expected)),map='Phi(t,x,y,z)=(t^2,x,y,z), t>0',includes_inhomogeneous_term=True)

B=s.diag(-2,3,5,7);v=s.sqrt(-B.det());ginv=B/v;g=ginv.inv()
k=s.Matrix([1,2,3,4]);mass2=s.Rational(5,7);phi=s.Rational(3,5)
stress=k*k.T-g*((k.T*ginv*k)[0]+mass2*phi**2)/2
trace=s.trace(ginv*stress);gradient=-(stress-g*trace/2)/2
eps=s.Symbol('epsilon',real=True);checks=[]
for m in range(4):
    for n in range(m,4):
        E=s.zeros(4);E[m,n]=E[n,m]=1
        shifted=B+eps*E;vs=s.sqrt(-shifted.det())
        dv=s.diff(vs,eps).subs(eps,0)
        dginv=(shifted/vs).diff(eps).subs(eps,0)
        trE=s.trace(g*E)
        density=-((k.T*shifted*k)[0]+vs*mass2*phi**2)/2
        derivative=s.diff(density,eps).subs(eps,0)
        contraction=sum(gradient[a,b]*E[a,b] for a in range(4) for b in range(4))
        checks.append(s.simplify(dv-trE/2)==0 and zero(dginv-(E-ginv*trE/2)/v) and s.simplify(derivative-contraction)==0)
check('direct density derivatives recover metric Jacobian and full scalar stress',all(checks),symmetric_directions=10,nonunit_density=str(v))

result={'status':'PASS','count':len(rows),'checks':rows,'scope':'Exact finite controls of coordinate naturality and density-response normalization. General proofs remain in the manuscript.'}
(out/'results/PUBLICATION_CONTROL_CHECKS.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'status':'PASS','checks':len(rows)},indent=2))
