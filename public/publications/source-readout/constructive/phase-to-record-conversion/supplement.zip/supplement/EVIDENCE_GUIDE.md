# Calculation and certificate guide

The analytical proofs in the manuscript and companion establish their universal claims. The supplement reconstructs finite examples and selected algebraic identities. All twelve original sources passed disposable replay, and all 42 selected printed examples matched their reported rounding precision. No experimental observations were supplied.

| Source | Evidence class | Scope and limits |
|---|---|---|
| `00_verify_detector.py` | floating diagnostics | Synthetic complete detector models; quadrature, matrix exponentials and reference tests. |
| `01_verify.py` | floating diagnostics | Saturating overlap approximation, modular reader/tomography checks and LP comparisons. |
| `02_verify_operational.py` | floating diagnostics | Bounded coherent and separate bounded-hazard examples; finite collision completeness. |
| `03_verify_phase.py` | floating diagnostics | Finite-reference LP/eigenvalue diagnostics and retained-reference instruments. |
| `04_verify_robust.py` | floating diagnostics | Analytic formulas numerically evaluated and compared with SLSQP/grids. Infeasible epsilon=.04 row records numerical_optimizer_success=false and is not a numerical impossibility certificate. |
| `05_verify_calibration.py` | floating diagnostics | Synthetic counts, beta/binomial routines and scalar optimization. The field named exact_binomial_grid_checks is floating evaluation, not exact arithmetic or an all-parameter proof. |
| `06_verify_internal.py` | floating diagnostics | Common-cell transfer corners, 4913-point grid and random factorization/reference checks. |
| `07_verify_monitoring.py` | mixed: exact integer certificate and floating diagnostics | Exact Gaussian-integer principal-minor sign calculation for 512 vertices/7168 minors, zero negative minors, plus integer witness characteristic coefficients. All probabilities, synthetic counts, matrix radii, roots, MGF enumeration and optimization are floating. |
| `08_verify_reader.py` | floating diagnostics | Controlled-path Gram/filter formulas and physical matrices; 10044-state grid, 90 reference samples and 1000 Gram checks. |
| `09_verify_direct_monitoring.py` | floating diagnostics | Synthetic two-template count tables, finite floating transcript/MGF enumeration and numerical span witnesses. Finite enumeration does not make arithmetic exact. |
| `10_verify_product_reader.py` | mixed: Fraction identities and floating diagnostics | Exact Fraction ensemble rates 1/2 and 1/4 and rational small-frame inputs; Poisson exponentials, finite sum/tail examples and fourth differences are floating. |
| `11_verify_sequential.py` | mixed: exact Fraction finite law and floating diagnostics | Exact Fraction propagation/normalization of 900 terminal states and rational selected-event sums. Event boundary is evaluated in floating point, as are exponentials and MGF comparisons; universal concentration is analytical. |
| `check_collision_identities.py` | Exact standard-library rational arithmetic | 144 finite-loss-first collision configurations, both diagonal effects per case, geometric success sums and six static wrong-click integrals. Does not prove the general coherent-control or hazard optimality theorem. |

## Interpretation safeguards

- The inherited field names `exact_binomial_grid_checks` and `exact_predictable_bernoulli_mgf` do not make their arithmetic exact. Those fields use floating evaluation.
- Source 07 checks 7,168 principal minors at 512 vertices with exact algebraic sign arithmetic; it also contains separate floating calculations.
- Source 10 uses exact `Fraction` ensemble rates 1/2 and 1/4. Its Poisson exponentials and truncation diagnostics are floating.
- Source 11 propagates a rational finite law on 900 terminal states exactly, but the selected-event boundary and exponential moment diagnostics use floating arithmetic.
- In source 04 the infeasible epsilon=0.04 exploratory SLSQP row records optimizer success as false. That failure is not an infeasibility certificate; the analytical frontier supplies the obstruction.
- Finite grids, sampled retained references and successful solver calls corroborate examples; they do not certify continuous uncertainty domains or replace reference-uniform channel proofs.
- The separate 144-case exact check verifies finite algebraic identities. Its attenuation parameter is rational for testing and is not a continuum bath simulation.

## Reported operating values

The saved JSON permits independent reconstruction of coherent success 0.2025106210074513, robust-source conclusive rate 0.18090985060664672, common-cell rate 0.11204532735103226, mismatch-protected rate 0.10188455010941908, and the formerly matched filter error 0.0901046826124055. These are binary64 evaluations of derived formulas, not rigorous numerical enclosures.

## Reproducibility boundaries

The runner checks source hashes and writes logs and outputs to a new directory. Floating last digits, runtime and image metadata can vary by platform. None of these programs is a formal theorem prover or a physical calibration of a real device. The code cannot establish trusted stock, path-blind dynamics, access restrictions, drift or fresh independence; those remain declared premises.
