"""Independent exact checks of declared finite collision effects, not a continuum-bath simulation."""
from fractions import Fraction as F
from pathlib import Path
import json
cases=0
for s in [F(1,5),F(3,5),F(4,5)]:
 for alpha in [F(3,4),F(4,5),F(1)]:
  for r in [F(1,2),F(2,3)]:
   for M in range(1,9):
    q=lambda k:(1-s)*(1-r**k)
    # Diagonal complete effect for ready basis0/1. All terms exact.
    for denom in [1+s,1-s]:
     null=alpha**M*(1-q(M)/denom)
     signal=sum(alpha**k*(q(k)-q(k-1))/denom for k in range(1,M+1))
     loss=sum((1-alpha)*alpha**(k-1)*(1-q(k-1)/denom) for k in range(1,M+1))
     assert null+signal+loss==1
    # Conditional psi+/psi- have identical ready diagonal weights.
    success=sum(alpha**k*(q(k)-q(k-1))for k in range(1,M+1))
    geometric=(1-s)*(1-r)*alpha*(1-(alpha*r)**M)/(1-alpha*r)
    assert success==geometric
    null=alpha**M*(1-q(M))
    loss=sum((1-alpha)*alpha**(k-1)*(1-q(k-1))for k in range(1,M+1))
    assert success+null+loss==1
    cases+=1
for s in [F(1,10),F(1,5),F(1,3),F(3,5),F(4,5),F(9,10)]:
 integrated=(1-s*s)/4*(1/(1-s)+1/(1+s)-2)
 assert integrated==s*s/2
out={'status':'PASS','finite_collision_exact_cases':cases,'effect_dimensions_checked_per_case':2,'static_wrong_click_integrals':6,'scope':'Independent exact checks of finite-loss-first effect completeness, geometric success sum, and static reciprocal-bank infinite-time integral. Does not replace general control optimality proof or identify the coherent continuum bath with recorded bins.'}
Path(__file__).with_name('collision_identity_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
