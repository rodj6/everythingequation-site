"""Task-specific two-template monitoring; synthetic counts, no device experiment.

Only NumPy and Python standard library. Analytical coverage is in chapter.tex.
No inherited verification scripts or campaign instructions are executed.
"""
from pathlib import Path
import math,json,itertools
import numpy as np
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(202610276)
alpha=.01;K=3;nu=1e-11;delta_prep=5e-5;delta_source=0.;age=100_000_000
def width(n):return math.sqrt(math.log(2*math.pi**2*n*n*K/alpha)/(2*n))
Fp=np.array([[.018,.002,.001j],[.002,.10,.15],[-.001j,.15,.325]],complex)
Fm=np.array([[.026,-.001j,.001],[.001j,.11,-.148j*np.sin(.02)-.148*np.cos(.02)],[.001,-.148*np.cos(.02)+.148j*np.sin(.02),.335]],complex)
E=[Fp,Fm,np.eye(3)-Fp-Fm]
assert min(np.linalg.eigvalsh(x).min()for x in E)>0
vectors=[np.array([0,math.sqrt(.8),s*math.sqrt(.2)],complex)for s in [1,-1]]
rhos=[np.outer(v,v.conj())for v in vectors]
P=np.array([[np.trace(e@rho).real for e in E]for rho in rhos])
q=P[:,:2].sum(axis=1);w=np.array([P[0,1],P[1,0]])
samples=[]
for n in [50_000,100_000,500_000,1_000_000,18_000_000]:
 counts=np.array([rng.multinomial(n,p)for p in P]);emp=counts/n
 Q=emp[:,:2].sum(axis=1);W=np.array([emp[0,1],emp[1,0]])
 ages=np.array([n+1,n],float)+age
 b=width(n)+delta_prep+delta_source+nu*ages
 bq=width(n)+delta_prep+delta_source+2*nu*ages
 cert=(W+b)/Q;success=Q-bq
 eps=.169748239;qtarget=.268980153
 power_error=2*width(n)+delta_prep+delta_source+nu*ages
 power_success=q-2*width(n)-delta_prep-delta_source-2*nu*ages
 power_ok=bool(np.all(power_error<=eps*q-w)and np.all(power_success>=qtarget))
 samples.append(dict(n_per_template=n,total_probe_trials=2*n,counts_plus_minus_null=counts.tolist(),
  anytime_width=width(n),mean_probe_ages=ages.tolist(),per_label_error=cert.tolist(),
  arbitrary_prior_error=float(cert.max()),per_label_conclusive=success.tolist(),
  arbitrary_prior_conclusive=float(success.min()),
  target_error=eps,target_conclusive=qtarget,
  sufficient_uniform_event_implies_deployment=power_ok,
  predicted_error_margins=(eps*q-w-power_error).tolist(),
  guaranteed_target_deployment_probability_if_stationary_benchmark=1-alpha if power_ok else None))
# Exact enumeration of all ternary transcript probabilities for a history-
# dependent, non-iid calibration law checks the range-one mgf statement.
mgf=[]
eps_grid=[0.,.13,.4,1.];theta=.7
for n in range(1,9):
 frontier=[(1.,0.,0)]
 for t in range(n):
  new=[]
  for mass,total,last in frontier:
   pp=np.array([.13+.03*last,.23-.01*last,.64-.02*last])
   vals=np.array([1-.3,-.3,0.]);mean=float(pp@vals)
   for j,p in enumerate(pp):new.append((mass*p,total+vals[j]-mean,j))
  frontier=new
 moment=sum(mass*math.exp(theta*total)for mass,total,last in frontier)
 bound=math.exp(n*theta*theta/8)
 assert moment<=bound+1e-12
 mgf.append(dict(n=n,mgf=moment,range_one_bound=bound))
# Three observed indicators supply a continuum of thresholds without a grid.
for _ in range(1000):
 true=rng.dirichlet(np.ones(3));observed=rng.dirichlet(np.ones(3))
 rad=max(abs(true[0]-observed[0]),abs(true[1]-observed[1]),abs(true[:2].sum()-observed[:2].sum()))
 for eps in eps_grid:
  actual=true[0]-eps*true[:2].sum();emp=observed[0]-eps*observed[:2].sum()
  assert abs(actual-emp)<=rad+1e-14
# Minimality / off-span blindness: one probe leaves a response direction.
rho0=rhos[0];rho1=rhos[1]
H=rho1-np.trace(rho0@rho1).real*rho0
assert abs(np.trace(H@rho0))<1e-14 and np.trace(H@rho1).real>.1
H/=np.linalg.norm(H,2)
plus=np.eye(3)/3+.05*H;null=np.eye(3)/3-.05*H
assert min(np.linalg.eigvalsh(plus).min(),np.linalg.eigvalsh(null).min())>0
assert abs(np.trace((plus-np.eye(3)/3)@rho0))<1e-14
blind_change=float(np.trace((plus-np.eye(3)/3)@rho1).real)
# Drift coefficient nu in W-eps*C is attained with an interior POVM.
drift=.01
for eps in eps_grid:
 change=(1-eps)*drift-eps*(-drift)
 assert abs(change-drift)<1e-14
report=dict(status='all direct-monitoring checks passed',synthetic=True,seed=202610276,
 parameters=dict(alpha=alpha,max_epochs=K,per_effect_operator_drift=nu,
  probe_preparation_trace_error=delta_prep,future_source_trace_error=delta_source,deployment_age=age,
  probe_family='two known occupied source templates; no vacuum-coherent probe'),
 true_probabilities=P.tolist(),true_labelwise_error=(w/q).tolist(),cases=samples,
 predicted_mgf_checks=mgf,one_probe_blind_response_change=blind_change,
 comparison=dict(fifth_probe_trials=36_000_000,fifth_prior_free_error=.169748239,
  fifth_prior_free_conclusive=.268980153,
  caution='Different task: two-template labels versus general qutrit effect tomography; no source/bath or full-POVM certificate follows.'),
 scope='All-prefix martingale coverage proven analytically. Synthetic multinomial count tables and finite checks are not experimental data or universal probability proofs.')
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
