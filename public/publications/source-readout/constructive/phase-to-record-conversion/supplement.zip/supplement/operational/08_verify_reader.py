"""Sharp controlled-path Gram reader: independent matrix diagnostics.
No original campaign jobs or external data. Python+NumPy+SciPy.
"""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import brentq
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(270620266)
pL,pU=.7,.9;vL=.95;Delta=math.pi/18
etaL=.31355905644099785;theta=.05;u0=.01;eps=.08
gamma=math.cos(theta);k=1-(1-gamma)/etaL
m=vL*(k*math.cos(Delta)-math.sqrt(1-k*k)*math.sin(Delta))
h=math.acosh(m/(1-2*eps));xL=math.sqrt(pL/(1-pL));xU=math.sqrt(pU/(1-pU))
L=-h-math.log(xL)+u0;U=h-math.log(xU)-u0
rstar=math.exp(min(U,-u0));Qstar=etaL*(1-pU+pU*rstar*rstar*math.exp(-2*u0))
width=.5*math.log(xU/xL)+u0
c_req=(1-2*eps)*math.cosh(width)/vL
phase_room=math.acos(c_req)-Delta
theta_max=math.acos(1-etaL*(1-math.cos(phase_room)))
def min_error(theta_budget):
 kk=1-(1-math.cos(theta_budget))/etaL
 mm=vL*math.cos(math.acos(kk)+Delta)
 return .5*(1-mm/math.cosh(width))
assert abs(min_error(theta_max)-eps)<1e-13
assert min_error(theta_max*.999)<eps and min_error(theta_max*1.001)>eps
def worst(r):
 return max(.5*(1-m/math.cosh(math.log(r)+uu+math.log(math.sqrt(p/(1-p)))))for p in[pL,pU]for uu in[-u0,u0])
assert abs(worst(rstar)-eps)<1e-13
assert abs(worst(math.exp(L))-eps)<1e-13
assert worst(rstar*1.001)>eps
oldr=.5347211623914206
alpha=math.acos(k);chi=np.exp(1j*alpha)
v0=np.array([math.sqrt(etaL),math.sqrt(1-etaL)],complex)
v1=np.array([math.sqrt(etaL)*chi,math.sqrt(1-etaL)],complex)
assert abs(np.vdot(v0,v1).real-gamma)<1e-14
# Input S2 -> path2 x port2 plus filter failure; flag path is measured in Had basis.
H=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
def full_isometry(ractual):
 V=np.zeros((5,2),complex)
 V[0:2,0]=ractual*v0;V[2:4,1]=v1
 V[4,0]=math.sqrt(1-ractual*ractual)
 assert np.linalg.norm(V.conj().T@V-np.eye(2))<1e-13
 return V
def effects(ractual):
 V=full_isometry(ractual)
 # Flag port is index0 within each path sector. Coherent Had mixing.
 K=H@V[[0,2],:]
 return [np.outer(row.conj(),row)for row in K]
worst_matrix=0.;success_matrix=1.
for p in np.linspace(pL,pU,81):
 for uu in np.linspace(-u0,u0,31):
  Es=effects(rstar*math.exp(uu))
  for delta in [-Delta,Delta]:
   for sign in [1,-1]:
    rho=np.array([[p,sign*vL*math.sqrt(p*(1-p))*np.exp(-1j*delta)],[sign*vL*math.sqrt(p*(1-p))*np.exp(1j*delta),1-p]])
    prob=[np.trace(E@rho).real for E in Es];q=sum(prob)
    success_matrix=min(success_matrix,q)
    worst_matrix=max(worst_matrix,prob[1 if sign==1 else 0]/q)
assert abs(worst_matrix-eps)<1e-12
assert abs(success_matrix-Qstar)<1e-12
# Invert only the explicit finite-dilation matrix response, without using m or h.
def matrix_error(nominal):
 ans=0.
 for pp in [pL,pU]:
  for uu in [-u0,u0]:
   EE=effects(nominal*math.exp(uu))
   for dd in [-Delta,Delta]:
    rr=np.array([[pp,vL*math.sqrt(pp*(1-pp))*np.exp(-1j*dd)],[vL*math.sqrt(pp*(1-pp))*np.exp(1j*dd),1-pp]])
    probs=[np.trace(e@rr).real for e in EE]
    ans=max(ans,probs[1]/sum(probs))
 return ans
matrix_root=brentq(lambda z:matrix_error(z)-eps,.45,.6,xtol=1e-14)
assert abs(matrix_root-rstar)<1e-12
# Exact pointer-channel distance, attained by an eigenvector of the effect perturbation.
ractual=rstar*math.exp(u0)
E=effects(ractual);Eideal=[etaL/2*np.array([[ractual*ractual,ss*ractual],[ss*ractual,1]])for ss in[1,-1]]
A=E[0]-Eideal[0];bound=ractual*math.sqrt(etaL)*math.sqrt(2*(1-gamma))/2
assert abs(np.linalg.norm(A,2)-bound)<1e-12
refmax=0.
for dR in [1,2,7]:
 for _ in range(30):
  psi=rng.normal(size=(2,dR))+1j*rng.normal(size=(2,dR));psi/=np.linalg.norm(psi)
  # R block contraction gives opposite pointer blocks.
  Rblock=psi.T@A.T@psi.conj()
  td=np.linalg.svd(Rblock,compute_uv=False).sum()
  refmax=max(refmax,float(td));assert td<=bound+1e-12
ev,Ue=np.linalg.eigh(A);z=Ue[:,-1];assert abs(abs(np.vdot(z,A@z))-bound)<1e-12
# General Gram lemma, without equal-efficiency simplification.
general_checks=0
for _ in range(1000):
 vv=[rng.normal(size=6)+1j*rng.normal(size=6)for _ in range(2)]
 vv=[z/np.linalg.norm(z)for z in vv]
 ef=[np.linalg.norm(z[:3])**2 for z in vv]
 g=np.vdot(vv[0],vv[1]).real;c=np.vdot(vv[0][:3],vv[1][:3]).real
 assert c>=g-math.sqrt((1-ef[0])*(1-ef[1]))-1e-12
 general_checks+=1
result=dict(status='all analytical-formula and physical-matrix diagnostics passed',
 source=dict(p=[pL,pU],visibility_lower=vL,phase_halfwidth=Delta),
 uncertainty=dict(equal_efficiency_lower=etaL,full_overlap_lower=gamma,theta=theta,filter_log_error=u0),
 sharp=dict(k=k,m=m,nominal_log_interval=[L,U],r=rstar,Q=Qstar,worst_error=worst_matrix,matrix_min_success=success_matrix,independent_matrix_root=matrix_root,source_grid_states=81*31*2*2,maximum_admitted_theta=theta_max),
 prior_filter=dict(r=oldr,actual_worst_error=worst(oldr),invalid_at_error_ceiling=True),
 pointer_reference=dict(sharp_half_diamond=bound,random_reference_samples=90,maximum_sampled_distance=refmax),
 general_unequal_efficiency_gram_checks=general_checks,
 caveat='Sharp for declared Gram/equal-efficiency/filter class; not arbitrary Hamiltonian norm balls, bath equality or empirical data')
(OUT/'reader_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
