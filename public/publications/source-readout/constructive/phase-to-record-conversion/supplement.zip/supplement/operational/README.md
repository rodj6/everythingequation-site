# Original operational verification sources

The twelve numbered Python files are unchanged copies from the scientific consolidation. `manifest.json` preserves their source locators and SHA-256 hashes. Numerical outputs must be generated in disposable copies.

Use the corrected portable entry point from the scientific package root:

```bash
python reproduce.py --check-only
python reproduce.py --output replay_new
```

For one script:

```bash
python reproduce.py --only 02_verify_operational.py --output replay_one
```

The filename retains its numeric prefix. The old example incorrectly copied `02_verify_operational.py` and then attempted to execute `verify_operational.py`; the runner fixes that mismatch and avoids platform-specific `$OLDPWD` assumptions.

Read `../EVIDENCE_GUIDE.md` for exact versus floating arithmetic and the limits of numerical checks. The sources also cover supporting interfaces: a successful replay does not make each output a main-paper theorem.
