"""Finite-reference/loss/noise theorem checks. numpy scipy matplotlib only.
Run python verify_phase.py; uploaded campaign code is never executed."""
from pathlib import Path
import math,json
import numpy as np
from numpy.linalg import norm,eigvalsh
from scipy.optimize import linprog
from scipy.sparse import diags
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(314159)
def proj(v):return np.outer(v,v.conj())
def rho(n):
 a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
 return a@a.conj().T/np.trace(a@a.conj().T)
def phase_basis(N,a=0):
 x=np.arange(N)
 return np.exp(2j*np.pi*(a*x[:,None]**2+x[:,None]*x[None,:])/N)/np.sqrt(N)
def token_lp(N,M):
 K=max(0,M-N+1)
 if not K:return 0.,np.ones(M)/M
 A=[]
 for i in range(K):
  for x in range(N):
   row=np.zeros(M+K);row[M+i]=1;row[i+x]=-1;A.append(row)
 ans=linprog(np.r_[np.zeros(M),-np.ones(K)],A_ub=A,b_ub=np.zeros(len(A)),A_eq=np.r_[np.ones(M),np.zeros(K)][None,:],b_eq=[1],bounds=(0,None),method='highs')
 assert ans.success
 return -ans.fun,ans.x[:M]
def block_sizes(N,M):
 return np.array([sum(0<=q-x<M for x in range(N)) for q in range(N+M-1)])
def frontier(N,M,nu,P):
 ms=block_sizes(N,M);w=ms/(N*M);confidence=(nu+(1-nu)*ms)/N
 order=np.argsort(-confidence);left=P;correct=0.;accept=np.zeros(len(ms))
 for q in order:
  take=min(left,w[q]);accept[q]=take/w[q];correct+=take*confidence[q];left-=take
  if left<1e-14:break
 assert abs(sum(w*accept)-P)<1e-12
 return correct,accept
results={'seed':314159,'scope':'All tests synthetic; proofs in chapter.tex. Energy/U(1) encoding and accessible token are explicit assumptions.'}
# Optimize all finite-support distributions for exact unambiguous success.
lp=[];maxlp=0.
for N in range(2,9):
 for M in range(1,31):
  val,p=token_lp(N,M);theory=max(0,M-N+1)/M
  maxlp=max(maxlp,abs(val-theory))
  assert abs(val-theory)<1e-10
  lp.append({'N':N,'M':M,'optimum':val,'theory':theory})
results['token_LP_cases']=len(lp);results['max_token_LP_error']=maxlp
# Random nonconsecutive supports; no free extra charge sectors.
maxratio=0.
for _ in range(1000):
 N=int(rng.integers(2,9));M=int(rng.integers(1,25))
 support=np.sort(rng.choice(np.arange(0,3*M+N),M,replace=False))
 p=rng.dirichlet(np.ones(M));lookup=dict(zip(support,p))
 eta=sum(min(lookup.get(q-x,0) for x in range(N)) for q in range(int(support.min()),int(support.max())+N))
 upper=max(0,M-N+1)/M
 assert eta<=upper+1e-12
 if upper:maxratio=max(maxratio,eta/upper)
results['random_support_cases']=1000;results['max_random_eta_to_global_bound_ratio']=maxratio
# Complete quantum instrument, active reference retained, coherent vs classical charge archive.
inst=[]
for N,M,a in [(2,3,0),(3,4,1),(5,8,2),(7,12,3)]:
 U=phase_basis(N,a);u=np.ones(M)/np.sqrt(M);W0=np.kron(np.eye(N),u[:,None])
 dim=N*M;qvals=np.array([x+n for x in range(N) for n in range(M)])
 interior=list(range(N-1,M));K=len(interior);eta=K/M
 Fs=[]
 for b in range(N):
  F=np.zeros((dim,dim),complex)
  for q in interior:
   v=np.zeros(dim,complex)
   for x in range(N):v[x*M+q-x]=U[x,b]
   F+=proj(v)
  Fs.append(F)
 P0=np.eye(dim)-sum(Fs);Ks=[F@W0 for F in Fs];K0=P0@W0
 completeness=norm(K0.conj().T@K0+sum(k.conj().T@k for k in Ks)-np.eye(N))
 rankerr=0.
 for b,k in enumerate(Ks):
  chi=k@U[:,b]/np.sqrt(eta)
  rankerr=max(rankerr,norm(k-np.sqrt(eta)*np.outer(chi,U[:,b].conj())))
 assert completeness<1e-12 and rankerr<1e-12 and norm(K0.conj().T@K0-(1-eta)*np.eye(N))<1e-12
 # Arbitrary entangled reference: complete retained branch differences to chosen ideal.
 R=3;rs=rho(N*R);err=0.
 for b,k in enumerate(Ks):
  actual=np.kron(k,np.eye(R))@rs@np.kron(k.conj().T,np.eye(R))
  ideal=actual/eta
  err+=np.sum(abs(eigvalsh(actual-ideal)))/2
 null=np.kron(K0,np.eye(R))@rs@np.kron(K0.conj().T,np.eye(R))
 err+=np.sum(abs(eigvalsh(null)))/2
 assert abs(err-(1-eta))<1e-11
 # Classical charge readout still has exact conclusive fixed sigma_b;
 # its null channel is generally not an isometry.
 chargeKs=[]
 for q in range(N+M-1):
  D=np.diag((qvals==q).astype(float));chargeKs.append(D@K0)
 psi=np.ones(N)/np.sqrt(N);pure=proj(psi)
 coherent_null=K0@pure@K0.conj().T/(1-eta)
 classical_null=sum(k@pure@k.conj().T for k in chargeKs)/(1-eta)
 purity_coherent=float(np.trace(coherent_null@coherent_null).real)
 purity_classical=float(np.trace(classical_null@classical_null).real)
 assert abs(purity_coherent-1)<1e-12 and purity_classical<1-1e-3
 inst.append({'N':N,'M':M,'a':a,'eta':eta,'completeness_error':float(completeness),'full_branch_rank1_error':float(rankerr),'entangled_input_complete_error':float(err),'predicted_complete_error':1-eta,'coherent_null_purity':purity_coherent,'classical_charge_null_purity':purity_classical})
results['complete_instruments']=inst
# Exact noisy frontier versus LP over acceptance blocks, plus PSD dual certificates
# bounding every invariant POVM, not merely symmetric candidates.
front=[]
for N,M,nu in [(3,5,0.),(3,5,.03),(5,9,.1),(7,12,.4)]:
 ms=block_sizes(N,M);w=ms/(N*M);C=(nu+(1-nu)*ms)/N
 max_lp=0.;min_slack=1.;max_dual_gap=0.
 for P in np.linspace(.01,1,51):
  correct,accept=frontier(N,M,nu,P)
  opt=linprog(-w*C,A_eq=w[None,:],b_eq=[P],bounds=[(0,1)]*len(w),method='highs')
  assert opt.success
  max_lp=max(max_lp,abs(correct+opt.fun))
 for lam in np.r_[-.1,np.unique(C),1.1]:
  primal=sum(w[q]*max(0,C[q]-lam) for q in range(len(ms)))
  dual=0.
  for q,m in enumerate(ms):
   xs=np.array([x for x in range(N) if 0<=q-x<M])
   gamma=max(0,(C[q]-lam)/(N*M))
   Y=gamma*np.eye(m);dual+=np.trace(Y)
   for b in range(N):
    v=np.exp(2j*np.pi*b*xs/N)
    sig=((1-nu)*proj(v)+nu*np.eye(m))/(N*M)
    # Objective coefficient sig/N - lam*average(sig_i).
    A=sig/N-lam*np.eye(m)/(N*M)
    min_slack=min(min_slack,float(eigvalsh(Y-A).min()))
  max_dual_gap=max(max_dual_gap,abs(primal-dual))
 assert max_lp<1e-10 and min_slack>-1e-12 and max_dual_gap<1e-12
 eta0=max(0,M-N+1)/M
 correct,_=frontier(N,M,nu,eta0)
 front.append({'N':N,'M':M,'nu':nu,'eta_zero_noise':eta0,'conditional_error_at_eta0':float(1-correct/eta0),'sharp_confidence_floor':nu*(1-1/N),'max_frontier_LP_error':max_lp,'minimum_dual_PSD_slack':min_slack,'max_primal_dual_gap':max_dual_gap})
results['noisy_frontiers']=front
# The interior-block construction with a noisy reference has exact linear effects.
N=3;M=5;nu=.07;a=1;dim=N*M;U=phase_basis(N,a)
uvec=np.ones(M)/np.sqrt(M);tau=(1-nu)*proj(uvec)+nu*np.eye(M)/M
lam,V=np.linalg.eigh(tau);effects=[];Fs=[]
for b in range(N):
 F=np.zeros((dim,dim),complex)
 for q in range(N-1,M):
  v=np.zeros(dim,complex)
  for x in range(N):v[x*M+q-x]=U[x,b]
  F+=proj(v)
 Fs.append(F)
 effects.append(sum(l*np.kron(np.eye(N),v[:,None]).conj().T@F@np.kron(np.eye(N),v[:,None]) for l,v in zip(lam,V.T)))
eta=(M-N+1)/M
noise_effect_error=max(norm(e-eta*((1-nu)*proj(U[:,b])+nu*np.eye(N)/N)) for b,e in enumerate(effects))
assert noise_effect_error<1e-12
# Explicit passive purification retained in the output, not discarded or accessed.
pur=np.zeros(M*(M+1),complex)
for n in range(M):
 pur[n*(M+1)]+=np.sqrt(1-nu)/np.sqrt(M)
 pur[n*(M+1)+n+1]+=np.sqrt(nu/M)
Jpur=np.kron(np.eye(N),pur[:,None])
Kpur=[np.kron(F,np.eye(M+1))@Jpur for F in Fs]
Pnull=np.eye(dim)-sum(Fs)
Knull=np.kron(Pnull,np.eye(M+1))@Jpur
completepur=norm(sum(k.conj().T@k for k in Kpur)+Knull.conj().T@Knull-np.eye(N))
assert completepur<1e-12
results['noisy_effect_and_passive_purifier']={'N':N,'M':M,'nu':nu,'effect_formula_error':float(noise_effect_error),'passive_purifier_dimension':M+1,'complete_retained_purification_instrument_error':float(completepur),'classical_pointer_halfdiamond_error_to_pure_heralded':eta*nu*(1-1/N)}
# General minimum-error optimum is principal eigenvalue of triangular Toeplitz matrix.
med=[]
for N,M in [(2,2),(2,5),(2,20),(5,9),(5,30),(9,30),(180,180),(180,360),(180,1000),(180,2000)]:
 diagonals=[];offsets=[]
 for d in range(-min(N-1,M-1),min(N-1,M-1)+1):
  offsets.append(d);diagonals.append(np.full(M-abs(d),N-abs(d),float))
 T=diags(diagonals,offsets,format='csr')
 val,v=eigsh(T,k=1,which='LA',tol=1e-12)
 r=abs(v[:,0]);r/=norm(r)
 ps=float(val[0]/N**2)
 uniform=float(np.ones(M)@(T@np.ones(M))/(M*N*N))
 residual=float(norm(T@r-val[0]*r))
 if N==2:assert abs(ps-(1+np.cos(np.pi/(M+1)))/2)<1e-12
 assert ps>=uniform-1e-11
 med.append({'N':N,'M':M,'optimal_correct':ps,'uniform_correct':uniform,'eigen_residual':residual})
results['minimum_error_optima']=med
results['N180_exact_resource_examples']=[{'loss_ceiling':e,'minimum_populated_charge_sectors':math.ceil((180-1)/e)} for e in [.1,.01,.001]]
# Publication figure.
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
fig,ax=plt.subplots(1,3,figsize=(13.3,3.9),layout='constrained')
N=5;M=9;pp=np.linspace(.0001,1,400)
for nu in [0,.03,.1]:
 cc=np.array([frontier(N,M,nu,p)[0] for p in pp])
 ax[0].plot(pp,(pp-cc)/pp,label=fr'$\nu={nu:g}$')
ax[0].axvline((M-N+1)/M,color='grey',ls=':',lw=1)
ax[0].set(xlabel='conclusive probability',ylabel='minimum conditional label error',title='Exact noisy error–erasure frontier (N=5, M=9)')
ax[0].legend()
MM=np.arange(2,101)
ax[1].loglog(MM,1/MM,label='exact heralded measurement: loss')
ax[1].loglog(MM,(1-np.cos(np.pi/(MM+1)))/2,label='best no-erasure label error')
ax[1].set(xlabel='populated reference charges M',ylabel='probability',title='Different tasks, different resources (N=2)')
ax[1].legend(fontsize=8)
NN=np.arange(2,181)
for e in [.1,.01]:
 ax[2].plot(NN,np.ceil((NN-1)/e),label=fr'loss $\leq {e:g}$')
ax[2].set(xlabel='number of energy modes N',ylabel='minimum reference sectors M',title='Sharp exact-measurement reference cost')
ax[2].legend()
fig.savefig(OUT/'phase_frontier.png');plt.close(fig)
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'LP_cases':len(lp),'max_LP_error':maxlp,'complete_instruments':inst,'noisy_frontiers':front,'N180':results['N180_exact_resource_examples'],'minimum_error':med},indent=2))
