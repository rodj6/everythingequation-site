#!/usr/bin/env python3
"""Synthetic exact-model diagnostics, not empirical data or interval certificates.
Python 3.11+, numpy, scipy; original research evidence is not modified.
"""
from pathlib import Path
import json,math
import numpy as np
from scipy.integrate import quad,quad_vec,solve_ivp
from scipy.linalg import expm
from scipy.optimize import brentq

SEED=27102026

def first_peak(G,ell):
    if ell==0:return math.pi/(2*G)
    d=G*G-ell*ell/16
    if abs(d)<1e-12*max(G*G,ell*ell):return 1/G
    if d>0:
        w=math.sqrt(d);return math.atan(4*w/ell)/w
    w=math.sqrt(-d);return math.atanh(4*w/ell)/w

def amplitude(g,ell,t):
    if g==0:return math.exp(-ell*t/2),0.
    d=g*g-ell*ell/16
    z=math.exp(-ell*t/4)
    if abs(d)<1e-12*max(g*g,ell*ell):return z*(1-ell*t/4),z*g*t
    if d>0:
        w=math.sqrt(d)
        return z*(math.cos(w*t)-ell/(4*w)*math.sin(w*t)),z*g/w*math.sin(w*t)
    w=math.sqrt(-d)
    return z*(math.cosh(w*t)-ell/(4*w)*math.sinh(w*t)),z*g/w*math.sinh(w*t)

def frontier(s,G,ell,T):
    tau=min(T,first_peak(G,ell));a,b=amplitude(G,ell,tau)
    return (1-s)*b*b,tau,b

def static_wrong(s,gamma,T):
    a,b=math.sqrt((1+s)/2),math.sqrt((1-s)/2)
    return quad(lambda t:gamma*a*a*b*b*(math.exp(-gamma*(1-s)*t/2)-math.exp(-gamma*(1+s)*t/2))**2,0,T,epsabs=1e-13)[0]

out={'scope':'declared source-reader-detector apparatus; exact analytic proofs in chapter.tex; floating diagnostics only','seed':SEED,'units':'G,ell,kappa in s^-1; time s; Hamiltonian/hbar in s^-1'}
s=.6;G=1.;ell=1.;T=2.
a,b=math.sqrt((1+s)/2),math.sqrt((1-s)/2)
q,tau,f1=frontier(s,G,ell,T)
ratio=math.sqrt((1-s)/(1+s))
g0=brentq(lambda g:amplitude(g,ell,tau)[1]-ratio*f1,0,G,xtol=1e-14)
Had=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
C=Had@np.diag([g0,G])
H=np.block([[np.zeros((2,2)),C.conj().T],[C,np.zeros((2,2))]])
P=np.diag([1,1,0,0])
Gen=-1j*H-ell*P/2
Inc=np.eye(4,dtype=complex)[:,:2]
N=expm(Gen*tau)@Inc
Kflag=N[2:,:]
Knull=N[:2,:]
# If T>tau, all couplings are off; remaining ready state keeps its declared loss.
Knull_deadline=math.exp(-ell*(T-tau)/2)*Knull
loss_gram=quad_vec(lambda t:ell*(expm(Gen*t)@Inc)[:2,:].conj().T@(expm(Gen*t)@Inc)[:2,:],0,tau,epsabs=1e-12)[0]
loss_gram+= (1-math.exp(-ell*(T-tau)))*(Knull.conj().T@Knull)
comp=Kflag.conj().T@Kflag+Knull_deadline.conj().T@Knull_deadline+loss_gram
psi_plus=np.array([a,b]);psi_minus=np.array([a,-b])
wrong=max(abs(Kflag[1]@psi_plus)**2,abs(Kflag[0]@psi_minus)**2)
correct=[abs(Kflag[0]@psi_plus)**2,abs(Kflag[1]@psi_minus)**2]
# Exact marked record kernel and full coherent bath isometry tested with entangled R.
rng=np.random.default_rng(SEED)
residuals=[]
for _ in range(100):
    psi=rng.normal(size=(2,7))+1j*rng.normal(size=(2,7));psi/=np.linalg.norm(psi)
    rho=psi@psi.conj().T
    residuals.append(abs(np.trace(rho@comp)-1))
assert wrong<1e-25 and max(abs(v-q) for v in correct)<1e-12
assert np.linalg.norm(comp-np.eye(2))<1e-11
out['coherent_loss_model']={'s':s,'G':G,'ell':ell,'deadline':T,'active_duration':tau,'weaker_tap_g0':g0,'maximum_tap_G':G,'correct_conclusive_each':correct,'q_frontier':q,'wrong_click_max':wrong,'full_null_loss_flag_completeness_residual':float(np.linalg.norm(comp-np.eye(2))),'100_entangled_Rdim7_normalization_max_residual':float(max(residuals)),'ready_null_effect_eigenvalues':np.linalg.eigvalsh(Knull_deadline.conj().T@Knull_deadline).tolist(),'loss_effect_eigenvalues':np.linalg.eigvalsh(loss_gram).tolist(),'signal_effect_eigenvalues':np.linalg.eigvalsh(Kflag.conj().T@Kflag).tolist()}
# Bound under arbitrary changing coherent drive, including backtracking and phases.
# Real scalar drive is a subfamily; operator theorem is analytic, not proved by sampling.
random_checks=[]
for j in range(100):
    values=rng.uniform(-G,G,8)
    def fun(t,y):
        g=values[min(7,int(t/T*8))]
        return np.array([-ell*y[0]/2-g*y[1],g*y[0]])
    sol=solve_ivp(fun,(0,T),[1.,0.],rtol=2e-10,atol=2e-12,max_step=T/200)
    prob=sol.y[1,-1]**2
    assert prob<=q/(1-s)+1e-7
    random_checks.append(prob)
# General ready/flag block controls, including complex couplings and block rotations.
operator_probs=[]
for _ in range(50):
    vec=np.array([0,1,0,0],complex)
    for j in range(6):
        raw=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2))
        Cr=raw/max(1.,np.linalg.norm(raw,2))*G
        ar=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));ar=(ar+ar.conj().T)*.2
        dr=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));dr=(dr+dr.conj().T)*.2
        Hr=np.block([[ar,Cr.conj().T],[Cr,dr]])
        vec=expm((-1j*Hr-ell*P/2)*(T/6))@vec
    probability=float(np.linalg.norm(vec[2:])**2)
    assert probability<=q/(1-s)+1e-12
    operator_probs.append(probability)
out['random_operator_controls']={'number':50,'pieces_each':6,'max_transfer_found':max(operator_probs),'proved_transfer_frontier':q/(1-s)}
# Exact finite loss-free source-reader-detector coupling at several exposures.
finiteunit=[]
for qq in [.05,.2,.4]:
    theta=np.arcsin(np.sqrt(np.array([qq/(1+s),qq/(1-s)])))
    Cu=Had@np.diag(theta)
    Hu=np.block([[np.zeros((2,2)),Cu.conj().T],[Cu,np.zeros((2,2))]])
    Vu=expm(-1j*Hu)@Inc
    assert np.linalg.norm(Vu.conj().T@Vu-np.eye(2))<1e-12
    wu=max(abs(Vu[3]@psi_plus)**2,abs(Vu[2]@psi_minus)**2)
    assert wu<1e-25
    finiteunit.append({'success':qq,'cross_action':float(theta.max()),'wrong_click_max':float(wu),'null_effect_rank':int(np.linalg.matrix_rank(Vu[:2].conj().T@Vu[:2],tol=1e-10))})
out['finite_unitary_exposures']=finiteunit
out['random_drives']={'number':100,'pieces_each':8,'max_transfer_found':max(random_checks),'proved_transfer_frontier':q/(1-s)}
# Regime boundary and noise threshold diagnostics.
regimes=[]
for ratioell in [0.,.1,1.,4.,10.,50.]:
    tp=first_peak(1,ratioell); ar,fr=amplitude(1,ratioell,tp)
    regimes.append({'ell_over_G':ratioell,'G_t_peak':tp,'transfer_at_peak':fr*fr,'exp_minus_ell_tpeak_over2':math.exp(-ratioell*tp/2),'ready_amplitude_at_peak':ar})
    assert abs(fr*fr-math.exp(-ratioell*tp/2))<1e-11 and abs(ar)<1e-10
pstar=.2
ellcrit=brentq(lambda x:frontier(.6,1.,x,100.)[0]-pstar,0,4)
out['loss_regimes']=regimes
out['sharp_noise_threshold']={'s':.6,'required_unambiguous_success':pstar,'critical_ell_over_G':ellcrit,'scope':'deadline at least first transfer peak; above this ratio impossible in declared ready-loss/stable-flag class'}
# Static reciprocal jump bank: starts dark, null backaction produces wrong clicks.
out['static_matched_bank']={'s':s,'gamma':1.,'T':2.,'wrong_click_probability':static_wrong(s,1.,2.),'wrong_infinite_time_exact':s*s/2}
# Markov hazard repair and finite optical collision discretization, all loss preserved.
kappa=1.;lm=.25;Tm=2.
qfun=lambda t:(1-s)*(1-math.exp(-kappa*t))
dq=lambda t:(1-s)*kappa*math.exp(-kappa*t)
qsig=(1-s)*kappa/(kappa+lm)*(1-math.exp(-(kappa+lm)*Tm))
null=math.exp(-lm*Tm)*(1-qfun(Tm))
loss=quad(lambda t:lm*math.exp(-lm*t)*(1-qfun(t)),0,Tm)[0]
assert abs(qsig+null+loss-1)<1e-12
steps=[]
D=np.diag([1/(1+s),1/(1-s)])
phi=[np.array([b,a]),np.array([b,-a])]
for M in [1,2,8,32,128]:
    dt=Tm/M;nprev=np.eye(2);signal_effect=np.zeros((2,2));loss_effect=np.zeros((2,2));qc=0
    for k in range(1,M+1):
        t=k*dt;dp=qfun(t)-qfun(t-dt)
        # Loss-first finite collision, followed by signal tap. Both source polarizations retained at loss.
        n_old=np.sqrt(np.eye(2)-qfun(t-dt)*D)
        loss_effect+=(1-math.exp(-lm*dt))*math.exp(-lm*(t-dt))*(n_old@n_old)
        signal_effect+=math.exp(-lm*t)*dp*D
        qc+=math.exp(-lm*t)*dp
    n_end=np.sqrt(np.eye(2)-qfun(Tm)*D)
    null_effect=math.exp(-lm*Tm)*(n_end@n_end)
    residual=np.linalg.norm(signal_effect+loss_effect+null_effect-np.eye(2))
    assert residual<1e-12 and qc<=qsig+1e-12 and qsig<=math.exp(lm*dt)*qc+1e-12
    steps.append({'M':M,'success':qc,'continuum_success':qsig,'relative_lower_bound_factor':math.exp(-lm*dt),'all_outputs_completeness_residual':float(residual),'minimal_timebin_output_dimension_with_losses':4*M+2})
out['bounded_hazard']={'s':s,'kappa':kappa,'uniform_loss':lm,'T':Tm,'success':qsig,'null_probability':null,'loss_probability':loss,'wrong_click_probability':0.,'finite_collision_approximations':steps}
Path(__file__).with_name('operational_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
