#!/usr/bin/env python3
"""Exact-formula robust reader diagnostics; standard QM; no empirical data.
Requires Python 3.11+, numpy, scipy. Does not modify original evidence.
"""
from pathlib import Path
import json,math
import numpy as np
from scipy.linalg import expm
from scipy.optimize import brentq,minimize
from scipy.integrate import quad_vec

SEED=271020264

def peak(G,ell):
    if ell==0:return math.pi/(2*G)
    d=G*G-ell*ell/16
    if abs(d)<1e-12*max(G*G,ell*ell):return 1/G
    if d>0:
        z=math.sqrt(d);return math.atan(4*z/ell)/z
    z=math.sqrt(-d);return math.atanh(4*z/ell)/z

def amp(g,ell,t):
    if g==0:return math.exp(-ell*t/2),0.
    d=g*g-ell*ell/16;v=math.exp(-ell*t/4)
    if abs(d)<1e-12*max(g*g,ell*ell):return v*(1-ell*t/4),v*g*t
    if d>0:
        w=math.sqrt(d);return v*(math.cos(w*t)-ell*math.sin(w*t)/(4*w)),v*g*math.sin(w*t)/w
    w=math.sqrt(-d);return v*(math.cosh(w*t)-ell*math.sinh(w*t)/(4*w)),v*g*math.sinh(w*t)/w

def sharp(pL,pU,vL,Delta,eps,eta=1.):
    xiL=math.sqrt(pL/(1-pL));xiU=math.sqrt(pU/(1-pU))
    width=.5*math.log(xiU/xiL);m=vL*math.cos(Delta)
    floor=(1-m/math.cosh(width))/2
    if eps<floor-1e-14:return {'feasible_positive':False,'error_floor':floor,'Q':0.}
    if eps>=.5:
        logr=0.;interval=[None,None]
    else:
        h=math.acosh(max(1.,m/(1-2*eps)))
        lo=-h-math.log(xiL);hi=h-math.log(xiU)
        logr=min(max(0.,lo),hi);interval=[lo,hi]
    r=math.exp(logr);t=eta/max(1.,r*r);x=t*r*r;y=t
    qs=[p*x+(1-p)*y for p in [pL,pU]]
    errs=[.5*(1-2*m*math.sqrt(p*(1-p)*x*y)/(p*x+(1-p)*y)) for p in [pL,pU]]
    return {'feasible_positive':True,'error_floor':floor,'Q':min(qs),'x':x,'y':y,'log_ratio':logr,'ratio':r,'allowed_log_ratio':interval,'worst_conditional_error':max(errs),'unconditional_wrong_max':max(.5*(p*x+(1-p)*y-2*m*math.sqrt(p*(1-p)*x*y)) for p in [pL,pU]),'m':m,'amplitude_log_halfwidth':width}

# Independent numerical constrained PSD optimization, not the closed ratio formula.
def numerical(pL,pU,m,eps,eta):
    # Variables x,y,z,Q; PSD matrices [[x,z],[z,y]] and bound diag<=eta.
    k=1-2*eps
    cons=[{'type':'ineq','fun':lambda u:.5*(u[0]+u[1]-math.sqrt((u[0]-u[1])**2+4*u[2]**2))}]
    for p in [pL,pU]:
        cons.append({'type':'ineq','fun':lambda u,p=p:p*u[0]+(1-p)*u[1]-u[3]})
        cons.append({'type':'ineq','fun':lambda u,p=p:2*m*math.sqrt(p*(1-p))*u[2]-k*(p*u[0]+(1-p)*u[1])})
    best=None
    for fraction in [.05,.3,.8]:
        res=minimize(lambda u:-u[3],np.array([eta*fraction,eta*fraction,eta*fraction*.9,eta*fraction*.1]),method='SLSQP',bounds=[(0,eta),(0,eta),(0,eta),(0,eta)],constraints=cons,options={'ftol':2e-12,'maxiter':1500})
        violation=min(c['fun'](res.x) for c in cons)
        if violation>=-1e-10 and (best is None or res.x[3]>best.x[3]):best=res
    if best is None:return 0.,[0.,0.,0.,0.],False
    return float(best.x[3]),best.x.tolist(),bool(best.success)

pL=.7;pU=.9;vL=.95;Delta=math.pi/18;G=1.;ell=1.;T=2.
tau=min(T,peak(G,ell));eta=amp(G,ell,tau)[1]**2
m=vL*math.cos(Delta)
rng=np.random.default_rng(SEED)
rows=[]
for eps in [.04,.06,.08,.10,.15,.22,.5]:
    row=sharp(pL,pU,vL,Delta,eps,eta)
    num,sol,success=numerical(pL,pU,m,eps,eta)
    row.update({'epsilon':eps,'numerical_PSD_optimum':num,'numerical_solution_xy_z_Q':sol,'numerical_optimizer_success':success})
    assert abs(row['Q']-num)<3e-7
    rows.append(row)
main=sharp(pL,pU,vL,Delta,.08,eta)
x,y=main['x'],main['y']
# Real physical attaining Hamiltonian in the same independently lossy 4-mode model.
gs=[]
for gain in [x,y]:
    target=math.sqrt(gain)
    gs.append(brentq(lambda g:amp(g,ell,tau)[1]-target,0,G,xtol=1e-14))
HAD=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
C=HAD@np.diag(gs)
H=np.block([[np.zeros((2,2)),C.conj().T],[C,np.zeros((2,2))]])
P=np.diag([1,1,0,0]);J=np.eye(4,dtype=complex)[:,:2]
A=-1j*H-ell*P/2
N=lambda t:expm(A*t)@J
F=N(tau)[2:]
N0=math.exp(-ell*(T-tau)/2)*N(tau)[:2]
L=quad_vec(lambda t:ell*N(t)[:2].conj().T@N(t)[:2],0,tau,epsabs=1e-12)[0]
L+=(1-math.exp(-ell*(T-tau)))*N(tau)[:2].conj().T@N(tau)[:2]
completeness=F.conj().T@F+N0.conj().T@N0+L
assert np.linalg.norm(completeness-np.eye(2))<1e-11
E=[np.outer(F[j].conj(),F[j]) for j in range(2)]
worste=0.;minq=1.;maxloss=0.;maxnull=0.
for p in np.linspace(pL,pU,151):
 for delta in np.linspace(-Delta,Delta,41):
  for h in [1,-1]:
   rho=np.array([[p,h*vL*math.sqrt(p*(1-p))*np.exp(-1j*delta)],[h*vL*math.sqrt(p*(1-p))*np.exp(1j*delta),1-p]])
   probs=[float(np.trace(e@rho).real) for e in E]
   q=sum(probs);err=probs[1 if h==1 else 0]/q
   worste=max(worste,err);minq=min(minq,q)
   maxloss=max(maxloss,float(np.trace(L@rho).real))
   maxnull=max(maxnull,float(np.trace(N0.conj().T@N0@rho).real))
assert abs(minq-main['Q'])<1e-12 and abs(worste-.08)<1e-12
referr=0.
for _ in range(100):
 psi=rng.normal(size=(2,7))+1j*rng.normal(size=(2,7));psi/=np.linalg.norm(psi)
 rho=psi@psi.conj().T
 referr=max(referr,abs(np.trace(rho@completeness)-1))
# Other regimes and limits, checked against independently optimized PSDs.
more=[]
for pl,pu,vl,de in [(.5,.5,1.,0.),(.8,.8,1.,0.),(.3,.7,.9,.1),(.2,.4,.99,.05),(.7,.9,1.,0.)]:
 fl=sharp(pl,pu,vl,de,.5)['error_floor']
 for eps in [fl+1e-5,min(.49,fl+.04),.49]:
  r=sharp(pl,pu,vl,de,eps,.73)
  num,_,_=numerical(pl,pu,vl*math.cos(de),eps,.73)
  assert abs(r['Q']-num)<2e-6
  more.append({'pL':pl,'pU':pu,'vL':vl,'Delta':de,'epsilon':eps,'Q':r['Q'],'numeric_Q':num})
# Recover previous exact USD limit: p=.8, eps0, fullvisibility.
usd=sharp(.8,.8,1.,0.,0.,eta)
assert abs(usd['Q']-.4*eta)<1e-12
# A required rate converts robust nuisance costs into a physical loss threshold.
B=sharp(pL,pU,vL,Delta,.08,1.)['Q'];Qrequired=.12
crit=brentq(lambda z:amp(1.,z,peak(1.,z))[1]**2*B-Qrequired,0,4)
out={'scope':'exact source-uncertainty minimax conditional-error/conclusive frontier in declared stable-flag readout class; synthetic float diagnostics','seed':SEED,'uncertainty':{'p_interval':[pL,pU],'visibility_lower':vL,'phase_halfwidth_radians':Delta,'m':m},'physical_model':{'G':G,'ell':ell,'deadline':T,'active_duration':tau,'transfer_ceiling_eta':eta},'pareto_rows':rows,'attaining_apparatus':{'epsilon':.08,'x':x,'y':y,'gains_g0_g1':gs,'guaranteed_conclusive':main['Q'],'worst_conditional_error_grid':worste,'maximum_unconditional_wrong':main['unconditional_wrong_max'],'loss_effect_eigenvalues':np.linalg.eigvalsh(L).tolist(),'null_effect_eigenvalues':np.linalg.eigvalsh(N0.conj().T@N0).tolist(),'maximum_loss_over_grid':maxloss,'maximum_null_over_grid':maxnull,'complete_output_normalization_residual':float(np.linalg.norm(completeness-np.eye(2))),'100_entangled_Rdim7_normalization_residual':float(referr)},'other_regime_PSD_tests':more,'previous_exact_USD_limit':usd,'required_rate_threshold':{'conditional_error_ceiling':.08,'required_guaranteed_conclusive':Qrequired,'robust_preparation_factor_B':B,'sharp_ell_over_G_max_for_sufficiently_long_deadline':crit}}
# Exact extension: unknown fixed mode-transmission efficiencies before the reader.
def gain_box(pL,pU,vL,Delta,eps,eta,aa,bb):
    tL=.5*math.log(pL/(1-pL))+.5*math.log(aa[0]/bb[1])
    tU=.5*math.log(pU/(1-pU))+.5*math.log(aa[1]/bb[0])
    m=vL*math.cos(Delta);width=(tU-tL)/2;floor=(1-m/math.cosh(width))/2
    if eps<floor:return {'Q':0.,'error_floor':floor,'feasible_positive':False}
    h=math.acosh(m/(1-2*eps));lo=-h-tL;hi=h-tU
    z=min(max(0.,lo),hi);r=math.exp(z)
    x=eta*r*r/max(1.,r*r);y=eta/max(1.,r*r)
    Q=min(pp*aa[0]*x+(1-pp)*bb[0]*y for pp in [pL,pU])
    errs=[]
    for pp in [pL,pU]:
     for al in aa:
      for be in bb:
       qq=pp*al*x+(1-pp)*be*y
       errs.append(.5*(1-2*m*math.sqrt(pp*(1-pp)*al*be*x*y)/qq))
    return {'Q':Q,'x':x,'y':y,'error_floor':floor,'log_ratio':z,'allowed_log_ratio':[lo,hi],'worst_error':max(errs),'feasible_positive':True}
aa=[.95,1.];bb=[.95,1.]
gain=gain_box(pL,pU,vL,Delta,.08,eta,aa,bb)
kg=1-2*.08
cons=[{'type':'ineq','fun':lambda u:.5*(u[0]+u[1]-math.sqrt((u[0]-u[1])**2+4*u[2]**2))}]
for pp in [pL,pU]:
 cons.append({'type':'ineq','fun':lambda u,pp=pp:pp*aa[0]*u[0]+(1-pp)*bb[0]*u[1]-u[3]})
 for al in aa:
  for be in bb:
   cons.append({'type':'ineq','fun':lambda u,pp=pp,al=al,be=be:2*m*math.sqrt(pp*(1-pp)*al*be)*u[2]-kg*(pp*al*u[0]+(1-pp)*be*u[1])})
res=minimize(lambda u:-u[3],[.1,.4,.2,.1],method='SLSQP',bounds=[(0,eta)]*4,constraints=cons,options={'ftol':1e-13,'maxiter':1000})
assert res.success and abs(res.x[3]-gain['Q'])<1e-8
# Complete upstream coherent loss map plus transmitted instrument, retaining R.
boxres=0.
for al in aa:
 for be in bb:
  At=np.diag(np.sqrt([al,be]));Bl=np.diag(np.sqrt([1-al,1-be]))
  boxres=max(boxres,np.linalg.norm(At.conj().T@completeness@At+Bl.conj().T@Bl-np.eye(2)))
assert boxres<1e-12
out['unknown_mode_efficiency_box']={'alpha_interval':aa,'beta_interval':bb,'analytic':gain,'independent_numerical_PSD_Q':float(res.x[3]),'upstream_loss_plus_reader_completeness_residual':float(boxres)}
# Controlled held-route witness: changing ready loss can change the calibrated ratio.
fixed_loss=[]
for actual_ell in [.8,.9,1.,1.1]:
    f0=amp(gs[0],actual_ell,tau)[1];f1=amp(gs[1],actual_ell,tau)[1]
    xx,yy=f0*f0,f1*f1
    errors=[.5*(1-2*m*math.sqrt(pp*(1-pp)*xx*yy)/(pp*xx+(1-pp)*yy)) for pp in [pL,pU]]
    fixed_loss.append({'actual_ell':actual_ell,'fixed_pulse_g0_g1':gs,'worst_conditional_error':max(errors)})
out['held_unknown_loss_rate_witness']=fixed_loss
# Concrete before/after: old exact-pair reader calibrated at p=.8 versus robust set.
oldx,oldy=usd['x'],usd['y']
oldQ=min(pp*oldx+(1-pp)*oldy for pp in [pL,pU])
oldE=max(.5*(1-2*m*math.sqrt(pp*(1-pp)*oldx*oldy)/(pp*oldx+(1-pp)*oldy)) for pp in [pL,pU])
out['before_after_nominal_exact_reader']={'old_nominal_p':.8,'old_exact_visibility':1.,'old_x':oldx,'old_y':oldy,'old_guaranteed_Q_on_uncertainty_set':oldQ,'old_worst_conditional_error_on_uncertainty_set':oldE,'robust_epsilon_0_08_Q':main['Q'],'relative_Q_improvement_at_error_ceiling_0_08':main['Q']/oldQ-1,'old_reader_fails_error_ceiling_0_06':oldE>.06}
Path(__file__).with_name('robust_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
