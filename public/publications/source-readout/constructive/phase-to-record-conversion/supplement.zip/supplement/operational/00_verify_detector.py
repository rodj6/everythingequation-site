#!/usr/bin/env python3
"""Reproduce the full-output detector examples. Analytic proofs are in chapter.tex.
Requires Python 3.11+, numpy, scipy. Original user evidence is never modified.
Quadratures are binary64 diagnostics, not interval or empirical certificates.
"""
from pathlib import Path
import json, math
import numpy as np
from scipy.integrate import quad, quad_vec
from scipy.linalg import expm

out={"scope":"synthetic declared quantum detector models; floating diagnostics, no empirical calibration","units":"times in seconds, rates and angular detuning in inverse seconds, H/hbar in inverse seconds"}

def survival(g,T): return math.exp(-g*T)
def time_tv(g,k,T):
    t=math.log(g/k)/(g-k) if g!=k else math.inf
    points=sorted(set([0.,T]+([t] if 0<t<T else [])))
    density_l1=0.
    for a,b in zip(points[:-1],points[1:]):
        density_l1+=abs((math.exp(-g*a)-math.exp(-g*b))-(math.exp(-k*a)-math.exp(-k*b)))
    return .5*(abs(survival(g,T)-survival(k,T))+density_l1)

def cq_pure_distance(g,k,T,overlap):
    p0,q0=survival(g,T),survival(k,T)
    f=lambda t: .5*math.sqrt(max(0.,(g*math.exp(-g*t)-k*math.exp(-k*t))**2+4*g*k*math.exp(-(g+k)*t)*(1-overlap**2)))
    return .5*abs(p0-q0)+quad(f,0,T,epsabs=1e-13)[0]

def exponential_affinity(g,k,T):
    s=(g+k)/2
    c=2*math.sqrt(g*k)/(g+k)
    return c+(1-c)*math.exp(-s*T)

T=1.; g=1.; delta=2.
c=math.exp(-g*T)+g*(-np.expm1(-(g-1j*delta)*T))/(g-1j*delta)
Dcoh=math.sqrt(1-abs(c)**2)
out['phase_same_rate']={"gamma":g,"T":T,"detuning":delta,"count_time_distance":0.,"coherent_overlap_real":float(c.real),"coherent_overlap_imag":float(c.imag),"coherent_distance":Dcoh,"infinite_time_distance":abs(delta)/math.sqrt(g*g+delta*delta),"epsilon_0.01_detuning_max_infinite_time":g*.01/math.sqrt(1-.01**2)}
out['orthogonal_marks']={"gamma":g,"T":T,"terminal_bit_distance":0.,"retained_time_mark_distance":1-math.exp(-g*T),"complete_coherent_distance":math.sqrt(1-math.exp(-2*g*T))}
assert abs(cq_pure_distance(g,g,T,0)-(1-math.exp(-g*T)))<1e-12
assert cq_pure_distance(g,g,T,1)<1e-12

rates=[.5,1.5]; weights=[.5,.5]
s=sum(p*survival(a,T) for p,a in zip(weights,rates))
k=-math.log(s)/T
refbit=sum(p*abs(survival(a,T)-s) for p,a in zip(weights,rates))
fulltime=sum(p*time_tv(a,k,T) for p,a in zip(weights,rates))
q1=sum(p*math.exp(-2*a*T) for p,a in zip(weights,rates))
q2=s*s
postnoclick=[p*survival(a,T)/s for p,a in zip(weights,rates)]
H=np.array([[sum(p*a**(i+j) for p,a in zip(weights,rates)) for j in range(2)] for i in range(2)])
# A genuine purification keeps coherent latent-label off-diagonal elements.
# Null and each time fibre are rank one in the retained I+P register.
cn=sum(p*math.exp(-(a+k)*T/2) for p,a in zip(weights,rates))
null_pur=math.sqrt(max(0.,s*s-cn*cn))
def pur_integrand(t):
    p=sum(w*a*math.exp(-a*t) for w,a in zip(weights,rates))
    q=k*math.exp(-k*t)
    c=sum(w*math.sqrt(a*k)*math.exp(-(a+k)*t/2) for w,a in zip(weights,rates))
    return .5*math.sqrt(max(0.,(p+q)**2-4*c*c))
pur_cq=null_pur+quad(pur_integrand,0,T,epsabs=1e-12)[0]
# Terminal bit while keeping all latent and purification quantum registers:
# the click block has several rank-one time fibres, integrated before comparing.
v0=np.array([math.sqrt(w)*math.exp(-a*T/2) for w,a in zip(weights,rates)])
u0=np.array([math.sqrt(w)*math.exp(-k*T/2) for w in weights])
Ctrue=quad_vec(lambda t:np.outer(np.array([math.sqrt(w*a)*math.exp(-a*t/2) for w,a in zip(weights,rates)]),np.array([math.sqrt(w*a)*math.exp(-a*t/2) for w,a in zip(weights,rates)])),0,T,epsabs=1e-12)[0]
rootw=np.sqrt(weights)
Cfit=(1-math.exp(-k*T))*np.outer(rootw,rootw)
pur_bit=.5*(np.linalg.svd(np.outer(v0,v0)-np.outer(u0,u0),compute_uv=False).sum()+np.linalg.svd(Ctrue-Cfit,compute_uv=False).sum())
out['hidden_rate_repair']={"rates":rates,"weights":weights,"T":T,"terminal_survival":s,"fitted_constant_rate":k,"unretained_terminal_bit_distance":0.,"retained_label_terminal_bit_distance":refbit,"retained_label_click_time_distance":fulltime,"no_click_posterior_weights":postnoclick,"shared_label_two_no_click_probability":q1,"redrawn_label_two_no_click_probability":q2,"two_use_event_gap":q1-q2,"survival_hankel_determinant":float(np.linalg.det(H)),"two_label_repair_error":0.,"coherent_purification_terminal_bit_distance":float(pur_bit),"coherent_purification_time_null_distance":float(pur_cq)}
assert abs(np.linalg.det(H)-weights[0]*weights[1]*(rates[1]-rates[0])**2)<1e-13
assert refbit>.19 and q1-q2>.036

# Clustering rates bounds full time + unchanged latent labels, not merely bits.
clustering=[]
for a,b in [(1.,1.1),(.5,1.5),(.99,1.01),(0.01,10.)]:
    tv=time_tv(a,b,T); aff=exponential_affinity(a,b,T)
    direct=cq_pure_distance(a,b,T,1)
    assert abs(tv-direct)<1e-8
    assert tv<=math.sqrt(max(0.,1-aff*aff))+1e-12
    clustering.append({"gamma":a,"representative":b,"T":T,"exact_time_tv":tv,"affinity":aff,"hellinger_upper":math.sqrt(max(0.,1-aff*aff))})
out['rate_cluster_certificates']=clustering

# Genuine operator model, with noncommuting ground H and non-scalar Q.
Q0=np.diag([.7,1.4]); Q1=np.diag([.72,1.35])
Hx=np.array([[0,.2],[.2,0]],complex)
H0=Hx; H1=Hx+np.diag([.01,-.01])
G0=-1j*H0-Q0/2; G1=-1j*H1-Q1/2
ang=.15
R=np.array([[math.cos(ang),-math.sin(ang)],[math.sin(ang),math.cos(ang)]])
B0=np.diag(np.sqrt(np.diag(Q0))); B1=R@np.diag(np.sqrt(np.diag(Q1)))
N0=lambda t:expm(G0*t)
N1=lambda t:expm(G1*t)
K0=lambda t:B0@N0(t)
K1=lambda t:B1@N1(t)
comp0=N0(T).conj().T@N0(T)+quad_vec(lambda t:K0(t).conj().T@K0(t),0,T,epsabs=1e-12)[0]
comp1=N1(T).conj().T@N1(T)+quad_vec(lambda t:K1(t).conj().T@K1(t),0,T,epsabs=1e-12)[0]
Dd=N1(T)-N0(T)
Dgram=Dd.conj().T@Dd+quad_vec(lambda t:(K1(t)-K0(t)).conj().T@(K1(t)-K0(t)),0,T,epsabs=1e-12)[0]
a_actual=math.sqrt(max(0.,float(np.linalg.eigvalsh(Dgram).max())))
S=N0(T).conj().T@N1(T)+quad_vec(lambda t:K0(t).conj().T@K1(t),0,T,epsabs=1e-12)[0]
cG=np.linalg.norm(G1-G0,2)
e=lambda t:t*cG
bound2=e(T)**2+quad(lambda t:(np.linalg.norm((B1-B0)@N0(t),2)+np.linalg.norm(B1,2)*e(t))**2,0,T,epsabs=1e-12)[0]
bound=math.sqrt(bound2)
rng=np.random.default_rng(26912026)
Ds=[]
for _ in range(200):
    psi=rng.normal(size=(2,5))+1j*rng.normal(size=(2,5)); psi/=np.linalg.norm(psi)
    rho=psi@psi.conj().T
    co=np.trace(rho@S)
    D=math.sqrt(max(0.,1-abs(co)**2)); Ds.append(D)
    assert D<=a_actual+1e-11
assert a_actual<=bound+1e-11
assert np.linalg.norm(comp0-np.eye(2))<1e-10 and np.linalg.norm(comp1-np.eye(2))<1e-10
out['operator_valued_example']={"T":T,"Q0":Q0.tolist(),"Q1":Q1.tolist(),"output_rotation_radians":ang,"G_defect_norm":float(cG),"isometry_completeness_residual0":float(np.linalg.norm(comp0-np.eye(2))),"isometry_completeness_residual1":float(np.linalg.norm(comp1-np.eye(2))),"exact_operator_isometry_defect_numerical":a_actual,"derived_Duhamel_budget":bound,"max_pure_coherent_distance_over_200_entangled_inputs_Rdim5":max(Ds),"all_200_entangled_inputs_satisfied_bound":True}

# General rank-one kernel formula checked directly on matrices for unequal weights.
maxerr=0.
for _ in range(100):
    u=rng.normal(size=4)+1j*rng.normal(size=4); u/=np.linalg.norm(u)
    v=rng.normal(size=4)+1j*rng.normal(size=4); v/=np.linalg.norm(v)
    p,q=rng.random(2)
    exact=.5*np.linalg.svd(p*np.outer(u,u.conj())-q*np.outer(v,v.conj()),compute_uv=False).sum()
    formula=.5*math.sqrt(max(0.,(p+q)**2-4*p*q*abs(np.vdot(u,v))**2))
    maxerr=max(maxerr,abs(exact-formula))
assert maxerr<1e-12
out['rank_one_trace_formula_100_random_checks_max_error']=maxerr
Path(__file__).with_name('detector_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
