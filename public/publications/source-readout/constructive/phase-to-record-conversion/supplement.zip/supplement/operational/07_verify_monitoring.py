"""Finite monitoring of a completely general three-outcome qutrit POVM.
Requires numpy, scipy, matplotlib. Synthetic counts, not an experiment.
Run: python research5/monitoring/verify_monitoring.py
"""
from pathlib import Path
import itertools,json,math
import numpy as np
from scipy.optimize import brentq, minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
rng=np.random.default_rng(202610275)
D=3; J=9; PAIRS=[(0,1),(0,2),(1,2)]
SIGNS=np.array(list(itertools.product([-1,1],repeat=J)),dtype=float)
C3=1+2*math.sqrt(5)

def reconstruct(v):
    v=np.asarray(v); H=np.diag(np.asarray(v[:3],complex)); k=3
    for i,j in PAIRS:
        H[i,j]=v[k]-(v[i]+v[j])/2+1j*((v[i]+v[j])/2-v[k+1])
        H[j,i]=H[i,j].conjugate(); k+=2
    return H
DUAL=np.array([reconstruct(np.eye(J)[k]) for k in range(J)])

def opnorm(H):return float(np.max(np.abs(np.linalg.eigvalsh(H))))
def trnorm(H):return float(np.sum(np.abs(np.linalg.eigvalsh(H))))
def radius(b):
    mats=np.einsum('sv,vij->sij',SIGNS*np.asarray(b),DUAL)
    return float(np.max(np.abs(np.linalg.eigvalsh(mats))))
def probes():
    eye=np.eye(D,dtype=complex); vecs=list(eye)
    for i,j in PAIRS:vecs.extend([(eye[i]+eye[j])/np.sqrt(2),(eye[i]+1j*eye[j])/np.sqrt(2)])
    return [np.outer(v,v.conj()) for v in vecs]
PROBES=probes()

def probs(E):return np.array([[np.trace(F@P).real for F in E] for P in PROBES])
def physicalize(raw):
    lam=max(0.,-min(np.linalg.eigvalsh(H).min() for H in raw))
    F=[(H+lam*np.eye(D))/(1+3*lam) for H in raw]
    shifts=[opnorm(F[k]-raw[k]) for k in range(2)]
    return F,lam,shifts

def anytime_width(n,alpha,K=3):
    # two outcome streams for each of nine probes and K possible epochs
    delta=alpha/(2*J*K)
    return math.sqrt(math.log(math.pi**2*n*n/(3*delta))/(2*n))
def fixed_width(n,alpha,K=3):return math.sqrt(math.log(4*J*K/alpha)/(2*n))

def sign_matrix(H):
    vals,U=np.linalg.eigh(H);return (U*np.sign(vals))@U.conj().T

def pair_stats(F,rhos,pi=(.5,.5)):
    avg=pi[0]*rhos[0]+pi[1]*rhos[1]
    W=pi[0]*np.trace(F[1]@rhos[0]).real+pi[1]*np.trace(F[0]@rhos[1]).real
    Q=np.trace((F[0]+F[1])@avg).real
    return float(W),float(Q),avg

def support(F,rhos,r,eps,pi=(.5,.5)):
    W,Q,avg=pair_stats(F,rhos,pi)
    A=[pi[1]*rhos[1]-eps*avg,pi[0]*rhos[0]-eps*avg]
    return W-eps*Q+r*sum(trnorm(a) for a in A),A

def error_bound(F,rhos,r,source_delta=0,pi=(.5,.5)):
    W,Q,avg=pair_stats(F,rhos,pi)
    q=max(0,Q-2*r-source_delta)
    if q<=0:return 1.,q
    fun=lambda eps:support(F,rhos,r,eps,pi)[0]+source_delta
    if fun(1)>0:return 1.,q
    eps=brentq(fun,0,1,xtol=1e-14)
    return float(eps),float(q)

def exact_sign_nonnegative(a,b):
    # Exact sign of a+b sqrt(5), integers only.
    if b==0:return a>=0
    if a>=0 and b>=0:return True
    if a<=0 and b<=0:return a==0 and b==0
    if a>=0:return a*a>=5*b*b
    return 5*b*b>=a*a

def algebraic_constant_certificate():
    failures=[]; zeros=0; checks=0
    for index,s in enumerate(SIGNS.astype(int)):
        H=reconstruct(s)
        # All entries are Gaussian integers for these vertices.
        assert np.allclose(H.real,np.round(H.real)) and np.allclose(H.imag,np.round(H.imag))
        for orientation in [-1,1]:
            # Python-integer Gaussian pairs make the finite certificate exact.
            ds=[orientation*int(z) for z in s[:3]]
            zs=[]
            for k,(i,j) in enumerate(PAIRS):
                mean=(int(s[i])+int(s[j]))//2
                zs.append((orientation*(int(s[3+2*k])-mean),
                           orientation*(mean-int(s[4+2*k]))))
            ns=[a*a+b*b for a,b in zs]
            # Principal minors of lambda I-A at lambda=1+2 sqrt(5).
            vals=[(1-int(d),2) for d in ds]
            for (i,j),n in zip(PAIRS,ns):
                vals.append((21-int(ds[i]+ds[j])+int(ds[i]*ds[j])-n,4-2*int(ds[i]+ds[j])))
            trace=sum(ds)
            c2=ds[0]*ds[1]+ds[0]*ds[2]+ds[1]*ds[2]-sum(ns)
            (a,b),(c,d),(e,f)=zs # z01, z02, z12; triple z01*z12*conj(z02)
            triple_real=(a*e-b*f)*c+(a*f+b*e)*d
            det=ds[0]*ds[1]*ds[2]+2*triple_real-ds[0]*ns[2]-ds[1]*ns[1]-ds[2]*ns[0]
            vals.append((61-21*trace+c2-det,46-4*trace+2*c2))
            for a,b in vals:
                checks+=1
                if a==b==0:zeros+=1
                if not exact_sign_nonnegative(a,b):failures.append([index,orientation,a,b])
    assert not failures
    witness=reconstruct([1,1,1,-1,-1,-1,1,-1,-1])
    witness_poly=[1,-3,-17,19] # (lambda-1)((lambda-1)^2-20)
    # Exact lower certificate: diagonal all 1, squared moduli 8,4,8,
    # Re[z01*z12*conj(z02)]=0. Characteristic coefficients are integers.
    witness_trace=3;witness_c2=3-(8+4+8);witness_det=1-8-4-8
    assert [1,-witness_trace,witness_c2,-witness_det]==witness_poly
    assert np.allclose(np.poly(witness).real,witness_poly)
    return dict(vertices=512,principal_minors_checked=checks,negative_minors=len(failures),zero_minors=zeros,
                constant=C3,witness_characteristic_polynomial=witness_poly,exact_witness_trace_c2_det=[witness_trace,witness_c2,witness_det],
                numerical_radius=radius(np.ones(9)))

# General asymmetric, dark-count, vacuum-coherent benchmark. Basis vac,0,1.
Fp=np.array([[.018,.002,.001j],[.002,.10,.15],[ -.001j,.15,.325]],complex)
Fm=np.array([[.026,-.001j,.001],[.001j,.11,-.148j*np.sin(.02)-.148*np.cos(.02)],
             [.001,-.148*np.cos(.02)+.148j*np.sin(.02),.335]],complex)
F0=np.eye(3)-Fp-Fm
TRUE=[Fp,Fm,F0]
assert min(np.linalg.eigvalsh(x).min() for x in TRUE)>0
# Opposite phase inputs in occupied qubit support, known in this benchmark.
a,b=math.sqrt(.8),math.sqrt(.2)
psi_p=np.array([0,a,b],complex);psi_m=np.array([0,a,-b],complex)
RHOS=[np.outer(v,v.conj()) for v in [psi_p,psi_m]]

alpha=.01; K=3; n=4_000_000; nu=1e-11; delta_prep=5e-5
P=probs(TRUE)
counts=np.array([rng.multinomial(n,p) for p in P])
emp=counts/n
raw=[reconstruct(emp[:,0]),reconstruct(emp[:,1])]
raw.append(np.eye(3)-raw[0]-raw[1])
CENTER,repair_lambda,shifts=physicalize(raw)
# Full round-robin cycle j=1,...,9 repeated n times; time is one clock slot.
ages=9*(n+1)/2-np.arange(0,9)
bs=anytime_width(n,alpha,K)+delta_prep+nu*ages
rt=[radius(bs)+shifts[y] for y in range(2)]
r0=max(rt)
margin=min(np.linalg.eigvalsh(CENTER[0]).min(),np.linalg.eigvalsh(CENTER[1]).min(),np.linalg.eigvalsh(CENTER[2]).min()/2)
W,Q,_=pair_stats(CENTER,RHOS)
e0,q0=error_bound(CENTER,RHOS,r0)
threshold=.16
s=abs(np.vdot(psi_p,psi_m))
critical_r=(threshold*Q-W)/math.sqrt(1-4*threshold*(1-threshold)*s*s)
max_age=max(0,(critical_r-r0)/nu)
# Hold the sharp interior-ball claim only below the physical-margin horizon.
sharp_age=max(0,(margin-r0)/nu)
age=1e8
r_age=r0+nu*age
e_age,q_age=error_bound(CENTER,RHOS,r_age)
val,As=support(CENTER,RHOS,r_age,e_age)
H=[r_age*sign_matrix(A) for A in As]
WORST=[CENTER[0]+H[0],CENTER[1]+H[1],CENTER[2]-H[0]-H[1]]
Wa,Qa,_=pair_stats(WORST,RHOS)
sharp_valid=r_age<=margin
quadratic_coefficients=[Q*Q-4*r_age*r_age*s*s,4*r_age*r_age*s*s-2*W*Q,W*W-r_age*r_age]
quadratic_residual=float(np.polyval(quadratic_coefficients,e_age))
# Direct expansion of (epsilon Q-W)^2-r^2[1-4epsilon(1-epsilon)s^2].
for xx in [.0,.17,.5,.9,1.]:
    lhs=(xx*Q-W)**2-r_age*r_age*(1-4*xx*(1-xx)*s*s)
    assert abs(np.polyval(quadratic_coefficients,xx)-lhs)<1e-16
assert abs(quadratic_residual)<1e-14
assert abs(Wa/Qa-e_age)<1e-11 and sharp_valid
assert min(np.linalg.eigvalsh(E).min() for E in WORST)>-1e-12
# Unconditional prior-independent labelwise alternative.
per_label=[]
for h in range(2):
    wh=np.trace(CENTER[1-h]@RHOS[h]).real
    ch=np.trace((CENTER[0]+CENTER[1])@RHOS[h]).real
    per_label.append(dict(h=h,error=min(1,float((wh+r_age)/ch)),conclusive=max(0,float(ch-2*r_age))))

# Random sharp support tests for arbitrary asymmetric effects and mixed qutrit sources.
support_tests=[]
for trial in range(300):
    A=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));R=A@A.conj().T;R/=np.trace(R)
    B=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));S=B@B.conj().T;S/=np.trace(S)
    r=float(rng.uniform(.0001,.5*margin));eps=float(rng.uniform(0,1))
    upper,Ams=support(CENTER,[R,S],r,eps)
    hh=[r*sign_matrix(A) for A in Ams]
    EE=[CENTER[0]+hh[0],CENTER[1]+hh[1],CENTER[2]-hh[0]-hh[1]]
    ww,qq,_=pair_stats(EE,[R,S]);support_tests.append(abs(ww-eps*qq-upper))
    assert min(np.linalg.eigvalsh(e).min() for e in EE)>=-1e-12
# Radius box random verification.
boxerr=[]
for _ in range(1000):
    bb=rng.uniform(0,.02,size=9);z=rng.uniform(-1,1,size=9)*bb
    boxerr.append(opnorm(reconstruct(z))-radius(bb))
assert max(boxerr)<1e-10

# Nonstationary, history-dependent calibration illustration, not coverage proof.
# At each clock slot modify effects by a predictable bounded-increment scalar.
n_small=1000; vv=2e-5; Hdir=np.diag([1.,-.4,.2]);state=0.; online_counts=np.zeros((9,3),int)
last_probs=[]
for t in range(1,9*n_small+1):
    j=(t-1)%9
    E=[Fp+state*Hdir,Fm-state*Hdir,F0]
    pp=np.array([np.trace(Ey@PROBES[j]).real for Ey in E])
    outcome=rng.choice(3,p=pp);online_counts[j,outcome]+=1
    # Small bounded predictable motion tied to the actual retained previous label.
    state=np.clip(state+vv*(1 if outcome==0 else -1),-.003,.003)
Eend=[Fp+state*Hdir,Fm-state*Hdir,F0]
rr=[reconstruct(online_counts[:,y]/n_small) for y in [0,1]]
ages_small=9*(n_small+1)/2-np.arange(0,9)
rad_small=radius(anytime_width(n_small,alpha,K)+vv*ages_small)
errs_small=[opnorm(rr[y]-Eend[y]) for y in [0,1]]
assert max(errs_small)<rad_small

# Exact finite exponential-moment enumeration for predictable Bernoulli means.
# Checks sample-mean martingale Hoeffding for a history-dependent non-iid law.
mgf=[]
for ntest in range(1,9):
    total=0.;theta=.7
    for bits in itertools.product([0,1],repeat=ntest):
        prob=1.;S=0.
        for i,x in enumerate(bits):
            p=.15+.7*((sum(bits[:i])+i)%3)/2
            prob*=p if x else 1-p;S+=x-p
        total+=prob*math.exp(theta*S-ntest*theta*theta/8)
    mgf.append(total)
assert max(mgf)<=1+1e-12

# Fixed-budget design curve, using the valid but conservative uniform-age bound.
ns=np.unique(np.geomspace(1000,100_000_000,500).astype(int))
r_fixed=C3*np.array([fixed_width(int(k),alpha,K)+delta_prep+nu*(9*k+9)/2 for k in ns])
r_any=C3*np.array([anytime_width(int(k),alpha,K)+delta_prep+nu*(9*k+9)/2 for k in ns])
opt=minimize_scalar(lambda logn:C3*(anytime_width(math.exp(logn),alpha,K)+delta_prep+nu*(9*math.exp(logn)+9)/2),
                    bounds=(math.log(1000),math.log(1e8)),method='bounded')
opt_n=int(round(math.exp(opt.x)))
opt_r=C3*(anytime_width(opt_n,alpha,K)+delta_prep+nu*(9*opt_n+9)/2)
A_fixed=math.sqrt(math.log(4*J*K/alpha)/2)
fixed_opt_n=(A_fixed/(J*nu))**(2/3)

# Complete pointer/reference distance witness: H+=H-=r I.
refdim=4
V=rng.normal(size=(D*refdim,D*refdim))+1j*rng.normal(size=(D*refdim,D*refdim))
rhoSR=V@V.conj().T;rhoSR/=np.trace(rhoSR)
def partial_input_trace(H,rho):
    A=(np.kron(H,np.eye(refdim))@rho).reshape(D,refdim,D,refdim)
    return np.einsum('irij->rj',A)
ptr_dist=.5*sum(trnorm(partial_input_trace(H,rhoSR)) for H in [r_age*np.eye(3),r_age*np.eye(3),-2*r_age*np.eye(3)])
assert abs(ptr_dist-2*r_age)<1e-12

# Exact missing-probe obstruction: all four occupied-qubit probes see no vacuum dark perturbation.
Hblind=np.diag([1.,0.,0.]); blind_shift=.01
occupied=[PROBES[j] for j in [1,2,7,8]]
blind_visibility=max(abs(np.trace(Hblind@S)) for S in occupied)
assert blind_visibility==0

report={
 'seed':202610275,'synthetic':True,'algebraic_constant_certificate':algebraic_constant_certificate(),
 'benchmark':{'basis':['vac','0','1'],'true_effects':[[[[float(z.real),float(z.imag)] for z in row] for row in E] for E in TRUE],
 'count_rows_probe_order':['vac','0','1','vac+0','vac+i0','vac+1','vac+i1','0+1','0+i1'],
 'counts_plus_minus_null':counts.tolist(),'n_per_probe':n,'maximum_epochs':K,'maximum_total_probe_budget':9*n*K,
 'failure_probability':alpha,'operator_norm_drift_per_clock_slot':nu,'probe_preparation_trace_error':delta_prep,
 'anytime_scalar_width':anytime_width(n,alpha,K),'mean_probe_ages':ages.tolist(),
 'repair_lambda':repair_lambda,'r0_by_effect':rt,'uniform_r0':r0,'physical_interior_radius':float(margin),
 'center_wrong_probability':W,'center_conclusive_probability':Q,'source_overlap':float(s),
 'initial_error_certificate':e0,'initial_conclusive_certificate':q0,'deployment_age':age,
 'deployment_radius':r_age,'deployment_error_certificate':e_age,'deployment_conclusive_certificate':q_age,
 'quadratic_coefficients':quadratic_coefficients,'quadratic_residual':quadratic_residual,'sharp_support_attainment_valid':bool(sharp_valid),'attaining_error':float(Wa/Qa),'support_residual':float(val),
 'attaining_minimum_eigenvalue':float(min(np.linalg.eigvalsh(E).min() for E in WORST)),
 'target_conditional_error':threshold,'max_performance_age_slots':max_age,'max_sharp_ball_age_slots':sharp_age,
 'labelwise_arbitrary_prior_certificates':per_label},
 'tests':{'reference_dimension':refdim,'pointer_half_trace_witness':ptr_dist,'pointer_sharp_bound_2r':2*r_age,'random_support_attainment_cases':len(support_tests),'max_support_residual':max(support_tests),
 'random_box_cases':len(boxerr),'max_box_excess':max(boxerr),'nonstationary_history_dependent_example':{
 'n_per_probe':n_small,'drift_bound':vv,'final_effect_errors':errs_small,'radius':rad_small,
 'all_nulls_retained':int(online_counts[:,2].sum())},'exact_predictable_bernoulli_mgf_by_n':mgf},
 'budget_design':{'anytime_optimal_n_per_probe':opt_n,'anytime_uniform_radius_at_optimum':float(opt_r),
 'fixed_terminal_optimal_n_continuous':fixed_opt_n,'claimed_optimization_scope':'specified uniform-age Hoeffding radius, not all tomography protocols'},
 'blind_probe_example':{'vacuum_shift':blind_shift,'all_occupied_probe_probability_changes':float(blind_visibility)}}
(HERE/'results.json').write_text(json.dumps(report,indent=2)+'\n')

plt.rcParams.update({'font.size':12,'axes.titlesize':13,'axes.labelsize':12,'xtick.labelsize':11,'ytick.labelsize':11})
fig=plt.figure(figsize=(10,7.4),layout='constrained')
gs=fig.add_gridspec(2,2,height_ratios=[1,1])
axs=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,:])]
axs[0].plot(ns,r_fixed,label='Fixed sample per epoch',lw=2)
axs[0].plot(ns,r_any,label='Any prefix may stop',lw=2)
axs[0].axvline(opt_n,color='gray',ls=':',label='Specified-radius optimum')
axs[0].set(xscale='log',yscale='log',xlabel='Probes per state per epoch',ylabel='Operator-norm radius',title='Statistics and accumulated drift')
axs[0].legend(fontsize=10)
ages_plot=np.linspace(0,min(max_age*1.15,8e8),180)
er=[];qq=[]
for ag in ages_plot:
    ee,cc=error_bound(CENTER,RHOS,r0+nu*ag);er.append(ee);qq.append(cc)
axs[1].plot(ages_plot/1e8,er,label='Worst conditional error',lw=2)
axs[1].plot(ages_plot/1e8,qq,label='Conclusive lower bound',lw=2)
axs[1].axhline(threshold,color='gray',ls='--',label='Error threshold 0.16')
axs[1].axvline(sharp_age/1e8,color='gray',ls=':',label='End of guaranteed sharp regime')
axs[1].set(xlabel='Age since calibration (100 million slots)',ylabel='Probability',title='A certificate expires without new probes')
axs[1].legend(fontsize=10)
width=.24;x=np.arange(9)
for y,(label,color) in enumerate(zip(['+','−','null'],['#2676ad','#dc7c34','#8a8a8a'])):
    axs[2].bar(x+(y-1)*width,counts[:,y]/n,width,label=label,color=color)
axs[2].set_xticks(x,['v','0','1','v+0','v+i0','v+1','v+i1','0+1','0+i1'],rotation=45,ha='right')
axs[2].set(ylabel='Observed frequency',title='Nine trusted probes; every null counted')
axs[2].legend(fontsize=10)
fig.savefig(HERE/'monitoring_certificate.png',dpi=180)
print(json.dumps(report,indent=2))
