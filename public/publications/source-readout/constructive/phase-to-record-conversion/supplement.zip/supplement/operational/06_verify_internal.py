#!/usr/bin/env python3
"""Fifth investigation: exact structured internal-uncertainty model diagnostics.
Python 3.11+, numpy, scipy. Synthetic float checks, not empirical/interval data.
"""
from pathlib import Path
import math,json
import numpy as np
from scipy.optimize import brentq
from scipy.linalg import expm
SEED=271020265

def peak(g,l):
 if l==0:return math.pi/(2*g)
 d=g*g-l*l/16
 if abs(d)<1e-12*max(g*g,l*l):return 1/g
 if d>0:
  o=math.sqrt(d);return math.atan(4*o/l)/o
 c=math.sqrt(-d);return math.atanh(4*c/l)/c

def amp(g,l,t):
 if g==0:return math.exp(-l*t/2),0.
 d=g*g-l*l/16;v=math.exp(-l*t/4)
 if abs(d)<1e-12*max(g*g,l*l):return v*(1-l*t/4),v*g*t
 if d>0:
  o=math.sqrt(d);return v*(math.cos(o*t)-l*math.sin(o*t)/(4*o)),v*g*math.sin(o*t)/o
 c=math.sqrt(-d);return v*(math.cosh(c*t)-l*math.sinh(c*t)/(4*c)),v*g*math.sinh(c*t)/c

def allowed(pL,pU,vis,delta,eps):
 m=vis*math.cos(delta);xx=[math.sqrt(p/(1-p)) for p in [pL,pU]]
 w=.5*math.log(xx[1]/xx[0]);floor=(1-m/math.cosh(w))/2
 assert eps>=floor
 h=math.acosh(m/(1-2*eps))
 return math.exp(-h-math.log(xx[0])),math.exp(h-math.log(xx[1])),floor,m

pL,pU,vis,delta,eps=.7,.9,.95,math.pi/18,.08
rL,rU,floor,m=allowed(pL,pU,vis,delta,eps)
gL,gU,lL,lU,tL,tU=.9,1.1,.8,1.2,.9,1.1
assert tU*(gU+lU/4)<1.57 # exact conservative bound 1.54 <1.57<pi/2
assert tU<peak(gU,lU)
f=lambda g,l,t:amp(g,l,t)[1]
Rmin=lambda d:f(d*gL,lU,tL)/f(gL,lU,tL)
Rmax=lambda d:f(d*gU,lL,tU)/f(gU,lL,tU)
dstar=brentq(lambda d:Rmax(d)-rU,0,1,xtol=1e-14)
dlower=brentq(lambda d:Rmin(d)-rL,0,1,xtol=1e-14)
assert dlower<=dstar and Rmin(dstar)>=rL
etaMin=f(gL,lU,tL)**2
etaMax=f(gU,lL,tU)**2
Qnew=etaMin*(1-pU+pU*rU*rU)
Qold=etaMin*(1-pU+pU*Rmin(dstar)**2)
dnom=brentq(lambda d:f(d,1,1)/f(1,1,1)-rU,0,1)
err=lambda ratio,p:.5*(1-m/math.cosh(math.log(ratio)+.5*math.log(p/(1-p))))
oldnomErr=max(err(Rmin(dnom),pL),err(Rmax(dnom),pU))
# Independent dense box verification of all extrema and predicted robust error.
etaGrid=[];ratioGrid=[];newErr=0.;oldErr=0.;nomErr=0.;QnewGrid=1.;QoldGrid=1.
for g in np.linspace(gL,gU,17):
 for l in np.linspace(lL,lU,17):
  for t in np.linspace(tL,tU,17):
   a=f(g,l,t);eta=a*a;ratio=f(dstar*g,l,t)/a
   etaGrid.append(eta);ratioGrid.append(ratio)
   for p in [pL,pU]:
    newErr=max(newErr,err(rU,p));oldErr=max(oldErr,err(ratio,p))
    nomErr=max(nomErr,err(f(dnom*g,l,t)/a,p))
    QnewGrid=min(QnewGrid,eta*(1-p+p*rU*rU))
    QoldGrid=min(QoldGrid,eta*(1-p+p*ratio*ratio))
assert abs(min(etaGrid)-etaMin)<1e-13 and abs(max(etaGrid)-etaMax)<1e-13
assert abs(min(ratioGrid)-Rmin(dstar))<1e-13 and abs(max(ratioGrid)-Rmax(dstar))<1e-13
assert newErr<=eps+1e-13 and oldErr<=eps+1e-13
assert abs(QnewGrid-Qnew)<1e-13 and abs(QoldGrid-Qold)<1e-13
# Physical finite filter: one orthogonal failure mode, no selected renormalization.
F=np.diag([rU,1.]).astype(complex)
B=np.array([[math.sqrt(1-rU*rU),0.]],complex)
assert np.linalg.norm(F.conj().T@F+B.conj().T@B-np.eye(2))<1e-14
# Common-mode random complex controllers: factorization survives detuning,
# reversal and waveform variation, even though no positive uniform rate is claimed.
rng=np.random.default_rng(SEED)
Had=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
maxRefDiff=0.;maxNorm=0.;varEta=[]
for k in range(100):
 U=np.eye(2,dtype=complex)
 for j in range(6):
  gg=rng.uniform(-1.5,1.5)+1j*rng.uniform(-.5,.5)
  det=rng.uniform(-.6,.6,2);loss=rng.uniform(.1,1.4)
  H2=np.array([[det[0],np.conj(gg)],[gg,det[1]]])
  U=expm((-1j*H2-np.diag([loss/2,0]))*.2)@U
 alpha,beta=U[1,0],U[0,0]
 eta=abs(alpha)**2;null=abs(beta)**2;lost=max(0.,1-eta-null)
 varEta.append(eta)
 K=[alpha*Had[j:j+1]@F for j in range(2)]
 K0=beta*F;KL=math.sqrt(lost)*F # full time state remains an independent common apparatus factor
 comp=sum(z.conj().T@z for z in K)+K0.conj().T@K0+KL.conj().T@KL+B.conj().T@B
 maxNorm=max(maxNorm,np.linalg.norm(comp-np.eye(2)))
 psi=rng.normal(size=(2,7))+1j*rng.normal(size=(2,7));psi/=np.linalg.norm(psi)
 for j in range(2):
  v=K[j]@psi;nom=(Had[j:j+1]@F)@psi
  actual=v.conj().T@v;target=eta*(nom.conj().T@nom)
  maxRefDiff=max(maxRefDiff,np.linalg.norm(actual-target))
assert maxNorm<2e-14 and maxRefDiff<2e-14
# Monotonicity samples include under-, critical-, overdamped boxes.
regimeTests=[]
for box in [(.4,.6,.1,.3,.2,.5),(.8,1.2,4.,5.,.15,.4),(.8,1.1,9.,11.,.1,.3),(.9,1.1,.8,1.2,.9,1.1)]:
 gl,gu,ll,lu,tl,tu=box
 assert tu<peak(gu,lu)
 etas=[];rs=[]
 for g in np.linspace(gl,gu,7):
  for l in np.linspace(ll,lu,7):
   for t in np.linspace(tl,tu,7):
    etas.append(f(g,l,t)**2);rs.append(f(.5*g,l,t)/f(g,l,t))
 assert abs(min(etas)-f(gl,lu,tl)**2)<1e-12
 assert abs(max(rs)-f(.5*gu,ll,tu)/f(gu,ll,tu))<1e-12
 regimeTests.append({'box':box,'eta_min':min(etas),'ratio_min':min(rs),'ratio_max':max(rs)})
out={'scope':'structured common-mode internal uncertainty; calibrated extra filter port; stable-flag-only readout; synthetic float diagnostics','seed':SEED,'source':{'p_interval':[pL,pU],'visibility_lower':vis,'phase_halfwidth_radians':delta,'conditional_error_ceiling':eps,'error_floor':floor,'allowed_effect_amplitude_ratio':[rL,rU]},'internal_box':{'gain':[gL,gU],'uniform_ready_loss':[lL,lU],'interaction_duration':[tL,tU],'units':'g,ell in s^-1; duration seconds','prepeak_conservative_product':tU*(gU+lU/4),'minimum_first_peak':peak(gU,lU),'eta_min':etaMin,'eta_max':etaMax},'architectures':{'filter_then_identical_taps':{'filter_amplitude_ratio':rU,'filter_failure_mode_added':1,'calibrated_filter_exchange_angle_radians':math.acos(rU),'guaranteed_conclusive':Qnew,'worst_conditional_error':newErr},'best_retuned_unequal_rectangular_taps':{'coupling_ratio':dstar,'feasible_lower_ratio':dlower,'actual_effect_ratio_min':Rmin(dstar),'actual_effect_ratio_max':Rmax(dstar),'guaranteed_conclusive':Qold,'worst_conditional_error':oldErr},'nominal_unequal_taps':{'coupling_ratio':dnom,'worst_conditional_error':nomErr,'fails_error_contract':nomErr>eps}},'resource_sensitive_relative_conclusive_improvement':Qnew/Qold-1,'dense_box_points':17**3,'common_complex_controller_tests':{'number':100,'reference_dimension':7,'eta_range_in_samples':[min(varEta),max(varEta)],'full_output_completeness_max_residual':float(maxNorm),'reference_assemblage_factorization_max_residual':float(maxRefDiff),'no_positive_rate_bound_claimed_for_these_arbitrary_waveforms':True},'monotonicity_regime_tests':regimeTests}
Path(__file__).with_name('internal_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
