"""Exact adaptive finite-record checks; all outputs, including nulls, retained."""
from fractions import Fraction as F
from pathlib import Path
import math,json

OUT=Path(__file__).resolve().parent
N=24;eps=F(1,10);alpha=F(1,50);beta=.1
# Full adaptive distribution on (wrong count, conclusive count, last outcome).
law={(0,0,2):F(1)}
for t in range(1,N+1):
 new={}
 for (w,c,last),prob in law.items():
  q=F(1,4)+F(1,4)*(last==1)+F(1,10)*(t%2)
  error=eps*(F(1) if last==2 else F(2,5))
  outcomes=[(0,q*(1-error)),(1,q*error),(2,1-q)]
  for event,p in outcomes:
   key=(w+(event==1),c+(event!=2),event)
   new[key]=new.get(key,F(0))+prob*p
 law=new
 assert sum(law.values())==1
b=math.sqrt(N/2*math.log(2/beta))
wrongtail=sum(p for (w,c,l),p in law.items() if float(F(w)-eps*c)>b)
concltail=sum(p for (w,c,l),p in law.items() if c<N/4-b)
assert float(wrongtail)<=beta/2 and float(concltail)<=beta/2
moments=[]
for theta in [.05,.2,.5,1.]:
 mgf=sum(float(p)*math.exp(theta*(w-float(eps)*c)) for (w,c,l),p in law.items())
 bound=math.exp(N*theta*theta/8)
 assert mgf<=bound+1e-13
 moments.append(dict(theta=theta,mgf=mgf,upper=bound))
# A single bad batch can govern every future use. It is not redrawn N times.
badviolates=(1-float(eps))*N>b
mixturetail=alpha*badviolates+(1-alpha)*wrongtail
assert float(mixturetail)<=float(alpha)+beta/2
result=dict(status='all assertions passed',N=N,conditional_error_bound=str(eps),
 alpha=str(alpha),beta=beta,boundary=b,adaptive_distribution_states=len(law),
 exact_probability_sum=str(sum(law.values())),wrong_tail_exact=str(wrongtail),
 wrong_tail=float(wrongtail),conclusive_tail=float(concltail),
 single_bad_calibration_mixture_tail=float(mixturetail),moments=moments,
 scope='Exact finite adaptive-model checks; universal theorem analytical; no independent future trials assumed')
(OUT/'sequential_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
