"""Finite accepted-count calibration + exact robust reader certificate.
Only numpy, scipy, matplotlib. No uploaded verification code is executed."""
from pathlib import Path
import math,json
import numpy as np
from numpy.linalg import norm,eigvalsh
from scipy.stats import beta,binom
from scipy.optimize import minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(271828)
def cp(k,n,alpha):
 if n==0:return (0.,1.)
 lo=0. if k==0 else float(beta.ppf(alpha/2,k,n-k+1))
 hi=1. if k==n else float(beta.ppf(1-alpha/2,k+1,n-k))
 return lo,hi
def cp_corrupted(kobs,n,kflip,alpha):
 return cp(max(0,kobs-kflip),n,alpha)[0],cp(min(n,kobs+kflip),n,alpha)[1]
def calibrate(records,alpha,gamma,eta_interval):
 NZ,NX=records['NZ'],records['NX']
 nZ,nX=records['nZ'],records['nX']
 Ip=cp_corrupted(records['KZobs'],nZ,records['kZ'],alpha/3)
 Iq=cp_corrupted(records['KXobs'],nX,records['kX'],alpha/3)
 It=(max(-1.,(2*Iq[0]-1)/gamma),min(1.,(2*Iq[1]-1)/gamma))
 Ihit=cp(nZ+nX,NZ+NX,alpha/3)
 eL,eU=eta_interval
 Iw=(max(0.,Ihit[0]/eU),min(1.,Ihit[1]/eL) if eL>0 else 1.)
 return {'Ip':Ip,'It':It,'Ihit':Ihit,'Iw':Iw}
def exact_certificate(Ip,tlo,wlo,Delta,x,y,z):
 """Exact over stated component interval/Bloch-ball/axis class, tlo>=0."""
 assert 0<=tlo<=1 and 0<=Delta<=np.pi/2 and x>=0 and y>=0 and z>=0 and z*z<=x*y+1e-12
 R2=max(0.,1-tlo*tlo);R=np.sqrt(R2)
 lo=max(2*Ip[0]-1,-R);hi=min(2*Ip[1]-1,R)
 if lo>hi+1e-13:raise ValueError('empty physical confidence/drift class')
 d=(x+y)/2;e=(x-y)/2;a=tlo*np.cos(Delta);b=np.sin(Delta)
 Amin=min(d+e*lo,d+e*hi)
 if Amin<=0:raise ValueError('no positive all-state conclusive guarantee')
 def value(u):return (a-b*np.sqrt(max(0.,R2-u*u)))/(d+e*u)
 candidates=[lo,hi]
 if b>1e-14 and R>1e-14:
  A=b*b*d*d+e*e*a*a
  B=2*b*b*d*e*R2
  C=b*b*e*e*R2*R2-e*e*a*a*R2
  if A>1e-28:
   for u in np.roots([A,B,C]):
    if abs(u.imag)>1e-9:continue
    u=float(u.real)
    if lo+1e-12<u<hi-1e-12:
     g=np.sqrt(max(0.,R2-u*u))
     left=b*(d*u+e*R2);right=e*a*g
     if abs(left-right)<1e-8*(1+abs(left)+abs(right)):candidates.append(u)
 vals=[value(u) for u in candidates]
 i=int(np.argmin(vals));contrast=z*vals[i]
 return {'u_interval':[float(lo),float(hi)],'candidate_u':[float(u) for u in candidates],
         'worst_u':float(candidates[i]),'minimum_reader_contrast':float(contrast),
         'worst_conditional_error':float((1-contrast)/2),
         'guaranteed_conclusive':float(wlo*Amin),
         'conditional_conclusive_min':float(Amin)}
# Fixed finite synthetic calibration, explicitly includes every null and adversarial flips.
p0=.8;v0=.98;phase0=.06;t0=2*np.sqrt(p0*(1-p0))*v0*np.cos(phase0)
w0=.93;eta_cal=.85;gamma=.97;alpha=.01
NZ=NX=25000;hit=w0*eta_cal
nZ=int(rng.binomial(NZ,hit));nX=int(rng.binomial(NX,hit))
KZtrue=int(rng.binomial(nZ,p0));KXtrue=int(rng.binomial(nX,(1+gamma*t0)/2))
kZ=kX=10
records={'NZ':NZ,'NX':NX,'nZ':nZ,'nX':nX,'nullZ':NZ-nZ,'nullX':NX-nX,'KZtrue':KZtrue,'KXtrue':KXtrue,
         'KZobs':min(nZ,KZtrue+kZ),'KXobs':min(nX,KXtrue+kX),'kZ':kZ,'kX':kX}
alpha_source=alpha/2;alpha_device=alpha/2
ci=calibrate(records,alpha_source,gamma,(eta_cal,eta_cal))
assert ci['Ip'][0]<=p0<=ci['Ip'][1] and ci['It'][0]<=t0<=ci['It'][1] and ci['Iw'][0]<=w0<=ci['Iw'][1]
dp=.005;dt=.01;dw=.01;Delta=.05
Ip=(max(0.,ci['Ip'][0]-dp),min(1.,ci['Ip'][1]+dp))
tl=ci['It'][0]-dt;assert tl>=0
wl=max(0.,ci['Iw'][0]-dw)
# Choose reader from same calibration data. The confidence event is uniform over this choice.
p_mid=sum(ci['Ip'])/2;eta_reader=.5062765525
ratio=(1-p_mid)/p_mid
x=eta_reader*min(ratio,1.);y=eta_reader*min(1.,1/ratio);z=np.sqrt(x*y)
cert=exact_certificate(Ip,tl,wl,Delta,x,y,z)
u_near=float(np.clip(0.,*cert['u_interval']))
rmax=np.sqrt(1-u_near*u_near);q=tl/rmax
m_cal=q*np.cos(Delta)-np.sqrt(max(0.,1-q*q))*np.sin(Delta)
# Freeze the selected actual apparatus, then calibrate its terminal effects.
# Four trusted probes audit both real and imaginary offdiagonal response.
Nprobe=100000;probe_trace_error=.0005;kprobe=5
phase_device=.018;c_actual=z*np.exp(1j*phase_device)
Axy=(x+y)/2
probabilities={'0':[x/2,x/2,1-x],'1':[y/2,y/2,1-y],
              'X':[(Axy+c_actual.real)/2,(Axy-c_actual.real)/2,1-Axy],
              'Y':[(Axy-c_actual.imag)/2,(Axy+c_actual.imag)/2,1-Axy]}
device_records={}
for label,probs in probabilities.items():
 truecounts=rng.multinomial(Nprobe,probs);observed=truecounts.copy()
 # Label-only corruptions; every null is preserved.
 flips=min(kprobe,int(observed[1])) if label in ['X','Y'] else 0
 observed[0]+=flips;observed[1]-=flips
 device_records[label]={'N':Nprobe,'true_counts':truecounts.tolist(),'observed_counts':observed.tolist(),'flip_budget':flips}
beta_device=alpha_device/6
def widen(interval,e):return max(0.,interval[0]-e),min(1.,interval[1]+e)
Ix=widen(cp(sum(device_records['0']['observed_counts'][:2]),Nprobe,beta_device),probe_trace_error)
Iy=widen(cp(sum(device_records['1']['observed_counts'][:2]),Nprobe,beta_device),probe_trace_error)
Is={}
for label in ['X','Y']:
 cs=device_records[label]['observed_counts'];kk=device_records[label]['flip_budget']
 Is[label]=[widen(cp_corrupted(cs[j],Nprobe,kk,beta_device),probe_trace_error) for j in [0,1]]
Ir=(Is['X'][0][0]-Is['X'][1][1],Is['X'][0][1]-Is['X'][1][0])
Ii=(Is['Y'][1][0]-Is['Y'][0][1],Is['Y'][1][1]-Is['Y'][0][0])
assert Ix[0]<=x<=Ix[1] and Iy[0]<=y<=Iy[1] and Ir[0]<=c_actual.real<=Ir[1] and Ii[0]<=c_actual.imag<=Ii[1]
assert Ir[0]>0
mod_lower=np.hypot(Ir[0],max(Ii[0],0.,-Ii[1]))
angle_upper=np.arctan2(max(abs(Ii[0]),abs(Ii[1])),Ir[0])
dx=dy=.001;dz=.001;dtheta=.01
xL=max(0.,Ix[0]-dx);xU=min(1.,Ix[1]+dx)
yL=max(0.,Iy[0]-dy);yU=min(1.,Iy[1]+dy)
zL=max(0.,mod_lower-dz);Delta_hardware=angle_upper+dtheta
complete_cal=exact_certificate(Ip,tl,wl,Delta_hardware,xU,yU,zL)
umin,umax=complete_cal['u_interval']
qconservative=wl*min((xL+yL)/2+(xL-yL)*umin/2,(xL+yL)/2+(xL-yL)*umax/2)
complete_cal['guaranteed_conclusive']=float(qconservative)
device_result={'alpha_device':alpha_device,'trusted_probe_trace_error_bound':probe_trace_error,'records':device_records,
               'Ix':Ix,'Iy':Iy,'I_Re_c':Ir,'I_Im_c':Ii,'modulus_lower':float(mod_lower),'axis_upper':float(angle_upper),
               'future_coefficient_bounds':{'x':[xL,xU],'y':[yL,yU],'z_lower':float(zL),'axis_upper':float(Delta_hardware)},
               'certificate':complete_cal,'error_corner_PSD_margin':float(xU*yU-zL*zL),
               'success_lower_corner_PSD_margin':float(xL*yL-zL*zL)}
# Test explicit qutrit calibration instruments retain vacuum and every inert reference.
def positive_sqrt(E):
 lam,V=np.linalg.eigh(E);return (V*np.sqrt(np.maximum(lam,0)))@V.conj().T
P=np.diag([0,1,1]).astype(complex);vac=np.diag([1,0,0]).astype(complex)
Xs=np.array([[0,0,0],[0,0,1],[0,1,0]],complex)
cal_effects=[eta_cal*(P+gamma*Xs)/2,eta_cal*(P-gamma*Xs)/2,vac+(1-eta_cal)*P]
cal_K=[positive_sqrt(E) for E in cal_effects]
cal_complete=norm(sum(K.conj().T@K for K in cal_K)-np.eye(3))
assert cal_complete<1e-12
# Construct a pure Bloch state attaining the bound.
u=cert['worst_u'];Y=np.sqrt(max(0.,1-u*u-tl*tl))
X_reader=tl*np.cos(Delta)-Y*np.sin(Delta)
Y_reader=tl*np.sin(Delta)+Y*np.cos(Delta)
state=np.array([[(1+u)/2,(X_reader-1j*Y_reader)/2],[(X_reader+1j*Y_reader)/2,(1-u)/2]])
Eplus=np.array([[x,z],[z,y]])/2;Eminus=np.array([[x,-z],[-z,y]])/2
concl=float(np.trace((Eplus+Eminus)@state).real)
err=float(np.trace(Eminus@state).real/concl)
assert abs(err-cert['worst_conditional_error'])<1e-12 and eigvalsh(state).min()>-1e-12
# Exact quadratic/root method against independent scalar optimization and fine grids.
maxerr=0.;internal=0
for _ in range(1000):
 tl0=float(rng.uniform(.05,.98));RR=np.sqrt(1-tl0*tl0)
 ls=sorted(rng.uniform(-RR,RR,2));ip=((ls[0]+1)/2,(ls[1]+1)/2)
 xx,yy=rng.uniform(.03,.9,2);zz=np.sqrt(xx*yy)*rng.uniform(0,1)
 DD=float(rng.uniform(0,.7))
 cc=exact_certificate(ip,tl0,1.,DD,xx,yy,zz)
 d=(xx+yy)/2;e=(xx-yy)/2;a=tl0*np.cos(DD);b=np.sin(DD)
 f=lambda u:(a-b*np.sqrt(max(0,RR*RR-u*u)))/(d+e*u)
 opt=minimize_scalar(f,bounds=ls,method='bounded',options={'xatol':1e-13})
 gold=min(f(ls[0]),f(ls[1]),opt.fun)
 error=abs(cc['minimum_reader_contrast']-zz*gold);maxerr=max(maxerr,error)
 assert error<2e-9
 internal+=len(cc['candidate_u'])>2
# Analytic CP coverage enumerated on a probability grid, no Monte Carlo used as proof.
coverage=[]
for n in [5,20,100]:
 worst=1.
 for p in np.linspace(.001,.999,301):
  cover=sum(binom.pmf(k,n,p) for k in range(n+1) if cp(k,n,.05)[0]<=p<=cp(k,n,.05)[1])
  worst=min(worst,float(cover))
 assert worst>=.95-1e-12
 coverage.append({'n':n,'minimum_coverage_over_grid':worst})
# Exhaustive deterministic accepted-label corruption containment.
corruption_error=0
for n in [5,10,20]:
 for k in range(n+1):
  base=cp(k,n,.05)
  for flips in range(min(3,n)+1):
   for obs in range(max(0,k-flips),min(n,k+flips)+1):
    envelope=cp_corrupted(obs,n,flips,.05)
    if envelope[0]>base[0]+1e-14 or envelope[1]<base[1]-1e-14:corruption_error+=1
assert corruption_error==0
# Identifiability obstructions.
# Z data alone: equal p=.5 states |+>,|-> give real reader opposite decisions.
# State-dependent loss can make p=.8 and p=.5 have same conditional Z clicks.
loss_bias={'true_p':.8,'efficiency0':.25,'efficiency1':1.,'clicked_conditional_p':(.25*.8)/(.25*.8+1.*.2)}
results={'seed':271828,'status':'All data synthetic; coverage and minimax claims proved in chapter.tex.',
 'true_source':{'p':p0,'visibility':v0,'phase':phase0,'t':t0,'excitation_weight':w0},
 'calibration_contract':{'alpha_global':alpha,'alpha_source':alpha_source,'gamma':gamma,'eta_cal':eta_cal,'stationary_iid_calibration':True,'accepted_label_flip_budget':[kZ,kX]},
 'records':records,'confidence':ci,'drift':{'dp':dp,'dt':dt,'dw':dw,'axis_offset':Delta},
 'future_confidence_class':{'Ip':Ip,'t_lower':tl,'w_lower':wl},
 'data_chosen_reader':{'x':x,'y':y,'z':z,'eta_cap':eta_reader},
 'certificate':cert,'actual_reader_calibration':device_result,'source_calibrator_complete_instrument_error':float(cal_complete),'effective_coherence_interface':{'u_nearest_zero':u_near,'r_max':float(rmax),'q_cal':float(q),'sharp_m_lower':float(m_cal),'separately_multiplied_bound_at_zero_axis_drift':float(q*q),'direct_bound_at_zero_axis_drift':float(q)},'attaining_state':{'Bloch':[X_reader,Y_reader,u],'minimum_eigenvalue':float(eigvalsh(state).min()),'direct_conditional_error':err},
 'root_checks':{'cases':1000,'interior_candidates':internal,'max_contrast_difference_to_scalar_optimization':maxerr},
 'exact_binomial_grid_checks':coverage,'adversarial_corruption_interval_containment_failures':corruption_error,
 'state_dependent_loss_counterexample':loss_bias}
# Calibration error versus phase drift; dependence is exact within confidence class.
DD=np.linspace(0,.25,151)
eps=np.array([exact_certificate(Ip,tl,wl,D,x,y,z)['worst_conditional_error'] for D in DD])
fig,ax=plt.subplots(1,3,figsize=(13.2,3.8),layout='constrained')
plt.rcParams.update({'font.size':10})
uu=np.linspace(-1,1,500);rr=np.sqrt(np.maximum(0,1-uu*uu))
ax[0].plot(uu,rr,color='grey');ax[0].plot(uu,-rr,color='grey')
ax[0].axvspan(2*Ip[0]-1,2*Ip[1]-1,color='C0',alpha=.15)
ax[0].axhspan(tl,1,color='C1',alpha=.15)
ax[0].scatter([u],[tl],c='black',s=28)
ax[0].set(xlabel='population coordinate u',ylabel='calibration-axis contrast t',ylim=(-.1,1.02),title='Two-observable physical confidence set')
ax[1].plot(DD,eps);ax[1].scatter([Delta],[cert['worst_conditional_error']],color='black')
ax[1].set(xlabel='differential phase bound (radians)',ylabel='sharp conditional-error certificate',title='Unknown transverse component is retained')
# An example whose worst point lies strictly inside population interval.
ip=(.1,.9);tl_demo=.6;D_demo=.3
demo=exact_certificate(ip,tl_demo,1.,D_demo,.9,.3,np.sqrt(.27))
uu=np.linspace(*demo['u_interval'],600);d=.6;e=.3
ff=(tl_demo*np.cos(D_demo)-np.sin(D_demo)*np.sqrt(np.maximum(0,1-tl_demo**2-uu*uu)))/(d+e*uu)
ax[2].plot(uu,(1-np.sqrt(.27)*ff)/2)
ax[2].scatter([demo['worst_u']],[demo['worst_conditional_error']],c='black')
ax[2].set(xlabel='population coordinate u',ylabel='conditional error',title='Endpoint-only calibration can fail')
fig.savefig(OUT/'calibration_certificate.png');plt.close(fig)
results['interior_extremum_example']=demo
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'records':records,'confidence':ci,'reader':results['data_chosen_reader'],'certificate':cert,'actual_reader_certificate':complete_cal,'effective_coherence_interface':results['effective_coherence_interface'],'root_checks':results['root_checks'],'coverage':coverage,'interior_example':demo},indent=2))
