"""Independent numerical verification; numpy/scipy/matplotlib. Run python verify.py."""
from pathlib import Path
import json, math
import numpy as np
from numpy.linalg import norm, eigvalsh, matrix_rank
from scipy.optimize import brentq, linprog
from scipy.linalg import expm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(27102026)
def projector(v): return np.outer(v,v.conj())
def random_rho(n):
    a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
    return a@a.conj().T/np.trace(a@a.conj().T)
def chirps(n):
    x=np.arange(n)
    return [np.eye(n,dtype=complex)]+[np.exp(2j*np.pi*(a*x[:,None]**2+x[:,None]*x[None,:])/n)/np.sqrt(n) for a in range(n)]
def phi(n): return sum(math.gcd(k,n)==1 for k in range(1,n+1))
def theory_dim(n): return n+sum(d*phi(d) for d in range(2,n+1) if n%d==0)
def response(alpha):
    q=np.exp(-alpha); eta=-np.expm1(-alpha)
    c=np.log(alpha/eta)/alpha
    m=1-eta*(1+np.log(alpha/eta))/alpha
    if m<=2*q:
        err=m/2; e0=err; e1=eta+err; regime='unconstrained feasible'
    else:
        def peak(t):
            s=1-t
            return s*(1-(1+np.log(alpha/s))/alpha)
        err=brentq(lambda t:peak(t)-t,q,0.5,xtol=5e-15)
        e0=err; e1=1.; regime='effect upper bound active'
    return dict(alpha=float(alpha),eta=float(eta),c_star=float(c),Gamma=float(m),d_hermitian=float(m/2),d_effect=float(err),effect_e0=float(e0),effect_e1=float(e1),regime=regime)
results={'seed':27102026,'status':'Analytic proofs are in chapter.tex. Floating tests are corroboration, not physical verification.'}
rr=[]
for alpha in [.01,.1,np.log(4),2.,2.5,5.,10.,50.]:
    r=response(alpha); c=r['c_star']; eta=r['eta']
    plus=np.array([np.sqrt(c),np.sqrt(1-c)],complex);minus=plus*np.array([1,-1])
    density=(projector(plus)+projector(minus))/2
    gap=-np.expm1(-alpha*c)-eta*c
    x=np.linspace(0,1,40001); h=-np.expm1(-alpha*x)
    line=r['effect_e0']+(r['effect_e1']-r['effect_e0'])*x
    r['witness_density_error']=float(norm(density-np.diag([c,1-c])))
    r['witness_gap_error']=float(abs(gap-r['Gamma']))
    r['max_grid_effect_error']=float(np.max(abs(h-line)))
    x=np.linspace(0,1,3001);y=-np.expm1(-alpha*x)
    A=np.vstack([np.column_stack((-(1-x),-x,-np.ones(len(x)))),np.column_stack(((1-x),x,-np.ones(len(x))))])
    lp=linprog([0,0,1],A_ub=A,b_ub=np.r_[-y,y],bounds=[(0,1),(0,1),(0,None)],method='highs')
    assert lp.success and abs(lp.fun-r['d_effect'])<1e-6
    r['grid_lp_error']=float(lp.fun);r['analytic_LP_difference']=float(abs(lp.fun-r['d_effect']))
    assert r['witness_density_error']<1e-14 and abs(gap-r['Gamma'])<2e-13
    rr.append(r)
results['saturating_overlap']=rr
rows=[];maxerr=0.
for n in [3,5,7,9,11,15,21]:
    bases=chirps(n)
    for a in range(n):
      for ap in range(n):
        g=math.gcd(a-ap,n)
        actual=abs(bases[a+1].conj().T@bases[ap+1])**2
        expected=np.fromfunction(lambda b,bp:np.where((bp-b)%g==0,g/n,0.),(n,n))
        maxerr=max(maxerr,float(np.max(abs(actual-expected))))
    ps=[projector(b[:,k]).reshape(-1) for b in bases for k in range(n)]
    rank=matrix_rank(np.stack(ps,axis=1),tol=1e-9);expected=theory_dim(n)
    assert rank==expected
    row={'N':n,'span_dimension':int(rank),'formula_dimension':expected,'full_dimension':n*n,'deficit':n*n-expected}
    if any(n%d==0 for d in range(2,math.isqrt(n)+1)):
      h=next(h for h in range(1,n) if math.gcd(h,n)>1);v=1
      w=np.zeros((n,n),complex)
      for y in range(n):w[(y+h)%n,y]=np.exp(2j*np.pi*v*y/n)
      delta=(w+w.conj().T)/2
      rp=(np.eye(n)+delta)/n;rm=(np.eye(n)-delta)/n
      probs=lambda rho:np.array([np.vdot(b[:,k],rho@b[:,k]).real for b in bases for k in range(n)])
      e=(np.eye(n)+delta)/2
      readoutgap=float(np.max(abs(probs(rp)-probs(rm))));targetgap=float(np.trace(e@(rp-rm)).real)
      row.update(h=h,v=v,min_state_eigenvalue=float(min(eigvalsh(rp).min(),eigvalsh(rm).min())),readout_gap=readoutgap,target_gap=targetgap)
      inputdist=float(np.sum(np.abs(eigvalsh(delta)))/n)
      row.update(input_trace_distance=inputdist,retained_null_source_trace_distance_at_alpha_1_7=float(np.exp(-1.7)*inputdist))
      assert readoutgap<1e-12 and abs(targetgap-.5)<1e-12
    rows.append(row)
results['quadratic_banks']=rows;results['max_Gram_probability_error']=maxerr
# Construct all missing Hermitian Weyl effects; verify exact binary completion ranks.
completion=[]
for n in [9,15]:
    bases=chirps(n)
    columns=[projector(b[:,k]).reshape(-1) for b in bases for k in range(n)]
    missing={(h,v) for h in range(1,n) for v in range(n) if v%math.gcd(h,n)}
    visited=set(); additions=[];mineig=1.
    for h,v in sorted(missing):
        if (h,v) in visited:continue
        visited.add((h,v));visited.add(((-h)%n,(-v)%n))
        w=np.zeros((n,n),complex)
        for y in range(n):w[(y+h)%n,y]=np.exp(2j*np.pi*v*y/n)
        for delta in [(w+w.conj().T)/2,(w-w.conj().T)/(2j)]:
            e=(np.eye(n)+delta)/2
            mineig=min(mineig,float(eigvalsh(e).min()),float(eigvalsh(np.eye(n)-e).min()))
            additions.append(e.reshape(-1))
    rank=matrix_rank(np.stack(columns+additions,axis=1),tol=1e-9)
    assert rank==n*n and len(additions)==n*n-theory_dim(n) and mineig>-1e-12
    completion.append({'N':n,'binary_additions':len(additions),'completed_rank':int(rank),'minimum_effect_or_complement_eigenvalue':mineig})
results['binary_completion']=completion
tomo=[]
for p in [3,5,7,11]:
    bases=chirps(p);rho=random_rho(p)
    probs=np.array([[np.vdot(b[:,k],rho@b[:,k]).real for k in range(p)] for b in bases])
    rec=sum(probs[j,k]*projector(b[:,k]) for j,b in enumerate(bases) for k in range(p))-np.eye(p)
    noise=rng.normal(scale=.002,size=probs.shape);noise-=noise.mean(axis=1,keepdims=True)
    delta=sum(noise[j,k]*projector(b[:,k]) for j,b in enumerate(bases) for k in range(p))
    hs=float(norm(delta,'fro')**2);coef=float(np.sum(noise**2))
    risk=float(sum(1-np.sum(z*z) for z in probs));theory=float(p-np.trace(rho@rho).real)
    assert norm(rec-rho)<1e-11 and abs(hs-coef)<1e-12 and abs(risk-theory)<1e-11
    tomo.append({'p':p,'inversion_HS_error':float(norm(rec-rho)),'HS_squared_error':hs,'squared_probability_error_sum':coef,'n_times_exact_HS_risk':risk,'p_minus_purity':theory})
results['prime_tomography']=tomo
n=5;m=7;T=1.3
rs=[]
for j in range(m):
    v=rng.normal(size=n)+1j*rng.normal(size=n);rs.append(v/norm(v))
rates=rng.uniform(.1,.8,m);S=sum(rate*projector(v) for rate,v in zip(rates,rs))
lam,U=np.linalg.eigh(S);effects=[]
for rate,v in zip(rates,rs):
    B=U.conj().T@(rate*projector(v))@U
    pair=lam[:,None]+lam[None,:]
    factor=np.where(abs(pair)>1e-12,2*(-np.expm1(-T*pair/2))/np.where(abs(pair)>1e-12,pair,1),T)
    effects.append(U@(B*factor)@U.conj().T)
E0=expm(-T*S);complete=float(norm(E0+sum(effects)-np.eye(n)))
assert complete<1e-12
p=5;alpha=1.7;eta=-np.expm1(-alpha);bases=chirps(p);weight=1/(p+1)
rho=random_rho(p*3);branches=[]
for b in bases:
 for k in range(p):
    bra=np.kron(b[:,k].conj()[None,:],np.eye(3))
    branches.append(eta*weight*bra@rho@bra.conj().T)
null=np.exp(-alpha)*rho
traces=sum(np.trace(z).real for z in branches)+np.trace(null).real
assert abs(traces-1)<1e-12
results['instruments']={'general_bank_completeness_error':complete,'general_bank_min_effect_eigenvalue':float(min(eigvalsh(x).min() for x in effects)),'tight_source_dimension':p,'retained_reference_dimension':3,'tight_branch_total_trace':float(traces),'tight_null_probability':float(np.trace(null).real),'predicted_null_probability':float(np.exp(-alpha))}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
fig,ax=plt.subplots(1,3,figsize=(13,3.8),layout='constrained')
x=np.linspace(0,1,500);alpha=np.log(4);r=response(alpha)
ax[0].plot(x,-np.expm1(-alpha*x),label='state-dependent saturation')
ax[0].plot(x,r['eta']*x,label='physical one-copy reader')
ax[0].plot(x,r['effect_e0']+(r['effect_e1']-r['effect_e0'])*x,'--',label='closest single-copy effect')
ax[0].vlines(r['c_star'],r['eta']*r['c_star'],-np.expm1(-alpha*r['c_star']),color='k',lw=1)
ax[0].set(xlabel='overlap c',ylabel='click probability',title='Finite-time exponent placement');ax[0].legend(fontsize=8)
ns=[z['N'] for z in rows]
ax[1].plot(ns,[z['full_dimension'] for z in rows],'o-',label='full operator space')
ax[1].plot(ns,[z['span_dimension'] for z in rows],'s-',label='all quadratic chirps + positions')
ax[1].set(xlabel='odd modulus N',ylabel='real operator dimensions',title='Composite banks retain blind directions');ax[1].legend(fontsize=8)
aa=np.logspace(-2,1.7,250);rx=[response(a) for a in aa]
ax[2].semilogx(aa,[z['Gamma'] for z in rx],label='exact ensemble gap')
ax[2].semilogx(aa,[z['d_effect'] for z in rx],label='best effect uniform error')
ax[2].set(xlabel=r'$\alpha=\kappa T$',ylabel='probability difference',title='Sharp mismatch calibration');ax[2].legend(fontsize=8)
fig.savefig(OUT/'matched_reader_results.png');plt.close(fig)
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'response_log4':rr[2],'dimensions':rows,'max_Gram_error':maxerr,'instrument':results['instruments']},indent=2))
