"""Source-product reader checks; Python 3 standard library only."""
from fractions import Fraction as F
from math import exp, factorial
import json
from pathlib import Path
# A=B=|0><0|. Two pure-state ensembles have the same density I/2.
z_ensemble=sum(F(1,2)*q*q for q in [F(1),F(0)])
x_ensemble=sum(F(1,2)*q*q for q in [F(1,2),F(1,2)])
assert z_ensemble==F(1,2) and x_ensemble==F(1,4)
eta=F(1,10); x=F(3,5); y=F(2,5); p_product=x*y
first=float(eta*p_product); source=-__import__('math').expm1(-first)
assert 0<=first-source<=float(eta*eta/2)
# Poisson OR protocol at eta=.8, x=.6,y=.4, budget m=6 tests.
eta_p=.8; p=.24; m=6
weights=[exp(-eta_p)*eta_p**n/factorial(n) for n in range(80)]
click=sum(weights[n]*(1-(1-p)**n) for n in range(80))
expected=1-exp(-eta_p*p)
assert abs(click-expected)<1e-14
loss=1-sum(weights[:m+1]); truncated=sum(weights[n]*(1-(1-p)**n) for n in range(m+1))
chernoff=(exp(1)*eta_p/(m+1))**(m+1)*exp(-eta_p)
assert expected-truncated<=loss+1e-15 and loss<=chernoff
# Finite-difference obstruction: 1-exp(-eta p^2) is nonpolynomial analytically;
# these are illustrative unequal fourth differences, not the universal proof.
f=lambda t:1-exp(-.8*t*t)
rows=[]
for start in [0,.2,.4]:
 vals=[f(start+.05*j) for j in range(5)]
 rows.append(sum((-1)**(4-j)*__import__('math').comb(4,j)*vals[j] for j in range(5)))
out={'ensemble_same_density':'I/2','z_ensemble_rate':str(z_ensemble),'x_ensemble_rate':str(x_ensemble),
     'small_frame':{'eta':str(eta),'x':str(x),'y':str(y),'two_copy_probability':first,'source_exponential':source,'defect':first-source,'uniform_defect_bound':float(eta*eta/2)},
     'poisson_protocol':{'eta':eta_p,'x_y_product':p,'expected_copies':2*eta_p,'max_tests':m,'max_copies':2*m,'exact_click':expected,'summed_click':click,'truncated_click':truncated,'retained_stock_loss':loss,'chernoff_tail_bound':chernoff},
     'illustrative_fourth_differences':rows,'proof_status':'Universal obstructions and Poisson identity analytic; computation corroborates numeric examples.'}
pth=Path(__file__).with_name('product_reader_results.json');pth.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
