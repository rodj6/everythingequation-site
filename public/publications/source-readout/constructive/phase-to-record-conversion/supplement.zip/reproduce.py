"""Check source hashes or replay selected Paper 2 verifiers in disposable directories.

Examples: python reproduce.py --check-only
          python reproduce.py --output replay_new
          python reproduce.py --only 02_verify_operational.py --output replay_one
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / 'supplement/operational'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--only', action='append', help='Exact filename; may repeat')
    parser.add_argument('--output', type=Path, help='New or empty destination directory')
    args = parser.parse_args()
    jobs = json.loads((SOURCES / 'manifest.json').read_text())
    jobs += json.loads((ROOT / 'supplement/additional_checks.json').read_text())
    files = {}
    imports = set()
    for job in jobs:
        f = (ROOT / job['relative_path']) if 'relative_path' in job else SOURCES / job['copy']
        assert f.is_file(), f
        assert hashlib.sha256(f.read_bytes()).hexdigest() == job['sha256'], f'Hash mismatch: {f.name}'
        tree = ast.parse(f.read_text(), filename=str(f))
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                imports.update(x.name.split('.')[0] for x in n.names)
            elif isinstance(n, ast.ImportFrom) and n.module:
                imports.add(n.module.split('.')[0])
        files[job['copy']] = (f, job)
    missing = sorted(x for x in imports if importlib.util.find_spec(x) is None)
    if missing:
        raise SystemExit('Missing dependencies: ' + ', '.join(missing))
    chosen = args.only or list(files)
    if len(chosen) != len(set(chosen)):
        raise SystemExit('Duplicate --only filenames are not permitted')
    if any(n not in files for n in chosen):
        raise SystemExit('Unknown filename in --only')
    if args.check_only:
        print(json.dumps({'status': 'PASS', 'source_hashes': len(files),
                          'imports_available': sorted(imports)}, indent=2))
        return
    if args.output is None:
        raise SystemExit('Use --output with a new or empty destination')
    out = args.output.resolve()
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise SystemExit('Output must be new or empty; no existing evidence will be replaced')
    out.mkdir(parents=True, exist_ok=True)
    receipts = []
    for name in chosen:
        f, job = files[name]
        dest = out / f.stem
        dest.mkdir()
        with tempfile.TemporaryDirectory(prefix='paper2_replay_') as tmp:
            work = Path(tmp)
            shutil.copy2(f, work / name)
            env = dict(os.environ, MPLBACKEND='Agg', PYTHONDONTWRITEBYTECODE='1')
            start = time.perf_counter()
            result = subprocess.run([sys.executable, name], cwd=work, env=env,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            (dest / 'stdout.log').write_text(result.stdout)
            (dest / 'stderr.log').write_text(result.stderr)
            products = []
            for output in sorted(work.iterdir()):
                if output.is_file() and output.name != name:
                    shutil.copy2(output, dest / output.name)
                    products.append({'filename': output.name, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest()})
            receipt = dict(source=name, source_sha256=job['sha256'],
                           returncode=result.returncode, elapsed_seconds=time.perf_counter()-start,
                           stderr_empty=not result.stderr, outputs=products)
            receipts.append(receipt)
            (out / 'receipts.json').write_text(json.dumps(receipts, indent=2))
            print(name + ': ' + ('PASS' if result.returncode == 0 else 'FAIL'), flush=True)
            if result.returncode:
                raise SystemExit(result.returncode)
    print('Replay complete. Computational checks corroborate scoped claims; they do not replace proofs.')

if __name__ == '__main__':
    main()
