"""Build the reviewed certification manuscript in disposable directories; requires pdflatex and bibtex."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
TARGETS = [('main_certification', 'Paper4_Certification_and_Retained_Records_Reviewed_v1')]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--logs-dir', type=Path)
    args = p.parse_args()
    if args.logs_dir:
        args.logs_dir.mkdir(parents=True, exist_ok=True)
    for source, name in TARGETS:
        with tempfile.TemporaryDirectory(prefix='paper4_build_') as tmp:
            work = Path(tmp)
            shutil.copytree(ROOT / 'latex', work, dirs_exist_ok=True)
            commands = [['pdflatex', '-interaction=nonstopmode', '-halt-on-error', '-jobname=' + name, source + '.tex'],
                        ['bibtex', name]]
            commands += [commands[0]] * 2
            transcript = []
            for cmd in commands:
                r = subprocess.run(cmd, cwd=work, text=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
                transcript.append(r.stdout)
                if r.returncode:
                    print(r.stdout)
                    raise SystemExit(r.returncode)
            if args.logs_dir:
                (args.logs_dir / (name + '.build.log')).write_text('\n'.join(transcript))
                shutil.copy2(work / (name + '.log'), args.logs_dir / (name + '.tex.log'))
                shutil.copy2(work / (name + '.bbl'), args.logs_dir / (name + '.bbl'))
            shutil.copy2(work / (name + '.pdf'), ROOT / (name + '.pdf'))
            print(name + '.pdf', flush=True)

if __name__ == '__main__':
    main()
