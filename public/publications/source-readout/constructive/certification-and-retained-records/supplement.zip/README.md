# Reviewed Paper 4: certification and retained reader records

**Certification Resources and the Value of Retained Quantum-Reader Records**. Author: Jeremy Rodgers, Independent Researcher, https://www.everythingequation.com.

This reviewed version preserves the central theorems and numerical resource bounds. It clarifies conditioning, ancillary-law scopes, parameter domains and exact-versus-approximate arithmetic; corrects source paths and citations; and restores omitted appendix checks. This is a theoretical scientific draft with within-workflow proof and certificate checking, not external peer review or empirical validation.

## Contents

- The readable manuscript PDF.
- `latex/main_certification.tex`, six section files and the manuscript-specific bibliography.
- `supplement/readers/`: unchanged original verification sources, policy/input data, hash manifest, scoped jobs and generated-input dependencies.
- `supplement/readers/independent/check_strict_bernstein.py`: a separate exact check of the strict coefficient inequalities used in the manuscript.
- `supplement/reviewed_outputs/`: representative regenerated results and verification summaries.
- `supplement/EVIDENCE_GUIDE.md`: evidence classes, guarantee boundaries and reproduction details.
- `build.py` and `reproduce.py`: portable build and verification entry points.

Stable code locators retain their original `research11`/`research12` directory names. These locators do not organize the scientific argument or create new findings.

## Rebuild the PDF

Use a TeX installation containing `pdflatex`, `bibtex`, Latin Modern, AMS packages, `microtype`, `mathtools`, `geometry`, `booktabs`, `longtable`, `array`, `enumitem`, `graphicx`, `xcolor`, `xurl`, `natbib` and `hyperref`:

```bash
python build.py
```

The build works in a disposable source copy and writes the PDF here. `--logs-dir PATH` optionally saves build logs and resolved references. Editable sources remain unchanged.

## Reproduce the checks

Python 3.10 or later, standard library only. Keep assertions enabled: **do not use `python -O`**. Tested environment: Python 3.12.14.

```bash
python reproduce.py --check
python reproduce.py --output replay_new
```

`--check` verifies all 23 source/data hashes, Python syntax, local-module closure, the fifteen job paths and their producer dependencies without running mathematical calculations. Full replay expands copies in a disposable tree, executes the jobs in the declared order and saves separate logs, receipts, per-job snapshots and final generated products. Existing nonempty output directories are preserved. Full replay takes roughly a minute, depending on the computer.

Selected jobs automatically include their required producers. For a short check:

```bash
python reproduce.py --only independent/check_strict_bernstein.py --output replay_strict
```

This first regenerates the Bernstein intervals, then checks all fourteen adjacent gaps strictly. A dependent tube check can likewise be selected directly; its rich-response producer is included automatically.

The job list contains ten original certification checks, four recovered terminal/resource checks and one independent strictness check. The public minimal package was replayed end to end: all fifteen jobs passed. The exact-derived `research11/nominal/results.json` is a declared, hashed input from the reviewed Paper 3 certificate; it is not advertised as newly generated here. Direct trajectory checks independently evaluate the same frozen policy. No external solver, network, experimental device or paused campaign job is used.

The inherited `record_information.py` docstring mentions a `--policy` option that it does not implement. The declared job uses no such option. Actual policy verification is performed by the supplied trajectory/policy checkers; the seed script verifies its specified information-projection example.

## What is established

The manuscript separates three validation tasks: unrestricted terminal-error observations, trusted-seed observations, and complete classical trajectories under a shared visibility family. Their resource minima differ.

For the specified frozen fourteen-copy reader and the shared-response family, a readable-record gate has false-certificate probability at most `2^-20`, nominal acceptance probability at least 0.95 and a deterministic cap of **720,160 source copies**. Every terminal-only validator with the same family promise and nominal power requirement needs **more than 1,992,371 copies in expectation**. The exact-nominal uncapped readable gate has expected consumption below **254,746 copies**. These are conditional mathematical resource results, not measured costs or universal calibration minima.

Expected stopping cost, finite-cap power, false-certificate size and conditional-on-acceptance deployment risk are different guarantees. The finite cap assumes independent exact nominal complete experiments. It is not transferred to the correlated response tube. Acceptance conditioning retains the stated failure-probability allowance.

All readable validation data here are classical records of a quantum reader. Extra quantum-output access is not granted. The preparation controller remains unavailable to the reader, while the trusted evaluator may know its validation label. Conditional source/device and tube promises must hold on the stated augmented mathematical past. Fresh uniform reader seeds are assumed for the structured four-state comparison; unrestricted-record and general trusted-seed models have their own ancillary-law contracts.

Ordinary Born probabilities, trusted preparations, the response family and deployment stability remain assumptions. Source stock, arithmetic, controllers, reference preparation, archive access, resets and timing are distinct costs. No universal hardware, energy, thermodynamic, consciousness or unique-ontology claim follows.
