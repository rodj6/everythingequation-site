"""Frozen-policy intersection--union validation with exact risk certificates.

Each observation is the terminal error of one complete B-copy experiment.
Nulls, settings and controller seeds remain in the retained experiment archive.
No detector response curve or residual quantum instrument is identified.
"""
from fractions import Fraction as F
from math import comb
from functools import lru_cache

def floor_fraction(x):return x.numerator//x.denominator
def ceil_fraction(x):return -((-x.numerator)//x.denominator)

def binomial_cdf_interval(n,c,p,bits=80):
    """Exact integer binomial sum followed by outward dyadic division."""
    p=F(p)
    if type(n)is not int or n<0 or type(c)is not int or not 0<=p<=1:raise ValueError('physical binomial inputs')
    if c<0:return F(0),F(0)
    if c>=n:return F(1),F(1)
    if p==0:return F(1),F(1)
    if p==1:return F(0),F(0)
    a,d=p.numerator,p.denominator;b=d-a
    term=b**n;total=term
    for j in range(c):
        numerator=term*(n-j)*a;denominator=(j+1)*b
        term,remainder=divmod(numerator,denominator)
        assert remainder==0
        total+=term
    den=d**n;scale=1<<bits;q,r=divmod(total*scale,den)
    return F(q,scale),F(q+(r!=0),scale)

def _log_series(x,tol):
    z=(x-1)/(x+1);a=abs(z)
    if not a:return F(0),F(0)
    total=F(0);power=a;index=0
    while True:
        total+=2*power/(2*index+1);index+=1;power*=a*a
        tail=2*power/((2*index+1)*(1-a*a))
        if tail<=tol:break
    return (total,total+tail)if z>0 else(-total-tail,-total)

@lru_cache(None)
def log_interval(x,bits=100):
    """Rational outward log enclosure, with exact power-of-two reduction."""
    x=F(x)
    if x<=0:raise ValueError('positive logarithm argument')
    exponent=x.numerator.bit_length()-x.denominator.bit_length()
    unit=F(1<<exponent)if exponent>=0 else F(1,1<<(-exponent))
    y=x/unit
    if y<1:exponent-=1;y*=2
    if y>=2:exponent+=1;y/=2
    assert 1<=y<2
    tol=F(1,(1<<(bits+8))*(abs(exponent)+1))
    a,b=_log_series(y,tol);c,d=_log_series(F(2),tol)
    if exponent>=0:lo,hi=a+exponent*c,b+exponent*d
    else:lo,hi=a+exponent*d,b+exponent*c
    scale=1<<bits
    return F(floor_fraction(lo*scale),scale),F(ceil_fraction(hi*scale),scale)

def sequential_budget(p0=F(887,100000),epsilon=F(1,100),alpha=F(1,2**20),labels=4,copies=14):
    p0,epsilon,alpha=map(F,(p0,epsilon,alpha))
    if not 0<p0<epsilon<1 or not 0<alpha<1:raise ValueError('strict testing interior')
    error=log_interval(p0/epsilon);correct=log_interval((1-p0)/(1-epsilon));threshold=log_interval(1/alpha)
    drift=(p0*error[0]+(1-p0)*correct[0],p0*error[1]+(1-p0)*correct[1])
    assert drift[0]>0
    upper=(threshold[1]+correct[1])/drift[0]
    return {'p0':p0,'epsilon':epsilon,'alpha':alpha,'log_error_ratio':error,
      'log_correct_ratio':correct,'log_threshold':threshold,'drift':drift,
      'expected_experiments_per_label_upper':upper,
      'expected_total_experiments_upper':labels*upper,
      'expected_source_copies_upper':labels*copies*upper,
      'expected_source_copies_integer_upper':ceil_fraction(labels*copies*upper)}

def lr_crossed(n,s,p0,epsilon,alpha):
    """Exact LR threshold decision using short logarithm enclosures first."""
    p0,epsilon,alpha=map(F,(p0,epsilon,alpha))
    if not 0<=s<=n or not 0<p0<epsilon<1 or not 0<alpha<1:raise ValueError('valid LR state')
    a=log_interval(p0/epsilon);b=log_interval((1-p0)/(1-epsilon));t=log_interval(1/alpha)
    low=s*a[0]+(n-s)*b[0];high=s*a[1]+(n-s)*b[1]
    if low>=t[1]:return True
    if high<t[0]:return False
    # Only an exceptionally close comparison pays for the exact giant powers.
    r=p0/epsilon;q=(1-p0)/(1-epsilon)
    numerator=alpha.numerator*r.numerator**s*q.numerator**(n-s)
    denominator=alpha.denominator*r.denominator**s*q.denominator**(n-s)
    return numerator>=denominator

class SequentialGate:
    def __init__(self,labels=('X+','X-','Y+','Y-'),p0=F(887,100000),epsilon=F(1,100),alpha=F(1,2**20)):
        self.p0,self.epsilon,self.alpha=map(F,(p0,epsilon,alpha))
        sequential_budget(self.p0,self.epsilon,self.alpha)
        if len(set(labels))!=len(labels)or not labels:raise ValueError('distinct trusted labels')
        self.rows={h:{'n':0,'errors':0,'accepted':False}for h in labels}
    def observe(self,label,terminal_error):
        if type(terminal_error)is not bool:raise ValueError('one complete experiment terminal error required')
        r=self.rows[label]
        if r['accepted']:raise ValueError('stop querying an already accepted label')
        r['n']+=1;r['errors']+=int(terminal_error)
        r['accepted']=lr_crossed(r['n'],r['errors'],self.p0,self.epsilon,self.alpha)
        return self.accepted
    @property
    def accepted(self):return all(r['accepted']for r in self.rows.values())

def zero_error_minimum(epsilon=F(1,100),alpha=F(1,2**20)):
    epsilon,alpha=F(epsilon),F(alpha)
    n=0;p=F(1)
    while p>alpha:n+=1;p*=1-epsilon
    assert (1-epsilon)**n<=alpha
    if n:assert (1-epsilon)**(n-1)>alpha
    return n
