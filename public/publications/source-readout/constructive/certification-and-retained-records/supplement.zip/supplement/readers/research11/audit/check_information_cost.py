"""Independent rational logarithms and labelled-test KL cost audit."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))

def logs(x,terms=110):
    # Independent range reduction by3/2, not producer's powers of2.
    x=F(x);k=0
    if x<=0:raise ValueError('positive log argument')
    while x>=F(3,2):x*=F(2,3);k+=1
    while x<1:x*=F(3,2);k-=1
    def series(q):
        z=(q-1)/(q+1);s=F(0)
        for j in range(terms):s+=2*z**(2*j+1)/(2*j+1)
        tail=2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
        return s,s+tail
    a,b=series(x);l,u=series(F(3,2))
    return(a+k*l,b+k*u)if k>=0 else(a+k*u,b+k*l)

def kl(p,q):
    lo=hi=F(0)
    for a,b in [(p,q),(1-p,1-q)]:
        if a:
            l,u=logs(a/b);lo+=a*l;hi+=a*u
    return lo,hi

def main():
    from research11.root.kl_cost import log_bounds,kl_bounds,cost_certificate
    rng=random.Random(11083);lc=kc=0
    vals=[F(1),F(2),F(1,2),F(3,2),F(1,2**20),F(887,1000),F(999113,990000)]
    vals+=[F(rng.randrange(1,1000000),rng.randrange(1,1000000))for _ in range(50)]
    with localcontext()as ctx:
        ctx.prec=130
        for x in vals:
            l,u=log_bounds(x);a,b=logs(x)
            assert l<=a<=b<=u,(x,l,a,b,u)
            ref=(Decimal(x.numerator)/Decimal(x.denominator)).ln()
            # Decimal input division/log round; this is only a sanity comparison.
            tolerance=Decimal('1e-120')
            assert Decimal(l.numerator)/Decimal(l.denominator)-tolerance<=ref<=Decimal(u.numerator)/Decimal(u.denominator)+tolerance
            lc+=1
    for p in [F(0),F(1,1000),F(887,100000),F(1,100),F(1,5),F(19,20),F(1)]:
        for q in [F(1,2**20),F(1,100),F(1,2),F(99,100)]:
            a,b=kl(p,q);l,u=kl_bounds(p,q)
            assert l<=max(F(0),a)<=max(F(0),b)<=u;kc+=1
    c=cost_certificate();lo,hi=map(F,c['expected_experiments_per_label_lower_interval'])
    a,b=kl(F(19,20),F(1,2**20));d,e=kl(F(887,100000),F(1,100))
    assert lo<=a/e<=b/d<=hi
    copies=56*lo;assert copies>10_800_000
    # Binary data processing monotonicity on separated event probabilities.
    checks=0
    for p in [F(19,20),F(97,100),F(99,100)]:
        for q in [F(1,2**20),F(1,2**21),F(1,2**22)]:
            l,u=kl(p,q);assert l>=a;checks+=1
    out={'status':'PASS','independent_log_enclosures':lc,'independent_KL_enclosures':kc,
         'event_probability_monotonicity_checks':checks,'certified_expected_source_copy_lower':str(copies),
         'display_expected_source_copy_lower':float(copies),
         'scope':'Terminal Bernoulli trusted-label validation with unrestricted one-bad-label alternatives, finite expected query counts and valid acceptance-power promise; not all physical calibration.'}
    Path(__file__).with_name('information_cost_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
