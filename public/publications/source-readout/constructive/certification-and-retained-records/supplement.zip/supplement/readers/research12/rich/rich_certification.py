"""Exact directed certificates for structured full-record reader validation.
Known eta=4/5, unknown shared v, trusted sinusoidal response and stable stock.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys,shutil
BASE=Path(__file__).resolve().parent
# Reviewed local proof helpers are copied beside this file for replay.
from calibration_gate import log_interval,sequential_budget
from policy_certificate import verify

def kl_action(d,h,v0=F(9,10),vc=F(89,100),eta=F(4,5)):
    c,s=map(F,d);x=abs((c,-c,s,-s)[h]);p=(1+v0*x)/2;q=(1+vc*x)/2
    a=log_interval(p/q);b=log_interval((1-p)/(1-q))
    return tuple(eta*(p*a[i]+(1-p)*b[i])for i in(0,1))

def drift(cert):
    """Nominal exact expected KL and all-good path-min lower drift per experiment."""
    ds=cert['directions'];eta=F(4,5);v0=F(9,10)
    kls=[[kl_action(d,h)for h in range(4)]for d in ds]
    prev=[[(F(0),F(0),F(0))for h in range(4)]for n in cert['levels'][0]]
    for nodes in cert['levels'][1:]:
        now=[]
        for n in nodes:
            a=n['action'];ch=n['children'];c,s=map(F,ds[a]);row=[]
            for h,x in enumerate((c,-c,s,-s)):
                K=(eta*(1+v0*x)/2,eta*(1-v0*x)/2,1-eta)
                lo=kls[a][h][0]+sum(K[o]*prev[ch[o]][h][0]for o in range(3))
                hi=kls[a][h][1]+sum(K[o]*prev[ch[o]][h][1]for o in range(3))
                # For any v >= v0 local LR drift >= nominal local KL; any future
                # branch expected accumulated drift >= minimum of child guarantees.
                pm=kls[a][h][0]+min(prev[j][h][2]for j in ch)
                row.append((lo,hi,pm))
            now.append(row)
        prev=now
    root=prev[cert['root']]
    return tuple(sum(r[i]for r in root)/4 for i in range(3)),root

def misspecified_drift(cert,zeta=F(1,10**6)):
    eta=F(4,5);v0=F(9,10);vc=F(89,100)
    prev=[[F(0)for h in range(4)]for n in cert['levels'][0]]
    for nodes in cert['levels'][1:]:
        now=[]
        for n in nodes:
            c,s=map(F,cert['directions'][n['action']]);ch=n['children'];row=[]
            for h,x in enumerate((c,-c,s,-s)):
                xx=abs(x);fp=(1+v0*xx)/(1+vc*xx);fm=(1-v0*xx)/(1-vc*xx)
                osc=fp-fm;norm=1+zeta*osc
                logosc=log_interval(fp)[1]-log_interval(fm)[0]
                penalty=zeta*logosc+log_interval(norm)[1]
                kl=kl_action(cert['directions'][n['action']],h)[0]
                K=(eta*(1+v0*x)/2,eta*(1-v0*x)/2,1-eta)
                W=[prev[j][h]for j in ch]
                row.append(kl-penalty+sum(K[o]*W[o]for o in range(3))-zeta*(max(W)-min(W)))
            now.append(row)
        prev=now
    return sum(prev[cert['root']])/4

def risk_cover(cert,steps=1100):
    old=cert['visibility'];maxu=F(0);values=[]
    for j in range(steps+1):
        v=F(89,100)+F(11*j,100*steps);cert['visibility']=str(v)
        out=verify(cert,bits=70);u=F(out['symmetrized_worst_error_interval'][1]);maxu=max(maxu,u)
        values.append(float(u))
    cert['visibility']=old
    # Adaptive distribution TV telescopes, each local kernel distance <=eta dv/2.
    margin=F(cert['horizon'])*F(4,5)*F(11,100*steps)/4
    return {'grid_points':steps+1,'step':str(F(11,100*steps)),
      'largest_grid_risk_upper':str(maxu),'uniform_risk_upper':str(maxu+margin),
      'lipschitz_allowance':str(margin),'risk_display':float(maxu+margin),
      'all_grid_risk_displays':values}

def main():
    cert=json.loads((BASE/'policy_14.json').read_text())
    risk=risk_cover(cert)
    assert F(risk['uniform_risk_upper'])<F(1,100)
    D,roots=drift(cert);A=log_interval(F(2**20));b=14*log_interval(F(190,189))[1]
    nominal_upper=14*(A[1]+b)/D[0]
    allgood_upper=14*(A[1]+b)/D[2]
    zeta=F(1,10**6);missD=misspecified_drift(cert,zeta);assert missD>0
    missU=14*(A[1]+b)/missD
    assert F(risk['uniform_risk_upper'])+14*zeta<F(1,100)
    term=sequential_budget(p0=F(875,100000))['expected_source_copies_upper']
    cert['visibility']='9/10'; good=verify(cert,bits=100)['symmetrized_worst_error_interval']
    cert['visibility']='177/200'; bad=verify(cert,bits=100)['symmetrized_worst_error_interval']
    pg=F(good[0]);pb=F(bad[1]);assert F(bad[0])>F(1,100) and pg<pb
    log1=log_interval(pg/pb);log0=log_interval((1-pg)/(1-pb))
    divergence_upper=pg*log1[1]+(1-pg)*log0[1]
    structured_terminal_lower=14*A[0]/divergence_upper
    power=F(19,20);alpha=F(1,2**20)
    log1=log_interval(power/alpha);log0=log_interval((1-power)/(1-alpha))
    numerator_lower=power*log1[0]+(1-power)*log0[0]
    structured_terminal_lower95=14*numerator_lower/divergence_upper
    assert nominal_upper<structured_terminal_lower

    result={'status':'PASS','interface':'Full record, trusted eta=.8 shared sinusoidal response with unknown fixed v; independent fresh stock; root seeds fresh uniform.',
      'v_certification_floor':'89/100','good_visibility':'9/10',
      'risk_cover':risk,'nominal_KL_interval':list(map(str,D[:2])),
      'uniform_good_drift_lower':str(D[2]),'nominal_KL_display':float(D[0]),
      'nominal_expected_source_upper':str(nominal_upper),'nominal_expected_source_upper_display':float(nominal_upper),
      'all_v_ge_point9_expected_source_upper':str(allgood_upper),'all_v_ge_point9_expected_source_upper_display':float(allgood_upper),
      'terminal_only_previous_upper_display':float(term),
      'misspecification':{'per_trial_TV':str(zeta),'risk_uniform_upper':str(F(risk['uniform_risk_upper'])+14*zeta),'nominal_visibility_robust_drift_lower':str(missD),'expected_source_upper':str(missU),'expected_source_upper_display':float(missU)},
      'nominal_stock_ratio':float(nominal_upper/term),
      'same_model_terminal_lower_display':float(structured_terminal_lower),
      'same_model_terminal_power95_lower_display':float(structured_terminal_lower95),
      'same_model_terminal_power95_lower':str(structured_terminal_lower95),
      'same_model_bad_visibility':'177/200',
      'same_model_terminal_lower':str(structured_terminal_lower),
      'same_model_good_risk_interval':good,'same_model_bad_risk_interval':bad,
      'same_model_stock_ratio_upper':float(nominal_upper/structured_terminal_lower),
      'root_label_KL_lower_display':[float(r[0])for r in roots],
      'scope':'Expected upper cost, not bounded worst stopping time or same-family universal optimum. Extra physical response promise; all bad devices outside promise not covered.'}
    (BASE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='risk_cover'},indent=2))
if __name__=='__main__':main()
