"""Independent finite-cap checks: ordered paths and outward power arithmetic."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import sys,json,itertools
from record_information import log_interval,down,up
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'rich'))
from finite_cap import affinity
P=BASE.parent/'rich';cert=json.loads((P/'policy_14.json').read_text())
r=json.loads((P/'finite_cap_results.json').read_text())

def root_interval(x,bits=120):
 S=1<<bits;n=isqrt(x.numerator*S*S//x.denominator)
 assert n*n*x.denominator<=x.numerator*S*S<(n+1)**2*x.denominator
 return F(n,S),F(n+1,S)

def ordered(c,t,node,h):
 if t==0:return F(1),F(1)
 outlo=outhi=F(0)
 for word in itertools.product(range(3),repeat=t):
  i=node;p=q=F(1)
  for level,o in zip(range(t,0,-1),word):
   row=c['levels'][level][i];a,b=map(F,c['directions'][row['action']]);x=(a,-a,b,-b)[h]
   K0=(F(2,5)*(1+F(9,10)*x),F(2,5)*(1-F(9,10)*x),F(1,5))
   Kc=(F(2,5)*(1+F(89,100)*x),F(2,5)*(1-F(89,100)*x),F(1,5))
   p*=K0[o];q*=Kc[o];i=row['children'][o]
  l,u=root_interval(p*q);outlo+=l;outhi+=u
 return outlo,outhi
checks=0
for node in (0,len(cert['levels'][3])//2,len(cert['levels'][3])-1):
 cc=dict(cert,levels=cert['levels'][:4],root=node)
 _,bounds=affinity(cc)
 for h in range(4):
  l,u=ordered(cc,3,node,h);a,b=bounds[h]
  assert l<=b and a<=u
  checks+=1
# Slightly coarser independent rational upper before independent 50term logs.
Mu=up(F(r['affinity_interval'][1]));assert Mu<1
_,logMu=log_interval(Mu)
_,A=log_interval(F(2**20));_,L=log_interval(F(20))
margin=F(r['completed_experiment_cap'])*(-logMu)-A/2-L
assert margin>0 and r['source_copy_cap']==14*r['completed_experiment_cap']
assert r['source_copy_cap']<1992371
out={'status':'PASS','ordered_subtree_affinity_checks':checks,
 'ordered_paths_per_subtree':27,'independent_log_power_margin_lower':str(down(margin)),
 'completed_experiment_cap':r['completed_experiment_cap'],'source_copy_cap':r['source_copy_cap'],
 'scope':'Exact shared-response nominal goodworld, independent complete experiments; not arbitraryresponseorconditionalTVtube power.'}
(BASE/'finite_cap_audit_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
