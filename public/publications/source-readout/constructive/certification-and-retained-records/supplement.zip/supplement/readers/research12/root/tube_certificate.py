"""Conservative independent full-block certificate for a predictable response tube."""
from fractions import Fraction as F
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research12/rich'))
from calibration_gate import log_interval
r=json.loads((ROOT/'research12/rich/results.json').read_text())
z=F(1,10**6);B=14;eps=F(1,100)
D=F(r['nominal_KL_interval'][0]);dm=F(r['uniform_good_drift_lower'])
A=log_interval(F(2**20))[1];b=B*log_interval(F(190,189))[1]
k=z*F(200,2079);norm=B*log_interval(1+k)[1]
R=log_interval(F(209,189))[1]
risk=F(r['risk_cover']['uniform_risk_upper'])+B*z
assert risk<eps
exactgood=D-norm
uniformtube=dm-B*B*z*R-norm
assert exactgood>0 and uniformtube>0
out={'status':'PASS','zeta':str(z),'normalizer':str(1+k),'safe_v_floor':'89/100',
 'risk_upper':str(risk),'risk_display':float(risk),
 'exact_nominal_drift_lower':str(exactgood),'all_v_ge_point9_tube_drift_lower':str(uniformtube),
 'exact_nominal_expected_copy_upper':str(B*(A+b)/exactgood),
 'exact_nominal_expected_copy_display':float(B*(A+b)/exactgood),
 'all_v_ge_point9_tube_expected_copy_upper':str(B*(A+b)/uniformtube),
 'all_v_ge_point9_tube_expected_copy_display':float(B*(A+b)/uniformtube),
 'method':'Global likelihood range, block coupling, exact rational directed log enclosures. Not fitted data.'}
(ROOT/'research12/root/tube_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if not(k.endswith('upper') or k.endswith('lower'))},indent=2))
