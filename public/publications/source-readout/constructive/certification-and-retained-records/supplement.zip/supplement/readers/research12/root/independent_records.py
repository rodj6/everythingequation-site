"""Independent forward interval propagation of the frozen policy, no baseline evaluator."""
from fractions import Fraction as F
from pathlib import Path
import json, math
ROOT=Path(__file__).resolve().parents[2]
p=json.loads((ROOT/'baseline_evidence/eleventh/research11/nominal/policy_14.json').read_text())
S=1<<100

def forward(v,h):
    state={p['root']:(S,S)}
    for t in range(p['horizon'],0,-1):
        nxt={}
        for j,(lo,hi) in state.items():
            nd=p['levels'][t][j]; c,s=map(F,p['directions'][nd['action']]);x=(c,-c,s,-s)[h]
            ks=[F(2,5)*(1+v*x),F(2,5)*(1-v*x),F(1,5)]
            assert sum(ks)==1 and min(ks)>=0
            for k,ch in zip(ks,nd['children']):
                a,b=nxt.get(ch,(0,0));num,den=k.numerator,k.denominator
                nxt[ch]=(a+lo*num//den,b+(hi*num+den-1)//den)
        state=nxt
    lows=[];ups=[]
    for j,(lo,hi) in state.items():
        if p['levels'][0][j]['decision']!=(1 if h in (0,2) else -1):lows.append(lo);ups.append(hi)
    return F(sum(lows),S),F(sum(ups),S)

rows=[]
for v in [F(177,200),F(89,100),F(9,10),F(1)]:
    rs=[forward(v,h)for h in range(4)];l=sum(a for a,b in rs)/4;u=sum(b for a,b in rs)/4
    rows.append({'v':str(v),'mean_interval':[str(l),str(u)],'display':float(u)})
assert F(rows[0]['mean_interval'][0])>F(1,100)
assert F(rows[2]['mean_interval'][1])<F(875,100000)
# Independent analytic LR conditional mean: linear and nonincreasing in bad v.
for x in [F(0),F(1,3),F(-2,3),F(1),F(-1)]:
    e=F(4,5);v0=F(9,10);vc=F(89,100)
    fplus=(1+v0*x)/(1+vc*x);fminus=(1-v0*x)/(1-vc*x)
    for vb in [F(0),F(1,2),vc]:
        mean=e*(1+vb*x)/2*fplus+e*(1-vb*x)/2*fminus+1-e
        exact=1+e*(vb-vc)*(v0-vc)*x*x/(1-vc*vc*x*x)
        assert mean==exact and mean<=1
out={'status':'PASS','method':'independent forward integer interval flow at 100 bits','risks':rows,'LR_identities':15}
(ROOT/'research12/root/independent_records_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
