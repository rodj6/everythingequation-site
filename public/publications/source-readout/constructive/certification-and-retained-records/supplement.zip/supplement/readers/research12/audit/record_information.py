"""Exact tests of full-record and trusted-seed certification interfaces.

Standard-library core. No empirical data or quantum channel identification.
The actual14 case uses copied outward risk enclosures from a separately replayed
reader certificate; optional --policy replays the supplied policy verifier.
"""
from fractions import Fraction as F
from pathlib import Path
import json,itertools,math

def log_interval(x,terms=50):
 x=F(x)
 if x<=0: raise ValueError('positive log argument')
 k=0
 while x>=2:x/=2;k+=1
 while x<1:x*=2;k-=1
 def series(v):
  z=(v-1)/(v+1);r=z;s=F(0)
  for j in range(terms):s+=2*r/(2*j+1);r*=z*z
  return s,s+2*r/((2*terms+1)*(1-z*z))
 a,b=series(x);c,d=series(F(2))
 return (a+k*c,b+k*d) if k>=0 else (a+k*d,b+k*c)

def down(x,scale=10**24):
 x=F(x)*scale;return F(x.numerator//x.denominator,scale)

def up(x,scale=10**24):return -down(-F(x),scale)

def kl_interval(p,q):
 p,q=map(F,(p,q));assert 0<p<1 and 0<q<1
 a,b=log_interval(p/q);c,d=log_interval((1-p)/(1-q))
 return p*a+(1-p)*c,p*b+(1-p)*d

def design(weights,nulls,lam,alpha=F(1,2**20)):
 w,q=list(map(F,weights)),list(map(F,nulls));lam=F(lam)
 assert sum(w)==1 and all(x>0 for x in w) and 0<lam<1
 eps=sum(a*b for a,b in zip(w,q))
 p=[v-lam*v*(1-v) for v in q]
 assert all(0<a<b<1 for a,b in zip(p,q))
 f0=[(1-a)/(1-b) for a,b in zip(p,q)];f1=[a/b for a,b in zip(p,q)]
 assert all(a-b==lam for a,b in zip(f0,f1))
 assert sum(a*b for a,b in zip(w,f0))==1+lam*eps
 Dlo=Dhi=F(0)
 for a,b,c in zip(w,p,q):
  lo,hi=kl_interval(b,c);Dlo+=a*lo;Dhi+=a*hi
 pbar=sum(a*b for a,b in zip(w,p));b0,b1=kl_interval(pbar,eps)
 Alo,Ahi=log_interval(1/alpha)
 blo,bhi=log_interval(max(f0))
 upper=(Ahi+bhi)/Dlo
 lower=Alo/Dhi
 # Universal null identity rather than a grid-derived soundness claim.
 for v in itertools.product([F(0),eps,F(1,5),F(1)],repeat=len(w)):
  avg=sum(a*b for a,b in zip(w,v))
  ev=sum(a*(r*t+(1-r)*s) for a,r,s,t in zip(w,v,f0,f1))
  assert ev==1+lam*(eps-avg)
  if avg>=eps:assert ev<=1
 return {'weights':list(map(str,w)),'null_errors':list(map(str,q)),
  'good_design_errors':list(map(str,p)),'lambda':str(lam),'target':str(eps),
  'good_mean_display':float(pbar),'D_interval':list(map(str,(down(Dlo),up(Dhi)))),
  'terminal_D_interval':list(map(str,(down(b0),up(b1)))),
  'D_ratio_interval':list(map(str,(down(Dlo/b1),up(Dhi/b0)))),
  'D_ratio_display':float(Dlo/b1),
  'expected_per_label_lower':str(down(lower)),'expected_per_label_upper':str(up(upper)),
  'expected_4label_14copy_upper_display':float(56*upper),
  'relative_upper_gap_display':float((Ahi+bhi)/Alo),
  'multipliers_0':list(map(str,f0)),'multipliers_1':list(map(str,f1))}

def verify_tilt():
 P=[F(1,20),F(3,20),F(1,10),F(1,5),F(1,4),F(1,4)]
 Y=[1,1,0,0,0,0];p=sum(a*b for a,b in zip(P,Y));q=F(1,3)
 Q=[a*(q/p if y else (1-q)/(1-p)) for a,y in zip(P,Y)]
 assert sum(P)==sum(Q)==1 and sum(a*y for a,y in zip(Q,Y))==q
 for a,b,y in zip(P,Q,Y):assert a/b==(p/q if y else (1-p)/(1-q))
 # Here seed1 occupies indices0,2,4 and seed2 the rest. The tilted seed
 # marginal is changed; an independently trusted seed law rules Q out.
 seed0=(0,2,4)
 assert sum(P[i] for i in seed0)!=sum(Q[i] for i in seed0)
 return {'status':'PASS','good_error':str(p),'bad_error':str(q),
  'trusted_seed_marginal_before':str(sum(P[i] for i in seed0)),
  'trusted_seed_marginal_after':str(sum(Q[i] for i in seed0)),
  'scope':'Unrestricted full transcripts admit exact Bernoulli-KL tilt; a known seed marginal can exclude it.'}

def main():
 # Exact rational example with mean good error .00875 and target .01.
 example=design([F(1,2)]*2,[F(1,1000),F(19,1000)],F(1250,9819))
 assert example['good_mean_display']==.00875
 # Rational KKT design just above the four certified actual14 base risks.
 q=[F(9878412306733,10**15),F(10310957849793,10**15),F(9685677297833,10**15)]
 q.append(F(1,25)-sum(q))
 actual=design([F(1,4)]*4,q,F(1263302514,10**10))
 upper_risks=[F('2612125318554657875355/302231454903657293676544'),
 F('5453345208281231421021/604462909807314587353088'),
 F('5122179157330791167185/604462909807314587353088'),
 F('5354825362781091305837/604462909807314587353088')]
 assert all(a<=F(b) for a,b in zip(upper_risks,actual['good_design_errors']))
 out={'status':'PASS','tilt':verify_tilt(),'exact_two_seed_example':example,
 'actual14_seed_design':actual,'actual14_upper_risks':list(map(str,upper_risks)),
 'actual14_scope':'Each source label permutes these four conditional root-seed risks. Trusted fresh uniform rootseed and stable conditional errors promised. Savings are negligible, not a practical resourceadvance.',
 'arithmetic':'All decision inequalities exact Fractions; logs enclosed by50term positive atanh series after powers-of-two reduction. Decimal values display only.'}
 Path(__file__).with_name('record_information_results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'status':out['status'],'two_seed_KL_ratio':example['D_ratio_display'],
 'actual14_KL_ratio':actual['D_ratio_display'],
 'actual14_source_upper':actual['expected_4label_14copy_upper_display']},indent=2))
if __name__=='__main__':main()
