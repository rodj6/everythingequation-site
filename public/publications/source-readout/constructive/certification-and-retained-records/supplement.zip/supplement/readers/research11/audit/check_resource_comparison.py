"""Independent exact checks of fixed-reader validation resource inequalities."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research11.audit.check_information_cost import logs,kl

def main():
    from research11.sources.resource_comparison import compare,bisector_error_interval
    from research9.continuous.equatorial import bisector_risks
    q=bisector_risks(14,F(4,5),F(9,10))[14]
    S=1<<130;k=isqrt(2*S*S);l,u=F(k,S),F(k+1,S)
    exact=(q.a+q.b*u,q.a+q.b*l)
    prod=bisector_error_interval();assert prod[0]<=exact[0]<=exact[1]<=prod[1]
    assert F(4433,500000)<=exact[0]and exact[1]<=F(887,100000)
    cases=[];alpha=F(1,2**20);epsilon=F(1,100);qlo=F(4433,500000)
    for beta,p0 in[(F(1,20),F(7,800)),(F(0),F(7,800)),(F(1,20),F(11,1250))]:
        c=compare(beta=beta,adaptive_good=p0)
        n0,n1=kl(1-beta,alpha);d0,d1=kl(qlo,epsilon)
        theoretical_floor=56*n0/d1
        a0,a1=logs(1/alpha);b0,b1=logs((1-p0)/(1-epsilon));e0,e1=kl(p0,epsilon)
        expected_upper=56*(a1+b1)/e0
        producer_floor=F(c['fixed_expected_source_copies_lower']);producer_upper=F(c['adaptive_expected_source_copies_upper'])
        assert producer_floor<=theoretical_floor and producer_upper>=expected_upper
        saving=1-producer_upper/producer_floor;assert saving==F(c['guaranteed_relative_cost_decrease_lower'])and saving>0
        latency=F(14,13)*(producer_floor/producer_upper-1)
        assert latency==F(c['feedback_latency_over_trial_time_strict_upper'])and latency>0
        cases.append({'good_power':str(1-beta),'adaptive_risk_promise':str(p0),
                      'fixed_reader_stock_lower_display':float(producer_floor),
                      'adaptive_stock_upper_display':float(producer_upper),
                      'relative_saving_display':float(saving),'latency_over_tau_upper_display':float(latency)})
    # A genuinely finite command-precision allowance, not an uncharged exact
    # phase reference. All additional physical overhead remains separately paid.
    err=F(14)*F(4,5)*F(9,10)*F(1,100000)/2;assert err==F(63,1250000)
    e=F(json.loads((ROOT/'research11/nominal/results.json').read_text())['policies'][-1]['symmetrized_worst_error_interval'][1])
    assert e+err<F(11,1250)
    out={'status':'PASS','independent_bisector_Qsqrt2_check':True,'exact_validation_resource_comparisons':cases,
         'finite_phase_risk_allowance':str(err),
         'scope':'Terminal-error-only validators for fixedbisector14 vsfrozenAD14, unrestrictedBernoullialternatives. Notallnonadaptivereaders, structuredparametercalibration or fullarchivereaders.'}
    Path(__file__).with_name('resource_comparison_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
