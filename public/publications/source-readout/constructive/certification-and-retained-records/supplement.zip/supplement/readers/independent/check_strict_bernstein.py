"""Check strict decrease of the regenerated outward Bernstein intervals.

This checks the manuscript's strictness assertion, stronger than the original
producer's non-strict boolean. It does not replace the Bernstein recursion proof.
"""
from pathlib import Path
from fractions import Fraction as F
import json

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'research12/rich/bernstein_global_results.json'
result = json.loads(source.read_text())
assert result['domain'] == ['0', '1']
intervals = [(F(a), F(b)) for a, b in result['bernstein_intervals']]
assert len(intervals) == 15 and all(a <= b for a, b in intervals)
gaps = [a - next_upper for (a, b), (next_lower, next_upper) in zip(intervals, intervals[1:])]
assert len(gaps) == 14 and min(gaps) > 0
out = {'status': 'PASS', 'adjacent_count': len(gaps),
       'minimum_exact_gap': str(min(gaps)),
       'scope': 'Strict interval separation for the supplied frozen reader only; no arbitrary-policy monotonicity claim.'}
Path(__file__).with_name('strict_bernstein_check.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
