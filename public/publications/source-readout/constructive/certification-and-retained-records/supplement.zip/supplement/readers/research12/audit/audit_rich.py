"""Independent exact local identities and forward-occupancy trajectory KL audit."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json
from record_information import log_interval,down,up
BASE=Path(__file__).resolve().parent
P=BASE.parent/'rich'
c=json.loads((P/'policy_14.json').read_text());r=json.loads((P/'results.json').read_text())
eta,v0,vc=F(4,5),F(9,10),F(89,100)
checks=0
for d in c['directions']:
 for x0 in map(F,d):
  for x in (x0,-x0):
   fp=(1+v0*x)/(1+vc*x);fm=(1-v0*x)/(1-vc*x)
   assert max(fp,fm,F(1))<=F(190,189)
   for v in (F(0),F(1,2),vc,v0,F(1)):
    mean=eta*(1+v*x)*fp/2+eta*(1-v*x)*fm/2+1-eta
    assert mean==1+eta*(v-vc)*(v0-vc)*x*x/(1-vc*vc*x*x)
    if v<=vc:assert mean<=1
    checks+=1
   # TV-tube robustness check at all extreme moves of probability mass.
   zeta=F(1,10**6);f=[fp,fm,F(1)];osc=max(f)-min(f)
   assert osc>=0
   k=[eta*(1+vc*x)/2,eta*(1-vc*x)/2,1-eta]
   for i in range(3):
    for j in range(3):
     if i==j:continue
     delta=min(zeta,k[i]);pert=k[:];pert[i]-=delta;pert[j]+=delta
     assert sum(a*b for a,b in zip(pert,f))<=1+zeta*osc
     checks+=1
@lru_cache(None)
def local_D(x):
 p=[eta*(1+v0*x)/2,eta*(1-v0*x)/2,1-eta]
 q=[eta*(1+vc*x)/2,eta*(1-vc*x)/2,1-eta]
 lo=hi=F(0)
 for a,b in zip(p,q):
  l,u=log_interval(a/b);lo+=a*l;hi+=a*u
 return down(lo),up(hi)
Ds=[]
for h in range(4):
 visits={c['root']:F(1)};lo=hi=F(0)
 for t in range(c['horizon'],0,-1):
  nxt={}
  assert sum(visits.values())==1
  for i,weight in visits.items():
   row=c['levels'][t][i];cc,ss=map(F,c['directions'][row['action']]);x=(cc,-cc,ss,-ss)[h]
   l,u=local_D(x);lo+=weight*l;hi+=weight*u
   k=[eta*(1+v0*x)/2,eta*(1-v0*x)/2,1-eta]
   for o,j in enumerate(row['children']):nxt[j]=nxt.get(j,F(0))+weight*k[o]
  visits=nxt
 Ds.append((lo,hi))
lo=sum(a for a,b in Ds)/4;hi=sum(b for a,b in Ds)/4
claimed=list(map(F,r['nominal_KL_interval']))
assert lo<=claimed[1] and claimed[0]<=hi
assert r['nominal_expected_source_upper_display']<254746
assert r['same_model_terminal_power95_lower_display']>1992371
payload={'status':'PASS','exact_local_identity_and_extreme_tube_checks':checks,
 'forward_occupancy_KL_interval':[str(down(lo)),str(up(hi))],
 'independent_forward_KL_display':float(lo),
 'scope':'Forward exact occupancies and independent50term logbounds overlap claimed backward-DAG drift; separate analytic proof review coversstopping/minimax assumptions.'}
(BASE/'rich_audit_results.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
