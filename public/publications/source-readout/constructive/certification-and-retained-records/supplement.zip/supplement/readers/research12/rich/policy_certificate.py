"""Exact standard-library verification of frozen alpha-vector reader DAGs.

All actions are rational unit directions and every node specifies actual
outcome children. Point-based synthesis need not have covered any belief:
attainability follows directly from the policy graph and exact risk recursion.
"""
from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,argparse

def kernel(direction,eta,v):
 c,s=map(F,direction)
 if c*c+s*s!=1:raise ValueError('action is not an exact unit circle direction')
 if not 0<=eta<=1 or not 0<=v<=1:raise ValueError('physical detector parameters')
 return [[eta*(1+v*x)/2,eta*(1-v*x)/2,1-eta]for x in(c,-c,s,-s)]

def freeze(candidate,horizon=None):
 B=candidate['horizon']if horizon is None else horizon
 levels=candidate['levels'][:B+1];root=min(range(len(levels[B]['vectors'])),key=lambda i:sum(levels[B]['vectors'][i]))
 used=[set()for _ in levels];used[B].add(root)
 for t in range(B,0,-1):
  for j in used[t]:used[t-1].update(levels[t]['nodes'][j]['children'])
 maps=[{old:new for new,old in enumerate(sorted(u))}for u in used]
 kept=[]
 for t,(level,U,M)in enumerate(zip(levels,used,maps)):
  nodes=[]
  for i in sorted(U):
   row=level['nodes'][i]
   nodes.append({'decision':row['decision']}if not t else{'action':row['action'],'children':[maps[t-1][j]for j in row['children']]})
  kept.append(nodes)
 return {'horizon':B,'root':maps[B][root],'eta':candidate['eta'],'visibility':candidate['visibility'],
   'directions':candidate['directions'],'levels':kept,'root_symmetry_bits':2,
   'outcome_order':[1,-1,0],
   'scope':'One frozen implementable DAG, independent copies conditional on one inaccessible fixed source label; no click postselection or global optimality claim.'}

def verify(cert,bits=80):
 if not isinstance(bits,int)or bits<8:raise ValueError('at least8 intervalbits')
 eta,v=F(cert['eta']),F(cert['visibility']);B=cert['horizon'];S=1<<bits
 assert cert['outcome_order']==[1,-1,0] and cert['root_symmetry_bits']==2
 K=[kernel(d,eta,v)for d in cert['directions']]
 # Single common integer denominator per action and source makes the exact
 # weighted risk update cheap; lower/upper rounding occurs only once per node.
 IK=[]
 for k in K:
  rows=[]
  for probs in k:
   D=lcm(*(p.denominator for p in probs));N=[int(p*D)for p in probs]
   assert min(N)>=0 and sum(N)==D;rows.append((D,N))
  IK.append(rows)
 levels=cert['levels'];assert len(levels)==B+1 and B>=1
 prev=[];total=0
 for t,nodes in enumerate(levels):
  now=[]
  for row in nodes:
   if not t:
    assert row['decision']in[-1,1]
    V=[int(row['decision']!=(1 if h%2==0 else-1))*S for h in range(4)]
    now.append([(x,x)for x in V]);continue
   a=row['action'];ch=row['children'];assert type(a)is int and 0<=a<len(IK)
   assert len(ch)==3 and all(type(j)is int and 0<=j<len(prev)for j in ch)
   V=[]
   for h in range(4):
    D,N=IK[a][h]
    lo=sum(N[o]*prev[ch[o]][h][0]for o in range(3))//D
    u=sum(N[o]*prev[ch[o]][h][1]for o in range(3));hi=-((-u)//D)
    assert 0<=lo<=hi<=S and hi-lo<=2*t
    V.append((lo,hi))
   now.append(V);total+=1
  prev=now
 assert 0<=cert['root']<len(prev)
 root=prev[cert['root']];lower=F(sum(x[0]for x in root),4*S);upper=F(sum(x[1]for x in root),4*S)
 # Axis exchange and global source-sign reversal act transitively on source
 # labels; uniform group randomization makes each label risk the same mean.
 return {'status':'PASS','horizon':B,'nodes_checked':total,
  'level_node_counts':list(map(len,levels)),'interval_bits':bits,
  'base_label_error_intervals':[[str(F(a,S)),str(F(b,S))]for a,b in root],
  'symmetrized_worst_error_interval':[str(lower),str(upper)],
  'upper_float':float(upper),'passes_one_percent':upper<F(1,100),
  'scope':'Exact outward integer recursion verifies attainability of the shipped rational policy, not optimality over a grid or the continuum.'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('certificate',type=Path);p.add_argument('--bits',type=int,default=80)
 a=p.parse_args();print(json.dumps(verify(json.loads(a.certificate.read_text()),a.bits),indent=2))
if __name__=='__main__':main()
