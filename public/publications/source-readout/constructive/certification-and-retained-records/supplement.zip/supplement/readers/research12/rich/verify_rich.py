"""Independent algebra and high-precision checks, not used as exact proofs."""
from fractions import Fraction as F
from pathlib import Path
import json,sys,math
from rich_certification import risk_cover,drift,misspecified_drift
from policy_certificate import verify
from calibration_gate import log_interval
BASE=Path(__file__).resolve().parent
p=json.loads((BASE/'policy_14.json').read_text())
# Exact local composite-null likelihood identity, including sign and null.
checks=0
for d in p['directions']:
 for x in map(F,d):
  for v in [F(0),F(1,2),F(89,100),F(9,10),F(1)]:
   eta=F(4,5);v0=F(9,10);vc=F(89,100)
   fp=(1+v0*x)/(1+vc*x);fm=(1-v0*x)/(1-vc*x)
   mean=eta*(1+v*x)*fp/2+eta*(1-v*x)*fm/2+1-eta
   assert mean==1+eta*(v-vc)*(v0-vc)*x*x/(1-vc*vc*x*x)
   if v<=vc:assert mean<=1
   checks+=1
# Independent floating forward occupancy computation of trajectory KL.
D=[]
for h in range(4):
 visits={p['root']:1.};total=0.
 for t in range(14,0,-1):
  nxt={}
  for i,w in visits.items():
   row=p['levels'][t][i];c,s=map(lambda z:float(F(z)),p['directions'][row['action']]);x=(c,-c,s,-s)[h]
   k0=[.4*(1+.9*x),.4*(1-.9*x),.2];kc=[.4*(1+.89*x),.4*(1-.89*x),.2]
   total+=w*sum(a*math.log(a/b)for a,b in zip(k0,kc))
   for o,j in enumerate(row['children']):nxt[j]=nxt.get(j,0.)+w*k0[o]
  visits=nxt
 D.append(total)
r=json.loads((BASE/'results.json').read_text())
assert abs(sum(D)/4-r['nominal_KL_display'])<1e-14
assert r['same_model_terminal_power95_lower_display']>1992371
assert r['nominal_expected_source_upper_display']<254746
assert r['misspecification']['expected_source_upper_display']<255044
assert F(r['misspecification']['risk_uniform_upper'])<F(1,100)
print(json.dumps({'status':'PASS','exact_multiplier_checks':checks,'forward_KL':sum(D)/4,'same_family_saving_lower':1-r['nominal_expected_source_upper_display']/r['same_model_terminal_power95_lower_display']},indent=2))
