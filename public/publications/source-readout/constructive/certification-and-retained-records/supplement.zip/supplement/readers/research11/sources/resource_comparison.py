"""Exact terminal-validation cost comparison for the two frozen B=14 readers.

This compares terminal-error-only certification interfaces, not arbitrary quantum hardware or the
best nonadaptive reader. The bisector lower bound uses its actual nominal risk,
an independent sqrt(2)/majority enclosure, and an unrestricted Bernoulli
alternative class. Source-copy times and feedback latency are explicit models.
"""
from fractions import Fraction as F
from math import comb, isqrt
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parent / 'calibration'), str(HERE.parent / 'root')]
from calibration_gate import sequential_budget
from kl_cost import cost_certificate


def majority_error(n, success):
    """Exact error with a fair terminal coin on an even-sample tie."""
    success = F(success)
    result = sum((F(comb(n,j))*success**j*(1-success)**(n-j)
                  for j in range((n+1)//2)), F(0))
    if n % 2 == 0:
        result += F(comb(n,n//2),2)*success**(n//2)*(1-success)**(n//2)
    return result


def bisector_error_interval(B=14, eta=F(4,5), visibility=F(9,10), bits=100):
    """Outward rational interval; monotonicity handles omitted square root."""
    denominator = 1 << bits
    root_floor = isqrt(2*denominator*denominator)
    assert root_floor*root_floor <= 2*denominator*denominator
    assert (root_floor+1)**2 > 2*denominator*denominator
    root_lo, root_hi = F(root_floor,denominator), F(root_floor+1,denominator)
    success_lo = (1 + visibility*root_lo/2)/2
    success_hi = (1 + visibility*root_hi/2)/2
    weights = [F(comb(B,n))*eta**n*(1-eta)**(B-n) for n in range(B+1)]
    lo = sum((w*majority_error(n,success_hi) for n,w in enumerate(weights)),F(0))
    hi = sum((w*majority_error(n,success_lo) for n,w in enumerate(weights)),F(0))
    assert F(4433,500000) <= lo <= hi <= F(887,100000)
    return lo,hi


def compare(beta=F(1,20), lower_error=F(4433,500000), adaptive_good=F(7,800)):
    """Use only outward guaranteed endpoints, never float comparisons."""
    ad_upper = sequential_budget(p0=adaptive_good)['expected_source_copies_upper']
    fixed_lower = F(cost_certificate(pgood=lower_error,beta=beta)['resource_lower_rational'])
    ratio = fixed_lower/ad_upper
    # AD validation: at most 13 feedback waits per 14-copy experiment.
    # Fixed comparator: 14*tau per experiment, no additional charged delay.
    latency_floor = F(14,13)*(ratio-1)
    assert ratio > 1
    return {
        'fixed_reader_good_risk_lower': str(lower_error),
        'adaptive_good_risk_upper': str(adaptive_good),
        'fixed_reader_acceptance_power_lower': str(1-beta),
        'false_certificate_upper': '1/1048576',
        'adaptive_expected_source_copies_upper': str(ad_upper),
        'adaptive_expected_source_copies_upper_display': float(ad_upper),
        'fixed_expected_source_copies_lower': str(fixed_lower),
        'fixed_expected_source_copies_lower_display': float(fixed_lower),
        'guaranteed_relative_cost_decrease_lower': str(1-ad_upper/fixed_lower),
        'guaranteed_relative_cost_decrease_display': float(1-ad_upper/fixed_lower),
        'feedback_latency_over_trial_time_strict_upper': str(latency_floor),
        'feedback_latency_over_trial_time_display': float(latency_floor),
    }


def main():
    lo,hi = bisector_error_interval()
    nominal_results = json.loads((HERE.parent/'nominal'/'results.json').read_text())
    policy14 = next(p for p in nominal_results['policies'] if p['horizon']==14)
    nominal_upper = F(policy14['symmetrized_worst_error_interval'][1])
    phase_error = F(1,100000) # radians, uniform over actual accessible histories
    phase_allowance = F(14)*F(4,5)*F(9,10)*phase_error/2
    assert nominal_upper + phase_allowance < F(11,1250)
    # Nearest 19-bit command on [0,pi/2]; pi<22/7 gives this rational upper.
    quantization_error_upper = F(22,28*((1<<19)-1))
    assert quantization_error_upper < phase_error
    out = {
        'status':'PASS',
        'bisector_error_interval':[str(lo),str(hi)],
        'bisector_error_display':[float(lo),float(hi)],
        'comparisons':[compare(),compare(beta=F(0)),compare(adaptive_good=F(11,1250))],
        'finite_phase_variant':{
            'uniform_phase_error_radians':str(phase_error),
            'nominal_policy_error_upper':str(nominal_upper),
            'risk_allowance':str(phase_allowance),
            'perturbed_policy_error_upper':str(nominal_upper+phase_allowance),
            'good_risk_promise':'11/1250',
            'quarter_circle_command_bits':19,
            'quantization_error_upper_radians':str(quantization_error_upper),
            'quantization_error_upper_display':float(quantization_error_upper),
            'remaining_phase_budget_lower_radians':str(phase_error-quantization_error_upper),
            'scope':'Nearest command rounding plus separately promised residual error, not a demonstrated actuator or calibrated phase reference.',
        },
        'assumptions':[
            'Exact inherited shared detector: eta=4/5, visibility=9/10, fixed source label.',
            'Independent repeated trusted-label whole-experiment terminal errors; four labels.',
            'Validator observes only trusted label, terminal error and its own randomness; intra-experiment settings/nulls/seeds are append-only retained but unavailable for validation feedback or stratification.',
            'Alternative validation models allow one arbitrarily bad Bernoulli label; no Pauli-model restriction.',
            'AD gate uses stated p0 and accepts almost surely under its good-risk promise.',
            'The fixed-bisector comparator has required power at its actual nominal error.',
            'Timing assumes 14 source trials of duration tau and at most 13 extra feedback waits ell per AD experiment.',
            'Switching, reset, reference, setup and controller times must be added separately; no finite worst stopping budget.',
        ],
        'scope':'Frozen AD14 versus fixed-bisector14 terminal-risk validators; not optimality over all nonadaptive readers or structured calibration schemes.',
    }
    path = HERE/'resource_results.json'
    path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='bisector_error_interval'},indent=2))


if __name__=='__main__':
    main()
