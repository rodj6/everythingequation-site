"""Independent finite references, exact large-binomial gates and sequential tests."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
from itertools import product
import json,random,time
from decimal import Decimal,localcontext
from calibration_gate import *

def main():
    start=time.monotonic();small=0
    for n in range(12):
        for p in [F(0),F(1,10),F(1,2),F(9,10),F(1)]:
            for c in range(-1,n+1):
                reference=sum((F(comb(n,k))*p**k*(1-p)**(n-k)for k in range(max(-1,c)+1)),F(0))
                lo,hi=binomial_cdf_interval(n,c,p)
                assert lo<=reference<=hi;small+=1
    alpha=F(1,2**20);eps=F(1,100);p0=F(887,100000);n=365000;c=3366
    null=binomial_cdf_interval(n,c,eps)
    next_null=binomial_cdf_interval(n,c+1,eps)
    power=binomial_cdf_interval(n,c,p0)
    assert null[1]<alpha<next_null[0]
    assert power[0]>F(79,80)
    # Valid without requiring calibration-label event independence.
    joint_power=1-4*(1-power[0]);assert joint_power>F(19,20)
    # Nominal14 exact quadratic-field risk below the planning value p0.
    coeff=F(41399471337169097241,119209289550781250000)
    assert (F(1,2)-p0)**2<2*coeff**2
    lr_checks=0;drift_checks=0
    for p in [F(1,20),F(1,5),F(1,3)]:
        e=F(2,5)
        for a in [F(1,10),F(1,100)]:
            for nn in range(12):
                for ss in range(nn+1):
                    exact=a*(p/e)**ss*((1-p)/(1-e))**(nn-ss)>=1
                    assert lr_crossed(nn,ss,p,e,a)==exact;lr_checks+=1
        for q in [e,(1+e)/2,F(1)]:
            expected=q*p/e+(1-q)*(1-p)/(1-e)
            assert expected<=1;drift_checks+=1
    log_checks=0
    with localcontext()as ctx:
        ctx.prec=110
        for x in [F(1,1048576),F(1048576),F(887,1000),F(99113,99000),F(7,8),F(1),F(2),F(3),F(1,3)]:
            lo,hi=log_interval(x)
            expected=(Decimal(x.numerator)/Decimal(x.denominator)).ln()
            assert Decimal(lo.numerator)/Decimal(lo.denominator)<=expected<=Decimal(hi.numerator)/Decimal(hi.denominator)
            log_checks+=1
    budget=sequential_budget();new_budget=sequential_budget(p0=F(7,800));finite_budget=sequential_budget(p0=F(11,1250));zero=zero_error_minimum()
    for item in [budget,new_budget,finite_budget]:
        floor=item['log_threshold'][0]/item['drift'][1]
        item['power_one_per_label_KL_lower']=floor
        item['expected_upper_to_KL_lower_ratio']=item['expected_experiments_per_label_upper']/floor
        assert item['expected_upper_to_KL_lower_ratio']<F(10001,10000)
    reduction=1-new_budget['expected_source_copies_upper']/budget['expected_source_copies_upper']
    assert reduction>F(18,100)
    assert zero==1380
    out={'status':'PASS','small_exact_binomial_checks':small,'exact_LR_threshold_checks':lr_checks,'supermartingale_drift_checks':drift_checks,'independent_decimal_log_checks':log_checks,
      'contract':{'B':14,'labels':4,'risk_target':str(eps),'false_certificate_alpha':str(alpha),'good_planning_risk_upper':str(p0),'calibration_and_deployment':'one frozen policy and stable conditional-independent apparatus/source stock; trusted label excluded from policy input'},
      'fixed_gate':{'experiments_per_label':n,'maximum_errors_per_label':c,'null_CDF_interval':list(map(str,null)),'next_count_CDF_interval':list(map(str,next_null)),'per_label_acceptance_power_interval':list(map(str,power)),'joint_acceptance_power_lower':str(joint_power),'source_copies':4*14*n,'per_label_gate_is_maximal_at_n':True},
      'sequential':budget,'new_AD14_planning_sequential':new_budget,'finite_command_AD14_planning_sequential':finite_budget,'new_AD14_expected_stock_reduction':reduction,'zero_error_minimum_experiments_per_label':zero,
      'legacy_uniform_kernel_source_probes':92928000000,
      'fixed_gate_legacy_probe_ratio':str(F(92928000000,4*14*n)),
      'sequential_legacy_probe_ratio_lower':str(F(92928000000)/budget['expected_source_copies_upper']),
      'scope':'Task risk only; full response curve/retained instrument not certified. Fixed gate has finite stock and >=.95 good-device power. Sequential gate has finite expected stock under q_h<=p0 but no finite deterministic stopping guarantee.',
      'seconds':time.monotonic()-start}
    Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
    print(json.dumps(out,indent=2,default=str))
if __name__=='__main__':main()
