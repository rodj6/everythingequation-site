# Certification sources, exact inputs and job dependencies

Use the top-level scientific-package entry point (two directories above this folder):

```bash
python reproduce.py --check
python reproduce.py --output replay_new
```

`INPUT_MANIFEST.json` records every stored and expanded hash plus provenance. `jobs.json` specifies fifteen entry points. `JOB_DEPENDENCIES.json` records which generated-result producers must precede consumers; selected jobs automatically include those producers.

The sources remain byte-identical to their original evidence. Four appendix source files omitted from the compact baseline were restored from the original Eleventh package. One exact reader-risk result is a declared immutable input from the individually reviewed Paper 3 package. All required relative paths, including identical policy/helper copies, must remain available even when their bytes match.

The full coordinated two-paper reader/certification runner is preserved privately. It is not the scoped entry point for Paper 4. Dedicated Paper 3 reader searches and certificate jobs are excluded here.

Read `../EVIDENCE_GUIDE.md` before interpreting exact arithmetic, diagnostic displays, historical docstrings or confidence/cost claims. All source/controller, preparation, response, clock, reference, null-retention, archive-access and deployment-stability contracts remain part of the results.
