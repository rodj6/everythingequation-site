"""Outward dyadic Bernstein certificate for one frozen DAG's risk curve."""
from fractions import Fraction as F
import json
from pathlib import Path

def certify(p,lo=F(89,100),hi=F(1),bits=80):
 S=1<<bits;eta=F(4,5)
 prev=[[[[int(n['decision']!=(1 if h%2==0 else-1))*S]*2]for h in range(4)]for n in p['levels'][0]]
 for t,nodes in enumerate(p['levels'][1:],1):
  now=[]
  for n in nodes:
   c,s=map(F,p['directions'][n['action']]);ch=n['children'];row=[]
   for h,x in enumerate((c,-c,s,-s)):
    K0=[eta*(1+lo*x)/2,eta*(1-lo*x)/2,1-eta]
    K1=[eta*(1+hi*x)/2,eta*(1-hi*x)/2,1-eta]
    coeff=[]
    for k in range(t+1):
     l=u=F(0)
     for o in range(3):
      if k<t:
       l+=F(t-k,t)*K0[o]*prev[ch[o]][h][k][0];u+=F(t-k,t)*K0[o]*prev[ch[o]][h][k][1]
      if k>0:
       l+=F(k,t)*K1[o]*prev[ch[o]][h][k-1][0];u+=F(k,t)*K1[o]*prev[ch[o]][h][k-1][1]
     coeff.append([l.numerator//l.denominator,-((-u.numerator)//u.denominator)])
    row.append(coeff)
   now.append(row)
  prev=now
 root=prev[p['root']];means=[]
 for k in range(15):means.append([F(sum(root[h][k][i]for h in range(4)),4*S)for i in range(2)])
 descending=all(means[k+1][1]<=means[k][0]for k in range(14))
 return {'status':'PASS','domain':[str(lo),str(hi)],'bits':bits,'bernstein_intervals':[[str(a),str(b)]for a,b in means],
 'maximum_coefficient_upper':str(max(b for a,b in means)),'descending_coefficients_certified':descending,
 'global_risk_upper_display':float(max(b for a,b in means))}
if __name__=='__main__':
 BASE=Path(__file__).resolve().parent;p=json.loads((BASE/'policy_14.json').read_text());r=certify(p)
 (BASE/'bernstein_results.json').write_text(json.dumps(r,indent=2)+'\n')
 full=certify(p,F(0),F(1));(BASE/'bernstein_global_results.json').write_text(json.dumps(full,indent=2)+'\n');print(json.dumps({'local':r,'global':full},indent=2))
