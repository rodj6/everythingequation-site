"""Finite-cap full-record gate: exact Hellinger/DAG power certificate."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json
from calibration_gate import log_interval,ceil_fraction
BASE=Path(__file__).resolve().parent

def sqrt_interval(x,bits=100):
 S=1<<bits;n=isqrt(x.numerator*S*S//x.denominator)
 lo,hi=F(n,S),F(n+1,S)
 assert lo*lo<=x<=hi*hi
 return lo,hi

def affinity(cert,bits=100):
 eta=F(4,5);v0=F(9,10);vc=F(89,100)
 prev=[[(F(1),F(1))for h in range(4)]for n in cert['levels'][0]]
 for nodes in cert['levels'][1:]:
  now=[]
  for n in nodes:
   c,s=map(F,cert['directions'][n['action']]);ch=n['children'];row=[]
   for h,x in enumerate((c,-c,s,-s)):
    p=(eta*(1+v0*x)/2,eta*(1-v0*x)/2,1-eta)
    q=(eta*(1+vc*x)/2,eta*(1-vc*x)/2,1-eta)
    ss=[sqrt_interval(a*b,bits)for a,b in zip(p,q)]
    row.append(tuple(sum(ss[o][i]*prev[ch[o]][h][i]for o in range(3))for i in(0,1)))
   now.append(row)
  prev=now
 roots=prev[cert['root']]
 return tuple(sum(r[i]for r in roots)/4 for i in(0,1)),roots

def main():
 p=json.loads((BASE/'policy_14.json').read_text());M,roots=affinity(p)
 assert 0<M[0]<=M[1]<1
 A=log_interval(F(2**20));L=log_interval(F(20));logM=log_interval(M[1]);den=-logM[1]
 N=ceil_fraction((A[1]/2+L[1])/den)
 assert F(N)*den>=A[1]/2+L[1]
 result={'status':'PASS','affinity_interval':list(map(str,M)),
  'affinity_display':float(M[1]),'per_virtual_label_affinity_interval':[[str(x)for x in r]for r in roots],
  'completed_experiment_cap':N,'source_copy_cap':14*N,'alpha':'1/1048576','power_lower':'19/20',
  'log_affinity_upper':str(logM[1]),'negative_log_affinity_lower':str(den),
  'log_power_check_margin':str(N*den-A[1]/2-L[1]),
  'scope':'Exact shared-response nominal v=.9 power; size valid for every v whose frozen reader risk exceeds1percent withinfamily. Terminal-only samefamilypower95 expectedfloor exceeds fixedsourcecap.'}
 assert 14*N<1992371
 (BASE/'finite_cap_results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if 'interval'not in k and 'log_'not in k},indent=2))
if __name__=='__main__':main()
