"""Exact quadratic-field bisector risks and rational circle-net certificates.

These conventional calculations are not a complete continuous-control optimizer.
Only the one/two-copy continuous optima are established analytically here.
"""
from dataclasses import dataclass
from fractions import Fraction as F

@dataclass(frozen=True)
class Q2:
    a: F=F(0)
    b: F=F(0)
    def __post_init__(self):
        object.__setattr__(self,'a',F(self.a));object.__setattr__(self,'b',F(self.b))
    @staticmethod
    def cast(x):return x if isinstance(x,Q2)else Q2(F(x))
    def __add__(self,x):
        x=self.cast(x);return Q2(self.a+x.a,self.b+x.b)
    __radd__=__add__
    def __neg__(self):return Q2(-self.a,-self.b)
    def __sub__(self,x):return self+-self.cast(x)
    def __rsub__(self,x):return self.cast(x)+-self
    def __mul__(self,x):
        x=self.cast(x);return Q2(self.a*x.a+2*self.b*x.b,self.a*x.b+self.b*x.a)
    __rmul__=__mul__
    def __truediv__(self,x):
        x=self.cast(x);d=x.a*x.a-2*x.b*x.b
        if not d:raise ZeroDivisionError
        return self*Q2(x.a/d,-x.b/d)
    def __pow__(self,n):
        if type(n)is not int or n<0:raise ValueError('nonnegative integer exponent')
        out=Q2(1);base=self
        while n:
            if n&1:out=out*base
            base=base*base;n//=2
        return out
    def sign(self):
        if not self.b:return (self.a>0)-(self.a<0)
        if not self.a:return (self.b>0)-(self.b<0)
        sa=(self.a>0)-(self.a<0);sb=(self.b>0)-(self.b<0)
        if sa==sb:return sa
        d=self.a*self.a-2*self.b*self.b
        return sa*((d>0)-(d<0))
    def __lt__(self,x):return (self-self.cast(x)).sign()<0
    def __le__(self,x):return (self-self.cast(x)).sign()<=0
    def __gt__(self,x):return (self-self.cast(x)).sign()>0
    def __ge__(self,x):return (self-self.cast(x)).sign()>=0
    def decimal(self):return float(self.a)+float(self.b)*2**.5
    def export(self):return {'rational':str(self.a),'sqrt2_coefficient':str(self.b),'approximate':self.decimal()}

def parameters(eta,visibility):
    eta,v=F(eta),F(visibility)
    if not 0<=eta<=1 or not 0<=v<=1:raise ValueError('physical eta,v in [0,1]')
    return eta,v

def bisector_risks(horizon,eta=F(1),visibility=F(1)):
    """All fixed-bisector majority risks through horizon, exact in Q(sqrt2)."""
    if type(horizon)is not int or horizon<0:raise ValueError('nonnegative integer horizon')
    eta,v=parameters(eta,visibility)
    plus=Q2(eta/2,eta*v/4);minus=Q2(eta/2,-eta*v/4);null=Q2(1-eta)
    dist={0:Q2(1)};out=[Q2(F(1,2))]
    for _ in range(horizon):
        nxt={}
        for d,p in dist.items():
            for step,q in [(1,plus),(-1,minus),(0,null)]:
                nxt[d+step]=nxt.get(d+step,Q2())+p*q
        dist=nxt
        out.append(sum((p for d,p in dist.items()if d<0),Q2())+dist.get(0,Q2())/2)
    return out

def exact_small_optima(eta=F(1),visibility=F(1)):
    eta,v=parameters(eta,visibility)
    return (Q2(F(1,2)),Q2(F(1,2),-eta*v/4),Q2(F(1,2),-eta*(2-eta)*v/4))

def last_step_certificate(weights,eta=F(1),visibility=F(1)):
    """Exact symbolic one-step optimum for any rational posterior weights.

    The value is rational_part + sqrt_coefficient*sqrt(radicand).
    This is an all-posterior terminal-control primitive, not a whole-horizon
    continuous optimizer. Normalize the returned nonzero direction numerator.
    """
    w=tuple(map(F,weights))
    if len(w)!=4 or any(x<0 for x in w):raise ValueError('four nonnegative rational weights')
    eta,v=parameters(eta,visibility)
    W=sum(w);d=w[0]-w[1]+w[2]-w[3];b=(w[0]+w[1],w[2]+w[3]);norm2=sum(x*x for x in b)
    dominated=d*d>=v*v*norm2
    if dominated:a,c,r=(W-abs(d))/2,F(0),F(0)
    else:a,c,r=(W-(1-eta)*abs(d))/2,-eta*v/2,norm2
    return {'rational_part':str(a),'sqrt_coefficient':str(c),'radicand':str(r),
       'direction_numerator':list(map(str,b)),'direction_norm_squared':str(norm2),
       'measurement_cannot_improve_current_decision':dominated,
       'scope':'Exact unnormalized one-remaining-copy Bayes value; minimax needs its separately stated prior/symmetry argument.'}

def threshold(epsilon=F(1,100),eta=F(1),visibility=F(1),maximum=40):
    epsilon=F(epsilon)
    if not 0<epsilon<F(1,2):raise ValueError('epsilon in (0,1/2)')
    risks=bisector_risks(maximum,eta,visibility)
    b=next((b for b,e in enumerate(risks)if e<=epsilon),None)
    return {'threshold':b,'epsilon':str(epsilon),'eta':str(F(eta)),'visibility':str(F(visibility)),
      'scope':'minimum for repeated fixed bisector majority, not all continuous-menu protocols',
      'preceding':None if b is None or b==0 else risks[b-1].export(),
      'attaining':None if b is None else risks[b].export()}

def circle(t):
    t=F(t);return (1-t*t)/(1+t*t),2*t/(1+t*t)

def circle_net(m):
    """Rational full-circle net closed under axis swap and global sign reversal."""
    if type(m)is not int or m<1:raise ValueError('positive integer net resolution')
    points=set()
    for k in range(-m,m+1):
        x,y=circle(F(k,m))
        for a,b in [(x,y),(y,x)]:
            points.add((a,b));points.add((-a,-b))
    return tuple(sorted(points))

def net_error(horizon,m,eta=F(1),visibility=F(1)):
    if type(horizon)is not int or horizon<0:raise ValueError('nonnegative integer horizon')
    if type(m)is not int or m<1:raise ValueError('positive integer resolution')
    eta,v=parameters(eta,visibility);kappa=eta*v/(2*m)
    return 1-(1-kappa)**horizon

def continuous_enclosure(grid_lower,grid_upper,horizon,m,eta=F(1),visibility=F(1)):
    """Transfer a separately certified same-class circle-net risk interval."""
    lo,hi=F(grid_lower),F(grid_upper)
    if not 0<=lo<=hi<=F(1,2):raise ValueError('valid grid interval required')
    error=net_error(horizon,m,eta,visibility)
    return {'lower':str(max(F(0),lo-error)),'upper':str(hi),'rounding_allowance':str(error),
      'linear_allowance':str(F(horizon)*F(eta)*F(visibility)/(2*m)),
      'requires':'Certified optimization over a menu containing circle_net(m), same adaptive or randomized-nonadaptive class. No grid optimum is asserted by this adapter.'}

if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--eta',default='4/5');p.add_argument('--visibility',default='9/10');p.add_argument('--maximum',type=int,default=24)
    a=p.parse_args();print(json.dumps(threshold(eta=F(a.eta),visibility=F(a.visibility),maximum=a.maximum),indent=2))
