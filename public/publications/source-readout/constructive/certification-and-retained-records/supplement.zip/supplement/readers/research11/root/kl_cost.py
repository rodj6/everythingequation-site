"""Exact outward logarithmic bounds and policy-validation information costs.

Bernoulli error experiments are the operational observations. This does not
lower-bound all structured quantum calibration schemes or real hardware.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
from pathlib import Path

@lru_cache(None)
def log_bounds(x,terms=45):
 x=F(x)
 if x<=0:raise ValueError('positive argument')
 if type(terms)is not int or terms<1:raise ValueError('positive series length')
 k=0
 while x>=2:x/=2;k+=1
 while x<1:x*=2;k-=1
 def small(q):
  z=(q-1)/(q+1);total=F(0);term=z
  for j in range(terms):total+=2*term/(2*j+1);term*=z*z
  error=2*abs(term)/((2*terms+1)*(1-z*z))
  return total,total+error # z>=0 after range reduction
 lo,hi=small(x);a,b=small(F(2))
 return (lo+k*a,hi+k*b)if k>=0 else(lo+k*b,hi+k*a)

def kl_bounds(p,q):
 p,q=F(p),F(q)
 if not 0<=p<=1 or not 0<q<1:raise ValueError('physical Bernoulli parameters')
 lo=hi=F(0)
 if p:
  a,b=log_bounds(p/q);lo+=p*a;hi+=p*b
 if p<1:
  a,b=log_bounds((1-p)/(1-q));lo+=(1-p)*a;hi+=(1-p)*b
 return max(F(0),lo),max(F(0),hi)

def cost_certificate(pgood=F(887,100000),target=F(1,100),alpha=F(1,2**20),beta=F(1,20),labels=4,copies_per_experiment=14):
 pgood,target,alpha,beta=map(F,(pgood,target,alpha,beta))
 if not 0<=pgood<target<1 or not 0<alpha<1-beta<=1:raise ValueError('separated accuracy/confidence/power')
 if type(labels)is not int or labels<1 or type(copies_per_experiment)is not int or copies_per_experiment<1:raise ValueError('positive resource counts')
 n0,n1=kl_bounds(1-beta,alpha);d0,d1=kl_bounds(pgood,target)
 assert d0>0
 low,high=n0/d1,n1/d0
 # Outward round only the exported display certificate, retaining proof bounds.
 scale=10**12
 low=F((low*scale).numerator//(low*scale).denominator,scale)
 high=F(-((-high*scale).numerator//(-high*scale).denominator),scale)
 return {'good_error':str(pgood),'target_error':str(target),'false_certificate_upper':str(alpha),'acceptance_power_lower':str(1-beta),
  'expected_experiments_per_label_lower_interval':[str(low),str(high)],'per_label_lower_display':float(low),
  'expected_all_label_experiments_lower_display':float(labels*low),
  'expected_source_copies_lower_display':float(labels*copies_per_experiment*low),
  'resource_lower_rational':str(labels*copies_per_experiment*low),
  'scope':'Adaptive sequential trusted-label terminal-risk validation, one-bad-label unrestricted Bernoulli alternatives; good-device acceptance>=1-beta and false certification<=alpha. Not a universal physical-calibration lower bound.'}

def main():
 cases=[cost_certificate(),cost_certificate(beta=F(0)),cost_certificate(pgood=F(7,800),beta=F(0)),cost_certificate(pgood=F(4433,500000)),cost_certificate(alpha=F(1,1000),beta=F(1,10)),cost_certificate(pgood=F(0))]
 out={'status':'PASS','cases':cases,'precision':'45-term rational atanh series after powers-of-two reduction, outward bounds; floats display only.'}
 Path(__file__).with_name('kl_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
