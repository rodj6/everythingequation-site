# Evidence and certificate guide

The paper and companion give the analytical assumptions and proofs. The checked release supplies exact proof objects and frozen policies; numerical search is not required for verification. All 17 core jobs and five restored supporting jobs passed in disposable copies. The original 58-file coordinated input tree remained byte-identical. The scoped release uses 53 distinct inputs and 23 jobs, including an independent 420-entry identity check.

## Core calculations

| Entry point | Evidence class | Scientific scope |
|---|---|---|
| `research7/physical/verify_phase_design.py` | Exact rational primal/dual and finite ordered-record checks | Scope: fixed X/Y count schedule, not randomized schedule/adaptive optimum. |
| `research8/adaptive/verify_adaptive.py` | Exact rational Bellman and independent normalized-prior DP | Declared local X/Y class;19 versus21 threshold stays specific to that menu. |
| `research8/robust/verify_robust.py` | Exact rational polynomial/Bernstein and finite history checks | One frozen policy; box certificate is not robust-minimax optimality for the visibility box. |
| `research9/continuous/verify_equatorial.py` | Exact quadratic-field and rational rounding checks | Only bisector attainment/small-horizon identities/net transfer; no finite net equals continuum optimum. |
| `research9/robust/verify_robust.py` | Exact quadratic-field signs and rational square-root enclosures | Frozen common-positive angle class;17/19 comparison not general robust advantage. |
| `research10/continuous/verify_continuous.py` | Exact rational word sums and quadratic-field geometry checks | Four-copy attainable trees and algebra checks; universal continuous theorem remains analytical. |
| `research10/nonadaptive/verify_four.py` | Rigorous rational interval certificate | 143633 complete octree leaves and full odd-decoder orbit coverage establish ideal NA4 lower1/32 after paper reduction. |
| `research10/nonadaptive/verify_nominal_integer.py` | Rigorous outward dyadic-integer interval certificate | 4230653 leaves,56 partitions,961 Fraction crosschecks; noisy NA4 lower13/125 after analytical reduction. |
| `research10/nonadaptive/verify_nonadaptive.py` | Exact finite odd-decoder classification and rational inequality checks | Tests support analytical B3 comparison; docstring scope reflects its original component, not later consolidated adaptive theorem. |
| `research10/robust/verify_robust.py` | Rigorous rational Schur-block trace-norm enclosure; exact geometry | Historical robust B12 lower and intermediate [13,17] output superseded for final status by B15 certificate. |
| `research11/bounds/ppt_certificate.py` | Rigorous rational PSD-factor dual and coefficient-residual certificate | Nominal12 lower; nonattaining relaxation applies to both reader classes. |
| `research11/bounds/robust_ppt_certificate.py` | Rigorous rational fixed-prior dual with root enclosures | Original robust15 lower; source-prior comparison does not randomize physical nuisance independently at each history. |
| `research11/robust/verify_robust.py` | Exact rational binomial/mixture/covariance identities | All-B frozen-angle theorem analytical; finite checks do not exclude varying/adaptive16copy policies. |
| `research11/nominal/verify_nominal.py` | Rigorous outward integer DAG recursion plus independent exact Fraction evaluation | B14 attains below1%;B13 candidate fails; no global optimum is claimed. |
| `research12/threshold/verify_threshold.py` | Rigorous rational B13 relaxation and exact finite-grid DP checks | B13 lower below1%;does not settle endpoint. Small-grid exact values are not continuous optima. |
| `research12/nominal/verify_nominal12.py` | Rigorous outward integer risk and rational support-function checks | Refined thirteen-copy candidates all fail; unsuccessful policies are not impossibility certificates. |
| `research12/robust/verify_robust12.py` | Exact rational fixed-nuisance polynomial/Bernstein checks | Method and interior-gain counterexample; no sixteen-copy attainment/optimum. Sound capped certifier may return INCONCLUSIVE. |

## Supporting calculations restored to the clean supplement

| Entry point | Scope |
|---|---|
| `research9/menu/verify_menu.py` | Exact finite-menu Bellman/likelihood comparisons, saved four/eight-copy certificates, and full regeneration at thirteen/fourteen copies. These are finite-menu minima, not continuous optima. |
| `research9/resources/verify_resources.py` | Rational phase/clock frontiers and arctangent enclosures, with separate floating reference diagnostics. |
| `research10/resources/verify_resources.py` | Exhaustive finite schedule-tour, row-distance, operating-budget and calibration-allocation checks using rational arithmetic. |
| `research10/resources/policy_resources.py` | Cost evaluation of the supplied four-copy policy using outward rational phase-angle bounds. |
| `research10/audit/check_resources.py` | Independently written finite timing/phase checks, including a different angle-series construction. |
| `independent/check_schur_coefficient_identity.py` | 420 rational tensor-basis comparisons through symmetric power six. This checks finite instances of the displayed formula, not the general Schur representation theorem. |

The menu/resource sources were recovered from the original Ninth/Tenth evidence and match their preserved hashes. Their source locators are recorded in INPUT_MANIFEST.json. Restoring omitted reproducibility assets does not change a scientific frontier.

## Which results are universal certificates?

- The four-copy ideal octree verifier checks 143,633 leaves. The nominal noisy verifier checks 4,230,653 leaves with outward integer arithmetic, including cube coverage and all required decoder/sign variants. These proof objects cover continuous settings within their declared comparison task.
- The Schur-block certificate factors are rational Gram factors. The residual allowance and directed square-root bounds charge any proposal error; no solver status establishes feasibility.
- Frozen policy graphs are evaluated with exact rational arithmetic or outward dyadic intervals. They establish attainment, not global adaptive optimality.
- Finite identity grids, selected subtree checks and angle-series spot checks corroborate implementation; their finite coverage is not a proof of an unrelated continuous assertion.
- Display decimals and execution times are not certificates. The exact rational/algebraic/interval comparisons decide the stated pass/fail results.

## Status fields and comparison classes

- Latest nominal one-percent minima: [13,14] for each full continuous local class. Latest original asymmetric robust minima: [16,17] for each class.
- Some unchanged historical programs print weaker intermediate intervals, including [13,17] in the tenth robust output. Those are valid old comparisons, not the latest status.
- X/Y-only 19-versus-21 thresholds, finite four-setting 0.9% 14-versus-15 thresholds, and continuous four-copy separations are different tasks. None proves a continuous one-percent copy separation.
- The supporting fixed-allocation table does not optimize mixtures over distinct allocations. Its budget-eight value 0.08270910464 differs legitimately from the broader randomized-schedule comparator.
- Failed thirteen/sixteen-copy candidates are not impossibility certificates.
- Calibration and complete retained-channel identification remain different tasks; this release does not execute Paper4 certification jobs.

## Reproduction outputs

The runner saves a separate log and receipt for each job. New or changed products are captured immediately under per_job before another verifier can replace the same output path. The generated directory additionally gives the final expanded-tree products. Unchanged exact inputs remain identified by the manifest rather than being copied as new results. Existing output directories must be empty, and assertions must stay enabled.

Physical preparation, independent stock, fixed-nuisance consistency, phase references, control accuracy, timing access and deployment stability are premises. No program proves them from synthetic data. Ordinary Born probabilities are assumed; no consciousness or source-ontology inference is certified.
