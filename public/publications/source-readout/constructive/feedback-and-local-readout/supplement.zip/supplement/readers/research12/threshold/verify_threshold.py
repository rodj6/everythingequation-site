"""Exact stdlib replay; no exploratory optimizer output trusted."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json
from inherited_ppt_certificate import certify_click
from convex_grid_bound import vertices,interpolation,run

def main():
 here=Path(__file__).resolve().parent;c=json.load(open(here/'nominal13_certificate.json'))
 eta,v=F(c['eta']),F(c['visibility']);B=c['horizon']
 assert (eta,v,B)==(F(4,5),F(9,10),13)
 es=[F(1,2)];clicks=[]
 for n in range(1,B+1):
  r=certify_click(n,v,c['clicks'][str(n)]);es.append(F(r['error_lower']));clicks.append(r)
 e=sum((comb(B,n)*eta**n*(1-eta)**(B-n)*es[n]for n in range(B+1)),F(0))
 assert F(944,100000)<e<F(1,100)
 for N in range(1,17):
  for x,y in vertices(N):assert x*x+y*y<=(1+F(1,2*N*N))**2
 import random
 rng=random.Random(12)
 for _ in range(1000):
  z=tuple(F(rng.randrange(20),rng.randrange(1,11))for h in range(4))
  interpolation(z,rng.randrange(1,30))
 # Independent simplex weighted reconstruction on faces, ties and interior.
 for z in [(F(1,4),)*4,(F(0),F(0),F(0),F(1)),(F(1,7),F(2,7),F(3,7),F(1,7))]:interpolation(z,8)
 expected=[(4,2,[F(23,100),F(323,2500),F(9211,125000)]),(8,2,[F(23,100),F(98,625),F(5163,50000)]),(8,4,[F(6,25),F(199,1250),F(18278,171875)])]
 grid=[]
 for M,N,refs in expected:
  r=run(M,N,3);assert [F(x['lower_exact'])for x in r['bounds']]==refs;grid.append(r)
 result={'status':'PASS','nominal13_error_lower':str(e),'display_nominal13_error_lower':float(e),'excludes_one_percent':False,'click_certificates':clicks,'grid_replays':grid,'scope':'Lower bound only. No threshold resolution or one-percent separation.'}
 (here/'verification_results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k not in ('click_certificates','grid_replays')},indent=2))
if __name__=='__main__':main()
