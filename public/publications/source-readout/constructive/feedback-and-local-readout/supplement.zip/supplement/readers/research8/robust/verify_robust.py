"""Independent ordered-record, erasure-mixture and Bernstein checks."""
from robust_reader import *
from itertools import product
from pathlib import Path
import json,random

def independent_ordered(budget,eta,v):
    # Enumerate physical histories directly, with a separately written decoder.
    total=F(0)
    for initial in ['X','Y']:
        for label in LABELS:
            risk=F(0)
            for word in product([1,-1,0],repeat=budget):
                axis=initial;seen=[];second=[];switched=False;prob=F(1)
                for outcome in word:
                    signal=(1 if label[1]=='+'else -1)if axis==label[0]else 0
                    prob*=1-eta if outcome==0 else eta*(1+outcome*v*signal)/2
                    if outcome:
                        if switched:second.append(outcome)
                        else:
                            seen.append(outcome)
                            if len(set(seen))==2:switched=True;axis='Y'if initial=='X'else 'X'
                guess=second[0]if second else 0 if switched or not seen else seen[0]
                loss=F(1,2)if guess==0 else F(int(guess!=(1 if label[1]=='+'else -1)))
                risk+=prob*loss
            total+=risk/8
    return total

def run():
    checks=0
    for b in range(11):
        for eta in [F(0),F(1,5),F(4,5),F(49,50),F(1)]:
            assert erased_error([eta]*b)==erased_closed_form(b,eta);checks+=1
    polynomials=[]
    for b in range(9):
        individual,p=risk_polynomials(b)
        assert evaluate(p,1,1)==ideal_error(b)
        for eta in [F(0),F(4,5),F(49,50),F(1)]:assert evaluate(p,eta,1)==erased_closed_form(b,eta)
        if b<=5:
            for eta,v in [(F(1),F(1)),(F(4,5),F(9,10)),(F(3,4),F(4,5))]:
                assert evaluate(p,eta,v)==independent_ordered(b,eta,v);checks+=1
        polynomials.append(p)
    # Independent binomial theorem reconstruction of random coefficient arrays.
    rng=random.Random(82026);bernstein_checks=0
    for case in range(30):
        p={(i,j):F(rng.randrange(-5,6),rng.randrange(1,8))for i in range(4)for j in range(4)}
        xi=(F(1,4),F(3,4));yi=(F(1,5),F(4,5));coeff=bernstein_coefficients(p,xi,yi)
        for t,s in [(F(0),F(0)),(F(1),F(1)),(F(1,3),F(3,7)),(F(1,2),F(1,2))]:
            value=sum((coeff[i][j]*comb(3,i)*t**i*(1-t)**(3-i)*comb(3,j)*s**j*(1-s)**(3-j)for i in range(4)for j in range(4)),F(0))
            assert value==evaluate(p,xi[0]+t*(xi[1]-xi[0]),yi[0]+s*(yi[1]-yi[0]));bernstein_checks+=1
    # Deterministic independent nonidentical erasure risks and monotone robust bound.
    for _ in range(30):
        efficiencies=[F(rng.randrange(80,101),100)for _ in range(7)]
        assert erased_error(efficiencies)<=erased_error([F(4,5)]*7);checks+=1
    cases=[]
    for budget,eta_box,v_box in [(7,(F(49,50),1),(1,1)),(7,(F(99,100),1),(F(999,1000),1)),(8,(F(49,50),1),(F(999,1000),1)),(8,(F(79,100),F(81,100)),(F(89,100),F(91,100)))]:
        p=polynomials[budget];cert=box_certificate(p,eta_box,v_box,1)
        nominal=evaluate(p,1 if eta_box[1]==1 else F(4,5),1 if v_box[1]==1 else F(9,10))
        delta=max(abs(F(eta_box[0])-(1 if eta_box[1]==1 else F(4,5))),abs(F(eta_box[1])-(1 if eta_box[1]==1 else F(4,5))))+F(1 if eta_box[1]==1 else F(4,5))*max(abs(F(v_box[0])-(1 if v_box[1]==1 else F(9,10))),abs(F(v_box[1])-(1 if v_box[1]==1 else F(9,10))))/2
        generic=nominal+1-(1-delta)**budget
        assert F(cert['lower'])<=F(cert['upper'])
        cases.append(dict(budget=budget,eta_interval=list(map(str,eta_box)),visibility_interval=list(map(str,v_box)),certificate=cert,upper_float=float(F(cert['upper'])),nominal_error=str(nominal),seventh_generic_TV_upper=str(generic),generic_upper_float=float(generic)))
    result={'status':'PASS','erasure_and_ordered_checks':checks,'Bernstein_reconstruction_checks':bernstein_checks,'ideal_minimax':[str(ideal_error(b))for b in range(11)],'erasure_7_at_98_percent':str(erased_closed_form(7,F(49,50))),'calibration_boxes':cases}
    Path('results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':run()
