"""Exact dyadic-integer outward interval replay of the nominal B4 proof.

Every stored integer encloses a real quantity after division by2**60.
All rounding is outward using integer floor/ceiling; no float is accepted.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,permutations
from functools import lru_cache
from math import isqrt,prod
import json,time,random
from verify_four import R,SUBSETS
BITS=60;SCALE=1<<BITS;ZERO=(0,0)
def ceildiv(n,d):return-((-n)//d)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def scale(n,d,a):
 if n<0:return scale(-n,d,(-a[1],-a[0]))
 return n*a[0]//d,ceildiv(n*a[1],d)
def mul(a,b):
 vals=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]]
 return min(vals)//SCALE,ceildiv(max(vals),SCALE)
def rootup(n):
 a=isqrt(n);return a if a*a==n else a+1
ROOT2=rootup(2*SCALE*SCALE)
C1=ceildiv(9*ROOT2,20);C3=ceildiv(4671*ROOT2,8000)
def abmax(a):return max(abs(a[0]),abs(a[1]))
@lru_cache(None)
def coords(depth,k):
 d=1<<depth;l=2*k-d;u=2*(k+1)-d;dd=d*d
 def ratio(n,q):return(n*SCALE//q,ceildiv(n*SCALE,q))
 cl=ratio(dd-l*l,dd+l*l);cu=ratio(dd-u*u,dd+u*u)
 c=min(cl[0],cu[0]),SCALE if l<=0<=u else max(cl[1],cu[1])
 s=ratio(2*l*d,dd+l*l)[0],ratio(2*u*d,dd+u*u)[1]
 return c,s

def upper(coeff,path):
 depth=len(path);idx=[0,0,0]
 for c in path:
  o=ord(c)-48
  for j in range(3):idx[j]=2*idx[j]+((o>>j)&1)
 vals=[coords(depth,k)for k in idx];C=[v[0]for v in vals];SS=[v[1]for v in vals]
 a=[add(c,s)for c,s in zip(C,SS)];am=[abmax(q)for q in a]
 c1=ceildiv(9*sum(am),20)+C1
 c2=ceildiv(9*sum(max(am[i],am[j])for i,j in[(0,1),(0,2),(1,2)]),20)+3*C1
 zz=add(mul(mul(C[0],C[1]),C[2]),mul(mul(SS[0],SS[1]),SS[2]))
 c3sum=0
 for rr in[(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]:
  v=ZERO
  for r,aa in zip(rr,a):v=add(v,scale(9*r,10,aa))
  v=add(v,scale(729*prod(rr),1000,zz));c3sum+=abmax(v)
 c3=min(C3,ceildiv(c3sum,8))+3*C3
 f0=ZERO;A=scale(*coeff[3],(SCALE,SCALE));B=A
 for i in range(3):
  if coeff[i][0]:f0=add(f0,scale(*coeff[i],a[i]))
 if coeff[4][0]:f0=add(f0,scale(81*coeff[4][0],100*coeff[4][1],zz))
 for (n,d),(i,j)in zip(coeff[5:],[(0,1),(0,2),(1,2)]):
  if n:A=add(A,scale(81*n,100*d,mul(C[i],C[j])));B=add(B,scale(81*n,100*d,mul(SS[i],SS[j])))
 root=rootup(abmax(A)**2+abmax(B)**2)
 return ceildiv(20*c1+80*c2+320*c3+576*(f0[1]+root),3125)

def main():
 start=time.monotonic();cert=json.loads(Path(__file__).with_name('nominal_certificate.json').read_text())
 assert cert['eta']=='4/5'and cert['visibility']=='9/10'
 target=F(cert['correlation_upper']);assert target==F(99,125) and F(cert['error_lower'])==F(13,125)
 seen=set();all_decoders=set();checks=0;maxdepth=0;maxupper=0;crosschecks=0
 from verify_nominal import upper as fraction_upper
 for row in cert['classes']:
  values=tuple(row['table']);D=dict(zip(R,values));assert len(D)==16 and all(s in(-1,1)for s in values)
  assert all(D[tuple(-x for x in r)]==-D[r]for r in R)
  raw=tuple(F(sum(D[r]*prod(r[i]for i in I)for r in R),16)for I in SUBSETS)
  assert list(map(str,raw))==row['coefficients']
  flips=tuple(row['first_three_direction_signs']);assert len(flips)==3 and all(s in(-1,1)for s in flips)
  key=(values,flips);assert key not in seen;seen.add(key)
  qq=tuple(q*prod(flips[i]for i in I if i<3)for q,I in zip(raw,SUBSETS));coef=tuple((q.numerator,q.denominator)for q in qq)
  assert list(map(str,qq))==row['transformed_coefficients']
  leaves=sorted(row['leaves']);assert len(leaves)==len(set(leaves));dep=max(map(len,leaves));maxdepth=max(maxdepth,dep)
  assert sum(1<<(3*(dep-len(p)))for p in leaves)==1<<(3*dep)
  assert all(not leaves[i+1].startswith(leaves[i])for i in range(len(leaves)-1))
  for k,path in enumerate(leaves):
   assert all(c in'01234567'for c in path)
   bound=upper(coef,path);assert bound*target.denominator<=target.numerator*SCALE,(row['orbit'],path,bound)
   if k%max(1,len(leaves)//20)==0:
    fq=fraction_upper(qq,tuple(map(int,path)));assert F(bound,SCALE)>=fq;crosschecks+=1
   maxupper=max(maxupper,bound);checks+=1
  for perm in permutations(range(4)):
   for ss in product((-1,1),repeat=4):all_decoders.add(tuple(D[tuple(ss[i]*r[perm[i]]for i in range(4))]for r in R))
  print('PASS row',len(seen),'leaves',checks,'seconds',round(time.monotonic()-start,2),flush=True)
 assert len(all_decoders)==256 and len(seen)==56
 reps={k[0]for k in seen};assert len(reps)==7 and all((rep,s)in seen for rep in reps for s in product((-1,1),repeat=3))
 out={'status':'PASS','eta':'4/5','visibility':'9/10','all_odd_four_click_decoders':256,'partitions':56,
      'exact_interval_leaves':checks,'max_depth':maxdepth,'interval_bits':BITS,'fraction_reference_crosschecks':crosschecks,
      'correlation_upper':str(target),'all_continuous_nonadaptive_error_lower':str((1-target)/2),
      'maximum_exact_leaf_upper':str(F(maxupper,SCALE)),'seconds':time.monotonic()-start,
      'scope':'Allcontinuousnonadaptivefourcopyreaders, retainednulls, fixedknownsharednoise. Exactintegeroutwardintervals; nofloataccepted.'}
 Path(__file__).with_name('nominal_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
