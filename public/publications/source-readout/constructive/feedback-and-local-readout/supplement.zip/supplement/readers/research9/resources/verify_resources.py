"""Independent exact references and checked resource-frontier certificates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import factorial,atan,asin,pi
import json,sys
from resource_frontier import *

def reference_risk(b,eta,beta):
    p=(1+beta)*eta/2;m=(1-beta)*eta/2;z=1-eta;total=F(0)
    for plus in range(b+1):
        for minus in range(b-plus+1):
            null=b-plus-minus
            if minus<plus:continue
            count=factorial(b)//(factorial(plus)*factorial(minus)*factorial(null))
            total+=count*p**plus*m**minus*z**null*(F(1,2)if minus==plus else 1)
    return total

def main():
    risk_checks=0
    for b in range(9):
        for eta in [F(1),F(4,5),F(1,2)]:
            for beta in [F(0),F(1,3),F(3,5),F(1)]:
                assert risk(b,eta,beta)==reference_risk(b,eta,beta);risk_checks+=1
    # Floating evaluations below are independent sanity checks, not the
    # source of the rigorous alternating-series enclosure theorem.
    transcendental_checks=0
    for x in [F(0),F(1,100),F(1,3),F(3,5),F(1),F(3)]:
        l,u=atan_bounds(x);assert float(l)-1e-14<=atan(float(x))<=float(u)+1e-14;transcendental_checks+=1
    for x in [F(0),F(1,100),F(1,3),F(3,5),F(9,10),F(1)]:
        l,u=asin_bounds(x);assert float(l)-1e-14<=asin(float(x))<=float(u)+1e-14;transcendental_checks+=1
    pl,pu=pi_bounds();assert float(pl)-1e-14<=pi<=float(pu)+1e-14
    for x in [F(0),F(1),F(2),F(3,7),F(9,16)]:
        l,u=sqrt_bounds(x);assert l*l<=x<=u*u
    parameters=(F(4,5),F(9,10),F(4,5),F(1,100),F(1,100))
    rows=[]
    for parent,r in [('held',F(1)),('held',F(1,10)),('held',F(1,20)),('held',F(1,50)),('pulse',F(1))]:
        v=frontier(*parameters,r,parent,max_budget=100,bits=45)
        assert v['winner']['budget']==(20 if parent=='held'and r==F(1,50)else 17)
        v['winner_angle_float']=[float(x)for x in v['winner']['least_angle']]
        v['winner_time_float']=[float(x)for x in v['winner']['time_interval']]
        rows.append(v)
    calibration=[dyadic_calibration(a,4,10,F(1,100))for a in [1,2,4]]
    assert [x['total_probes']for x in calibration]==[300000,640000,1360000]
    clock=feedback_clock_certificate(14,15,F(1,50),F(1,50),extra_setup=10,runs=21)
    assert clock['strict_advantage']and clock['certified_total_time_saving']==F(2,25)
    no_gain=feedback_clock_certificate(14,15,F(1,25),F(1,25));assert not no_gain['strict_advantage']
    out={'status':'PASS','exact_risk_reference_checks':risk_checks,
         'transcendental_sanity_checks':transcendental_checks,
         'parameters':{'eta_floor':'4/5','X_gain_floor':'9/10','Y_gain_floor':'4/5','tan_phase_radius':'1/100','error_target':'1/100'},
         'frontiers':rows,'calibration_allocations':calibration,'feedback_time_example':clock,
         'no_feedback_advantage_example':no_gain,
         'proof_scope':'Fixed-angle common-sign reader class; two distinct phase-control timing parents. No general hardware optimum.'}
    (Path(__file__).parent/'results.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
    print(json.dumps(out,indent=2,default=str))

if __name__=='__main__':main()
