"""Exact schedule ordering and finite continuous-menu calibration interfaces.

Angles in the ordering routines are rational turns of the projective circle:
1 turn = pi radians. This is a declared slew-limited phase actuator with known
outcome-polarity recoding, not a per-copy Hamiltonian pulse.
"""
from fractions import Fraction as F
from itertools import permutations
from math import comb

def distance(x,y):
    d=(F(x)-F(y))%1
    return min(d,1-d)

def path_length(order,start=F(0)):
    total=F(0);last=F(start)%1
    for point in order:
        total+=distance(last,point);last=F(point)%1
    return total

def ordered_schedule(points,start=F(0)):
    """Return globally minimum open slew among schedule permutations.

    Multiplicities are retained and can be measured consecutively at no
    additional slew. Angle-dependent trial dwell costs are separate.
    """
    points=tuple(F(x)%1 for x in points);start=F(start)%1
    unique=sorted(set(points+(start,)))
    if len(unique)==1:return {'distance':F(0),'order':points,'omitted_gap':F(1)}
    candidates=[]
    for i,left in enumerate(unique):
        right=unique[(i+1)%len(unique)];gap=(right-left)%1;length=1-gap
        u=(start-right)%1
        assert 0<=u<=length
        coords={p:(p-right)%1 for p in unique}
        if u<=length-u:
            order=sorted((p for p in unique if coords[p]<=u),key=lambda p:-coords[p])
            order+=sorted((p for p in unique if coords[p]>u),key=lambda p:coords[p])
        else:
            order=sorted((p for p in unique if coords[p]>=u),key=lambda p:coords[p])
            order+=sorted((p for p in unique if coords[p]<u),key=lambda p:-coords[p])
        expanded=[]
        for p in order:expanded.extend([p]*points.count(p))
        cost=length+min(u,length-u)
        # Shortest segment lifts may cross the nominated omitted gap. The
        # minimum candidate still matches the global open-path theorem.
        actual=path_length(expanded,start)
        candidates.append((cost,actual,tuple(expanded),gap))
    best=min(candidates)
    assert best[0]==best[1]
    return {'distance':best[0],'order':best[2],'omitted_gap':best[3]}

def calibration_allocation(k,u,w):
    """Four M-probe batches; failure <=2^-k by two Hoeffding allocations.

    Z is in [-1,1]; its four means determine two sinusoids. The common click
    rate is pooled over all 4M independent probes. No per-angle calibration
    extrapolation is valid without the stated sinusoidal effect promise.
    """
    u,w=F(u),F(w)
    if type(k)is not int or k<1 or not 0<u<=1 or not 0<w<=1:raise ValueError('valid confidence parameters')
    bound=max(2*F(k+4)/u**2,F(k+2)/(8*w**2))
    m=-((-bound.numerator)//bound.denominator)
    assert F(m)*u*u/2>=k+4 and 8*F(m)*w*w>=k+2
    return {'failure_upper':F(1,2**k),'per_batch':m,'batches':4,'trusted_probes':4*m,
            'signed_mean_radius':u,'pooled_efficiency_radius':w}

def row_tv(eta_difference,mean_difference):
    e,m=abs(F(eta_difference)),abs(F(mean_difference))
    return (e+max(e,m))/2

def record_transfer(horizon,kappa):
    if type(horizon)is not int or horizon<0 or not 0<=kappa<=1:raise ValueError('physical horizon and row distance')
    return 1-(1-F(kappa))**horizon

def dyadic(kappa_lower,kappa_upper,budget,risk0,target,alpha):
    """Conservative decision-risk guarantee from an outward kappa interval."""
    low=record_transfer(budget,kappa_lower);high=record_transfer(budget,kappa_upper)
    return {'record_tv_interval':[low,high],
            'joint_accept_and_error_upper':F(risk0)+high+F(alpha),
            'target_certified':F(risk0)+high+F(alpha)<=F(target)}
