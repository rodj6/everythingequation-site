"""Exact same-class robust fixed-prior local-effect certificate."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json
from ppt_certificate import sqrt_bounds,certify_click

def objectives(n,a,b,t):
 d=2*(1+t*t);dot=-2*a*b*t/(1+t*t);p=(b*b-dot)/(a*a+b*b-2*dot)
 ux,uz=a*(1-t)/d,-a*(1+t)/d;vx,vz=b*(1-t)/d,b*(1+t)/d
 root=sqrt_bounds(d);out={}
 for i in range(n+1):
  for j in range(n-i+1):
   deg=i+j
   if deg%2:
    coef=2*comb(n,i)*comb(n-i,j)*(p*ux**i*uz**j+(1-p)*vx**i*vz**j)*d**((deg-1)//2)
    out[i,j]=min(coef*root[0],coef*root[1]),max(coef*root[0],coef*root[1])
 return out

def certify(c):
 a,b,t,eta=map(F,[c[x]for x in ['gain_x','gain_y','tan_delta','eta']]);B=c['horizon']
 assert(a,b,t,eta,B)==(F(9,10),F(4,5),F(1,100),F(4,5),15)
 clicks=[{'n':0,'error_lower':'1/2','display_error_lower':.5}]
 for n in range(1,B+1):clicks.append(certify_click(n,None,c['clicks'][str(n)],objectives(n,a,b,t)))
 e=sum((comb(B,n)*eta**n*(1-eta)**(B-n)*F(clicks[n]['error_lower'])for n in range(B+1)),F(0))
 return {'status':'PASS','horizon':B,'error_lower':str(e),'display_error_lower':float(e),
   'excludes_one_percent':e>F(1,100),'click_certificates':clicks,
   'scope':'Every full-equatorial local robust adaptive/nonadaptive reader under original fixed-nuisance contract; fixed hidden axis prior from tenth convex-hull theorem. Not local attainment.'}
def main():
 here=Path(__file__).resolve().parent;c=json.loads((here/'robust_ppt_certificate.json').read_text());r=certify(c)
 assert r['excludes_one_percent']
 (here/'robust_results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='click_certificates'},indent=2))
if __name__=='__main__':main()
