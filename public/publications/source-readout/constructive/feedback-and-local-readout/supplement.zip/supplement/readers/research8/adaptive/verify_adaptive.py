"""Exact production certificate checks plus structurally different small-tree reference."""
from fractions import Fraction as F
from itertools import product
from functools import lru_cache
from pathlib import Path
import json,sys
from adaptive_reader import Reader,verify_certificate,fixed_randomized,kernel

# Independent reference uses normalized rational PRIOR vectors and no likelihood
# gcd normalizer or certificate values. Bayes optimality over complete trees.
def prior_reference(B,eta,v):
    def probs(h,a):
        r=(1 if h%2==0 else -1)if h//2==a else 0
        return(eta*(1+v*r)/2,eta*(1-v*r)/2,1-eta)
    @lru_cache(None)
    def rec(t,prior):
        if not t:return min(prior[0]+prior[2],prior[1]+prior[3])
        acts=[]
        for a in range(2):
            risk=F(0)
            for o in range(3):
                weights=tuple(prior[h]*probs(h,a)[o]for h in range(4));mass=sum(weights)
                if mass:risk+=mass*rec(t-1,tuple(x/mass for x in weights))
            acts.append(risk)
        return min(acts)
    return rec(B,(F(1,4),)*4)

root=Path(__file__).parent
rows=[];certs=[];reference_cases=0
for eta,v,maxb in [(F(1),F(1),16),(F(4,5),F(9,10),19),(F(2,3),F(3,4),8),(F(0),F(1),4),(F(1),F(0),4)]:
    r=Reader(eta,v)
    for b in range(maxb+1):
        data=r.solve(b)
        if eta==v==1:assert F(data['minimax_error'])==(F(1,2)if b==0 else F(1,4)if b==1 else F(1,2**b))
        if eta==0 or v==0:assert F(data['minimax_error'])==F(1,2)
        assert F(data['minimax_error'])<=F(fixed_randomized(b,eta,v)['error'])
        if b<=5:
            assert F(data['minimax_error'])==prior_reference(b,eta,v);reference_cases+=1
        if b in [4,8,12,18,19]or(b in[0,1,2,3] and eta==v==1):
            data['randomized_nonadaptive']=fixed_randomized(b,eta,v);rows.append(data)
    if eta==F(4,5)and v==F(9,10):
        for b in [4,8,12,19]:
            cert=Reader(eta,v).solve(b,True)
            cert=json.loads(json.dumps(cert))
            assert verify_certificate(cert)
            certs.append(cert)
        bad=json.loads(json.dumps(certs[1]));bad['nodes'][-1]['value']='999'
        try:verify_certificate(bad)
        except AssertionError:pass
        else:raise AssertionError('tampered certificate accepted')
for bad in [(-1,F(1)),(F(2),F(1)),(F(1),-1)]:
    try:Reader(*bad)
    except ValueError:pass
    else:raise AssertionError('invalid model accepted')
assert Reader().action(3,(0,0,0,0))==0
assert Reader().decide_plus((0,0,0,0))==F(1,2)
a18=F(Reader(F(4,5),F(9,10)).solve(18)['minimax_error'])
a19=F(Reader(F(4,5),F(9,10)).solve(19)['minimax_error'])
n20=fixed_randomized(20,F(4,5),F(9,10));n21=fixed_randomized(21,F(4,5),F(9,10))
assert a18>F(1,100)>a19 and F(n20['error'])>F(1,100)>F(n21['error'])
threshold={'target':'1/100','eta':'4/5','visibility':'9/10',
           'adaptive_minimum_copies':19,'adaptive_at18':str(a18),'adaptive_at19':str(a19),
           'randomized_nonadaptive_minimum_copies':21,'nonadaptive_at20':n20,'nonadaptive_at21':n21,
           'minimum_argument':'risk cannot increase with extra copies, since a policy may ignore their outcomes'}
result={'status':'PASS: exact Bellman certificates, direct policy risks, independent prior DP',
        'reference_cases':reference_cases,'model_horizon_checks':17+20+9+5+5,
        'certificate_horizons':[4,8,12,19], 'noise_copy_threshold':threshold, 'rows':rows}
(root/'results.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'certificates.json').write_text(json.dumps(certs,separators=(',',':'))+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
