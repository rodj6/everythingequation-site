"""Independent finite exact check of the normalized symmetric-power entry formula.

Uses direct tensor-basis sums; does not call the supplied polynomial generator.
This supports a formula audit, not general proof or physical attainability.
"""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json
cases=0
for s in range(0,7):
 words=list(product((0,1),repeat=s))
 for x,z in [(F(1,5),F(1,7)),(F(-2,5),F(3,11)),(F(0),F(-1,2))]:
  A=((1+z,x),(x,1-z))
  for k in range(s+1):
   for l in range(s+1):
    direct=F(0)
    for out in words:
     if sum(out)!=k:continue
     for inn in words:
      if sum(inn)!=l:continue
      p=F(1)
      for o,i in zip(out,inn):p*=A[o][i]
      direct+=p
    # Common normalization is sqrt(C(s,k) C(s,l)); multiplying the
    # manuscript's sqrt(C(s,k)/C(s,l)) entry yields C(s,k)*polynomial.
    polynomial=sum(F(comb(k,q)*comb(s-k,l-q))*x**(k+l-2*q)*(1+z)**(s-k-l+q)*(1-z)**q for q in range(max(0,k+l-s),min(k,l)+1))
    assert direct==comb(s,k)*polynomial,(s,k,l,x,z,direct,polynomial)
    cases+=1
out={'status':'PASS','exact_entry_cases':cases,'max_symmetric_power':6,'independent_method':'Direct rational tensor-basis sums, compared after multiplication by common positive Dicke normalization. No supplied generator imported.','scope':'Finite formula check only; general representation and reader constraints remain analytical.'}
Path(__file__).with_name('schur_coefficient_identity_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
