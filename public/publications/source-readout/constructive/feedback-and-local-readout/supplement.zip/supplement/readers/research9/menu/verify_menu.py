"""Exact reference checks, full finite-menu frontiers and saved certificates."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import sys,json,copy,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research9.menu.expanded_reader import Reader,DEFAULT,kernel,fixed_optimum,fixed_bayes,verify_certificate

def reference(t,prior,menu,eta,v):
    # Separate normalized-posterior recursion, probabilities rather than integer-gcd weights.
    @lru_cache(None)
    def rec(t,pi):
        if not t:return min(pi[0]+pi[2],pi[1]+pi[3])
        costs=[]
        for c,s in menu:
            risk=F(0)
            for o in (1,-1,0):
                probs=tuple((1-eta)if not o else eta*(1+o*v*r)/2 for r in(c,-c,s,-s))
                mass=sum((x*y for x,y in zip(pi,probs)),F(0))
                if mass:risk+=mass*rec(t-1,tuple(x*y/mass for x,y in zip(pi,probs)))
            costs.append(risk)
        return min(costs)
    return rec(t,prior)

def ordered_fixed(counts,eta,v):
    sequence=[a for a,n in enumerate(counts)for _ in range(n)]
    risk=F(0)
    for word in product((1,-1,0),repeat=sum(counts)):
        w=[F(1,4)]*4
        for a,o in zip(sequence,word):
            c,s=DEFAULT[a]
            probs=tuple(1-eta if not o else eta*(1+o*v*r)/2 for r in(c,-c,s,-s))
            w=[x*y for x,y in zip(w,probs)]
        risk+=min(w[0]+w[2],w[1]+w[3])
    return risk

def main():
    start=time.monotonic();reference_cases=fixed_cases=0
    for eta,v in [(F(1),F(1)),(F(4,5),F(9,10)),(F(0),F(1)),(F(1),F(0))]:
        r=Reader(eta=eta,v=v)
        for b in range(4):
            for w in [(1,1,1,1),(1,2,3,4),(2,0,1,3)]:
                total=sum(w);got=r.value(b,w)/total
                assert got==reference(b,tuple(F(x,total)for x in w),DEFAULT,eta,v);reference_cases+=1
        for counts in [(1,0,1,1),(0,0,2,1),(0,1,0,2),(1,1,1,0)]:
            assert fixed_bayes(counts,eta=eta,v=v)==ordered_fixed(counts,eta,v);fixed_cases+=1
    for bad in [(),((F(1),F(0)),),((F(1),F(0)),(F(1),F(0)))]:
        try:Reader(menu=bad)
        except ValueError:pass
        else:raise AssertionError('invalid minimax menu accepted')
    rows=[];certs=[]
    r=Reader()
    for b in range(9):
        a=r.solve(b,certificate=b in(4,8));f=fixed_optimum(b)
        assert F(a['minimax_error'])<=F(f['minimax_error'])
        if b in(4,8):
            assert verify_certificate(a);certs.append(a)
        rows.append({k:v for k,v in a.items()if k not in('bellman','kernel','denominator')}|{'randomized_nonadaptive':f})
    bad=copy.deepcopy(certs[0]);bad['bellman'][-1]['value']='9'
    try:verify_certificate(bad)
    except AssertionError:pass
    else:raise AssertionError('forged value accepted')
    # Nominal threshold is a complete exact finite computation, not a grid of measurement directions.
    threshold=[]
    for b in(13,14):
        a=r.solve(b);f=fixed_optimum(b)
        assert (F(a['minimax_error'])<F(1,100))==(b==14)
        assert (F(f['minimax_error'])<F(1,100))==(b==14)
        threshold.append({'horizon':b,'adaptive':a,'randomized_nonadaptive':f})
    answer={'status':'PASS','reference_cases':reference_cases,'ordered_histogram_checks':fixed_cases,
            'certificate_horizons':[4,8],'rows':rows,'threshold':threshold,
            'one_percent_minimum_copies':{'adaptive':14,'randomized_nonadaptive':14},
            'seconds':time.monotonic()-start,'scope':'Exact four-action rational menu, not all equatorial angles.'}
    explicit15=fixed_bayes((0,0,7,8))
    assert explicit15<F(9,1000)
    assert F(threshold[0]['adaptive']['minimax_error'])>F(9,1000)
    assert F(threshold[1]['adaptive']['minimax_error'])<F(9,1000)<F(threshold[1]['randomized_nonadaptive']['minimax_error'])
    answer['tighter_target_example']={'target_error':'9/1000','adaptive_minimum_copies':14,
        'randomized_nonadaptive_minimum_copies':15,'explicit_attaining_nonadaptive_counts':[0,0,7,8],
        'explicit_attaining_nonadaptive_error':str(explicit15),
        'status':'Target selected transparently within the certified risk-gap interval; not a universal copy gain.'}
    here=Path(__file__).resolve().parent
    (here/'results.json').write_text(json.dumps(answer,indent=2)+'\n')
    (here/'certificates.json').write_text(json.dumps(certs,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in answer.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
