"""Exact fixed-schedule phase-reader design with primal/dual certificates.

Conventional quantum probabilities, independent copies, calibrated noisy Pauli
readers. This is not an implementation of the ETH contraction algorithm.
Only Python's standard library is required.
"""
from fractions import Fraction as F
from math import factorial
from itertools import product
if not __debug__:raise RuntimeError('Do not disable exact certificate assertions.')

LABELS=('X+','X-','Y+','Y-')

def multinomial(n,p):
    """Distribution of (plus,minus,null) histograms, all nulls retained."""
    out={}
    for a in range(n+1):
        for b in range(n-a+1):
            c=n-a-b
            value=F(factorial(n),factorial(a)*factorial(b)*factorial(c))
            value*=p[0]**a*p[1]**b*p[2]**c
            if value:out[a,b,c]=value
    assert sum(out.values(),F(0))==1
    return out

def reader_probs(h,axis,eta=F(1),visibility=F(1)):
    eta,visibility=F(eta),F(visibility)
    if not 0<=eta<=1 or not 0<=visibility<=1:raise ValueError('physical eta,v in [0,1]')
    signal=(1 if h[1]=='+' else -1) if h[0]==axis else 0
    return (eta*(1+visibility*signal)/2,eta*(1-visibility*signal)/2,1-eta)

def experiment(nx,ny,eta=F(1),visibility=F(1)):
    if nx<0 or ny<0:raise ValueError('nonnegative integer sample counts')
    axes={h:[multinomial(n,reader_probs(h,a,eta,visibility))
             for n,a in [(nx,'X'),(ny,'Y')]]for h in LABELS}
    records=set()
    per_label={}
    for h in LABELS:
        per_label[h]={x+y:px*py for x,px in axes[h][0].items()
                                for y,py in axes[h][1].items()}
        records.update(per_label[h])
    records=sorted(records)
    vectors={r:tuple(per_label[h].get(r,F(0))for h in LABELS)for r in records}
    return vectors

def flip(r):return (r[1],r[0],r[2],r[4],r[3],r[5])

def errors(vectors,policy):
    e=[F(0)]*4
    for r,probs in vectors.items():
        q=policy[r]
        for j,p in enumerate(probs):e[j]+=p*((1-q)if j in (0,2)else q)
    return tuple(e)

def bayes_bound(vectors,alpha):
    """Least-favourable prior weights alpha/2,alpha/2,(1-alpha)/2,(1-alpha)/2."""
    return sum((min(alpha*p[0]+(1-alpha)*p[2],
                    alpha*p[1]+(1-alpha)*p[3])/2
                for p in vectors.values()),F(0))

def minimax(nx,ny,eta=F(1),visibility=F(1),include_policy=True):
    vectors=experiment(nx,ny,eta,visibility)
    roots={F(0),F(1)}
    for p in vectors.values():
        dx,dy=p[0]-p[1],p[2]-p[3]
        if dx!=dy:
            a=-dy/(dx-dy)
            if 0<=a<=1:roots.add(a)
    # Concave piecewise-linear Bayes risk has no untested interior maximum.
    candidates=sorted((bayes_bound(vectors,a),a)for a in roots)
    optimum,alpha=candidates[-1]
    policies=[]
    for minimize_difference in [True,False]:
        q={}
        for r,p in vectors.items():
            dx,dy=p[0]-p[1],p[2]-p[3]
            score=alpha*dx+(1-alpha)*dy
            if score:q[r]=F(int(score>0))
            else:
                coefficient=-(dx-dy)/2
                q[r]=F(int(coefficient<0 if minimize_difference else coefficient>0))
        # Enforce sign covariance; this preserves both axis-averaged risks.
        q={r:(q[r]+1-q[flip(r)])/2 for r in vectors}
        ex=errors(vectors,q)
        assert ex[0]==ex[1]and ex[2]==ex[3]
        assert alpha*ex[0]+(1-alpha)*ex[2]==optimum
        policies.append((ex[0]-ex[2],q))
    dlo,qlo=policies[0];dhi,qhi=policies[1]
    assert dlo<=dhi
    if alpha==0:
        assert dlo<=0;q=qlo
    elif alpha==1:
        assert dhi>=0;q=qhi
    elif dhi==dlo:
        assert dlo==0;q=qlo
    else:
        assert dlo<=0<=dhi
        t=-dlo/(dhi-dlo)
        q={r:(1-t)*qlo[r]+t*qhi[r]for r in vectors}
    ex=errors(vectors,q)
    assert max(ex)==optimum
    result=dict(nx=nx,ny=ny,eta=str(F(eta)),visibility=str(F(visibility)),
                minimax_error=str(optimum),error_float=float(optimum),
                least_favourable_axis_prior=str(alpha),individual_errors=list(map(str,ex)),
                histogram_records=len(vectors),breakpoints=len(roots),
                exact_primal_dual_gap='0')
    if include_policy:
        result['certificate']=[dict(record=list(r),probabilities=list(map(str,vectors[r])),
                                    decide_plus=str(q[r]))for r in vectors]
    return result

def optimum_at_budget(budget,eta=F(1),visibility=F(1),cx=1,cy=1):
    """Optimal fixed schedule under integer costs and an at-most budget."""
    rows=[minimax(nx,ny,eta,visibility,False)
          for nx in range(budget//cx+1)
          for ny in range((budget-cx*nx)//cy+1)]
    best=min(F(r['minimax_error'])for r in rows)
    return dict(budget=budget,costs=[cx,cy],error=str(best),
                schedules=[[r['nx'],r['ny']]for r in rows if F(r['minimax_error'])==best],
                admitted_schedules=len(rows))

def decision_probability(certificate,record):
    """Complete terminal decoder; absent (nominal-zero) records default to plus."""
    for row in certificate['certificate']:
        if tuple(row['record'])==tuple(record):return F(row['decide_plus'])
    return F(1)

if __name__=='__main__':
    import argparse,json
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--nx',type=int,default=1);ap.add_argument('--ny',type=int,default=7)
    ap.add_argument('--eta',default='1');ap.add_argument('--visibility',default='1')
    args=ap.parse_args()
    print(json.dumps(minimax(args.nx,args.ny,F(args.eta),F(args.visibility)),indent=2))
