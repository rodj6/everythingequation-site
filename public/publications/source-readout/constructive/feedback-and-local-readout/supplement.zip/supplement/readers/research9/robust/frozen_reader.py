"""Exact quadratic-field certificates for a frozen robust equatorial reader.

Arithmetic uses only fractions, integers and exact square-root enclosures.
The minimax theorem covers the declared common-positive fixed-angle class,
not arbitrary adaptive equatorial measurements.
"""
from fractions import Fraction as F
from math import comb,isqrt

def add(x,y):return x[0]+y[0],x[1]+y[1]
def scale(x,k):return x[0]*k,x[1]*k
def mul(x,y,q):return x[0]*y[0]+q*x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def power(x,n,q):
    out=(F(1),F(0))
    for _ in range(n):out=mul(out,x,q)
    return out

def click_error(n,q):
    """A+B*sqrt(q): exact fair-tie majority error for n signs."""
    q=F(q)
    if type(n)is not int or n<0 or not 0<=q<=1:raise ValueError('physical bias and horizon')
    p=(F(1,2),F(1,2));r=(F(1,2),F(-1,2));out=(F(0),F(0))
    for k in range((n-1)//2+1):
        out=add(out,scale(mul(power(p,k,q),power(r,n-k,q),q),comb(n,k)))
    if n%2==0:out=add(out,scale(mul(power(p,n//2,q),power(r,n//2,q),q),F(comb(n,n//2),2)))
    return out

def trial_error(budget,eta,q):
    eta,q=F(eta),F(q)
    if type(budget)is not int or budget<0 or not 0<=eta<=1:raise ValueError('physical efficiency and horizon')
    out=(F(0),F(0))
    for n in range(budget+1):out=add(out,scale(click_error(n,q),comb(budget,n)*eta**n*(1-eta)**(budget-n)))
    return out

def root_interval(q,bits=96):
    q=F(q)
    if q<0 or type(bits)is not int or bits<1:raise ValueError('nonnegative rational and positive precision')
    den=1<<bits;v=isqrt((q.numerator<<(2*bits))//q.denominator)
    lo=F(v,den)
    hi=lo if lo*lo==q else F(v+1,den)
    assert lo*lo<=q<=hi*hi
    return lo,hi

def enclosure(value,q,bits=96):
    a,b=value;lo,hi=root_interval(q,bits)
    return (a+b*lo,a+b*hi)if b>=0 else(a+b*hi,a+b*lo)

def at_most(value,q,target):
    """Exact comparison A+B*sqrt(q) <= target, no floating arithmetic."""
    a,b=value;target,q=F(target),F(q)
    if b==0:return a<=target
    if b>0:return target>=a and b*b*q<=(target-a)**2
    return a<=target or (a-target)**2<=b*b*q

def optimal_tangent(a,b,t):
    a,b,t=map(F,(a,b,t))
    if not 0<a<=1 or not 0<b<=1 or not 0<=t<1:raise ValueError('positive gain floors and tan phase radius in [0,1)')
    return (a+b*t)/(b+a*t)

def optimal_bias_squared(a,b,t):
    a,b,t=map(F,(a,b,t));optimal_tangent(a,b,t)
    return a*a*b*b*(1-t*t)**2/((1+t*t)*((a*a+b*b)*(1+t*t)+4*a*b*t))

def bisector_bias_squared(a,b,t):
    a,b,t=map(F,(a,b,t));optimal_tangent(a,b,t)
    return min(a,b)**2*(1-t)**2/(2*(1+t*t))

def certificate(budget,eta,q):
    value=trial_error(budget,eta,q);lo,hi=enclosure(value,q)
    return {'trials':budget,'eta':str(eta),'bias_squared':str(q),
            'error':{'rational_part':str(value[0]),'root_coefficient':str(value[1]),'radicand':str(q)},
            'lower':str(lo),'upper':str(hi),'lower_float':float(lo),'upper_float':float(hi),
            'at_most_one_percent':at_most(value,q,F(1,100)),
            'scope':'Fixed common-positive equatorial angle; unknown fixed gains/phase; sign-blind independent erasures.'}

def threshold(eta,q,target=F(1,100),maximum=200):
    for budget in range(maximum+1):
        if at_most(trial_error(budget,eta,q),q,target):return budget
    return None

def pauli_probabilities(gx,gy):
    gx,gy=F(gx),F(gy)
    if not 0<=gx<=1 or not 0<=gy<=1:raise ValueError('gains in [0,1]')
    gz=gx*gy
    p=((1+gx+gy+gz)/4,(1+gx-gy-gz)/4,(1-gx+gy-gz)/4,(1-gx-gy+gz)/4)
    assert all(x>=0 for x in p)and sum(p)==1
    return gz,p
