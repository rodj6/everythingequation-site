"""Exact expanded rational equatorial reader menu; no continuous optimum claim."""
from fractions import Fraction as F
from functools import reduce,lru_cache
from math import gcd,lcm,factorial
from itertools import product

DEFAULT=((F(1),F(0)),(F(0),F(1)),(F(3,5),F(4,5)),(F(4,5),F(3,5)))

def normalize(w):
    g=reduce(gcd,w)
    return (g,tuple(x//g for x in w))if g else (0,(0,0,0,0))

def kernel(menu=DEFAULT,eta=F(4,5),v=F(9,10)):
    eta,v=F(eta),F(v)
    if not 0<=eta<=1 or not 0<=v<=1:raise ValueError('physical eta/v')
    rows=[]
    for c,s in menu:
        c,s=F(c),F(s)
        if c*c+s*s!=1:raise ValueError('unit equatorial direction required')
        r=(c,-c,s,-s)
        rows.append(tuple(tuple(eta*(1+sign*v*x)/2 for x in r)for sign in (1,-1))+((1-eta,)*4,))
    D=lcm(*(p.denominator for a in rows for o in a for p in o))
    return D,tuple(tuple(tuple(int(p*D)for p in o)for o in a)for a in rows)

class Reader:
    def __init__(self,menu=DEFAULT,eta=F(4,5),v=F(9,10)):
        self.menu=tuple(tuple(map(F,a))for a in menu);self.eta=F(eta);self.v=F(v)
        if not self.menu or len(set(self.menu))!=len(self.menu):raise ValueError('nonempty distinct menu')
        if any((s,c)not in self.menu for c,s in self.menu):
            raise ValueError('minimax interface requires exact closure under axis swap')
        self.D,self.k=kernel(self.menu,self.eta,self.v);self.nodes={}
    def value(self,t,w=(1,1,1,1)):
        if type(t)is not int or t<0:raise ValueError('nonnegative horizon')
        if len(w)!=4 or any(type(x)is not int or x<0 for x in w):raise ValueError('nonnegative integer weights')
        g,w=normalize(w)
        if not g:return F(0)
        key=t,w
        if key not in self.nodes:
            if t==0:self.nodes[key]=(F(min(w[0]+w[2],w[1]+w[3])),None,None)
            else:
                vals=tuple(sum((self.value(t-1,tuple(x*y for x,y in zip(w,p)))for p in a),F(0))/self.D for a in self.k)
                action=min(range(len(vals)),key=vals.__getitem__)
                self.nodes[key]=(vals[action],action,vals)
        return g*self.nodes[key][0]
    def action(self,t,w):
        if type(t)is not int or t<=0:raise ValueError('positive remaining horizon required')
        if not any(w):return 0 # total policy default on nominally impossible histories
        self.value(t,w)
        return self.nodes[t,normalize(w)[1]][1]
    def solve(self,t,certificate=False):
        val=self.value(t)/4
        errors=self.base_errors(t)
        assert sum(errors,F(0))/4==val
        ans={'horizon':t,'eta':str(self.eta),'visibility':str(self.v),'menu':[[str(x)for x in a]for a in self.menu],
             'minimax_error':str(val),'error_float':float(val),'nodes':len(self.nodes),
             'base_policy_errors':list(map(str,errors)),'symmetrized_errors':[str(val)]*4,
             'symmetrization':'Uniform axis swap and global sign reversal; two fair root bits. Deterministic plus terminal ties.'}
        if certificate:
            ans['denominator']=self.D;ans['kernel']=self.k
            ans['bellman']=[{'t':t,'weights':w,'value':str(v),'action':a,'actions':None if av is None else list(map(str,av))}
                           for(t,w),(v,a,av)in sorted(self.nodes.items())]
        return ans
    def base_errors(self,t):
        self.value(t)
        @lru_cache(None)
        def risk(t,w):
            if not t or not any(w):
                q=F(w[0]+w[2]>=w[1]+w[3])
                return (1-q,q,1-q,q)
            a=self.nodes[t,w][1];out=[F(0)]*4
            for p in self.k[a]:
                g,z=normalize(tuple(x*y for x,y in zip(w,p)))
                if g:
                    e=risk(t-1,z)
                    for h in range(4):out[h]+=F(p[h],self.D)*e[h]
            return tuple(out)
        return risk(t,(1,1,1,1))

def compositions(n,m):
    if m==1:yield(n,);return
    for a in range(n+1):
        for rest in compositions(n-a,m-1):yield(a,)+rest

def histogram_rows(n,axis):
    out=[]
    for plus in range(n+1):
        for minus in range(n-plus+1):
            null=n-plus-minus
            mult=factorial(n)//(factorial(plus)*factorial(minus)*factorial(null))
            w=tuple(axis[0][h]**plus*axis[1][h]**minus*axis[2][h]**null for h in range(4))
            if any(w):out.append((mult,w))
    return out

def fixed_bayes(counts,menu=DEFAULT,eta=F(4,5),v=F(9,10)):
    D,k=kernel(menu,eta,v);total=0
    for choices in product(*(histogram_rows(n,a)for n,a in zip(counts,k))):
        mult=1;w=[1]*4
        for c,z in choices:
            mult*=c;w=[x*y for x,y in zip(w,z)]
        total+=mult*min(w[0]+w[2],w[1]+w[3])
    return F(total,4*D**sum(counts))

def fixed_optimum(t,menu=DEFAULT,eta=F(4,5),v=F(9,10)):
    # Action order does not matter for the conditional product preparation/noise law.
    if not menu or any((s,c)not in menu for c,s in menu):raise ValueError('axis-swap closed menu required')
    if type(t)is not int or t<0:raise ValueError('nonnegative horizon')
    rows=[(fixed_bayes(c,menu,eta,v),c)for c in compositions(t,len(menu))]
    best=min(v for v,_ in rows)
    return {'minimax_error':str(best),'error_float':float(best),'counts':[c for v,c in rows if v==best],
            'schedules_checked':len(rows)}

def verify_certificate(cert):
    menu=tuple(tuple(map(F,a))for a in cert['menu'])
    assert menu and all((s,c)in menu for c,s in menu)
    D,k=kernel(menu,F(cert['eta']),F(cert['visibility']))
    assert D==cert['denominator'] and [[list(o)for o in a]for a in k]==[[list(o)for o in a]for a in cert['kernel']]
    nodes={}
    for row in cert['bellman']:
        key=row['t'],tuple(row['weights']);assert key not in nodes and normalize(key[1])==(1,key[1]);nodes[key]=row
    for(t,w),row in sorted(nodes.items()):
        if not t:assert F(row['value'])==min(w[0]+w[2],w[1]+w[3])and row['action']is None and row['actions']is None;continue
        vals=[]
        for axis in k:
            val=F(0)
            for p in axis:
                g,z=normalize(tuple(x*y for x,y in zip(w,p)))
                if g:val+=g*F(nodes[t-1,z]['value'])
            vals.append(val/D)
        assert vals==list(map(F,row['actions']))
        assert type(row['action'])is int and 0<=row['action']<len(k)
        assert F(row['value'])==min(vals)==vals[row['action']]
    assert F(nodes[cert['horizon'],(1,1,1,1)]['value'])/4==F(cert['minimax_error'])
    @lru_cache(None)
    def risk(t,w):
        if not t or not any(w):
            q=F(w[0]+w[2]>=w[1]+w[3]);return(1-q,q,1-q,q)
        out=[F(0)]*4
        for p in k[nodes[t,w]['action']]:
            g,z=normalize(tuple(x*y for x,y in zip(w,p)))
            if g:
                e=risk(t-1,z)
                for h in range(4):out[h]+=F(p[h],D)*e[h]
        return tuple(out)
    e=risk(cert['horizon'],(1,1,1,1))
    assert e==tuple(map(F,cert['base_policy_errors']))
    assert sum(e,F(0))/4==F(cert['minimax_error'])
    assert list(map(F,cert['symmetrized_errors']))==[sum(e,F(0))/4]*4
    return True

if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--horizon',type=int,default=4)
    p.add_argument('--eta',default='4/5');p.add_argument('--visibility',default='9/10');p.add_argument('--certificate',action='store_true')
    a=p.parse_args();r=Reader(eta=F(a.eta),v=F(a.visibility)).solve(a.horizon,a.certificate)
    r['randomized_nonadaptive']=fixed_optimum(a.horizon,eta=F(a.eta),v=F(a.visibility))
    print(json.dumps(r,indent=2))
