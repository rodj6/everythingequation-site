"""Independent exact geometry tests and full rational adaptive-policy checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json,copy
HERE=Path(__file__).resolve().parent

def root_sign(a,b):
    # Sign of a+b*sqrt(2), determined only by rational squaring.
    a,b=F(a),F(b)
    if not b:return(a>0)-(a<0)
    if not a:return(b>0)-(b<0)
    sa=(a>0)-(a<0);sb=(b>0)-(b<0)
    if sa==sb:return sa
    d=a*a-2*b*b;return sa*((d>0)-(d<0))

def circle(t):
    t=F(t);return(1-t*t)/(1+t*t),2*t/(1+t*t)

def check_mixed(c,s,p,q,u):
    # Rigorous check of |A+B|+sqrt(2-2uC+u²Q) <= sqrt2(3-u/2).
    S=abs(c+s+p+q);C=c*p+s*q;Q=c*c*p*p+s*s*q*q;K=3-u/2
    Z=2-2*u*C+u*u*Q
    assert root_sign(-S,K)>=0
    assert root_sign(2*K*K+S*S-Z,-2*K*S)>=0

def reference_policy(cert):
    eta,v=F(cert['eta']),F(cert['visibility']);node=cert['nodes'];leaves=cert['leaves']
    def key(prefix):return ','.join(map(str,prefix))
    risk=[F(0)]*4;mass=[F(0)]*4;checked=0
    for word in product([1,-1,0],repeat=4):
        probs=[F(1)]*4
        for t,o in enumerate(word):
            c,s=map(F,node[key(word[:t])]['direction']);assert c*c+s*s==1
            for h,signal in enumerate((c,-c,s,-s)):
                probs[h]*=(1-eta)if not o else eta*(1+o*v*signal)/2
        decision=leaves[key(word)]['decision'];assert decision in(-1,1)
        for h in range(4):
            mass[h]+=probs[h]
            if decision!=(1 if h%2==0 else-1):risk[h]+=probs[h]
        checked+=1
    assert mass==[F(1)]*4
    assert list(map(str,risk))==cert['base_label_errors']
    assert str(sum(risk)/4)==cert['minimax_attainable_upper']
    # Explicitly transform source labels for each of the four physical root
    # symmetries, retaining the root seed for decoder and controller.
    equal=[]
    for h in range(4):
        values=[]
        for swap in (0,1):
            for flip in (0,1):
                transformed=2*((h//2)^swap)+((h%2)^flip)
                values.append(risk[transformed])
        equal.append(sum(values)/4)
    assert equal==[sum(risk)/4]*4
    return risk,checked

def main():
    geometry=0
    for t in [F(-3),F(-1),F(-2,3),F(-1,5),F(0),F(1,5),F(2,3),F(1),F(3)]:
        c,s=circle(t)
        for z in [F(-2),F(-1),F(-1,2),F(0),F(1,3),F(1),F(2)]:
            p,q=circle(z)
            for u in [F(0),F(1,10),F(1,2),F(81,100),F(1)]:
                check_mixed(c,s,p,q,u)
                check_mixed(c,s,-p,-q,u);geometry+=2
                # Both square-root branches have sum <=2sqrt(2+u²).
                assert 4*(2+u*u)<=2*(3-u/2)**2
    cases=[]
    for name,upper in [('ideal',F(30605,1000000)),('nominal',F(103471,1000000))]:
        c=json.loads((HERE/(name+'_four_policy.json')).read_text())
        r,n=reference_policy(c);e=sum(r)/4;assert e<upper
        cases.append({'mode':name,'status':'PASS','ordered_words':n,'exact_error':str(e),
            'error_float':float(e),'rational_upper':str(upper),
            'all_retained_word_masses':'normalized for each of four source labels',
            'root_symmetrized_label_risks':list(map(str,[e]*4))})
    # Independent direct majority click-mixture coefficient check at B3.
    eta,v=F(4,5),F(9,10)
    coeff=-(3*eta-3*eta*eta+F(3,2)*eta**3)*v/4+eta**3*v**3/16
    assert coeff==F(-4023,15625)
    out={'status':'PASS','exact_mixed_geometry_checks':geometry,'four_copy_policies':cases,
        'B3_nominal_exact':{'rational':'1/2','sqrt2_coefficient':str(coeff)},
        'scope':'Analytical proof covers all continuous angles; finite exact tests validate algebra and frozen policy upper certificates, not search optimality.'}
    (HERE/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
