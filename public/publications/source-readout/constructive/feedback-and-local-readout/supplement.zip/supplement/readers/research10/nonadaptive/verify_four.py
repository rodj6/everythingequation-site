"""Exact all-angle nonadaptive four-copy lower certificate.

Every octree leaf is covered by rational interval arithmetic; float searches
are not used to accept any inequality. Standard library only.
"""
from fractions import Fraction as F
from math import prod,isqrt
from pathlib import Path
from itertools import product,permutations
from functools import lru_cache
import json,time
R=tuple(product((-1,1),repeat=4))
SUBSETS=((0,),(1,),(2,),(3,),(0,1,2),(0,1,3),(0,2,3),(1,2,3))
Z=(F(0),F(0))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def scale(q,a):return(q*a[0],q*a[1])if q>=0 else(q*a[1],q*a[0])
def mul(a,b):
 vals=(a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]);return min(vals),max(vals)
@lru_cache(None)
def cs(depth,k):
 den=1<<depth;l=F(2*k-den,den);u=F(2*(k+1)-den,den)
 c=lambda t:(1-t*t)/(1+t*t)
 s=lambda t:2*t/(1+t*t)
 return (min(c(l),c(u)),F(1)if l<=0<=u else max(c(l),c(u))),(s(l),s(u))
def sqrt_upper(q):
 scale=1<<60;k=isqrt(q.numerator*scale*scale//q.denominator)
 lo=F(k,scale)
 return lo if lo*lo==q else F(k+1,scale)
def bound(coeff,path):
 depth=len(path);indices=[0,0,0]
 for octant in path:
  for j in range(3):indices[j]=2*indices[j]+((octant>>j)&1)
 vals=[cs(depth,k)for k in indices];C=[x[0]for x in vals];S=[x[1]for x in vals]
 f0=Z;A=(coeff[3],coeff[3]);B=A
 for i in range(3):
  if coeff[i]:f0=add(f0,scale(coeff[i],add(C[i],S[i])))
 if coeff[4]:
  z=add(mul(mul(C[0],C[1]),C[2]),mul(mul(S[0],S[1]),S[2]));f0=add(f0,scale(coeff[4],z))
 for q,(i,j)in zip(coeff[5:],[(0,1),(0,2),(1,2)]):
  if q:A=add(A,scale(q,mul(C[i],C[j])));B=add(B,scale(q,mul(S[i],S[j])))
 r2=max(A[0]*A[0],A[1]*A[1])+max(B[0]*B[0],B[1]*B[1])
 return(f0[1]+sqrt_upper(r2))/2

def main():
 start=time.monotonic();p=Path(__file__).with_name('four_certificate.json');cert=json.loads(p.read_text())
 assert cert['correlation_upper']=='15/16' and cert['error_lower']=='1/32'
 all_decoders=set();seen=set();leafchecks=0;maxdepth=0;maxupper=F(0)
 for row in cert['classes']:
  values=tuple(row['table']);assert len(values)==16 and all(s in(-1,1)for s in values)
  D=dict(zip(R,values));assert all(D[tuple(-s for s in r)]==-D[r]for r in R)
  coeff=tuple(F(sum(D[r]*prod(r[i]for i in I)for r in R),16)for I in SUBSETS)
  assert list(map(str,coeff))==row['coefficients']
  flips=tuple(row['first_three_direction_signs']);assert len(flips)==3 and all(s in(-1,1)for s in flips)
  key=(values,flips);assert key not in seen;seen.add(key)
  coeff=tuple(q*prod(flips[i]for i in I if i<3)for q,I in zip(coeff,SUBSETS))
  assert list(map(str,coeff))==row['transformed_coefficients']
  leaves=set(row['leaves']);assert len(leaves)==len(row['leaves'])
  volume=F(0)
  for path in leaves:
   assert all(s in'01234567'for s in path)
   assert not any(path[:i]in leaves for i in range(len(path)))
   volume+=F(1,8**len(path));maxdepth=max(maxdepth,len(path))
   upper=bound(coeff,tuple(map(int,path)));assert upper<=F(15,16),(row['orbit'],path,str(upper))
   maxupper=max(maxupper,upper);leafchecks+=1
  assert volume==1
  # Sign/permutation orbit must be accounted exactly, not assumed from names.
  orbit=set()
  for perm in permutations(range(4)):
   for ss in product((-1,1),repeat=4):orbit.add(tuple(D[tuple(ss[i]*r[perm[i]]for i in range(4))]for r in R))
  assert len(orbit)==row['orbit'];all_decoders|=orbit
 assert len(all_decoders)==256
 representatives={k[0]for k in seen};assert len(representatives)==7
 assert all((rep,ss)in seen for rep in representatives for ss in product((-1,1),repeat=3))
 assert len(seen)==56
 out={'status':'PASS','all_odd_decoders_covered':256,'sign_permutation_orbits':7,
      'hemisphere_sign_variants':56,'exact_interval_leaves':leafchecks,'maximum_octree_depth':maxdepth,
      'correlation_upper':'15/16','all_continuous_nonadaptive_error_lower':'1/32',
      'maximum_exact_leaf_upper':str(maxupper),'seconds':time.monotonic()-start,
      'scope':'Ideal shared eta=v=1, B4. Covers all continuous local equatorial schedules and their randomization, with arbitrary terminal decision. Not exact optimum.'}
 Path(__file__).with_name('four_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
