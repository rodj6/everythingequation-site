"""Standard-library replay of robust convex geometry and rational certificates."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,random,copy
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from robust_global import *

def kron(A,B,d):
    return [[mul(A[i//len(B)][j//len(B)],B[i%len(B)][j%len(B)],d)
             for j in range(len(A)*len(B))]for i in range(len(A)*len(B))]
def matrix_linear(mats,cs):
    n=len(mats[0]);return [[sum_pairs([scale(A[i][j],c)for A,c in zip(mats,cs)])for j in range(n)]for i in range(n)]
def sum_pairs(xs):
    out=(F(0),F(0))
    for x in xs:out=add(out,x)
    return out

def main():
    rng=random.Random(101211);geom=identity=0
    I=[[(F(1),F(0)),(F(0),F(0))],[(F(0),F(0)),(F(1),F(0))]]
    for _ in range(100):
        a=F(rng.randrange(1,101),100);b=F(rng.randrange(1,101),100);t=F(rng.randrange(0,100),100)
        p=parameters(a,b,t);w=p['p'];dot=p['dot_uv'];m=p['m_squared']
        assert 0<w<1 and 0<m<=1
        z2=w*w*a*a+(1-w)**2*b*b+2*w*(1-w)*dot
        assert z2==m==w*a*a+(1-w)*dot==w*dot+(1-w)*b*b;geom+=1
        rho=source_matrices(a,b,t);d=p['d'];cs=[w,-w,1-w,-(1-w)]
        delta1=matrix_linear(rho,cs)
        delta2=matrix_linear([kron(A,A,d)for A in rho],cs)
        expected=matrix_linear([kron(delta1,I,d),kron(I,delta1,d)],[F(1,2),F(1,2)])
        assert delta2==expected;identity+=1
        # n=1 Schur block agrees with the exact matrix without tensor replacement.
        A=difference_block(1,0,a,b,t)
        for i in range(2):
            for j in range(2):
                lo,hi=interval(delta1[i][j],d)
                assert A[i][j][0]<=hi and A[i][j][1]>=lo
    eta=F(4,5);par=parameters();small=small_horizon()
    # Exact one/two-copy values match inherited robust binomial formula.
    from research9.robust.frozen_reader import trial_error,optimal_bias_squared,enclosure,threshold
    q=optimal_bias_squared(F(9,10),F(4,5),F(1,100))
    assert q==par['m_squared'] and threshold(eta,q)==17
    for B,k in [(1,eta),(2,eta*(2-eta))]:
        assert trial_error(B,eta,q)==(F(1,2),-k/2)
    certificate=json.loads(Path(__file__).with_name('collective_certificate.json').read_text())
    out=verify_collective(certificate);assert out['excludes_one_percent'] and out['lower_float']>.01184
    # A deliberately poor rank-one proposal remains a valid loose upper bound;
    # it cannot certify a stronger conclusion by corrupting floating eigenvalues.
    empty={'vectors':[['0','0'],['0','0']],'values':['0','0']}
    M=[[(F(1),F(1)),(F(0),F(0))],[(F(0),F(0)),(F(-1),F(-1))]]
    norm,details=verify_block(M,empty);assert norm>=2
    res={'status':'PASS','exact_convex_geometry_cases':geom,'fixed_axis_two_copy_matrix_identities':identity,
        'one_two_copy_global_robust_values':{str(k):{n:list(map(str,v))if isinstance(v,list)else str(v)for n,v in row.items()}for k,row in small.items()},
        'certified_B12_error_lower':out['robust_minimax_error_lower'],
        'certified_B12_error_lower_float':out['lower_float'],'checked_schur_blocks':out['block_count'],
        'robust_continuous_one_percent_threshold_interval':[13,17],
        'scope':'Global robust local equatorial classes; exact small-horizon equality, longer-horizon interval only. No Bayesian assumption about nuisance is imposed.'}
    Path(__file__).with_name('results.json').write_text(json.dumps(res,indent=2)+'\n')
    print(json.dumps(res,indent=2))
if __name__=='__main__':main()
