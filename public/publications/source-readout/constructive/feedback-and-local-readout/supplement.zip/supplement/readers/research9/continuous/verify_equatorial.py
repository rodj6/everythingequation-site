"""Exact reference path sums, quadratic signs and rational-net transfer checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import comb
import random,json
from equatorial import Q2,bisector_risks,exact_small_optima,threshold,circle,circle_net,net_error,continuous_enclosure,last_step_certificate

def direct_majority(b,eta,v):
    # Independent binomial click-mixture, not signed-random-walk implementation.
    p=Q2(F(1,2),v/4);q=1-p;answer=Q2()
    for n in range(b+1):
        er=Q2()
        for k in range((n-1)//2+1):er+=comb(n,k)*p**k*q**(n-k)
        if n%2==0:er+=F(comb(n,n//2),2)*(p*q)**(n//2)
        answer+=comb(b,n)*eta**n*(1-eta)**(b-n)*er
    return answer

def trial_likelihood(n,h,o,eta,v):
    if not o:return Q2(1-eta)
    signal=n[h//2]*(1 if h%2==0 else -1)
    return eta*(1+o*v*signal)/2

def two_path_sum(first,eta,v):
    second=(Q2(0,F(1,2)),Q2(0,F(1,2)))
    answer=Q2()
    for r,s in product((-1,0,1),repeat=2):
        likelihood=[trial_likelihood(tuple(map(Q2,first)),h,r,eta,v)*trial_likelihood(second,h,s,eta,v)/4 for h in range(4)]
        plus=likelihood[0]+likelihood[2];minus=likelihood[1]+likelihood[3]
        answer+=min(plus,minus)
    return answer

def main():
    rng=random.Random(94071);comb_checks=two_checks=net_checks=0
    for eta,v in [(F(1),F(1)),(F(4,5),F(9,10)),(F(0),F(1)),(F(1),F(0)),(F(1,2),F(3,5))]:
        risks=bisector_risks(16,eta,v)
        assert risks[0]==Q2(F(1,2))
        assert risks[:3]==list(exact_small_optima(eta,v))
        for b,r in enumerate(risks):
            assert r==direct_majority(b,eta,v);comb_checks+=1
            assert 0<=r<=F(1,2)
            if b:assert r<=risks[b-1]
        for k in range(-12,13):
            first=circle(F(k,12));actual=two_path_sum(first,eta,v)
            predicted=Q2(F(1,2),-eta*v/4)-eta*(1-eta)*v*abs(sum(first))/4
            assert actual==predicted and actual>=risks[2];two_checks+=1
    for m in [1,2,3,7,16,40]:
        net=circle_net(m)
        assert all(x*x+y*y==1 for x,y in net)
        assert all((y,x)in net and(-x,-y)in net for x,y in net)
        for _ in range(120):
            t=F(rng.randrange(-100000,100001),100000)
            k=max(-m,min(m,(2*t.numerator*m+t.denominator)//(2*t.denominator)))
            point=circle(t);rounded=circle(F(k,m))
            # The exact chord bound implies each source-specific TV bound.
            distance=sum((x-y)**2 for x,y in zip(point,rounded))
            assert distance<=F(1,m*m)
            for coord in range(2):assert abs(point[coord]-rounded[coord])<=F(1,m)
            net_checks+=1
        for b in range(20):
            assert 0<=net_error(b,m,F(4,5),F(9,10))<=F(b)*F(4,5)*F(9,10)/(2*m)
    posterior_checks=0
    for bx,by,norm in [(3,4,5),(5,12,13),(0,7,7),(7,0,7)]:
        for xplus in range(bx+1):
            for yplus in range(by+1):
                w=(F(xplus),F(bx-xplus),F(yplus),F(by-yplus));eta,v=F(4,5),F(9,10)
                c=last_step_certificate(w,eta,v)
                actual=F(0)
                for o in [-1,0,1]:
                    masses=[w[h]*trial_likelihood((Q2(F(bx,norm)),Q2(F(by,norm))),h,o,eta,v)for h in range(4)]
                    actual+=min(masses[0]+masses[2],masses[1]+masses[3]).a
                predicted=F(c['rational_part'])+F(c['sqrt_coefficient'])*(0 if c['radicand']=='0'else norm)
                assert actual==predicted;posterior_checks+=1
    nominal=threshold(eta=F(4,5),visibility=F(9,10))
    ideal=threshold()
    assert nominal['threshold']==14 and ideal['threshold']==9
    assert bisector_risks(14,F(4,5),F(9,10))[13]>F(1,100)
    assert bisector_risks(14,F(4,5),F(9,10))[14]<F(1,100)
    # Exact irrational signs are never decided from floating values.
    assert Q2(-1,1).sign()==1 and Q2(1,-1).sign()==-1
    result={'status':'PASS','independent_click_mixture_checks':comb_checks,
       'exact_two_copy_ordered_sums':two_checks,'rational_net_chord_checks':net_checks,'arbitrary_posterior_terminal_checks':posterior_checks,
       'continuous_exact_optima':{str((str(e),str(v))):[x.export()for x in exact_small_optima(e,v)]for e,v in [(F(1),F(1)),(F(4,5),F(9,10))]},
       'fixed_bisector_noise_threshold':nominal,'fixed_bisector_ideal_threshold':ideal,
       'noise_risks':[{'copies':b,'risk':e.export()}for b,e in enumerate(bisector_risks(21,F(4,5),F(9,10)))],
       'net_transfer_example':continuous_enclosure(F(3,100),F(4,100),8,1000,F(4,5),F(9,10)),
       'net_example_status':'Illustrates transfer of supplied bounds; no continuous or grid optimum claimed by this example.'}
    (Path(__file__).parent/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
