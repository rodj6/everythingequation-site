"""Exact fixed-nuisance frozen-reader risk polynomials and Bernstein bounds.
Standard library only. No global source-memory or feedback optimum is claimed.
"""
from fractions import Fraction as F
from math import comb
from itertools import product
ZERO=(0,0,0)
def add(p,q):
 r=dict(p)
 for a,c in q.items():r[a]=r.get(a,F(0))+c
 return {a:c for a,c in r.items()if c}
def scale(p,c):return {a:v*c for a,v in p.items()if v*c}
def mul(p,q):
 r={}
 for a,c in p.items():
  for b,d in q.items():
   k=tuple(x+y for x,y in zip(a,b));r[k]=r.get(k,F(0))+c*d
 return {a:c for a,c in r.items()if c}
def value(p,x):return sum((c*prod(v**n for v,n in zip(x,a))for a,c in p.items()),F(0))
def prod(xs):
 r=F(1)
 for x in xs:r*=x
 return r
I={ZERO:F(1)};ETA={(1,0,0):F(1)};U={(0,1,0):F(1)};W={(0,0,1):F(1)}
def risks(policy):
 """Return four risk polynomials in eta,u=eta*g*cos(delta),w=eta*g*sin(delta).
 Each label uses its own relevant gain (gX or gY), fixed across the DAG.
 """
 ds=[tuple(map(F,d))for d in policy['directions']]
 for c,s in ds:assert c*c+s*s==1
 prev=[]
 for t,nodes in enumerate(policy['levels']):
  now=[]
  for row in nodes:
   if t==0:
    now.append([{ZERO:F(row['decision']!=(1 if h%2==0 else -1))}for h in range(4)]);continue
   c,s=ds[row['action']];children=row['children'];sigx=add(scale(U,c),scale(W,-s));sigy=add(scale(U,s),scale(W,c));out=[]
   for h in range(4):
    sig=scale(sigx if h<2 else sigy,1 if h%2==0 else -1)
    ks=[scale(add(ETA,sig),F(1,2)),scale(add(ETA,scale(sig,-1)),F(1,2)),add(I,scale(ETA,-1))]
    z={}
    for o in range(3):z=add(z,mul(ks[o],prev[children[o]][h]))
    out.append(z)
   now.append(out)
  prev=now
 return prev[policy.get('root',0)]
def bernstein_bounds(p,box):
 """Exact tensor Bernstein coefficient enclosure on a rational box."""
 d=tuple(max((a[i]for a in p),default=0)for i in range(3));q={}
 for a,c in p.items():
  for b in product(*(range(n+1)for n in a)):
   v=c*prod(F(comb(ai,bi))*l**(ai-bi)*(u-l)**bi for ai,bi,(l,u)in zip(a,b,box))
   q[b]=q.get(b,F(0))+v
 vals=[]
 for k in product(*(range(n+1)for n in d)):
  vals.append(sum((c*prod(F(comb(ki,bi),comb(di,bi))for ki,bi,di in zip(k,b,d))for b,c in q.items()if all(bi<=ki for bi,ki in zip(b,k))),F(0)))
 return min(vals),max(vals)
def may_be_physical(box,eta0,a,t):
 (el,eu),(ul,uu),(wl,wu)=box
 if eu<eta0 or el>1 or uu<0:return False
 wmin=F(0)if wl<=0<=wu else min(abs(wl),abs(wu));wmax=max(abs(wl),abs(wu))
 if wmin>t*uu:return False
 lo=max(F(0),ul)**2+wmin*wmin;hi=max(abs(ul),abs(uu))**2+wmax*wmax
 return not(lo>eu*eu or hi<a*a*el*el)
def certify(p,eta0,gain_floor,tan_delta,epsilon,max_boxes=10000):
 """Sound finite certificate search; strict-feasibility complete without a cap.
 Returns PASS only after a finite physical-domain cover is bounded.
 A cap/interruption cannot certify failure. Rational actions assumed.
 """
 eta0,a,t,eps=map(F,(eta0,gain_floor,tan_delta,epsilon))
 assert 0<eta0<=1 and 0<a<=1 and 0<=t<1
 initial=((eta0,F(1)),(F(0),F(1)),(-t,t));pending=[(initial,0)];checked=pruned=0;leaves=[]
 while pending and checked<max_boxes:
  box,depth=pending.pop();checked+=1
  if not may_be_physical(box,eta0,a,t):pruned+=1;continue
  lo,hi=bernstein_bounds(p,box)
  if hi<eps:
   leaves.append({'box':[[str(x)for x in q]for q in box],'upper':str(hi)});continue
  axis=depth%3
  # Skip zero-width axes, while ensuring all nontrivial coordinates shrink.
  for _ in range(3):
   if box[axis][0]<box[axis][1]:break
   axis=(axis+1)%3
  l,u=box[axis];m=(l+u)/2
  if l==u:pending.append((box,depth));break
  left=list(box);right=list(box);left[axis]=(l,m);right[axis]=(m,u)
  pending.extend([(tuple(left),depth+1),(tuple(right),depth+1)])
 return {'status':'PASS'if not pending else'INCONCLUSIVE','processed_boxes':checked,'pruned_boxes':pruned,'pending_boxes':len(pending),'certified_leaves':leaves,'epsilon':str(eps),'scope':'Uniform frozen-policy risk under one fixed nuisance, not a robust optimality certificate.'}
