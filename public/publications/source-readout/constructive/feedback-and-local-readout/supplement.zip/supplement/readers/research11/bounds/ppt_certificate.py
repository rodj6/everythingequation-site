"""Standard-library exact dual verification for a local-reader relaxation.

The proposal generator is optional. Every supplied dual is encoded as a
rational factor L, making LL^T positive semidefinite without a solver trust.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb,isqrt,factorial
from functools import lru_cache
import json

def sqrt_bounds(x,bits=100):
 x=F(x);D=1<<bits;k=isqrt(x.numerator*D*D//x.denominator);lo=F(k,D)
 return lo,lo if lo*lo==x else F(k+1,D)
@lru_cache(None)
def polynomial(s,k,l,K):
 D={}
 for q in range(max(0,k+l-s),min(k,l)+1):
  x=k+l-2*q;u=s-k-l+q;base=comb(k,q)*comb(s-k,l-q)
  for a in range(u+1):
   for b in range(q+1):
    key=x,a+b;D[key]=D.get(key,0)+base*comb(u,a)*comb(q,b)*(-1)**b
 O={}
 for a in range(K+1):
  for b in range(K-a+1):
   coef=factorial(K)//factorial(a)//factorial(b)//factorial(K-a-b)*(-1)**(a+b)
   for(x,z),c in D.items():
    key=x+2*a,z+2*b;O[key]=O.get(key,0)+coef*c
 return {q:c for q,c in O.items()if c}

def gram(L):
 L=[[F(x)for x in row]for row in L];d=len(L)
 assert d and all(len(row)==d for row in L)
 return [[sum((L[i][k]*L[j][k]for k in range(d)),F(0))for j in range(d)]for i in range(d)]

def certify_click(n,v,rows,objective=None):
 assert len(rows)==n//2+1
 keys=[(a,b)for a in range(n+1)for b in range(n-a+1)if(a+b)%2]
 dualcost=F(0);res={q:list(objective[q])if objective is not None else[F(comb(n,q[0]))*v**q[0]if q[1]==0 else F(comb(n,q[1]))*v**q[1]if q[0]==0 else F(0)]*2 for q in keys}
 for K,row in enumerate(rows):
  s=n-2*K;A,C=gram(row['positive']),gram(row['negative']);assert len(A)==len(C)==s+1
  dualcost+=sum((A[i][i]+C[i][i]for i in range(s+1)),F(0))/2
  for k in range(s+1):
   for l in range(s+1):
    value=A[k][l]-C[k][l]
    if not value:continue
    root=sqrt_bounds(F(comb(s,k),comb(s,l)))
    poly=polynomial(s,k,l,K)
    for q in keys:
     c=value*poly.get(q,0)
     if not c:continue
     z0,z1=c*root[0],c*root[1]
     res[q][0]-=max(z0,z1);res[q][1]-=min(z0,z1)
 penalty=sum((max(abs(a),abs(b))for a,b in res.values()),F(0))/2
 upper=dualcost+penalty
 return {'n':n,'dual_cost':str(dualcost),'coefficient_residual_allowance':str(penalty),
   'correlation_upper':str(min(F(1),upper)),'error_lower':str(max(F(0),(1-upper)/2)),
   'display_error_lower':float(max(F(0),(1-upper)/2))}

def certify(cert):
 eta,v=F(cert['eta']),F(cert['visibility']);B=cert['horizon']
 assert eta==F(4,5)and v==F(9,10)and B==12
 clicks=[{'n':0,'error_lower':'1/2','display_error_lower':.5}]
 for n in range(1,B+1):clicks.append(certify_click(n,v,cert['clicks'][str(n)]))
 error=sum((comb(B,n)*eta**n*(1-eta)**(B-n)*F(clicks[n]['error_lower'])for n in range(B+1)),F(0))
 return {'status':'PASS','horizon':B,'eta':str(eta),'visibility':str(v),'error_lower':str(error),
   'display_error_lower':float(error),'excludes_one_percent':error>F(1,100),'click_certificates':clicks,
   'scope':'All declared local adaptive and randomized nonadaptive equatorial readers; permutation/partial-transpose invariant effect relaxation. Not an attainable local protocol.'}
def main():
 here=Path(__file__).resolve().parent;c=json.loads((here/'ppt_certificate.json').read_text());r=certify(c)
 assert r['excludes_one_percent']
 (here/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
