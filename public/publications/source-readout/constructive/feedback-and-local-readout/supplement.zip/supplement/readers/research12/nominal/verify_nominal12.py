"""Standard-library exact checks of the new frozen nominal attempts.
No search, no claimed optimality, and no angular discretization lower bound.
"""
from pathlib import Path
from fractions import Fraction as F
import json,random
from policy_certificate import verify
D=Path(__file__).resolve().parent
out={}
for name in ['baseline_policy_13.json','policy_13_refined.json','policy_13_pool.json']:
 p=json.loads((D/name).read_text());out[name]=verify(p,100)
 assert not out[name]['passes_one_percent']
lo,hi=map(F,out['policy_13_pool.json']['symmetrized_worst_error_interval'])
blo,bhi=map(F,out['baseline_policy_13.json']['symmetrized_worst_error_interval'])
assert hi<blo and lo>F(1,100)
# Support-function identity: the algebraic minimizing vector is (-u,-z)/r.
# Exact squared Cauchy-Schwarz checks use rational circle points.
rng=random.Random(12013)
for _ in range(1000):
 u,z=F(rng.randrange(-100,101),37),F(rng.randrange(-100,101),41)
 t=F(rng.randrange(-100,101),43);c,s=(1-t*t)/(1+t*t),2*t/(1+t*t)
 assert c*c+s*s==1
 assert (u*c+z*s)**2<=u*u+z*z
out['backup_support_checks']=1000
out['scope']='All new thirteen-copy candidates fail; no impossibility or global optimization follows.'
(D/'results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
