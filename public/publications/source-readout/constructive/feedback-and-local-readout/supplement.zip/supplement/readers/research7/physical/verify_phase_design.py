"""Deterministic exact tests and retained primal/dual certificates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
from phase_design import LABELS,reader_probs,experiment,minimax,optimum_at_budget,decision_probability
import json

OUT=Path(__file__).resolve().parent

def check_certificate(result):
    alpha=F(result['least_favourable_axis_prior']);es=[F(0)]*4;mass=[F(0)]*4;dual=F(0)
    for row in result['certificate']:
        probs=list(map(F,row['probabilities']));q=F(row['decide_plus']);assert 0<=q<=1
        for i,p in enumerate(probs):
            assert p>=0;mass[i]+=p;es[i]+=p*((1-q)if i in [0,2]else q)
        dual+=min(alpha*probs[0]+(1-alpha)*probs[2],alpha*probs[1]+(1-alpha)*probs[3])/2
    assert mass==[F(1)]*4
    assert max(es)==dual==F(result['minimax_error'])
    assert list(map(str,es))==result['individual_errors']

ideal_checks=0
for nx,ny in product(range(7),repeat=2):
    result=minimax(nx,ny);check_certificate(result)
    want=F(1,2)if min(nx,ny)==0 else F(1,2**nx+2**ny)
    assert F(result['minimax_error'])==want
    ideal_checks+=1

noisy=[]
for eta,v in [(F(4,5),F(9,10)),(F(2,3),F(3,4)),(F(1),F(0)),(F(0),F(1))]:
    for nx,ny in [(1,1),(1,3),(2,2),(3,3),(1,7),(4,4)]:
        result=minimax(nx,ny,eta,v);check_certificate(result)
        noisy.append({k:val for k,val in result.items()if k!='certificate'})

# An independent ordered-record enumeration verifies histogram multiplicities.
ordered_checks=0
for nx,ny in [(1,2),(2,2),(2,3)]:
    vectors=experiment(nx,ny,F(4,5),F(9,10))
    raw=defaultdict(lambda:[F(0)]*4)
    for word in product(range(3),repeat=nx+ny):
        hist=tuple(word[:nx].count(k)for k in range(3))+tuple(word[nx:].count(k)for k in range(3))
        for i,h in enumerate(LABELS):
            probability=F(1)
            for t,outcome in enumerate(word):probability*=reader_probs(h,'X'if t<nx else'Y',F(4,5),F(9,10))[outcome]
            raw[hist][i]+=probability
        ordered_checks+=1
    assert {r:tuple(p)for r,p in raw.items()}==vectors

# Ideal full-label optimum: four corners, randomized axis assignment.
full_label_checks=0
for nx,ny in product(range(1,7),repeat=2):
    vectors=experiment(nx,ny);px=F(2**nx,2**nx+2**ny);errors=[F(0)]*4
    for r,probs in vectors.items():
        xplus,xminus,_,yplus,yminus,_=r
        active=[]
        for j,p in enumerate(probs):
            if p:active.append(j)
        if len(active)==1:decision={active[0]:F(1)}
        else:
            assert len(active)==2
            decision={j:(px if j<2 else 1-px)for j in active}
        for j,p in enumerate(probs):errors[j]+=p*(1-decision.get(j,F(0)))
    assert errors==[F(2,2**nx+2**ny)]*4
    full_label_checks+=1

frontiers={}
for name,eta,v in [('ideal',F(1),F(1)),('noisy',F(4,5),F(9,10))]:
    frontiers[name]=[optimum_at_budget(b,eta,v)for b in range(2,11)]
assert frontiers['ideal'][6]['error']=='1/130'
assert frontiers['ideal'][6]['schedules']==[[1,7],[7,1]]
assert frontiers['noisy'][6]['error']=='8077061/97656250'
assert frontiers['noisy'][6]['schedules']==[[4,4]]

certificates=[minimax(1,7),minimax(4,4,F(4,5),F(9,10)),minimax(1,7,F(4,5),F(9,10))]
for cert in certificates:check_certificate(cert)
assert decision_probability(certificates[0],(0,0,1,3,4,0))==1
robust_eight=F(1,130)+1-F(3999,4000)**8
assert robust_eight<F(1,100)
deterministic_robust_eight=F(1,128)+1-F(3999,4000)**8
assert deterministic_robust_eight<F(1,100)
vec=experiment(1,7)
from phase_design import errors
policy={r:F(int((r[3]==7)or(not(r[3]==7 or r[4]==7)and r[0]==1)))for r in vec}
assert max(errors(vec,policy))==F(1,128)
(OUT/'certificates.json').write_text(json.dumps(certificates,indent=2)+'\n')
result=dict(status='PASS: exact rational primal/dual and independent record tests',
            ideal_frontier_checks=ideal_checks,noisy_certificate_checks=len(noisy),
            ordered_records_enumerated=ordered_checks,ideal_full_label_checks=full_label_checks,
            noisy_points=noisy,budget_frontiers=frontiers,
            benchmark=dict(ideal_optimal_8='1/130',ideal_balanced_8='1/32',
                           noisy_optimal_8='8077061/97656250',
                           noisy_unbalanced_8='726821937001/4803417968750',
                           eight_copy_error_with_conditional_TV_1_over_4000=str(robust_eight),
                           deterministic_eight_error_with_same_TV_budget=str(deterministic_robust_eight)),
            scope='Fixed nonadaptive X/Y menu, independent equally prepared copies; calibrated eta/v; no arbitrary POVM or adaptive optimum.')
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['noisy_points','budget_frontiers']},indent=2))
