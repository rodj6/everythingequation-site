"""Independent ordered-path and rational-geometry checks for the robust reader."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import json,random
from frozen_reader import *

def ordered_reference(n,eta,beta):
    kernel={1:eta*(1+beta)/2,-1:eta*(1-beta)/2,0:1-eta}
    return sum((prod(kernel[o]for o in word)*(F(1)if sum(word)<0 else F(1,2)if sum(word)==0 else F(0))
                for word in product((-1,0,1),repeat=n)),F(0))

def main():
    ordered=0
    for n in range(8):
        for eta in [F(0),F(2,3),F(1)]:
            for beta in [F(0),F(3,5),F(1)]:
                value=trial_error(n,eta,beta*beta)
                assert value[0]+value[1]*beta==ordered_reference(n,eta,beta)
                ordered+=1
    geometry=0;rng=random.Random(90196)
    for _ in range(100):
        a=F(rng.randrange(1,101),100);b=F(rng.randrange(1,101),100);t=F(rng.randrange(0,80),100)
        q=optimal_bias_squared(a,b,t);r=optimal_tangent(a,b,t)
        den=(1+r*r)*(1+t*t)
        assert a*a*(1-r*t)**2/den==q and b*b*(r-t)**2/den==q
        for r1 in [t, (r+t)/2,r,(r+(1/t if t else 100))/2,(1/t if t else 100)]:
            d=(1+r1*r1)*(1+t*t)
            got=min(a*a*(1-r1*t)**2/d,b*b*(r1-t)**2/d)
            assert got<=q
            geometry+=1
        for dt in [-t,-t/2,F(0),t/2,t]:
            den=(1+r*r)*(1+dt*dt)
            assert a*a*(1-r*dt)**2/den>=q
            assert b*b*(r+dt)**2/den>=q
            geometry+=2
        gx=F(rng.randrange(101),100);gy=F(rng.randrange(101),100)
        gz,p=pauli_probabilities(gx,gy)
        assert p[0]+p[1]-p[2]-p[3]==gx
        assert p[0]-p[1]+p[2]-p[3]==gy
    enclosure_checks=0
    for q in [F(0),F(1),F(2,5),F(36,61),F(81,200)]:
        for x in [F(-2),F(0),F(1,2)]:
            for y in [F(-3),F(0),F(5)]:
                lo,hi=enclosure((x,y),q)
                assert lo<=hi
                for bound in [lo-F(1),lo,hi,hi+F(1)]:
                    if bound<lo:assert not at_most((x,y),q,bound)
                    if bound>=hi:assert at_most((x,y),q,bound)
                    enclosure_checks+=1
    examples=[]
    for name,a,b,t,eta in [
        ('asymmetric_high_gain',F(9,10),F(4,5),F(1,100),F(4,5)),
        ('asymmetric_wide_phase',F(4,5),F(3,5),F(1,10),F(9,10)),
        ('high_efficiency',F(999,1000),F(499,500),F(1,1000),F(99,100)),
        ('inherited_noise_bisector',F(9,10),F(9,10),F(0),F(4,5))]:
        qo=optimal_bias_squared(a,b,t);qb=bisector_bias_squared(a,b,t)
        no,nb=threshold(eta,qo),threshold(eta,qb)
        assert no<=nb
        rows={'name':name,'gain_floor_X':str(a),'gain_floor_Y':str(b),'tan_phase_radius':str(t),'eta_floor':str(eta),
              'optimal_nominal_tangent':str(optimal_tangent(a,b,t)),
              'optimized_minimum_trials':no,'bisector_minimum_trials':nb,
              'optimized_at_threshold':certificate(no,eta,qo),'optimized_previous':certificate(no-1,eta,qo),
              'bisector_at_threshold':certificate(nb,eta,qb),'bisector_previous':certificate(nb-1,eta,qb)}
        assert rows['optimized_at_threshold']['at_most_one_percent']and not rows['optimized_previous']['at_most_one_percent']
        assert rows['bisector_at_threshold']['at_most_one_percent']and not rows['bisector_previous']['at_most_one_percent']
        examples.append(rows)
    result={'status':'PASS','ordered_reference_cases':ordered,'rational_geometry_checks':geometry,
            'quadratic_enclosure_checks':enclosure_checks,'examples':examples,
            'scope':'Exact robust minimax in the common-positive frozen-angle class; no global adaptive equatorial optimality claim.'}
    (Path(__file__).parent/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
