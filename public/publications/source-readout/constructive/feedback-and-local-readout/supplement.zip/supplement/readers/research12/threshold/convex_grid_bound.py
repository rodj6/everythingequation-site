"""Exact rational continuous-action Bayes-risk lower DP.

No solver, floating point, angular-net risk transfer, or local-optimality claim.
Each polygon vertex is a fictitious valid kernel, not a physical command.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
import json,time

ETA,V=F(4,5),F(9,10)

def normals(N):
 # Unit rational directions. N is the number of half-angle t intervals
 # between the positive X axis and positive Y axis, then rotate four times.
 q=[]
 for j in range(N):
  t=F(j,N);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
  # This parameterization covers a quadrant monotonically, including X,
  # excluding Y. Four exact rotations cover the full circle.
  q.append((c,s))
 return q+[(-s,c)for c,s in q]+[(-c,-s)for c,s in q]+[(s,-c)for c,s in q]

def vertices(N):
 ns=normals(N);vs=[]
 for (a,b),(c,d) in zip(ns,ns[1:]+ns[:1]):
  det=a*d-b*c;assert det>0
  x,y=(d-b)/det,(a-c)/det
  assert all(u*x+v*y<=1 for u,v in ns)
  # Cardinal support constraints guarantee that fictitious source kernels
  # remain nonnegative even at nonphysical outer vertices.
  assert abs(x)<=1 and abs(y)<=1
  vs.append((x,y))
 return vs

def interpolation(z,M):
 mass=sum(z,F(0))
 if mass==0:return []
 cs=[M*sum(z[:j],F(0))/mass for j in (1,2,3)]
 floor=[c.numerator//c.denominator for c in cs];r=[c-f for c,f in zip(cs,floor)]
 order=sorted(range(3),key=lambda j:(r[j],j),reverse=True)
 b=[1-r[order[0]],r[order[0]]-r[order[1]],r[order[1]]-r[order[2]],r[order[2]]]
 cumulative=floor[:];pts=[]
 for i in range(4):
  v=(cumulative[0],cumulative[1]-cumulative[0],cumulative[2]-cumulative[1],M-cumulative[2])
  if b[i]:
   assert min(v)>=0 and sum(v)==M
   pts.append((v,mass*b[i]))
  if i<3:cumulative[order[i]]+=1
 assert sum((a for _,a in pts),F(0))==mass
 assert all(sum((a*F(v[h],M)for v,a in pts),F(0))==z[h] for h in range(4))
 return pts

def grid(M):
 return [(a,b,c,M-a-b-c)for a in range(M+1)for b in range(M-a+1)for c in range(M-a-b+1)]

def run(M,N,B):
 assert M%4==0
 vs=vertices(N);ks=[]
 for c,s in vs:
  k=[tuple(ETA/2*(1+sgn*V*x)for x in (c,-c,s,-s))for sgn in (1,-1)]
  k.append((1-ETA,)*4)
  assert all(sum(k[o][h]for o in range(3))==1 for h in range(4))
  ks.append(k)
 gs=grid(M);lo={p:F(min(p[0]+p[2],p[1]+p[3]),M)for p in gs}
 # All interpolation tables are exact and independent of remaining horizon.
 cache={}
 for p in gs:
  bs=[]
  for K in ks:
   bs.append([interpolation(tuple(F(p[h],M)*K[o][h]for h in range(4)),M)for o in range(3)])
  cache[p]=bs
 out=[]
 for t in range(1,B+1):
  new={}
  for p in gs:
   new[p]=min(sum((coef*lo[q]for row in rows for q,coef in row),F(0))for rows in cache[p])
  lo=new;v=lo[(M//4,)*4]
  assert 0<=v<=F(1,2)
  out.append({'horizon':t,'lower_exact':str(v),'lower_display':float(v)})
 return {'M':M,'normals':4*N,'grid_points':len(gs),'bounds':out,
   'status':'exact rational lower bounds; not claimed tight'}

def main():
 started=time.time();out=[]
 for M,N,B in [(4,2,3),(8,2,3),(8,4,3)]:
  r=run(M,N,B);out.append(r);print(json.dumps(r),flush=True)
 # Independent geometric and interpolation adversarial checks.
 for N in (1,2,4,8):
  vertices(N)
 for z in [(F(1,4),)*4,(F(0),F(0),F(0),F(1)),(F(1,7),F(2,7),F(3,7),F(1,7))]:
  interpolation(z,8)
 payload={'method':'outer-action polygon plus true-cost concavity and exact grid interpolation',
  'results':out,'seconds':time.time()-started,'checks':'PASS'}
 Path(__file__).with_name('grid_results.json').write_text(json.dumps(payload,indent=2)+'\n')
if __name__=='__main__':main()
