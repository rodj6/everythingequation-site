"""Exact replay: fixed-parameter polynomial identities, enclosures, interior peak."""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json
from polynomial_certificate import risks,value,bernstein_bounds,may_be_physical,certify
P={'directions':[['1','0'],['3/5','4/5'],['0','1']],
 'levels':[[{'decision':1},{'decision':-1}],
 [{'action':0,'children':[0,1,0]},{'action':1,'children':[0,1,1]}],
 [{'action':2,'children':[0,1,0]},{'action':1,'children':[1,0,1]}],
 [{'action':1,'children':[0,1,0]}]],'root':0}
polys=risks(P)
def direct(h,eta,g,c,s):
 out=F(0)
 for word in product(range(3),repeat=3):
  prob=F(1);node=0
  for t,o in zip(range(3,0,-1),word):
   row=P['levels'][t][node];x,y=map(F,P['directions'][row['action']]);sig=g*(x*c-y*s if h<2 else y*c+x*s)*(1 if h%2==0 else -1)
   prob*=eta*(1+sig)/2 if o==0 else eta*(1-sig)/2 if o==1 else 1-eta
   node=row['children'][o]
  if P['levels'][0][node]['decision']!=(1 if h%2==0 else -1):out+=prob
 return out
count=0
for eta in [F(4,5),F(9,10),F(1)]:
 for g in [F(4,5),F(9,10),F(1)]:
  for c,s in [(F(1),F(0)),(F(9999,10001),F(200,10001)),(F(9999,10001),F(-200,10001))]:
   for h,p in enumerate(polys):
    assert max(map(sum,p))<=3;assert value(p,(eta,eta*g*c,eta*g*s))==direct(h,eta,g,c,s);count+=1
box=((F(4,5),F(1)),(F(7,10),F(9,10)),(F(-1,100),F(1,100)))
for p in polys:
 lo,hi=bernstein_bounds(p,box)
 for k in product(range(5),repeat=3):
  x=[l+(u-l)*F(ki,4)for ki,(l,u)in zip(k,box)];v=value(p,x);assert lo<=v<=hi
assert may_be_physical(((F(4,5),F(1)),(F(0),F(1)),(F(-1,100),F(1,100))),F(4,5),F(9,10),F(1,100))
assert not may_be_physical(((F(4,5),F(1)),(F(0),F(1,10)),(F(1,2),F(3,5))),F(4,5),F(9,10),F(1,100))
# Legal 16-trial reader, X+ label, cos(theta)=4/5, eta=1,delta=0.
# Return minus iff exactly14plus outcomes; otherwise plus. Peak g=15/16.
def peak(g):
 p=(1+F(4,5)*g)/2;return comb(16,14)*p**14*(1-p)**2
vals={str(g):peak(g)for g in [F(9,10),F(15,16),F(1)]}
assert vals['15/16']>max(vals['9/10'],vals['1'])
assert certify({(0,0,0):F(1,200)},F(4,5),F(9,10),F(1,100),F(1,100))['status']=='PASS'
assert certify({(0,0,0):F(1,50)},F(4,5),F(9,10),F(1,100),F(1,100),max_boxes=5)['status']=='INCONCLUSIVE'
r={'status':'PASS','independent_ordered_word_identities':count,'bernstein_grid_checks':4*5**3,'maximum_risk_degree':3,'gain_endpoint_counterexample':{k:{'exact':str(v),'decimal':float(v)}for k,v in vals.items()},'scope':'Polynomial and enclosure method only. No16copy attainment or global optimum.'}
Path(__file__).with_name('verification_results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
