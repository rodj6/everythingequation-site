"""Independent rational/ordered-path checks for the compact reader certificate."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,copy
from policy_certificate import verify,freeze
HERE=Path(__file__).resolve().parent

def exact_cost(cert):
 eta,v=F(cert['eta']),F(cert['visibility']);previous=[]
 for t,nodes in enumerate(cert['levels']):
  current=[]
  for row in nodes:
   if not t:current.append([F(row['decision']!=(1 if h%2==0 else-1))for h in range(4)]);continue
   c,s=map(F,cert['directions'][row['action']]);signals=(c,-c,s,-s)
   V=[]
   for h,signal in enumerate(signals):
    kernels=(eta*(1+v*signal)/2,eta*(1-v*signal)/2,1-eta)
    V.append(sum(p*previous[ch][h]for p,ch in zip(kernels,row['children'])))
   current.append(V)
  previous=current
 return previous[cert['root']]

def ordered(cert):
 B=cert['horizon'];eta,v=F(cert['eta']),F(cert['visibility']);risk=[F(0)]*4;mass=[F(0)]*4
 for word in product((1,-1,0),repeat=B):
  node=cert['root'];P=[F(1)]*4
  for t,o in enumerate(word):
   row=cert['levels'][B-t][node];c,s=map(F,cert['directions'][row['action']])
   for h,signal in enumerate((c,-c,s,-s)):P[h]*=1-eta if not o else eta*(1+o*v*signal)/2
   node=row['children'][0 if o==1 else 1 if o==-1 else 2]
  decision=cert['levels'][0][node]['decision']
  for h in range(4):
   mass[h]+=P[h]
   if decision!=(1 if h%2==0 else-1):risk[h]+=P[h]
 assert mass==[F(1)]*4
 return risk

def prefix_certificate(cert,t,root=0):
 # Any stored t-level subtree is an admitted t-copy policy.
 x=copy.deepcopy(cert);x['horizon']=t;x['levels']=x['levels'][:t+1];x['root']=root;return x

def main():
 results=[];small=0
 for B in(13,14):
  cert=json.loads((HERE/f'policy_{B}.json').read_text());r=verify(cert)
  values=exact_cost(cert);bounds=r['base_label_error_intervals']
  assert all(F(lo)<=x<=F(hi)for x,(lo,hi)in zip(values,bounds))
  mean=sum(values)/4;lo,hi=map(F,r['symmetrized_worst_error_interval']);assert lo<=mean<=hi
  if B==13:assert mean>F(1,100)
  else:assert mean<F(875,100000)
  # Each of four physical root symmetries permutes labels transitively.
  for h in range(4):
   sym=sum(values[2*((h//2)^a)+((h%2)^s)]for a in(0,1)for s in(0,1))/4
   assert sym==mean
  for t in range(1,6):
   for j in range(min(3,len(cert['levels'][t]))):
    sub=prefix_certificate(cert,t,j);assert exact_cost(sub)==ordered(sub);small+=1
  bad=copy.deepcopy(cert);bad['levels'][-1][0]['children'][0]=10**9
  try:verify(bad)
  except AssertionError:pass
  else:raise AssertionError('invalid graph accepted')
  bad=copy.deepcopy(cert);bad['directions'][0]=['1','1']
  try:verify(bad)
  except ValueError:pass
  else:raise AssertionError('nonunit direction accepted')
  results.append(r|{'exact_base_label_errors':list(map(str,values)),'exact_symmetrized_error':str(mean)})
 out={'status':'PASS','policies':results,'independent_ordered_subtree_checks':small,
  'scope':'Compact feasible upper certificates only. B13candidate failsonepercent; B14candidate passes. No global optimum or separation atonepercent established.'}
 (HERE/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
