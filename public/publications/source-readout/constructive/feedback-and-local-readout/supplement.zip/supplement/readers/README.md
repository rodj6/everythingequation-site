# Reader verification sources and inputs

Use `python reproduce.py --check` or `python reproduce.py --output replay_new` from the scientific package root (two directories above this folder). The top-level runner is scoped to Paper 3 and its methods companion. No external solver, network access or campaign job is required.

`INPUT_MANIFEST.json` records each stored SHA-256, expanded SHA-256 and source locator. `jobs.json` lists the 23 declared entry points. Inputs are expanded only in a disposable tree. Large JSON proof objects are gzip-compressed; their expanded bytes match the original certificate content. Outputs from the five restored menu/resource jobs are checked under the same scientific contracts as their associated manuscript sections.

The 27-job runner from the coordinated two-paper reader/certification supplement is retained in the private baseline evidence. It is not the entry point for this scoped release; Paper 4's dedicated certification jobs are excluded here.

Consult `../EVIDENCE_GUIDE.md` before interpreting historical status fields, finite tests, display decimals or exact certificates. A successful execution does not establish a device's physical noise or preparation assumptions.
