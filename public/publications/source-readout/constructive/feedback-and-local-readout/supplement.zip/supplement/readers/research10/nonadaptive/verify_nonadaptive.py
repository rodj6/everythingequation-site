"""Exact finite classification and quadratic-field B3 reference checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research9.continuous.equatorial import Q2,bisector_risks

def b3_optimum(eta=F(4,5),v=F(9,10)):
 eta,v=F(eta),F(v)
 if not 0<=eta<=1 or not 0<=v<=1:raise ValueError('physical sharedeta,v required')
 bracket=3*eta*(1-eta)+eta**3*(6-v*v)/4
 return Q2(F(1,2),-v*bracket/4)
def classify():
 R=tuple(product((-1,1),repeat=3));half=tuple(r for r in R if r[0]==1)
 counts={'dictator':0,'parity':0,'majority':0}
 for bits in product((-1,1),repeat=4):
  d=dict(zip(half,bits));table={r:d[r]if r[0]==1 else-d[tuple(-a for a in r)]for r in R}
  co=[F(sum(table[r]*prod(r[i]for i in I)for r in R),8)for I in[(0,),(1,),(2,),(0,1,2)]]
  if sum(c!=0 for c in co)==1:
   key='parity'if co[3]else'dictator'
  else:
   assert all(abs(c)==F(1,2)for c in co)
   assert co[3]==-4*prod(co[:3]);key='majority'
  counts[key]+=1
 assert counts=={'dictator':6,'parity':2,'majority':8}
 return counts

def main():
 exact=0
 for eta in map(F,['0','1/5','4/5','1']):
  for v in map(F,['0','1/3','9/10','1']):
   assert b3_optimum(eta,v)==bisector_risks(3,eta,v)[3];exact+=1
 # Algebraic squared comparison F<=5 on the diagonal and derivative signs
 # checked on rational square variables; the supplied proof covers continuity.
 comparisons=0
 for i in range(41):
  x=F(i,40)
  for j in range(41):
   y=F(j,40);r2=(3-2*y*y)**2+4*x*x*(1-x*x)
   if x>=y:assert x*x*r2-y*y*(3-2*y*y)**2>=0
   if y>=x and 2*x*x>1:assert y*y*r2-x*x*(2*x*x-1)**2>=0
   assert (5-4*x*y)>=0 and(5-4*x*y)**2>=r2
   comparisons+=1
 out={'status':'PASS','odd_decoder_classes':classify(),'exact_bisector_formula_checks':exact,
      'rational_two_variable_inequality_checks':comparisons,
      'nominal_nonadaptive_B3':b3_optimum().export(),
      'ideal_nonadaptive_B3':b3_optimum(1,1).export(),
      'scope':'Analytical proof covers all continuous nonadaptive angle schedules and randomization at B3. No B3 adaptive optimum claimed.'}
 Path(__file__).with_name('three_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
