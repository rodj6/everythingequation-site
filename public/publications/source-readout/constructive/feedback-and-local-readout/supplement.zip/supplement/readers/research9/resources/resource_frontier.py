"""Exact fixed-reader copy/phase-clock frontier under two distinct parents.

Only standard-library rational arithmetic is used for certification. Decimal
displays are illustrative; the stored rational intervals carry guarantees.
"""
from fractions import Fraction as F
from math import comb,isqrt
from functools import lru_cache

@lru_cache(None)
def risk(b,eta,beta):
    """Majority sign error with fair ties; nulls remain in the population."""
    eta,beta=F(eta),F(beta)
    if type(b)is not int or b<0 or not 0<=eta<=1 or not 0<=beta<=1:
        raise ValueError('physical budget, efficiency and signal required')
    p=(1+beta)/2;r=1-p
    pp=[p**i for i in range(b+1)];rr=[r**i for i in range(b+1)]
    answer=F(0)
    for n in range(b+1):
        e=sum((comb(n,j)*pp[j]*rr[n-j]for j in range((n-1)//2+1)),F(0))
        if n%2==0:e+=F(comb(n,n//2),2)*pp[n//2]*rr[n//2]
        answer+=comb(b,n)*eta**n*(1-eta)**(b-n)*e
    return answer

def sqrt_bounds(x,digits=35):
    x=F(x)
    if x<0:raise ValueError('negative square root')
    s=10**digits;k=isqrt(x.numerator*s*s//x.denominator)
    lo=F(k,s)
    return lo,lo if lo*lo==x else F(k+1,s)

def atan_small(x,tol=F(1,10**32)):
    x=F(x)
    if abs(x)>F(1,2):raise ValueError('small argument required')
    total=F(0);term=x;j=0
    while True:
        total+=term/F(2*j+1);j+=1;term=-term*x*x
        nxt=term/F(2*j+1)
        if abs(nxt)<=tol:return min(total,total+nxt),max(total,total+nxt)

def outward(pair,digits=25):
    """Rational outward rounding keeps certificates small without narrowing."""
    lo,hi=pair;s=10**digits
    a=(lo*s).numerator//(lo*s).denominator
    b=-((-hi*s).numerator//(-hi*s).denominator)
    return F(a,s),F(b,s)

@lru_cache(None)
def pi_bounds():
    a,b=atan_small(F(1,5));c,d=atan_small(F(1,239))
    return outward((16*a-4*d,16*b-4*c))

def atan_bounds(x):
    x=F(x)
    if x<0:
        a,b=atan_bounds(-x);return-b,-a
    if x<=F(1,2):return outward(atan_small(x))
    pl,pu=pi_bounds()
    if x<=1:
        a,b=atan_small((x-1)/(x+1));return outward((pl/4+a,pu/4+b))
    a,b=atan_bounds(1/x);return outward((pl/2-b,pu/2-a))

def asin_bounds(x):
    x=F(x)
    if not 0<=x<=1:raise ValueError('asin argument')
    if x==1:
        a,b=pi_bounds();return a/2,b/2
    l,u=sqrt_bounds(1-x*x)
    a,_=atan_bounds(x/u);_,b=atan_bounds(x/l)
    return a,b

def signal_max_sq(a,b,tan_delta):
    a,b,t=map(F,(a,b,tan_delta))
    if not 0<a<=1 or not 0<b<=1 or not 0<=t<1:
        raise ValueError('positive physical gains and phase radius<pi/4')
    sin2=2*t/(1+t*t);cos2=(1-t*t)/(1+t*t)
    return a*a*b*b*cos2*cos2/(a*a+b*b+2*a*b*sin2)

def beta_requirement(b,eta,target,bits=55):
    eta,target=F(eta),F(target)
    if not 0<eta<=1 or not 0<target<F(1,2):raise ValueError('nontrivial target')
    if risk(b,eta,F(1))>target:return None
    lo,hi=F(0),F(1)
    for _ in range(bits):
        mid=(lo+hi)/2
        if risk(b,eta,mid)>target:lo=mid
        else:hi=mid
    assert risk(b,eta,lo)>=target and risk(b,eta,hi)<=target
    return lo,hi

def copy_point(b,eta,a,bgain,tan_delta,target,bits=55):
    """Certified interval for the least feasible phase at a nominated copy count."""
    eta,a,bgain,t,target=map(F,(eta,a,bgain,tan_delta,target))
    need=beta_requirement(b,eta,target,bits)
    if need is None:return {'budget':b,'status':'below_erasure_floor'}
    ml,mh=sqrt_bounds(signal_max_sq(a,bgain,t))
    bl,bh=need
    if bl>mh:return {'budget':b,'status':'infeasible'}
    if bh>ml:return {'budget':b,'status':'unresolved_interval'}
    dl,dh=atan_bounds(t)
    al,_=asin_bounds(bl/bgain);_,ah=asin_bounds(bh/bgain)
    # A feasible angle uses the upper signal root. Prove the upper-angle
    # endpoint also lies below arccos(bh/a)-Delta by interval separation.
    _,beta_asin_hi=asin_bounds(bh/a)
    pl,_=pi_bounds();upper_feasible=pl/2-beta_asin_hi-dh
    assert dh+ah<=upper_feasible
    return {'budget':b,'status':'feasible','signal_requirement':[bl,bh],
            'least_angle':[dl+al,dh+ah],
            'constructive_angle_upper':dh+ah,
            'scope':'fixed majority reader, common-sign angle class, fixed unknown calibration box'}

def time_bounds(point,omega_tau,parent='held'):
    """Time/ordinary-trial-duration; omega_tau is a dimensionless product."""
    r=F(omega_tau)
    if r<=0 or parent not in ('held','pulse'):raise ValueError('clock parent')
    b=point['budget'];lo,hi=point['least_angle'];factor=1 if parent=='held'else b
    return b+factor*lo/r,b+factor*hi/r

def frontier(eta,a,bgain,tan_delta,target,omega_tau,parent='held',max_budget=120,bits=55):
    points=[];best_upper=None
    for b in range(1,max_budget+1):
        if best_upper is not None and b>best_upper:break
        p=copy_point(b,eta,a,bgain,tan_delta,target,bits)
        if p['status']=='unresolved_interval':raise ArithmeticError('increase root precision')
        if p['status']!='feasible':continue
        tb=time_bounds(p,omega_tau,parent);p['time_interval']=tb;points.append(p)
        best_upper=min(best_upper,tb[1])if best_upper is not None else tb[1]
    if not points:raise ArithmeticError('no feasible point within budget cap')
    if b==max_budget and max_budget<=best_upper:
        raise ArithmeticError('cap does not certify omitted large budgets')
    winner=min(points,key=lambda p:p['time_interval'][1])
    assert all(winner['time_interval'][1]<p['time_interval'][0]
               for p in points if p['budget']!=winner['budget'])
    return {'parent':parent,'omega_tau':F(omega_tau),'winner':winner,
            'tested_feasible_points':len(points),'last_budget_considered':b,
            'tail_certificate':'Every omitted budget B has T/tau>=B>attained upper bound.'}

def dyadic_calibration(settings,labels,confidence_bits,accuracy):
    """Exact conservative Hoeffding allocation with failure at most2^-k."""
    A,H,k=settings,labels,confidence_bits;eps=F(accuracy)
    if any(type(x)is not int or x<1 for x in (A,H,k))or not 0<eps<1:
        raise ValueError('positive cells/confidence bits and rational accuracy')
    c=(6*A*H-1).bit_length();q=F(k+c,2*eps*eps)
    m=(q.numerator+q.denominator-1)//q.denominator
    assert 2*m*eps*eps>=k+c and 2**c>=6*A*H
    return {'per_source_setting_probes':m,'total_probes':A*H*m,
            'failure_upper':F(1,2**k),'entry_accuracy':eps,'union_cells':3*A*H,
            'scope':'Independent fresh trusted probes; declared stationarity through deployment; finite menu fixed before validation.'}

def feedback_clock_certificate(trials_adaptive,trials_nonadaptive,feedback,switching,
                               common_trial=F(1),extra_setup=F(0),runs=1):
    """Sufficient serial-clock advantage over a proved trial lower bound."""
    b,n=trials_adaptive,trials_nonadaptive
    ell,s,tau,d=map(F,(feedback,switching,common_trial,extra_setup))
    if type(b)is not int or type(n)is not int or b<1 or n<1 or min(ell,s,d)<0 or tau<=0 or type(runs)is not int or runs<1:
        raise ValueError('physical timing/count domain')
    upper=b*tau+(b-1)*(ell+s)
    lower=n*tau
    total_gap=runs*(lower-upper)-d
    return {'adaptive_per_run_upper':upper,'nonadaptive_per_run_lower':lower,
            'extra_one_time_setup':d,'runs':runs,'certified_total_time_saving':total_gap,
            'strict_advantage':total_gap>0,
            'scope':'Uniform padded reader/preparation slot tau; outcome-dependent feedback/switch overheads bounded by ell,s; final decision and shared calibration costs matched.'}
