"""Exact all-B certificates for randomized frozen-angle robust readers.

The theorem's measurement class chooses one common-positive nominal angle
before a block, retains the seed, repeats that angle and uses any decoder.
It does NOT include a varying-angle schedule or an adaptive controller.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research9.robust.frozen_reader import optimal_bias_squared,trial_error,enclosure,threshold

def padd(a,b):
 out=[F(0)]*max(len(a),len(b))
 for i,x in enumerate(a):out[i]+=x
 for i,x in enumerate(b):out[i]+=x
 return out

def pscale(a,c):return[x*c for x in a]
def pmul(a,b):
 out=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out

def ppow(a,n):
 out=[F(1)]
 for _ in range(n):out=pmul(out,a)
 return out

def derivative(a):return[i*a[i]for i in range(1,len(a))]or[F(0)]
def peval(a,x):
 s=F(0)
 for c in reversed(a):s=s*x+c
 return s

def click_poly(n):
 # Variable beta; P(correct sign)=(1+beta)/2.
 p=[F(1,2),F(1,2)];q=[F(1,2),F(-1,2)];out=[F(0)]
 for k in range((n-1)//2+1):out=padd(out,pscale(pmul(ppow(p,k),ppow(q,n-k)),comb(n,k)))
 if n%2==0:out=padd(out,pscale(pmul(ppow(p,n//2),ppow(q,n//2)),F(comb(n,n//2),2)))
 return out

def deadline_poly(B,eta):
 out=[F(0)]
 for n in range(B+1):out=padd(out,pscale(click_poly(n),comb(B,n)*eta**n*(1-eta)**(B-n)))
 return out

def parameters(a=F(9,10),b=F(4,5),t=F(1,100)):
 a,b,t=map(F,(a,b,t));dot=-2*a*b*t/(1+t*t);L2=a*a+b*b-2*dot
 p=(b*b-dot)/L2;q=optimal_bias_squared(a,b,t)
 V=p*(1-p)*L2
 return {'a':a,'b':b,'tan_delta':t,'axis_prior':p,'bias_squared':q,
         'difference_squared':L2,'fixed_axis_variance':V}

def result():
 eta=F(4,5);p=parameters();q=p['bias_squared']
 rows=[]
 for B in[1,2,3,13,14,15,16,17]:
  poly=deadline_poly(B,eta);slope=derivative(poly)
  assert all(slope[i]==0 for i in range(1,len(slope),2))
  minus_derivative=-sum(c*q**(i//2)for i,c in enumerate(slope)if i%2==0)
  assert minus_derivative>0
  bounds=enclosure(trial_error(B,eta,q),q)
  rows.append({'B':B,'worst_error_interval':list(map(str,bounds)),
               'display_error':float(bounds[1]),
               'minus_derivative_at_m':str(minus_derivative),
               'angle_penalty_coefficient':'2*sqrt('+str(q)+')*('+str(minus_derivative)+')/pi^2'})
 assert threshold(eta,q)==17
 return {'status':'PASS','theorem_class':'Randomized common-positive frozen angle with retained seed and arbitrary terminal decoder; not varying schedules.',
         'eta_floor':str(eta),'parameters':{k:str(v)for k,v in p.items()},
         'one_percent_threshold_in_class':17,'rows':rows,
         'stock_witness':{'two_copy_trace_distance':str(p['fixed_axis_variance']/2),
             'retained_null_transverse_correlation_gap':str(eta**2*p['fixed_axis_variance'])},
         'original_full_continuous_robust_threshold_interval':[16,17],
         'interval_dependency':'Separate exact local-effect PPT certificate in research11/bounds; not proved by the frozen-angle polynomial checker.'}

def main():
 out=result();Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
