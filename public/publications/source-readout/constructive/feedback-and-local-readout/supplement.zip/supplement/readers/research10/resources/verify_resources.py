"""Independent exhaustive open-tour checks and exact calibration arithmetic."""
from fractions import Fraction as F
from itertools import permutations,combinations,product
from pathlib import Path
import json,random
from resource_tools import *

def main():
    tour_checks=0;individual_order_checks=0
    rng=random.Random(10031)
    lattice=[F(i,12)for i in range(12)]
    for size in range(1,8):
        for _ in range(12):
            points=tuple(rng.sample(lattice,size));start=rng.choice(lattice)
            got=ordered_schedule(points,start)
            ref=min(sum(min(abs(a-b),1-abs(a-b))for a,b in zip((start,)+p,p))for p in permutations(points))
            assert got['distance']==ref and path_length(got['order'],start)==ref
            tour_checks+=1
    for size in range(1,7):
        points=tuple(F(i,20)for i in range(1,size+1))
        got=ordered_schedule(points)
        assert got['distance']==max(points)
        for order in permutations(points):assert path_length(order)>=got['distance'];individual_order_checks+=1
    # Multiplicity needs no additional slew; different starting coordinates work.
    assert ordered_schedule([F(1,4)]*6)['distance']==F(1,4)
    assert ordered_schedule([F(1,4),F(3,4)],F(0))['distance']==F(3,4)
    tv_checks=0
    for eta1,eta2 in product([F(1,2),F(4,5),F(1)],repeat=2):
        for mu1,mu2 in product([F(-1,3),F(0),F(1,3)],repeat=2):
            p=[(eta1+mu1)/2,(eta1-mu1)/2,1-eta1]
            q=[(eta2+mu2)/2,(eta2-mu2)/2,1-eta2]
            assert sum(abs(x-y)for x,y in zip(p,q))/2==row_tv(eta1-eta2,mu1-mu2);tv_checks+=1
    allocations=[calibration_allocation(k,F(u),F(w))for k,u,w in [(10,'1/100','1/100'),(20,'1/22000','1/88000')]]
    assert allocations[0]['trusted_probes']==1120000
    assert allocations[1]['trusted_probes']==92928000000
    for B in range(20):
        for kappa in [F(0),F(1,1000),F(1,10),F(1)]:
            assert 0<=record_transfer(B,kappa)<=min(1,B*kappa)
    # Exact conservative acceptance-event demonstration. No conditional
    # accepted-run claim is made without an acceptance-probability premise.
    u,w=F(1,22000),F(1,88000)
    root2_upper=F(70711,50000)
    assert root2_upper**2>2
    kappa=w+root2_upper*u
    nominal14_upper=F(887,100000)
    nominal14_coefficient=F(41399471337169097241,119209289550781250000)
    assert (F(1,2)-nominal14_upper)**2<2*nominal14_coefficient**2
    acceptance_error_upper=nominal14_upper+record_transfer(14,kappa)+F(1,2**20)
    assert acceptance_error_upper<F(1,100)
    out={'status':'PASS','exhaustive_open_tour_instances':tour_checks,
        'individual_order_comparisons':individual_order_checks,'exact_ternary_TV_checks':tv_checks,
        'continuous_calibration_allocations':allocations,
        'calibration_acceptance_event_error_upper':acceptance_error_upper,
        'calibration_event_scope':'Bound for joint acceptance and deployment error, not unconditional conditional-on-acceptance accuracy.',
        'scope':'Held actuator with projective-axis polarity recoding; continuous kernel transfer only under declared sinusoidal/common-erasure promise.'}
    Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
    print(json.dumps(out,indent=2,default=str))
if __name__=='__main__':main()
