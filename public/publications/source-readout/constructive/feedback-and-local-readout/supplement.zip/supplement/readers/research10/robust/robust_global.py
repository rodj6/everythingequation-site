"""Exact robust small-horizon theorem and rational Schur-block lower certificates.

All certificate verification uses the standard library. Numpy is used only by
make_collective_certificate.py to propose finite rational decompositions.
"""
from fractions import Fraction as F
from math import comb,isqrt
from functools import lru_cache
import json

def add(x,y):return x[0]+y[0],x[1]+y[1]
def scale(x,k):return x[0]*k,x[1]*k
def mul(x,y,d):return x[0]*y[0]+x[1]*y[1]*d,x[0]*y[1]+x[1]*y[0]
def power(x,n,d):
    z=(F(1),F(0))
    for _ in range(n):z=mul(z,x,d)
    return z

def sqrt_bounds(q,bits=100):
    q=F(q)
    if q<0:raise ValueError('nonnegative square root')
    D=1<<bits;v=isqrt(q.numerator*D*D//q.denominator)
    return F(v,D),F(v,D)if v*v*q.denominator==q.numerator*D*D else F(v+1,D)
def interval(x,d,bits=100):
    l,u=sqrt_bounds(d,bits);a,b=x
    return (a+b*l,a+b*u)if b>=0 else(a+b*u,a+b*l)
def imul(x,y):
    p=[a*b for a in x for b in y];return min(p),max(p)
def iadd(x,y):return x[0]+y[0],x[1]+y[1]
def iscale(x,k):return (x[0]*k,x[1]*k)if k>=0 else(x[1]*k,x[0]*k)

def parameters(a=F(9,10),b=F(4,5),t=F(1,100)):
    a,b,t=map(F,(a,b,t))
    if not 0<a<=1 or not 0<b<=1 or not 0<=t<1:raise ValueError('physical gain floors and tan phase radius')
    dot=-2*a*b*t/(1+t*t)
    p=(b*b-dot)/(a*a+b*b-2*dot)
    m2=(a*b*(1-t*t)/(1+t*t))**2/(a*a+b*b-2*dot)
    return {'a':a,'b':b,'t':t,'d':2*(1+t*t),'p':p,'m_squared':m2,'dot_uv':dot}

def small_horizon(eta=F(4,5),a=F(9,10),b=F(4,5),t=F(1,100)):
    eta=F(eta)
    if not 0<eta<=1:raise ValueError('positive physical efficiency floor')
    p=parameters(a,b,t);m=p['m_squared']
    out={}
    for B,k in [(1,eta),(2,eta*(2-eta))]:
        l,u=sqrt_bounds(m)
        out[B]={'risk_interval':[F(1,2)-k*u/2,F(1,2)-k*l/2],
                'coefficient_of_sqrt_m_squared':-k/2,'m_squared':m}
    return out

def source_matrices(a,b,t):
    """Two fixed-axis sources and their opposite signs, after one common rotation.

    Each entry is A+B sqrt(d); this is a basis change of u=(a cosD,-a sinD)
    and v=(-b sinD,b cosD), NOT an iid average over axes.
    """
    a,b,t=map(F,(a,b,t))
    par=parameters(a,b,t);d=par['d'];mat=[]
    c=(F(0),(1-t)/d);s=(F(0),(1+t)/d)
    for g,side in [(a,-1),(b,1)]:
        for sign in [1,-1]:
            diag=scale(s,sign*side*g/2);off=scale(c,sign*g/2)
            mat.append(((add((F(1,2),F(0)),diag),off),
                        (off,add((F(1,2),F(0)),scale(diag,-1)))))
    return mat

def symmetric_power(N,A,d):
    """Normalized symmetric-power block intervals; exact polynomial before roots."""
    aa,bb,cc,dd=A[0][0],A[0][1],A[1][0],A[1][1]
    powers=[[power(x,k,d)for k in range(N+1)]for x in [aa,bb,cc,dd]]
    out=[]
    for k in range(N+1):
        row=[]
        for l in range(N+1):
            x=(F(0),F(0))
            for i in range(max(0,k-(N-l)),min(l,k)+1):
                q=powers[0][N-l-k+i]
                for j,e in [(1,l-i),(2,k-i),(3,i)]:q=mul(q,powers[j][e],d)
                x=add(x,scale(q,comb(l,i)*comb(N-l,k-i)))
            row.append(imul(interval(x,d),sqrt_bounds(F(comb(N,l),comb(N,k)))))
        out.append(row)
    return out

@lru_cache(None)
def difference_block(n,k,a=F(9,10),b=F(4,5),t=F(1,100)):
    """Schur block of fixed-axis Omega_plus(n)-Omega_minus(n)."""
    if type(n)is not int or type(k)is not int or not 0<=k<=n//2:raise ValueError('Schur index')
    a,b,t=map(F,(a,b,t))
    p=parameters(a,b,t);d=p['d'];pr=p['p'];N=n-2*k
    matrices=source_matrices(a,b,t);blocks=[symmetric_power(N,x,d)for x in matrices]
    coeff=[pr*((1-a*a)/4)**k,-pr*((1-a*a)/4)**k,
           (1-pr)*((1-b*b)/4)**k,-(1-pr)*((1-b*b)/4)**k]
    out=[]
    for i in range(N+1):
        row=[]
        for j in range(N+1):
            z=(F(0),F(0))
            for x,c in zip(blocks,coeff):z=iadd(z,iscale(x[i][j],c))
            row.append(z)
        out.append(row)
    return out

def verify_block(block,certificate):
    """Upper bound trace norm with a rational rank-one sum and residual."""
    n=len(block);Q=[[F(x)for x in row]for row in certificate['vectors']]
    values=[F(x)for x in certificate['values']]
    if len(Q)!=n or any(len(row)!=n for row in Q)or len(values)!=n:raise ValueError('wrong certificate shape')
    # Q rows index coordinates, columns index the proposed rank-one terms.
    triangle=sum((abs(v)*sum(Q[i][j]**2 for i in range(n))for j,v in enumerate(values)),F(0))
    squared=F(0)
    for i in range(n):
        for j in range(n):
            r=sum((values[h]*Q[i][h]*Q[j][h]for h in range(n)),F(0))
            lo,hi=block[i][j];squared+=max(abs(lo-r),abs(hi-r))**2
    residual=sqrt_bounds(squared)[1]*sqrt_bounds(F(n))[1]
    return triangle+residual,{'triangle':str(triangle),'residual_trace_allowance':str(residual)}

def verify_collective(certificate):
    if certificate['contract']!='fixed-axis robust least-favourable prior, orthogonal erasure flags':raise ValueError('wrong contract')
    a,b,t,eta=map(F,[certificate[x]for x in ['a','b','tan_delta','eta']]);B=certificate['horizon']
    if not 0<eta<=1 or type(B)is not int or B<0:raise ValueError('physical horizon and efficiency')
    p=parameters(a,b,t);bounds={};traces=[]
    for n in range(B+1):
        total=F(0)
        for k in range(n//2+1):
            c=certificate['blocks'][f'{n},{k}'];block=difference_block(n,k,a,b,t)
            norm,details=verify_block(block,c)
            mult=comb(n,k)-(comb(n,k-1)if k else 0)
            total+=mult*norm/2
            traces.append({'n':n,'k':k,'multiplicity':mult,'trace_norm_upper':str(norm),**details})
        bounds[n]=min(F(1),total)
    trace=sum((comb(B,n)*eta**n*(1-eta)**(B-n)*bounds[n]for n in range(B+1)),F(0))
    lower=(1-trace)/2
    return {'status':'PASS','horizon':B,'robust_minimax_error_lower':str(lower),
        'lower_float':float(lower),'trace_distance_upper':str(trace),
        'excludes_one_percent':lower>F(1,100),'axis_prior':str(p['p']),
        'block_count':len(traces),'block_certificates':traces,
        'scope':'Every admitted continuous-equatorial adaptive or nonadaptive policy; no local attainment or actual residual-instrument equivalence claimed.'}
