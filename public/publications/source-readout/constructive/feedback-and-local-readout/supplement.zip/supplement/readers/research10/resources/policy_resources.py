"""Exact noise-transfer and outward clock costs for the rational four-copy reader."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research9.resources.resource_frontier import atan_bounds,pi_bounds
from research10.resources.resource_tools import record_transfer

def total_error_certificate(ideal_error,eta_floor,gain_floor,phase_radius):
    e,eta,g,d=map(F,(ideal_error,eta_floor,gain_floor,phase_radius))
    if not 0<=e<=F(1,2) or not 0<=eta<=1 or not 0<=g<=1 or not 0<=d<1:raise ValueError('physical comparison parameters')
    kappa=((1-eta)+(1-eta*g)+eta*g*d)/2
    extra=record_transfer(4,kappa)
    return {'ideal_risk':e,'eta_floor':eta,'gain_floor':g,'phase_and_control_radius':d,
            'row_tv_upper':kappa,'record_tv_upper':extra,'worst_error_upper':e+extra}

def angle_bounds(direction):
    c,s=map(F,direction)
    assert c*c+s*s==1 and c>=0 and s>=0
    lo,hi=atan_bounds(s/(1+c))
    return 2*lo,2*hi

def subtract_abs(a,b):
    low=a[0]-b[1];high=a[1]-b[0]
    return (0 if low<=0<=high else min(abs(low),abs(high)),max(abs(low),abs(high)))

def cost_certificate(cert,include_nulls=True):
    """Worst-path phase-cost intervals over both axis-swap root controls.

    All directions in these files lie in the first quadrant, so interval
    absolute differences are also shortest projective-circle distances.
    Output polarity symmetrization has no setting motion cost.
    """
    pb=pi_bounds();halfpi=pb[0]/2,pb[1]/2
    actions={k:angle_bounds(row['direction'])for k,row in cert['nodes'].items()}
    assert len(actions)==40
    results=[]
    for swap in (False,True):
        aa={k:(halfpi[0]-v[1],halfpi[1]-v[0])if swap else v for k,v in actions.items()}
        for word in product((1,-1,0)if include_nulls else(1,-1),repeat=4):
            previous=(F(0),F(0));held=[F(0),F(0)];pulse=[F(0),F(0)]
            for t in range(4):
                angle=aa[','.join(map(str,word[:t]))]
                # The actual retained direction command determines the slew.
                step=subtract_abs(angle,previous)
                held=[held[i]+step[i]for i in range(2)]
                pulse=[pulse[i]+angle[i]for i in range(2)]
                previous=angle
            results.append({'axis_swap':swap,'word':list(word),'held':held,'pulse':pulse})
    out={'scope':'Four fresh copies; commanded setting IDs/signs/nulls retained; unread true analog phase; both root axis controls; no terminal reset.',
         'include_nulls':include_nulls,'number_of_paths':len(results),'horizon':4,
         'internal_tree_nodes':40,'terminal_prefixes':81,'root_ready_bits':2,
         'constant_decoder_terminal_nodes':sum(row['committed_before_last_trial']for row in cert['nodes'].values())}
    for parent in ['held','pulse']:
        lo=max(x[parent][0]for x in results);hi=max(x[parent][1]for x in results)
        witness=max(results,key=lambda x:x[parent][0])
        out[parent]={'worst_phase_interval':[lo,hi],'worst_phase_float':[float(lo),float(hi)],
                     'witness':{'axis_swap':witness['axis_swap'],'word':witness['word']}}
    return out

def main():
    path=ROOT/'research10/continuous/ideal_four_policy.json'
    cert=json.loads(path.read_text());e=F(cert['minimax_attainable_upper'])
    robustness=total_error_certificate(e,F(99999,100000),F(99999,100000),F(1,10000))
    assert robustness['worst_error_upper']<F(31,1000)<F(1,32)
    resource=cost_certificate(cert,True)
    # An explicit five-copy nonadaptive attainment uses the same noise box.
    # The exact ideal error is 1/2 - 43 sqrt(2)/128 <2492/100000.
    bisector_upper=F(2492,100000)
    assert (F(1,2)-bisector_upper)**2<2*F(43,128)**2
    bisector_noisy_upper=bisector_upper+record_transfer(5,robustness['row_tv_upper'])
    assert bisector_noisy_upper<F(31,1000)
    held_cap,pulse_cap=F(139,25),F(47,10)
    # 15-bit command rounding costs <1/40000 rad per action. A four-action
    # open slew has seven endpoint contributions; pulse sum has four.
    assert F(22,7*4*32767)<F(1,40000)
    assert resource['held']['worst_phase_interval'][1]+F(7,40000)<held_cap
    assert resource['pulse']['worst_phase_interval'][1]+F(4,40000)<pulse_cap
    latency,omega_tau=F(1,20),F(20)
    savings={'held':1-3*latency-held_cap/omega_tau,
             'pulse':1-3*latency-pulse_cap/omega_tau}
    assert savings=={'held':F(143,250),'pulse':F(123,200)}
    out={'status':'PASS','operating_region':robustness,'physical_cost':resource,
         'five_copy_bisector_error_upper':bisector_noisy_upper,
         'clock_example':{'omega_tau':omega_tau,'latency_over_tau':latency,
                          'held_time_saving_at_least_tau':savings['held'],
                          'pulse_time_saving_at_least_tau':savings['pulse'],
                          'held_extra_setup_10_tau_break_even_runs':18,
                          'pulse_extra_setup_10_tau_break_even_runs':17},
         'continuous_nonadaptive_lower':'1/32','selected_target':'31/1000',
         'scope':'Robust operating certificate for one frozen adaptive tree; comparison depends on the independent universal ideal nonadaptive lower proof.'}
    Path(__file__).with_name('policy_results.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
    print(json.dumps(out,indent=2,default=str))
if __name__=='__main__':main()
