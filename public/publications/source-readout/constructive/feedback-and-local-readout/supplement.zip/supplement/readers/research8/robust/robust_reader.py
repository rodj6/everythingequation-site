"""Exact erasure frontier and fixed-unknown calibration-box certificate.

One reader policy, fixed before eta and visibility are known. All arithmetic
is rational; no new ETH backend or physical law is implemented.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import comb

LABELS=('X+','X-','Y+','Y-')

def ideal_error(n):
    if not isinstance(n,int)or n<0:raise ValueError('nonnegative integer horizon')
    return F(1,2)if n==0 else F(1,4)if n==1 else F(1,2**n)

def erased_error(efficiencies):
    """Exact minimax risk for independent, nonidentical sign-blind erasures."""
    distribution=[F(1)]
    for eta in map(F,efficiencies):
        if not 0<=eta<=1:raise ValueError('efficiencies in [0,1]')
        nxt=[F(0)]*(len(distribution)+1)
        for j,p in enumerate(distribution):nxt[j]+=p*(1-eta);nxt[j+1]+=p*eta
        distribution=nxt
    return sum((p*ideal_error(n)for n,p in enumerate(distribution)),F(0))

def erased_closed_form(budget,eta):
    if not isinstance(budget,int)or budget<0:raise ValueError('nonnegative integer horizon')
    eta=F(eta)
    if not 0<=eta<=1:raise ValueError('eta in [0,1]')
    if budget==0:return F(1,2)
    return (1-eta/2)**budget-(1-eta)**budget/2-F(budget,4)*eta*(1-eta)**(budget-1)

def clean(p):return {k:v for k,v in p.items()if v}
def add(a,b):
    out=dict(a)
    for k,v in b.items():out[k]=out.get(k,F(0))+v
    return clean(out)
def scale(a,s):return clean({k:v*s for k,v in a.items()})
def multiply(a,b):
    out={}
    for (i,j),x in a.items():
        for (k,l),y in b.items():out[i+k,j+l]=out.get((i+k,j+l),F(0))+x*y
    return clean(out)
def evaluate(p,eta,v):return sum((c*F(eta)**i*F(v)**j for(i,j),c in p.items()),F(0))

def reader_policy(state,outcome):
    """state=(initial-axis first sign, switched, committed other-axis sign).
    Outcomes are +1,-1,0. Continue consuming trials after commitment,
    retaining records but ignoring later signs in the terminal decision.
    """
    first,switched,committed=state
    if committed or outcome==0:return state
    if switched:return first,True,outcome
    if first==0:return outcome,False,0
    if outcome!=first:return first,True,0
    return state

def decision(state):
    first,switched,committed=state
    s=committed if switched else first
    return F(1,2)if not s else F(int(s==1))

def risk_polynomials(budget):
    """Per-label risk of initial-axis-X policy, then the fair-axis risk.
    Polynomials use powers eta^i * visibility^j. The initial fair axis coin
    symmetrizes labels, so the mean risk is every label's error.
    """
    if not isinstance(budget,int)or budget<0:raise ValueError('nonnegative integer horizon')
    @lru_cache(None)
    def recurse(left,state,h):
        if not left:
            q=decision(state)
            return {(0,0):(1-q)if h.endswith('+')else q}
        axis='Y'if state[1]else 'X'
        signal=(1 if h.endswith('+')else -1)if h.startswith(axis)else 0
        plus={(1,0):F(1,2),(1,1):F(signal,2)}
        minus={(1,0):F(1,2),(1,1):-F(signal,2)}
        null={(0,0):F(1),(1,0):-F(1)}
        out={}
        for o,kernel in [(1,clean(plus)),(-1,clean(minus)),(0,null)]:
            out=add(out,multiply(kernel,recurse(left-1,reader_policy(state,o),h)))
        return out
    individual=[recurse(budget,(0,False,0),h)for h in LABELS]
    mean={}
    for p in individual:mean=add(mean,scale(p,F(1,4)))
    return individual,mean

def bernstein_coefficients(p,eta_interval,v_interval,degree=None):
    """Exact tensor Bernstein coefficients on a rational calibration box."""
    a,b=map(F,eta_interval);c,d=map(F,v_interval)
    if not 0<=a<=b<=1 or not 0<=c<=d<=1:raise ValueError('physical ordered calibration box')
    ni=max((i for i,j in p),default=0);nj=max((j for i,j in p),default=0)
    if degree is not None:
        if degree<max(ni,nj):raise ValueError('insufficient Bernstein degree')
        ni=nj=degree
    # Substitute eta=a+(b-a)t and v=c+(d-c)s.
    transformed={}
    for(i,j),x in p.items():
        for k in range(i+1):
            for l in range(j+1):
                key=k,l
                transformed[key]=transformed.get(key,F(0))+x*comb(i,k)*a**(i-k)*(b-a)**k*comb(j,l)*c**(j-l)*(d-c)**l
    return [[sum((x*F(comb(k,i),comb(ni,i))*F(comb(l,j),comb(nj,j))
                  for(i,j),x in transformed.items()if i<=k and j<=l),F(0))
             for l in range(nj+1)]for k in range(ni+1)]

def box_certificate(p,eta_interval,v_interval,subdivision_depth=0):
    if not isinstance(subdivision_depth,int)or subdivision_depth<0:raise ValueError('nonnegative subdivision depth')
    cells=[(tuple(map(F,eta_interval)),tuple(map(F,v_interval)))]
    for _ in range(subdivision_depth):
        refined=[]
        for (a,b),(c,d)in cells:
            x=(a+b)/2;y=(c+d)/2
            refined.extend([((a,x),(c,y)),((a,x),(y,d)),((x,b),(c,y)),((x,b),(y,d))])
        cells=refined
    upper=F(-10);lower=F(-10);witness=None
    for x,y in cells:
        coeff=bernstein_coefficients(p,x,y)
        upper=max(upper,max(map(max,coeff)))
        for eta in x:
            for v in y:
                value=evaluate(p,eta,v)
                if value>lower:lower=value;witness=eta,v
    return {'lower':str(lower),'upper':str(upper),'gap':str(upper-lower),
            'witness':list(map(str,witness)),'cells':len(cells)}
