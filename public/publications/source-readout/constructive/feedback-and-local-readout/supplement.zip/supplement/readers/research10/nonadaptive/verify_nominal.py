"""Exact interval proof of the nominal continuous nonadaptive B4 lower bound."""
from fractions import Fraction as F
from math import prod,isqrt
from pathlib import Path
from itertools import product,permutations
import json,time
from verify_four import R,SUBSETS,cs,add,mul,scale,sqrt_upper
V=F(9,10);ETA=F(4,5);Z=1-ETA
ROOT2=sqrt_upper(F(2));C1=V*ROOT2/2;C3=V*(6-V*V)*ROOT2/8
ZERO=(F(0),F(0))
def abmax(x):return max(abs(x[0]),abs(x[1]))
def upper(coeff,path):
 depth=len(path);indices=[0,0,0]
 for octant in path:
  for j in range(3):indices[j]=2*indices[j]+((octant>>j)&1)
 vals=[cs(depth,k)for k in indices];C=[x[0]for x in vals];S=[x[1]for x in vals]
 a=[add(c,s)for c,s in zip(C,S)];am=[abmax(x)for x in a]
 c1=V*sum(am)/2+C1
 c2=V*sum(max(am[i],am[j])for i,j in[(0,1),(0,2),(1,2)])/2+3*C1
 zz=add(mul(mul(C[0],C[1]),C[2]),mul(mul(S[0],S[1]),S[2]))
 c3=F(0)
 for signs in product((-1,1),repeat=2):
  rr=(1,)+signs;tot=ZERO
  for r,ai in zip(rr,a):tot=add(tot,scale(V*r,ai))
  tot=add(tot,scale(V**3*prod(rr),zz));c3+=abmax(tot)/8
 c3=min(C3,c3)+3*C3
 rest=ETA*Z**3*c1+ETA**2*Z**2*c2+ETA**3*Z*c3
 f0=ZERO;A=(coeff[3],coeff[3]);B=A
 for i in range(3):
  if coeff[i]:f0=add(f0,scale(coeff[i],a[i]))
 if coeff[4]:f0=add(f0,scale(V*V*coeff[4],zz))
 for q,(i,j)in zip(coeff[5:],[(0,1),(0,2),(1,2)]):
  if q:A=add(A,scale(V*V*q,mul(C[i],C[j])));B=add(B,scale(V*V*q,mul(S[i],S[j])))
 r2=max(A[0]*A[0],A[1]*A[1])+max(B[0]*B[0],B[1]*B[1])
 return rest+ETA**4*V*(f0[1]+sqrt_upper(r2))/2

def main():
 start=time.monotonic();cert=json.loads(Path(__file__).with_name('nominal_certificate.json').read_text())
 assert cert['eta']=='4/5'and cert['visibility']=='9/10'
 target=F(cert['correlation_upper']);assert target==F(99,125) and F(cert['error_lower'])==F(13,125)
 seen=set();all_decoders=set();checks=0;maxdepth=0;maxupper=F(0)
 for row in cert['classes']:
  values=tuple(row['table']);D=dict(zip(R,values));assert len(D)==16 and all(s in(-1,1)for s in values)
  assert all(D[tuple(-x for x in r)]==-D[r]for r in R)
  raw=tuple(F(sum(D[r]*prod(r[i]for i in I)for r in R),16)for I in SUBSETS)
  assert list(map(str,raw))==row['coefficients']
  flips=tuple(row['first_three_direction_signs']);assert len(flips)==3 and all(s in(-1,1)for s in flips)
  key=(values,flips);assert key not in seen;seen.add(key)
  coeff=tuple(q*prod(flips[i]for i in I if i<3)for q,I in zip(raw,SUBSETS))
  assert list(map(str,coeff))==row['transformed_coefficients']
  leaves=set(row['leaves']);assert len(leaves)==len(row['leaves']);volume=F(0)
  for path in leaves:
   assert all(c in'01234567'for c in path)and not any(path[:i]in leaves for i in range(len(path)))
   volume+=F(1,8**len(path));maxdepth=max(maxdepth,len(path))
   bound=upper(coeff,tuple(map(int,path)));assert bound<=target,(row['orbit'],path,str(bound))
   maxupper=max(maxupper,bound);checks+=1
  assert volume==1
  for perm in permutations(range(4)):
   for ss in product((-1,1),repeat=4):all_decoders.add(tuple(D[tuple(ss[i]*r[perm[i]]for i in range(4))]for r in R))
  print('PASS row',len(seen),'leafchecks',checks,'seconds',round(time.monotonic()-start,2),flush=True)
 assert len(all_decoders)==256 and len(seen)==56
 reps={k[0]for k in seen};assert len(reps)==7 and all((rep,s)in seen for rep in reps for s in product((-1,1),repeat=3))
 out={'status':'PASS','eta':'4/5','visibility':'9/10','all_odd_four_click_decoders':256,'partitions':56,
      'exact_interval_leaves':checks,'max_depth':maxdepth,'correlation_upper':str(target),'all_continuous_nonadaptive_error_lower':str((1-target)/2),
      'maximum_exact_leaf_upper':str(maxupper),'seconds':time.monotonic()-start,
      'scope':'Full noisyfourcopycontinuousnonadaptiveclass. Erasureconditionrelaxationoptimizesfourthanglesseparatelyforpatternsforvalidlowerboundonly.'}
 Path(__file__).with_name('nominal_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
