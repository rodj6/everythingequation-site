"""Independent positive-series clock enclosures and noise/copy resource checks."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
from itertools import product
from functools import lru_cache
import json
ROOT=Path(__file__).resolve().parents[2]
def asin_small(x,tol=F(1,10**28)):
    assert 0<=x<=F(71,100)
    total=F(0);xp=x;n=0
    while True:
        total+=F(comb(2*n,n),4**n*(2*n+1))*xp
        n+=1;xp*=x*x
        tail=F(comb(2*n,n),4**n*(2*n+1))*xp/(1-x*x)
        if tail<tol:return total,total+tail
@lru_cache(None)
def angle(c,s):
    assert c*c+s*s==1 and c>=0 and s>=0
    if s<=c:return asin_small(s)
    pl,ph=asin_small(F(1,2));cl,ch=asin_small(c)
    return 3*pl-ch,3*ph-cl
def absolute_difference(x,y):
    l,h=x[0]-y[1],x[1]-y[0]
    return(F(0)if l<=0<=h else min(abs(l),abs(h)),max(abs(l),abs(h)))
def outward(pair):
    scale=10**20;l,h=pair
    return F((l*scale).numerator//(l*scale).denominator,scale),F(-((-h*scale).numerator//(-h*scale).denominator),scale)
def main():
    c=json.loads((ROOT/'research10/continuous/ideal_four_policy.json').read_text())
    E=F(c['minimax_attainable_upper']);eta=g=F(99999,100000);phase=F(1,10000)
    k=((1-eta)+(1-eta*g)+eta*g*phase)/2
    noise=1-(1-k)**4;assert E+noise<F(31,1000)<F(1,32)
    five=F(2492,100000)+1-(1-k)**5;assert five<F(31,1000)
    assert(F(1,2)-F(2492,100000))**2<2*F(43,128)**2
    # Ideal three-copy lower excludes every robust policy with B<=3.
    assert 2*F(5,16)**2<(F(1,2)-F(31,1000))**2
    acts={key:angle(*map(F,row['direction']))for key,row in c['nodes'].items()}
    pi3=asin_small(F(1,2));halfpi=3*pi3[0],3*pi3[1]
    paths=[]
    for swap in(False,True):
        aa={key:(halfpi[0]-z[1],halfpi[1]-z[0])if swap else z for key,z in acts.items()}
        for word in product((-1,0,1),repeat=4):
            prev=F(0),F(0);held=[F(0),F(0)];pulse=[F(0),F(0)]
            for t in range(4):
                z=aa[','.join(map(str,word[:t]))];step=absolute_difference(prev,z)
                for j in range(2):held[j]+=step[j];pulse[j]+=z[j]
                prev=z
            paths.append((held,pulse))
    held=[max(x[0][j]for x in paths)for j in range(2)]
    pulse=[max(x[1][j]for x in paths)for j in range(2)]
    assert held[1]<F(139,25) and pulse[1]<F(47,10)
    heldsaving=1-3*F(1,20)-F(139,25)/20
    pulsesaving=1-3*F(1,20)-F(47,10)/20
    assert heldsaving==F(143,250)and pulsesaving==F(123,200)
    assert 18*heldsaving>10>=17*heldsaving
    assert 17*pulsesaving>10>=16*pulsesaving
    out={'status':'PASS','independent_positive_arcsine_angles':len(set(acts.values())),
        'physical_axis_swap_paths':len(paths),'noise_row_TV':str(k),
        'adaptive_robust_four_copy_upper':str(E+noise),
        'nonadaptive_five_copy_upper':str(five),'robust_selected_target':'31/1000',
        'independent_held_phase_interval':list(map(str,outward(held))),
        'independent_pulse_phase_interval':list(map(str,outward(pulse))),
        'held_saving_tau':str(heldsaving),'pulse_saving_tau':str(pulsesaving),
        'scope':'Fixed delivered policy, all ternary paths. Distinct held and pulse clock parents; no universal hardware or uncharged calibration/reference claim.'}
    Path(__file__).with_name('resources_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
