"""Independent exact polynomial, mixture and covariance tests."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from frozen_mixtures import *

def main():
 polynomial_checks=0;derivative_checks=0;mixture_checks=0;variance_checks=0
 # Closed-form binomial derivative validates convexity for every polynomial.
 for n in range(1,23):
  poly=click_poly(n)
  if n%2==0:
   prev=click_poly(n-1)
   assert poly[:len(prev)]==prev and all(c==0 for c in poly[len(prev):])
  else:
   k=(n-1)//2
   expected=pscale(ppow([F(1),F(0),F(-1)],k),-F(n*comb(2*k,k),2**(2*k+1)))
   got=derivative(poly);assert got==expected;derivative_checks+=1
  for beta in[F(0),F(1,4),F(1,2),F(9,10),F(1)]:
   ref=sum((F(comb(n,k))*((1+beta)/2)**k*((1-beta)/2)**(n-k)for k in range((n-1)//2+1)),F(0))
   if n%2==0:ref+=F(comb(n,n//2),2)*((1-beta*beta)/4)**(n//2)
   assert peval(poly,beta)==ref;polynomial_checks+=1
 # Mixtures of positive biases have majority as a common Bayes decoder.
 for n in range(1,12):
  for k in range(n+1):
   for prior in[F(1,5),F(1,2),F(4,5)]:
    biases=(F(1,3),F(4,5));plus=minus=F(0)
    for weight,beta in zip((prior,1-prior),biases):
     plus+=weight*((1+beta)/2)**k*((1-beta)/2)**(n-k)
     minus+=weight*((1-beta)/2)**k*((1+beta)/2)**(n-k)
    assert (plus-minus)*(2*k-n)>=0;mixture_checks+=1
 rng=random.Random(11071)
 for _ in range(120):
  a,b=F(rng.randrange(1,101),100),F(rng.randrange(1,101),100);t=F(rng.randrange(100),100)
  p=parameters(a,b,t);w=p['axis_prior'];dot=-2*a*b*t/(1+t*t);q=p['bias_squared']
  assert q==w*w*a*a+(1-w)**2*b*b+2*w*(1-w)*dot
  assert p['fixed_axis_variance']==w*a*a+(1-w)*b*b-q
  assert p['fixed_axis_variance']==w*(1-w)*p['difference_squared'];variance_checks+=1
 r=result();assert F(r['rows'][-2]['worst_error_interval'][0])>F(1,100)>F(r['rows'][-1]['worst_error_interval'][1])
 out={'status':'PASS','binomial_probability_checks':polynomial_checks,
      'closed_form_odd_derivative_identities':derivative_checks,'positive_bias_mixture_decisions':mixture_checks,
      'exact_covariance_identities':variance_checks,
      'random_frozen_one_percent_threshold':17,
      'scope':'Finite checks supplement analytical all-B convexity/minimax proof. They do not exclude general varying-angle/adaptive16copy readers.'}
 Path(__file__).with_name('verification_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
