"""Exact Bayesian Bellman certificates and symmetrized minimax X/Y readers.

Conventional rational computation, not an ETH implementation. Four source
labels X+,X-,Y+,Y-; a source label is fixed and independently prepared copies
are consumed. All sign/null outcomes count. No collective measurement claim.
"""
from fractions import Fraction as F
from functools import reduce,lru_cache
from math import gcd,lcm

LABELS=('X+','X-','Y+','Y-')

def normalize(weights):
    if len(weights)!=4 or any(not isinstance(x,int)or x<0 for x in weights):
        raise ValueError('four nonnegative integer likelihood weights required')
    g=reduce(gcd,weights)
    return (g,tuple(x//g for x in weights))if g else(0,(0,0,0,0))

def kernel(eta=F(1),visibility=F(1)):
    eta,visibility=F(eta),F(visibility)
    if not 0<=eta<=1 or not 0<=visibility<=1:raise ValueError('physical eta,v in [0,1]')
    probs=(eta*(1+visibility)/2,eta*(1-visibility)/2,eta/2,1-eta)
    D=lcm(*(x.denominator for x in probs))
    a,b,c,z=[int(x*D)for x in probs]
    return D,(((a,b,c,c),(b,a,c,c),(z,z,z,z)),
              ((c,c,a,b),(c,c,b,a),(z,z,z,z)))

class Reader:
    def __init__(self,eta=F(1),visibility=F(1)):
        self.eta,self.visibility=F(eta),F(visibility)
        self.D,self.k=kernel(eta,visibility)
        self.nodes={}
    def value(self,remaining,weights=(1,1,1,1)):
        if not isinstance(remaining,int)or remaining<0:raise ValueError('integer horizon >=0')
        g,w=normalize(tuple(weights))
        if not g:return F(0)
        key=(remaining,w)
        if key not in self.nodes:
            if remaining==0:
                self.nodes[key]=(F(min(w[0]+w[2],w[1]+w[3])),None,None)
            else:
                values=tuple(sum((self.value(remaining-1,tuple(x*y for x,y in zip(w,row)))
                                  for row in axis),F(0))/self.D for axis in self.k)
                self.nodes[key]=(min(values),int(values[1]<values[0]),values)
        return g*self.nodes[key][0]
    def action(self,remaining,weights):
        if remaining<=0:raise ValueError('no action at a terminal node')
        if not any(weights):return 0 # declared default on nominal-impossible histories
        self.value(remaining,weights)
        return self.nodes[(remaining,normalize(tuple(weights))[1])][1]
    @staticmethod
    def decide_plus(weights):
        plus=weights[0]+weights[2];minus=weights[1]+weights[3]
        return F(1)if plus>minus else F(0)if plus<minus else F(1,2)
    def base_errors(self,horizon):
        self.value(horizon)
        @lru_cache(None)
        def rec(t,w):
            if t==0 or not any(w):
                q=self.decide_plus(w)
                return(1-q,q,1-q,q)
            a=self.action(t,w);out=[F(0)]*4
            for row in self.k[a]:
                child=tuple(x*y for x,y in zip(w,row));g,c=normalize(child)
                if not g:continue
                e=rec(t-1,c)
                for h,p in enumerate(row):out[h]+=F(p,self.D)*e[h]
            return tuple(out)
        return rec(horizon,(1,1,1,1))
    def weights_from_counts(self,counts):
        """Online sufficient controller state; null count remains in timing/archive."""
        if len(counts)!=4 or any(not isinstance(x,int)or x<0 for x in counts):
            raise ValueError('four nonnegative sign counts required')
        xp,xm,yp,ym=counts
        a,b,c,_=self.k[0][0]
        w=(a**xp*b**xm*c**(yp+ym),b**xp*a**xm*c**(yp+ym),
           c**(xp+xm)*a**yp*b**ym,c**(xp+xm)*b**yp*a**ym)
        return normalize(w)[1]
    def solve(self,horizon,certificate=False):
        value=self.value(horizon)/4;errors=self.base_errors(horizon)
        assert sum(errors,F(0))/4==value
        result={'horizon':horizon,'eta':str(self.eta),'visibility':str(self.visibility),
                'minimax_error':str(value),'error_float':float(value),
                'base_policy_errors':list(map(str,errors)),
                'symmetrized_errors':[str(value)]*4,'bellman_nodes':len(self.nodes),
                'symmetrization':'uniform axis swap and global sign reversal: two fair control bits',
                'scope':'adaptive local X/Y, fixed horizon, always decide sign, all nulls retained'}
        if certificate:
            result['denominator']=self.D;result['kernel']=self.k
            result['nodes']=[{'remaining':t,'weights':list(w),'value':str(v),
                             'action':a,'action_values':None if av is None else list(map(str,av))}
                            for(t,w),(v,a,av)in sorted(self.nodes.items())if t<=horizon]
        return result

def verify_certificate(cert):
    """Check every Bellman equality without optimizing or trusting producer values."""
    D,k=kernel(F(cert['eta']),F(cert['visibility']))
    assert D==cert['denominator']and [[list(row)for row in axis]for axis in k]==[[list(row)for row in axis]for axis in cert['kernel']]
    nodes={}
    for row in cert['nodes']:
        key=(row['remaining'],tuple(row['weights']))
        assert key not in nodes and normalize(key[1])==(1,key[1])
        nodes[key]=row
    for(t,w),row in sorted(nodes.items()):
        value=F(row['value'])
        if t==0:
            assert row['action'] is None and row['action_values'] is None
            assert value==min(w[0]+w[2],w[1]+w[3]);continue
        vals=[]
        for axis in k:
            total=F(0)
            for p in axis:
                g,c=normalize(tuple(x*y for x,y in zip(w,p)))
                if g:total+=g*F(nodes[t-1,c]['value'])
            vals.append(total/D)
        assert list(map(F,row['action_values']))==vals
        assert type(row['action'])is int and row['action']in(0,1)
        assert value==min(vals)==vals[row['action']]
    optimum=F(nodes[cert['horizon'],(1,1,1,1)]['value'])/4
    assert optimum==F(cert['minimax_error'])
    @lru_cache(None)
    def risks(t,w):
        if not t or not any(w):
            q=Reader.decide_plus(w);return(1-q,q,1-q,q)
        a=nodes[t,w]['action'];out=[F(0)]*4
        for row in k[a]:
            g,c=normalize(tuple(x*y for x,y in zip(w,row)))
            if g:
                r=risks(t-1,c)
                for h,p in enumerate(row):out[h]+=F(p,D)*r[h]
        return tuple(out)
    actual=risks(cert['horizon'],(1,1,1,1))
    assert actual==tuple(map(F,cert['base_policy_errors']))
    assert sum(actual,F(0))/4==optimum
    assert list(map(F,cert['symmetrized_errors']))==[optimum]*4
    return True

def fixed_randomized(horizon,eta=F(1),visibility=F(1)):
    """Best nonadaptive schedule + terminal decoder + root group randomization."""
    # Import only the inspected unchanged conventional seventh-run evaluator.
    import sys
    from pathlib import Path
    sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
    from research7.physical.phase_design import experiment,bayes_bound
    vals=[(bayes_bound(experiment(nx,horizon-nx,eta,visibility),F(1,2)),nx)
          for nx in range(horizon+1)]
    best=min(x[0]for x in vals)
    return {'error':str(best),'schedules':[[nx,horizon-nx]for e,nx in vals if e==best]}

if __name__=='__main__':
    import argparse,json
    ap=argparse.ArgumentParser();ap.add_argument('--horizon',type=int,default=8)
    ap.add_argument('--eta',default='4/5');ap.add_argument('--visibility',default='9/10')
    ap.add_argument('--certificate',action='store_true');args=ap.parse_args()
    r=Reader(F(args.eta),F(args.visibility)).solve(args.horizon,args.certificate)
    r['randomized_nonadaptive']=fixed_randomized(args.horizon,F(args.eta),F(args.visibility))
    print(json.dumps(r,indent=2))
