# Evidence and scope guide

The manuscript supplies analytical proofs. Executable checks corroborate the finite compiler, implementations, exact arithmetic and specified examples. Neither successful execution nor parallel model agreement is external peer review or formal verification of the whole paper.

## Scoped checks

| Entry point | Evidence and scope |
|---|---|
| `research7/finite/verify_finite.py` | Exact CNF/enumeration comparisons, unique gate extensions, finite synthesis, prior/empty cases and nonlinear port-cost examples. |
| `research7/weighted/verify_weighted.py` | Exact rational enumeration, elimination, modular recovery, 140 random signed models, 3,400 interval cases, HMM likelihood/posterior and low-width cycles. |
| `research7/reciprocal/verify_response_summary.py` | Exact Walsh/GF(2) summaries, parity-fibre minimality in the stated class and equivalent integer dynamic programmes through horizon 256. |
| `research7/audit/check_finite.py` | Separately organized source-enumeration and subset references; does not assume the circuit implementation's returned optimum. |
| `research7/audit/check_weighted.py` | Independently organized signed/probability arithmetic and modular interval references. |
| `research7/audit/check_reciprocal.py` | Independently organized target-summary and exact marginal references. |
| `research8/solver/verify_solver.py` | 160 exact optimizer instances, 640 interrupted bounds, 20 full source-table cases, 292 GF(2)/CNF comparisons and forged certificate rejection; generates example tables and certificates. |
| `research8/solver/verify_interface.py` | Four saved-certificate CLI roundtrips; unknown oracle, empty admitted source and malformed table cases. Requires the solver producer. |
| `research8/tensor/verify_tensor.py` | Exact octonion/projection identities, integer Bell factors, pattern/right-inverse queries and quotient-network examples. Writes relative to its own job directory. |
| `research8/audit/check_solver.py` | Independent all-subset/pair references, including non-upward feasibility and interrupted costs. |
| `research8/audit/check_tensor.py` | Independently organized crossing, rank, integer-factor and signed quotient references. |
| `checks/test_certificate_numbers.py` | Nineteen malformed proof-number/index rejections, ten public CLI checks, long-decimal costs/priors, nonfinite-token and `-O` rejection, and four regenerated saved-certificate roundtrips. Requires the solver producer. |

The minimal replay has twenty Python source inputs and twelve jobs. No precomputed result JSON is required as an executable input. The producer regenerates examples before consumers run; selected consumers include their producer automatically. Per-job snapshots preserve the first producer even if later checks write a path again. Final generated outputs and per-job receipts are distinct views.

## Preserved results

- Nonlinear predictive completion retains exact unit-port cost `b`, while full-source recovery costs `2b-1`; the manuscript gives the complete unequal-price formulas and the assumptions behind the gain.
- The 20-block recognized source remains an exact 40-source-bit, 59-port example with optimum 20. The 24- and 32-port table optima remain `28/3` and `23/2`.
- The interrupted example remains `6 <= OPT <= 26/3` with forty-four charged source queries, including starting-design construction/revalidation. Bounded status is preserved.
- The recorded controlled counts remain 16,384 versus 30; 57,344 versus 128; and 327,680 versus 142 for subset visits versus expanded nodes. These are different work units. Measured seconds and traced allocation bytes are diagnostic, machine-dependent values.
- The HMM word probability is `848/60025`; the specified initial-bit posterior is `1501/7420`. An independently justified event bound reduces the example's modular precision from 27 to 24 bits.
- The parity calculation retains exact update counts `2*b*(b-1)` versus `8*b-12`; at `b=256` the ratio is `32640/509`. This compares specified implementations, not all algorithms.
- The four-vertex quotient contraction remains `45621248`, with full enumeration of 262,144 assignments versus 64 quotient assignments. The six-vertex full `2^45` enumeration was not executed.

## What the review corrected

The mathematical collision statement uses gate fan-in at most two; normalization of a larger fan-in circuit must charge its expanded gate count. A subexponential source-bit interpretation also requires an appropriately bounded supplied description. The rational adapter's wire-only specialization requires no isolated scalar factors or unused source variables; its general bound always charges the enlarged parameter containing vertices and precision.

The old public checker could mix exact fractions with an externally supplied Python float and accept an upward-rounded lower bound. The reviewed checker validates proof-relevant rational and integer types before arithmetic; JSON decimals are parsed exactly before conversion. Direct optimized Python cannot bypass assertion-based checking. The original counterexample, three-module patch, original source hashes and regression evidence are preserved in the private review records. These are bounded correctness repairs, not new optimization theorems. Exact generated optima are unchanged.

The omitted `research7/root/shadow_tool.py` was recovered from the original Seventh/Eighth evidence. Its reviewed derivative additionally preserves JSON decimal priors/prices exactly. Full original code and intermediate experiments remain in the separate preservation archive; the public manifest identifies only the corrected executable closure.

## Conditional external dependencies

The finite compiler and synthesis theorems, rational reconstruction, parity summaries and wire-quotient identities do not depend on ETH. Only separately labelled asymptotic consequences invoke the supplied external theorems. `EXTERNAL_THEOREM_INPUTS.json` records exact PDF hashes, dates and personally inspected statement interfaces. Entire external proofs and Lean builds were not independently reproduced. A formalized related statement does not automatically certify every sharper printed bound or its correspondence.

OpenAI's cited theorem uses bit complexity and explicit edge/degree/precision/table-access conditions. Anthropic's cited network bounds use its stated word-RAM operation model. Their size parameters and computational models must not be interchanged. Neither preprint's complete algorithm is implemented here.

## Remaining premises

The exact separator and the unchanged pure feasible-set predicate remain part of a covering-tree certificate's trust interface. An unknown/incomplete oracle supplies no sufficiency certificate. A finite-menu impossibility is not a universal physical impossibility. Supplied intervals, priors, quotient-factorization promises and target projections must be justified independently.

Source access, prediction deadlines, clocks, controllers, references, retained archives and physical intervention compatibility require their own operational realization. No empirical quantum device, biological coupling or consciousness mechanism was tested. Born selection and the paused campaign's six obligations retain their previous status.
