"""Exact finite source/readout completion. Conventional DPLL, not an ETH solver.

No third-party dependencies. Circuits use positive integer wire identifiers.
All source assignments have exactly one extension to the Tseitin gate variables.
The optimizer enumerates finite menu subsets and reoptimizes after every cut.
"""
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import product


OPS = {'not': lambda a: 1-a, 'and':lambda a,b:a&b,
       'or':lambda a,b:a|b, 'xor':lambda a,b:a^b,
       'true':lambda:1, 'false':lambda:0}


class Circuit:
    def __init__(self,n):
        if n<0:raise ValueError('Negative number of source bits')
        self.n=n; self.gates=[]
    def input(self,i):
        if not 0<=i<self.n:raise ValueError('Input index')
        return i+1
    @property
    def wires(self):return self.n+len(self.gates)
    def gate(self,op,*args):
        arity={'not':1,'and':2,'or':2,'xor':2,'true':0,'false':0}.get(op)
        if arity is None or len(args)!=arity:raise ValueError('Gate operation/arity')
        if any(not 1<=a<=self.wires for a in args):raise ValueError('Forward or invalid wire')
        self.gates.append((op,tuple(args)))
        return self.wires
    def const(self,value):return self.gate('true' if value else 'false')
    def fold(self,op,wires):
        wires=tuple(wires)
        if not wires:return self.const(op=='and')
        a=wires[0]
        for b in wires[1:]:a=self.gate(op,a,b)
        return a
    def evaluate(self,x):
        if len(x)!=self.n or any(v not in (0,1)for v in x):raise ValueError('Source assignment')
        vals=[None]+list(x)
        for op,args in self.gates:vals.append(OPS[op](*(vals[a]for a in args)))
        return vals


def gate_cnf(op,args,out):
    """Forbid exactly the inconsistent local truth-table rows (width <= 3)."""
    clauses=[]
    for bits in product((0,1),repeat=len(args)+1):
        if bits[-1]!=OPS[op](*bits[:-1]):
            clauses.append(tuple(-v if b else v for v,b in zip((*args,out),bits)))
    return clauses


def compile_circuit(circuit,offset=0):
    clauses=[]
    for j,(op,args)in enumerate(circuit.gates,circuit.n+1):
        clauses.extend(gate_cnf(op,tuple(a+offset for a in args),j+offset))
    return clauses


def canonical(clauses):
    rows=[]
    for c in clauses:
        c=set(c)
        if any(-l in c for l in c):continue
        rows.append(tuple(sorted(c,key=lambda x:(abs(x),x))))
    return tuple(sorted(set(rows),key=lambda c:(len(c),c)))


def simplify(clauses,literal):
    return canonical(tuple(l for l in c if l!=-literal)for c in clauses if literal not in c)


def propagate(clauses,free):
    assignments={}
    while clauses and len(clauses[0])<=1:
        if not clauses[0]:return None,None,assignments
        lit=clauses[0][0];var=abs(lit)
        if var not in free:raise AssertionError('Assigned variable remains in formula')
        assignments[var]=int(lit>0);free=free-{var};clauses=simplify(clauses,lit)
    return clauses,free,assignments


@lru_cache(maxsize=4096)
def _count(clauses,free):
    clauses,free,_=propagate(clauses,free)
    if clauses is None:return 0
    if not clauses:return 1<<len(free)
    var=abs(clauses[0][0])
    return _count(simplify(clauses,var),free-{var})+_count(simplify(clauses,-var),free-{var})


def count_cnf(clauses,nvars):
    if any(not 1<=abs(l)<=nvars for c in clauses for l in c):raise ValueError('CNF variable')
    return _count(canonical(clauses),frozenset(range(1,nvars+1)))


def witness_cnf(clauses,nvars):
    clauses=canonical(clauses);free=frozenset(range(1,nvars+1));answer={}
    while True:
        clauses,free,assign=propagate(clauses,free);answer.update(assign)
        if clauses is None:return None
        if not clauses:
            answer.update({v:0 for v in free});return answer
        var=abs(clauses[0][0])
        for lit in (-var,var):
            new=simplify(clauses,lit)
            if _count(new,free-{var})>0:
                answer[var]=int(lit>0);clauses=new;free=free-{var};break
        else:return None


@dataclass(frozen=True)
class Sensor:
    name:str
    wires:tuple
    cost:Fraction=Fraction(1)
    def __post_init__(self):
        if not isinstance(self.cost,(Fraction,int)):raise ValueError('Sensor cost must be an exact integer or Fraction')
        object.__setattr__(self,'cost',Fraction(self.cost))
        object.__setattr__(self,'wires',tuple(self.wires))


class Model:
    def __init__(self,circuit,admissible,readout,target,sensors=()):
        self.circuit=circuit;self.admissible=admissible
        self.readout=tuple(readout);self.target=tuple(target);self.sensors=tuple(sensors)
        allw=[admissible,*self.readout,*self.target,*[w for s in self.sensors for w in s.wires]]
        if any(not 1<=w<=circuit.wires for w in allw):raise ValueError('Unknown model wire')
        if any(s.cost<0 for s in self.sensors):raise ValueError('Costs must be nonnegative')
        if len({s.name for s in self.sensors})!=len(self.sensors):raise ValueError('Duplicate sensor names')
    def _selection(self,selected):
        selected=tuple(selected)
        if len(set(selected))!=len(selected)or any(not isinstance(j,int)or not 0<=j<len(self.sensors)for j in selected):raise ValueError('Invalid or duplicate sensor indices')
        return selected
    def observe(self,x,selected=()):
        selected=self._selection(selected)
        v=self.circuit.evaluate(x)
        return tuple(v[w]for w in self.readout)+tuple(v[w]for j in selected for w in self.sensors[j].wires)
    def answer(self,x):
        v=self.circuit.evaluate(x);return tuple(v[w]for w in self.target)
    def allowed(self,x):return bool(self.circuit.evaluate(x)[self.admissible])
    def collision_formula(self,selected=()):
        selected=self._selection(selected)
        c=self.circuit;L=c.wires
        clauses=compile_circuit(c)+compile_circuit(c,L)
        clauses.extend([(self.admissible,),(L+self.admissible,)])
        # Duplicate comparison clauses are irrelevant, even when record labels repeat.
        obs=list(dict.fromkeys(list(self.readout)+[w for j in selected for w in self.sensors[j].wires]))
        for w in obs:clauses.extend([(-w,L+w),(w,-L-w)])
        nextvar=2*L;diffs=[]
        for w in dict.fromkeys(self.target):
            nextvar+=1;clauses.extend(gate_cnf('xor',(w,L+w),nextvar));diffs.append(nextvar)
        # A wide disjunction must also be compiled, not smuggled into fixed width.
        if diffs:
            out=diffs[0]
            for w in diffs[1:]:
                nextvar+=1;clauses.extend(gate_cnf('or',(out,w),nextvar));out=nextvar
            clauses.append((out,))
        else:clauses.append(())
        return clauses,nextvar
    def obstruction(self,selected=(),with_count=False):
        selected=self._selection(selected)
        clauses,nvars=self.collision_formula(selected)
        witness=witness_cnf(clauses,nvars)
        result={'status':'sufficient' if witness is None else 'obstructed',
                'selected':list(selected),'compiled_variables':nvars,
                'compiled_clauses':len(clauses),'max_width':max(map(len,clauses),default=0)}
        if witness is not None:
            n=self.circuit.n;L=self.circuit.wires
            x=tuple(witness[i+1]for i in range(n));xp=tuple(witness[L+i+1]for i in range(n))
            assert self.allowed(x)and self.allowed(xp)and self.observe(x,selected)==self.observe(xp,selected)and self.answer(x)!=self.answer(xp)
            result['witness']=[list(x),list(xp)]
        else:
            domain=count_cnf(compile_circuit(self.circuit)+[(self.admissible,)],self.circuit.wires)
            result['admissible_source_count']=domain
            result['empty_admissible_set']=(domain==0)
        if with_count:result['ordered_collision_count']=count_cnf(clauses,nvars)
        return result
    def compatible_count(self,readout,target=None,selected=()):
        selected=self._selection(selected)
        c=self.circuit;clauses=compile_circuit(c)+[(self.admissible,)]
        obs=list(self.readout)+[w for j in selected for w in self.sensors[j].wires]
        if len(readout)!=len(obs):raise ValueError('Readout length')
        if any(b not in (0,1)for b in readout):raise ValueError('Readout bits must be Boolean')
        clauses.extend((w if b else -w,)for w,b in zip(obs,readout))
        if target is not None:
            if len(target)!=len(self.target):raise ValueError('Target length')
            if any(b not in (0,1)for b in target):raise ValueError('Target bits must be Boolean')
            clauses.extend((w if b else -w,)for w,b in zip(self.target,target))
        return count_cnf(clauses,c.wires)
    def posterior(self,readout,selected=(),weights=None):
        """Exact finite prior. weights=None nominates the uniform admitted-source prior.

        Nonuniform weights are a user-supplied table and are evaluated by exhaustive
        reference enumeration, not represented as an ETH-speed weighted oracle.
        """
        selected=self._selection(selected)
        if len(readout)!=len(self.readout)+sum(len(self.sensors[j].wires)for j in selected)or any(b not in (0,1)for b in readout):raise ValueError('Readout bit vector')
        if weights is not None:
            for x,w in weights.items():
                if len(x)!=self.circuit.n or any(b not in (0,1)for b in x):raise ValueError('Prior source key')
                if not isinstance(w,(int,Fraction))or w<0:raise ValueError('Prior weights must be exact nonnegative rationals')
        totals={};mass=Fraction(0)
        for x in product((0,1),repeat=self.circuit.n):
            if not self.allowed(x)or self.observe(x,selected)!=tuple(readout):continue
            w=Fraction(1)if weights is None else Fraction(weights.get(x,0))
            if w<0:raise ValueError('Negative probability stock')
            a=self.answer(x);totals[a]=totals.get(a,Fraction(0))+w;mass+=w
        if mass==0:return {'status':'impossible_or_zero_mass_readout','mass':mass,'posterior':{}}
        return {'status':'defined','mass':mass,'posterior':{a:v/mass for a,v in totals.items()}}


def subsets(k):
    for mask in range(1<<k):yield tuple(j for j in range(k)if mask>>j&1)


def synthesize(model,feasible=lambda s:True,max_iterations=None):
    """Exact implicit hitting-set synthesis; every iteration fully reoptimizes.

    Feasible may impose any decidable restriction on finite menu subsets.
    The optimizer is exhaustive enumeration. With a limit, returns incomplete,
    never a sufficiency certificate. Cost ties use lexicographic subset order.
    """
    k=len(model.sensors);cuts=[];history=[]
    while True:
        candidates=(s for s in subsets(k)if feasible(s)and all(set(s)&set(d)for d in cuts))
        selected=min(candidates,key=lambda s:(sum((model.sensors[j].cost for j in s),Fraction(0)),s),default=None)
        if selected is None:
            return {'status':'no_feasible_sufficient_selection','cuts':cuts,'history':history}
        cost=sum((model.sensors[j].cost for j in selected),Fraction(0))
        lower_bound=cost
        if max_iterations is not None and len(history)>=max_iterations:
            return {'status':'incomplete','lower_bound':lower_bound,'candidate':selected,'cuts':cuts,'history':history}
        answer=model.obstruction(selected)
        row={'selection':list(selected),'cost':cost,'oracle':answer};history.append(row)
        if answer['status']=='sufficient':
            return {'status':'optimal','selection':list(selected),'cost':cost,'lower_bound':lower_bound,
                    'cuts':cuts,'history':history,'selected_names':[model.sensors[j].name for j in selected]}
        x,xp=answer['witness']
        d=[j for j,s in enumerate(model.sensors)if tuple(model.circuit.evaluate(x)[w]for w in s.wires)!=tuple(model.circuit.evaluate(xp)[w]for w in s.wires)]
        assert not set(selected)&set(d)
        row['distinguishing_menu']=d
        if not d:return {'status':'menu_insufficient','witness':[x,xp],'cuts':cuts,'history':history}
        cuts.append(d)


def future_register(blocks):
    """Nonlinear global predictive target, local raw/XOR sensor menu."""
    c=Circuit(2*blocks);x=[c.input(i)for i in range(2*blocks)]
    parity=c.fold('xor',x);target=c.gate('and',x[0],parity);truth=c.const(1)
    sensors=[Sensor('raw_'+str(i),(x[i],))for i in range(1,2*blocks)]
    for j in range(blocks):sensors.append(Sensor('pair_'+str(j),(c.gate('xor',x[2*j],x[2*j+1]),)))
    return Model(c,truth,(x[0],),(target,),sensors)
