"""Reproduce finite compiler, oracle, synthesis and predictive-register results.

Uses independent source enumeration as the reference, never the CNF solver to
define expected answers. No implementation of the new ETH algorithm is claimed.
"""
from pathlib import Path
from itertools import product,combinations
from fractions import Fraction
import random,time,json
from completion import Circuit,Sensor,Model,synthesize,future_register,count_cnf,compile_circuit,subsets
if not __debug__:raise RuntimeError('Run with assertions enabled.')
OUT=Path(__file__).resolve().parent
rng=random.Random(70120261027)

def brute_collision(m,s):
    states=[x for x in product((0,1),repeat=m.circuit.n)if m.allowed(x)]
    return sum(m.observe(x,s)==m.observe(y,s)and m.answer(x)!=m.answer(y)for x in states for y in states)

def brute_sufficient(m,s):
    seen={}
    for x in product((0,1),repeat=m.circuit.n):
        if not m.allowed(x):continue
        y=m.observe(x,s);a=m.answer(x)
        if y in seen and seen[y]!=a:return False
        seen[y]=a
    return True

def brute_optimum(m,feasible=lambda s:True):
    good=[s for s in subsets(len(m.sensors))if feasible(s)and brute_sufficient(m,s)]
    return min((sum((m.sensors[j].cost for j in s),Fraction(0)),s)for s in good)if good else None

def assert_raises(f):
    try:f()
    except ValueError:return
    raise AssertionError('invalid API input was accepted')

# DPLL on unrelated randomized CNFs, with unused variables and tautologies.
cnf_cases=0
for n in range(0,7):
    for rep in range(30):
        clauses=[]
        for _ in range(rng.randrange(0,10)):
            clauses.append(tuple(rng.choice((-1,1))*rng.randrange(1,n+1)for _ in range(rng.randrange(4)))if n else ())
        actual=count_cnf(clauses,n)
        want=sum(all(any(x[abs(l)-1]==int(l>0)for l in c)for c in clauses)for x in product((0,1),repeat=n))
        assert actual==want,(n,clauses,actual,want);cnf_cases+=1

# Every input has exactly one complete satisfying gate assignment.
gate_extension_cases=0
for n in range(0,5):
    c=Circuit(n);w=[c.input(i)for i in range(n)]+[c.const(0),c.const(1)]
    for rep in range(12):
        op=rng.choice(['not','and','or','xor']);args=[rng.choice(w)for _ in range(1 if op=='not'else 2)];w.append(c.gate(op,*args))
    cnf=compile_circuit(c)
    for x in product((0,1),repeat=n):
        fixed=cnf+[(i+1 if b else -(i+1),)for i,b in enumerate(x)]
        assert count_cnf(fixed,c.wires)==1
        v=c.evaluate(x);assert all(any(v[abs(l)]==int(l>0)for l in cl)for cl in cnf);gate_extension_cases+=1

# Random nonlinear readout/target circuits with random constrained source sets.
model_cases=0;selection_checks=0;posterior_checks=0
for rep in range(18):
    n=3+(rep%2);c=Circuit(n);w=[c.input(i)for i in range(n)];truth=c.const(1)
    for _ in range(5):
        op=rng.choice(['not','and','or','xor']);w.append(c.gate(op,*[rng.choice(w)for _ in range(1 if op=='not'else 2)]))
    admissible=rng.choice(w+[truth]);readout=(rng.choice(w),);target=tuple(rng.sample(w,2))
    sensors=[Sensor('s'+str(i),(rng.choice(w),),Fraction(1+i%2))for i in range(3)]
    m=Model(c,admissible,readout,target,sensors)
    for selected in subsets(3):
        r=m.obstruction(selected,with_count=True);want=brute_collision(m,selected)
        assert r['ordered_collision_count']==want and (r['status']=='sufficient')==(want==0);selection_checks+=1
    for y in product((0,1),repeat=1):
        for a in product((0,1),repeat=2):
            want=sum(m.allowed(x)and m.observe(x)==y and m.answer(x)==a for x in product((0,1),repeat=n))
            assert m.compatible_count(y,a)==want;posterior_checks+=1
    expected=brute_optimum(m);got=synthesize(m)
    if expected is None:assert got['status']=='menu_insufficient'
    else:assert got['status']=='optimal'and(got['cost'],tuple(got['selection']))==expected
    model_cases+=1

# Main nonlinear global future target and an all-time finite closure.
family=[]
for b in [1,2,3,4,5]:
    m=future_register(b);start=time.perf_counter();result=synthesize(m);elapsed=time.perf_counter()-start
    assert result['status']=='optimal'and result['cost']==b
    selected=result['selection'];n=2*b
    assert m.obstruction(with_count=True)['ordered_collision_count']==2**(4*b-3)
    assert m.obstruction(selected,with_count=True)['ordered_collision_count']==0
    # Check all-time autonomous closure by equal completed present signatures.
    transitions={};future_classes=set();raw_classes=set()
    for x in product((0,1),repeat=n):
        y=x[0];q=m.answer(x)[0];future_classes.add((y,q));raw_classes.add(m.observe(x,selected))
        xp=(q,)+x[1:];xpp=(m.answer(xp)[0],)+xp[1:]
        assert xp[0]==xpp[0]==m.answer(xpp)[0]
        old=m.observe(x,selected);new=m.observe(xp,selected)
        if old in transitions:assert transitions[old]==new
        transitions[old]=new
    assert future_classes=={(0,0),(1,0),(1,1)}and len(raw_classes)==2**(b+1)
    # Independent brute-subset global optimum for the first three sizes.
    if b<=3:assert brute_optimum(m)[0]==b
    weights={x:Fraction(3 if m.answer(x)==(1,)else 1)for x in product((0,1),repeat=n)}
    uniform=m.posterior((1,));weighted=m.posterior((1,),weights=weights)
    assert uniform['posterior'][(1,)]==Fraction(1,2)and weighted['posterior'][(1,)]==Fraction(3,4)
    row={'blocks':b,'source_bits':n,'gates_including_menu':len(m.circuit.gates),'target_completion_cost':str(result['cost']),
         'raw_or_full_source_minimum_cost':2*b-1,'canonical_predictive_states':3,
         'retained_port_signatures':len(raw_classes),'CEGIS_iterations':len(result['history']),
         'selected':result['selected_names'],'compiled_collision_variables':m.collision_formula()[1],
         'prototype_seconds':elapsed,'initial_ordered_collision_count':2**(4*b-3),
         'uniform_target_one_given_readout_one':'1/2','specified_weighted_target_one_given_readout_one':'3/4',
         'history':result['history']}
    family.append(row)

# An actual failure of irrevocable cheapest counterexample repair.
# State 00 has target0; the three remaining states target1. Sensors detect
# individual nonzero states for cost1, or raw-bit ports for cost6/5.
c=Circuit(2);x0,x1=c.input(0),c.input(1);truth=c.const(1);target=c.gate('or',x0,x1)
notx0=c.gate('not',x0);notx1=c.gate('not',x1)
singleton=[c.gate('and',notx0,x1),c.gate('and',x0,notx1),c.gate('and',x0,x1)]
menu=[Sensor('singleton_'+str(i),(w,),Fraction(1))for i,w in enumerate(singleton)]
menu += [Sensor('x0',(x0,),Fraction(6,5)),Sensor('x1',(x1,),Fraction(6,5))]
trap=Model(c,truth,(),(target,),menu);opt=synthesize(trap);assert opt['cost']==Fraction(11,5)
greedy=[];greedy_cuts=[]
while True:
    r=trap.obstruction(greedy)
    if r['status']=='sufficient':break
    a,z=r['witness'];d=[j for j in range(len(menu))if trap.observe(a,[j])!=trap.observe(z,[j])]
    add=min(d,key=lambda j:(menu[j].cost,j));greedy.append(add);greedy_cuts.append(d)
assert sum(menu[j].cost for j in greedy)==3
assert brute_optimum(trap)[0]==Fraction(11,5)

# Exact weighted frontier, independently checked by whole-subset enumeration.
weighted_frontier=[]
for b in [1,2,3]:
    m0=future_register(b)
    for rep in range(4):
        costs=[Fraction(rng.randrange(1,15),rng.randrange(1,5))for _ in m0.sensors]
        m=Model(m0.circuit,m0.admissible,m0.readout,m0.target,
                [Sensor(s.name,s.wires,cost)for s,cost in zip(m0.sensors,costs)])
        pair_start=2*b-1
        frontier=min(costs[0],costs[pair_start])
        for j in range(1,b):frontier+=min(costs[2*j-1]+costs[2*j],costs[pair_start+j])
        full_frontier=min(costs[0],costs[pair_start])
        for j in range(1,b):
            u,v,w=costs[2*j-1],costs[2*j],costs[pair_start+j]
            full_frontier+=min(u+v,u+w,v+w)
        got=synthesize(m);assert got['cost']==frontier==brute_optimum(m)[0]
        # Source-reconstruction reference separately checks injective readouts.
        def reconstructs(selected):
            seen={}
            for x in product((0,1),repeat=2*b):
                obs=m.observe(x,selected)
                if obs in seen and seen[obs]!=x:return False
                seen[obs]=x
            return True
        actual_full=min(sum((costs[j]for j in selected),Fraction(0))for selected in subsets(len(costs))if reconstructs(selected))
        assert actual_full==full_frontier
        weighted_frontier.append({'blocks':b,'costs':list(map(str,costs)),
            'proved_future_optimum':str(frontier),'proved_full_source_optimum':str(full_frontier),
            'synthesis_selection':got['selected_names']})

# Edge cases and user-interface validation.
c=Circuit(2);zero=c.const(0);one=c.const(1)
empty=Model(c,zero,(c.input(0),),(c.input(1),),[Sensor('r',(c.input(1),))])
assert empty.obstruction()['empty_admissible_set']and synthesize(empty)['cost']==0
assert empty.compatible_count((0,))==0 and empty.posterior((0,))['status']=='impossible_or_zero_mass_readout'
constant=Model(c,one,(),(),[]);assert constant.obstruction(with_count=True)['ordered_collision_count']==0
m=future_register(2)
assert synthesize(m,max_iterations=0)['status']=='incomplete'
assert synthesize(m,feasible=lambda s:False)['status']=='no_feasible_sufficient_selection'
assert synthesize(m,feasible=lambda s:len(s)<=1)['status']=='no_feasible_sufficient_selection'
assert_raises(lambda:m.compatible_count((2,)))
assert_raises(lambda:m.compatible_count((1,),(2,)))
assert_raises(lambda:m.obstruction([-1]))
assert_raises(lambda:m.obstruction([0,0]))
assert_raises(lambda:m.posterior((1,),weights={(0,0,0,0):Fraction(-1)}))
assert_raises(lambda:Sensor('bad',(1,),.1))

# Repeated output labels do not inflate comparison gates or CNF density.
c=Circuit(2);truth=c.const(1)
minimal=Model(c,truth,(1,),(2,));repeated=Model(c,truth,(1,)*17,(2,)*31)
assert minimal.collision_formula()==repeated.collision_formula()
assert repeated.obstruction(with_count=True)['ordered_collision_count']==4
assert repeated.compatible_count((0,)*17,(1,)*31)==1
assert repeated.compatible_count((0,)*16+(1,))==0

report={'status':'PASS','backend':'bounded-cache conventional exact DPLL and exhaustive subset optimizer; not an ETH-algorithm implementation',
        'random_CNF_cases':cnf_cases,'unique_gate_extension_cases':gate_extension_cases,'random_models':model_cases,
        'all_selection_collision_checks':selection_checks,'compatible_target_count_checks':posterior_checks,
        'predictive_register_family':family,
        'weighted_frontier_exact_checks':weighted_frontier,
        'irreversible_repair_counterexample':{'optimal_cost':'11/5','optimal_selection':opt['selected_names'],
         'cheapest_irrevocable_repair_cost':'3','greedy_selection':[menu[j].name for j in greedy]},
        'edge_cases':'empty admissible source, impossible readout, empty target, hardware infeasibility, incomplete separation, malformed bits/costs/priors passed',
        'claims':'Exact finite answers and derived parametric proofs; no empirical subexponential speedup claim.'}
(OUT/'results.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='predictive_register_family'},indent=2,default=str))
for r in family:print({k:v for k,v in r.items()if k!='history'})
