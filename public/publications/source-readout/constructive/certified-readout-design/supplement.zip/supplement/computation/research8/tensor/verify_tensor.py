#!/usr/bin/env python3
"""Exact component checks plus independent dense network reference answers."""
from pathlib import Path
import json,random,time
from itertools import product
from fractions import Fraction
from math import comb,ceil,log2
from target_crossing import (octonion_piece,projected_octonion_pieces,crossing,
    binary_piece,binary_factor,matrix_of,exact_rank,right_inverse,linear_readout,
    lift_value,QuotientNetwork,pattern_count,unrank_pattern,binary_grouped_piece,
    grouped_integer_factor,rational_network)


def check():
    rng=random.Random(801342)
    for z in product(range(8),repeat=4):
        assert sum(octonion_piece(w,*z)for w in ('R','C'))==2*crossing(*z)
    projected=projected_octonion_pieces()
    invalid_context_original=sum(int(z==0)**2 for z in range(4))
    invalid_context_compressed=2*sum(int(z==0)**2 for z in range(2))
    assert invalid_context_original==1 and invalid_context_compressed==2
    for z in product(range(2),repeat=4):
        assert sum(projected[w][z]for w in projected)==32*crossing(*z)
        assert sum(binary_piece(w,*z)for w in ('I','minusA'))==crossing(*z)
        for w in ('I','minusA'):
            for d in ('row','column'):
                assert sum(a*b for a,b in binary_factor(w,d,*z))==binary_piece(w,*z)
    ranks={w:{d:exact_rank(matrix_of(tab,2,d))for d in ('row','column')}
           for w,tab in projected.items()}
    assert ranks=={'R':{'row':4,'column':4},'C':{'row':4,'column':4}}
    newranks={w:{d:exact_rank(matrix_of({z:binary_piece(w,*z)for z in product(range(2),repeat=4)},2,d))
                    for d in ('row','column')}for w in ('I','minusA')}
    assert newranks=={'I':{'row':4,'column':1},'minusA':{'row':1,'column':4}}
    # Each of the 16 basis contexts delta_(Hx,Hy,Hu,Hv) is checked. By
    # linearity this is every rational surrounding context of the declared type.
    for z in product(range(2),repeat=4):
        lhs=sum(crossing(*zz)for zz in product(range(8),repeat=4)
                if tuple(x&1 for x in zz)==z)
        rhs=16*sum(binary_piece(w,*z)for w in ('I','minusA'))
        assert lhs==rhs
    # Random signed contexts, independently enumerated over the original domain.
    for _ in range(40):
        f={z:rng.randrange(-4,5)for z in product(range(2),repeat=4)}
        lhs=sum(crossing(*z)*f[tuple(x&1 for x in z)]for z in product(range(8),repeat=4))
        rhs=16*sum(crossing(*z)*v for z,v in f.items())
        assert lhs==rhs
    pattern_checks=0;factor_checks=0;grouped_rank_results=[]
    for t in range(1,5):
        for special in (0,3):
            for k in range(t+1):
                expected=[p for p in product(range(4),repeat=t)if sum(d!=special for d in p)<=k]
                assert len(expected)==pattern_count(t,k)
                assert [unrank_pattern(t,k,special,j)for j in range(len(expected))]==expected
                pattern_checks+=len(expected)
    for t in range(1,4):
        domain=list(product(range(1<<t),repeat=4))
        identity_domain=domain
        for z in identity_domain:
            assert sum(binary_grouped_piece(t,i,*z)for i in range(t+1))==crossing(*z)
        factor_domain=domain if t<=2 else rng.sample(domain,40)
        for i in range(t+1):
            for z in factor_domain:
                for d,budget in [('row',t-i),('column',i)]:
                    got=sum(a*b for a,b in (grouped_integer_factor(t,i,d,j,*z)
                                 for j in range(pattern_count(t,budget))))
                    assert got==(1<<t)*binary_grouped_piece(t,i,*z)
                    assert grouped_integer_factor(t,i,d,pattern_count(t,budget),*z)==(0,0)
                    factor_checks+=1
            table={z:binary_grouped_piece(t,i,*z)for z in domain}
            actual={d:exact_rank(matrix_of(table,1<<t,d))for d in ('row','column')}
            want={'row':pattern_count(t,t-i),'column':pattern_count(t,i)}
            assert actual==want
            assert ceil(log2(want['row']))+ceil(log2(want['column']))<=t*log2(12)+2
            grouped_rank_results.append({'bits':t,'piece':i,'ranks':actual})
    inverse_checks=0
    for width in range(1,9):
        for _ in range(25):
            masks=[]
            for _ in range(rng.randrange(width+1)):
                candidates=[m for m in range(1,1<<width)if
                            m not in masks]
                rng.shuffle(candidates)
                for m in candidates:
                    try:right_inverse(width,masks+[m])
                    except ValueError:continue
                    masks.append(m);break
            inv=right_inverse(width,masks)
            for y in range(1<<len(masks)):
                assert linear_readout(lift_value(y,inv),masks)==y;inverse_checks+=1
    # Genuine complete networks, not only isolated crossing gadgets.
    benches=[]
    for vertices in [3,4,6]:
        edges=[(a,b,3,(3,))for a in range(vertices)for b in range(a+1,vertices)]
        tables={v:{p:rng.randrange(1,8)for p in product(range(2),repeat=vertices-1)}
                for v in range(vertices)}
        net=QuotientNetwork(vertices,edges,tables)
        started=time.perf_counter();q,qcost=net.contract(True);qt=time.perf_counter()-started
        rec={'vertices':vertices,'edges':len(edges),'original_bits':3*len(edges),
             'quotient_bits':len(edges),'answer':str(q),'quotient_cost':qcost,
             'quotient_seconds':qt,'full_enumerator_assignments':str(1<<(3*len(edges))),
             'fair_specialized_comparator':'A quotient-aware ordinary evaluator has the same compressed task; no advantage over it is claimed.',
             'dense_original_executed':vertices<=4}
        if vertices<=4:
            started=time.perf_counter();full,fcost=net.contract(False);ft=time.perf_counter()-started
            assert q==full;rec.update(full_cost=fcost,full_seconds=ft)
            # Independently derive the original answer by equality incidence:
            # every retained edge tuple has exactly 4^E original lifts.
            slow=0
            for assignment in product(range(2),repeat=len(edges)):
                vals=[]
                for v in range(vertices):
                    local=tuple(assignment[j]for j,(a,b,_,_)in enumerate(edges)if v in (a,b))
                    vals.append(tables[v][local])
                term=1
                for value in vals:term*=value
                slow+=term
            assert q==slow*4**len(edges)
        benches.append(rec)
    invalid=0
    for w,m in [(3,(1,1)),(2,(0,)),(2,(4,)),(-1,())]:
        try:right_inverse(w,m)
        except ValueError:invalid+=1
        else:raise AssertionError('invalid quotient accepted')
    rational_checks=0
    for _ in range(30):
        edges=[(0,1,2,(3,)),(1,2,2,(1,)),(0,2,2,(2,))]
        tables={v:{p:Fraction(rng.randrange(-4,5),rng.randrange(1,8))
                   for p in product(range(2),repeat=2)}for v in range(3)}
        net,Q,param=rational_network(3,edges,tables)
        actual=Fraction(net.contract(True)[0],Q)
        reference=Fraction()
        for z in product(range(4),repeat=3):
            h=(int((z[0]&1)!=((z[0]>>1)&1)),z[1]&1,(z[2]>>1)&1)
            reference+=tables[0][h[0],h[2]]*tables[1][h[0],h[1]]*tables[2][h[1],h[2]]
        assert actual==reference;rational_checks+=1
    ans={'status':'PASS: exact identities, integer factors, context tests and network queries',
         'octonion_identity_cases':4096,'basis_context_cases':16,'random_context_cases':40,
         'projected_ranks':ranks,'recomposed_binary_ranks':newranks,
         'pattern_unranking_checks':pattern_checks,'integer_factorization_checks':factor_checks,
         'right_inverse_checks':inverse_checks,'invalid_input_checks':invalid,
         'signed_rational_network_checks':rational_checks,
         'invalid_context_counterexample':{'original':invalid_context_original,
             'incorrect_representative_compression':invalid_context_compressed},
         'grouped_rank_results':grouped_rank_results,'network_benchmarks':benches,
         'rho_binary':log2(12)/4,'alpha_binary':log2(4/log2(12)),
         'status_relative_to_paper':'Explicit integer completion of Appendix H rank hint; not a new crossing identity, not a better bound than Appendix B, and not a full ETH implementation.'}
    Path('results.json').write_text(json.dumps(ans,indent=2)+'\n')
    Path('projected_crossing_certificate.json').write_text(json.dumps({
      'row_order':['00','01','10','11'],
      'projected_R':matrix_of(projected['R'],2,'row'),
      'projected_C':matrix_of(projected['C'],2,'row'),
      'sum_scale':32,'ranks':ranks,'new_ranks':newranks},indent=2)+'\n')
    print(json.dumps(ans,indent=2))

if __name__=='__main__':check()
