#!/usr/bin/env python3
"""Exact finite target-completion interface. Conventional backend, not ETH code."""
from pathlib import Path
import argparse, json, sys
from fractions import Fraction

HOME=Path(__file__).resolve().parent
PACKAGE=HOME.parents[1] if HOME.name=='root' else HOME
sys.path.insert(0,str(PACKAGE))
from research7.finite.completion import Circuit, Sensor, Model, synthesize, future_register

def wire_ids(text,model):
    if not text:return ()
    names={s.name:i for i,s in enumerate(model.sensors)}
    return tuple(names[x] for x in text.split(','))

def load_model(path):
    def reject_constant(value):
        raise ValueError('Non-finite JSON value in source model: '+value)
    spec=json.loads(Path(path).read_text(),parse_float=Fraction,
                    parse_constant=reject_constant)
    c=Circuit(spec['source_bits'])
    for gate in spec.get('gates',[]):c.gate(gate['op'],*gate.get('args',[]))
    admissible=spec.get('admissible')
    if admissible is None:admissible=c.const(True)
    sensors=[Sensor(s['name'],tuple(s['wires']),Fraction(str(s.get('cost',1))))
             for s in spec.get('sensors',[])]
    model=Model(c,admissible,spec.get('readout',[]),spec.get('target',[]),sensors)
    names={s.name:i for i,s in enumerate(sensors)}
    pairs=[tuple(names[n]for n in pair)for pair in spec.get('incompatible_pairs',[])]
    prereq=[(names[a],names[b])for a,b in spec.get('prerequisites',[])]
    maximum=spec.get('max_selected',len(sensors))
    def feasible(selection):
        s=set(selection)
        return (len(s)<=maximum and all(not set(pair)<=s for pair in pairs)
                and all(a not in s or b in s for a,b in prereq))
    weights=None
    if 'prior' in spec:
        weights={tuple(int(b)for b in row['source']):Fraction(row['weight'])for row in spec['prior']}
    return model,feasible,weights

def json_default(x):
    if isinstance(x,Fraction):return str(x)
    if isinstance(x,(set,frozenset,tuple)):return list(x)
    raise TypeError(type(x).__name__)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('operation',choices=['audit','synthesize','posterior','demo'])
    p.add_argument('--model',help='JSON circuit and permitted-sensor description')
    p.add_argument('--selected',default='',help='comma-separated sensor names')
    p.add_argument('--observed',default='',help='observed bit string, including selected sensors')
    p.add_argument('--blocks',type=int,default=3,help='nonlinear future-register demo size')
    p.add_argument('--max-iterations',type=int)
    p.add_argument('--output',help='optional JSON result path')
    a=p.parse_args()
    if a.operation=='demo':
        if a.blocks<1:p.error('blocks must be positive')
        model=future_register(a.blocks)
        result={'backend':'conventional exact DPLL and exhaustive finite-menu optimizer',
                'before':model.obstruction(with_count=True),'design':synthesize(model,max_iterations=a.max_iterations)}
    else:
        if not a.model:p.error('--model is required')
        model,feasible,weights=load_model(a.model)
        selected=wire_ids(a.selected,model)
        if a.operation=='audit':result=model.obstruction(selected,with_count=True)
        elif a.operation=='synthesize':result=synthesize(model,feasible,a.max_iterations)
        else:
            if any(c not in '01'for c in a.observed):p.error('--observed must be a bit string')
            q=model.posterior(tuple(map(int,a.observed)),selected,weights)
            result={'status':q['status'],'mass':q['mass'],
                    'posterior':[{'target':list(k),'probability':v}for k,v in q['posterior'].items()]}
    output=json.dumps(result,indent=2,default=json_default)+'\n'
    if a.output:Path(a.output).write_text(output)
    print(output,end='')
if __name__=='__main__':main()
