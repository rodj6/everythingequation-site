"""Exact context-quotient preprocessing and a faithful crossing component.

No implementation of the full Anthropic or OpenAI ETH algorithm is claimed.
The functions below implement the paper's actual eight-square identity,
its finite pushforward, and an integer network boundary-quotient adapter.
"""
from fractions import Fraction
from itertools import product
from math import comb, lcm, prod


def parity(x):
    return x.bit_count() & 1


def linear_readout(x, masks):
    return sum(parity(x & m) << i for i, m in enumerate(masks))


def right_inverse(width, masks):
    """Polynomial-work F2 Gaussian elimination, returning lifted output basis."""
    if not isinstance(width, int) or isinstance(width, bool) or width < 0:
        raise ValueError('width must be a nonnegative integer')
    masks = tuple(masks)
    if any(not isinstance(m, int) or isinstance(m, bool) or m <= 0 or m >= (1 << width)
           for m in masks):
        raise ValueError('masks must be positive width-bit integers')
    basis = {}
    for j in range(width):
        y, x = linear_readout(1 << j, masks), 1 << j
        while y:
            p = y.bit_length()-1
            if p not in basis:
                basis[p] = (y, x)
                break
            z, lift = basis[p]
            y ^= z
            x ^= lift
    if len(basis) != len(masks):
        raise ValueError('readout must have full row rank')
    lifts = []
    for k in range(len(masks)):
        y, x = 1 << k, 0
        while y:
            p = y.bit_length()-1
            z, lift = basis[p]
            y ^= z
            x ^= lift
        lifts.append(x)
    return tuple(lifts)


def lift_value(y, lifts):
    if y < 0 or y >= 1 << len(lifts):
        raise ValueError('quotient value out of range')
    x = 0
    for i, v in enumerate(lifts):
        if y >> i & 1:
            x ^= v
    return x


def octonion_sign(p, q):
    """Paper equation (27), with low-to-high bits naming p1,p2,p3."""
    a = tuple(p >> i & 1 for i in range(3))
    b = tuple(q >> i & 1 for i in range(3))
    e = sum(a[i]*b[j] for i in range(3) for j in range(i, 3))
    e += b[0]*a[1]*a[2]+a[0]*b[1]*a[2]+a[0]*a[1]*b[2]
    return 1-2*(e & 1)


def crossing(x, y, u, v):
    return int(x == v and y == u)


def octonion_piece(which, x, y, u, v):
    if which not in ('R', 'C'):
        raise ValueError('piece must be R or C')
    if x ^ y ^ u ^ v:
        return 0
    if which == 'R':
        return octonion_sign(x, y)*octonion_sign(v, u)
    return octonion_sign(x, u)*octonion_sign(v, y)


def projected_octonion_pieces():
    """Exact four-boundary fibre sums for H(x)=x mod 2."""
    ans = {w: {z: 0 for z in product(range(2), repeat=4)} for w in ('R', 'C')}
    for z in product(range(8), repeat=4):
        h = tuple(x & 1 for x in z)
        for w in ans:
            ans[w][h] += octonion_piece(w, *z)
    return ans


def antisymmetric(x, y):
    return (y-x) if x != y else 0


def binary_piece(which, x, y, u, v):
    """Appendix H's one-bit identity S=I-A, with integer factors."""
    if which == 'I':
        return int(x == u and y == v)
    if which == 'minusA':
        return -antisymmetric(x, y)*antisymmetric(u, v)
    raise ValueError('unknown binary piece')


def binary_factor(which, direction, x, y, u, v):
    """Return the exact inner products, explicitly enumerating permitted bits.

    I column: one product; minusA row: one product.
    In the other direction use four terms, the coordinate-selector factorization.
    """
    if direction == 'row':
        if which == 'minusA':
            return [(-antisymmetric(x, y), antisymmetric(u, v))]
        return [(int((x, y) == (a, b)), binary_piece(which, a, b, u, v))
                for a, b in product(range(2), repeat=2)]
    if direction == 'column':
        if which == 'I':
            return [(int(x == u), int(y == v))]
        return [(int((x, u) == (a, b)), binary_piece(which, a, y, b, v))
                for a, b in product(range(2), repeat=2)]
    raise ValueError('direction must be row or column')


def exact_rank(matrix):
    a = [list(map(Fraction, row)) for row in matrix]
    k = 0
    for j in range(len(a[0])) if a else ():
        p = next((p for p in range(k, len(a)) if a[p][j]), None)
        if p is None:
            continue
        a[k], a[p] = a[p], a[k]
        d = a[k][j]
        a[k] = [x/d for x in a[k]]
        for p in range(k+1, len(a)):
            d = a[p][j]
            if d:
                a[p] = [x-d*y for x, y in zip(a[p], a[k])]
        k += 1
    return k


def matrix_of(table, size, direction):
    pairs = tuple(product(range(size), repeat=2))
    if direction == 'row':
        return [[table[x, y, u, v] for u, v in pairs] for x, y in pairs]
    return [[table[x, y, u, v] for y, v in pairs] for x, u in pairs]


def pattern_count(t, k):
    if k < 0:
        return 0
    return sum(comb(t,z)*3**z for z in range(min(t,k)+1))


def unrank_pattern(t, k, special, index):
    """Bell patterns with at most k nonspecial positions, lexicographic order."""
    if not 0 <= index < pattern_count(t,k):
        raise ValueError('pattern index out of range')
    ans=[]
    for pos in range(t):
        left=t-pos-1
        for d in range(4):
            budget=k-int(d!=special)
            n=pattern_count(left,budget)
            if index < n:
                ans.append(d);k=budget;break
            index-=n
    return tuple(ans)


def bell_entry(d,a,b):
    """Phi+, Phi-, Psi+, Psi-; integer vectors of squared norm two."""
    if d < 2:
        return int(a==b)*(1 if d==0 or a==0 else -1)
    return int(a!=b)*(1 if d==2 or a==0 else -1)


def bell_product(pattern,a,b):
    value=1
    for j,d in enumerate(pattern):
        value*=bell_entry(d,a>>j&1,b>>j&1)
    return value


def binary_grouped_piece(t,i,x,y,u,v):
    """Coefficient of T^i in product(I_j-T A_j)."""
    if t < 1 or not 0 <= i <= t:
        raise ValueError('require t>=1 and 0<=i<=t')
    p=[1]
    for j in range(t):
        z=tuple(w>>j&1 for w in (x,y,u,v))
        a,b=binary_piece('I',*z),binary_piece('minusA',*z)
        q=[0]*(len(p)+1)
        for k,c in enumerate(p):q[k]+=a*c;q[k+1]+=b*c
        p=q
    return p[i]


def grouped_integer_factor(t,i,direction,index,x,y,u,v):
    """Integer factors of 2^t B_i through exactly the certified matrix rank.

    Out-of-range padding indexes return zero, as Definition 1 requires.
    """
    if t < 1 or not 0 <= i <= t:
        raise ValueError('require t>=1 and 0<=i<=t')
    if direction=='row':
        special,budget=3,t-i
    elif direction=='column':
        special,budget=0,i
    else:raise ValueError('unknown direction')
    if index < 0 or index >= pattern_count(t,budget):return 0,0
    pattern=unrank_pattern(t,budget,special,index)
    if direction=='row':
        z=pattern.count(3)
        eigen=(-2)**i*comb(z,i)
        return eigen*bell_product(pattern,x,y),bell_product(pattern,u,v)
    z=t-pattern.count(0)
    eigen=(-1)**(pattern.count(3)+i-z)*2**(t-i)*comb(t-z,i-z)
    return eigen*bell_product(pattern,x,u),bell_product(pattern,y,v)


class QuotientNetwork:
    """Closed integer network, with supplied quotient-factorized vertex tables.

    Edges are (a,b,width,masks). The table for vertex v is a mapping from a tuple
    of quotient-edge values to an integer, in input edge order. The full tensor
    is DEFINED as its pullback, not inferred from a few dense queries.
    """
    def __init__(self, vertices, edges, tables):
        self.vertices = vertices
        self.edges = tuple((a,b,w,tuple(m)) for a,b,w,m in edges)
        self.lifts = []
        if vertices < 1:
            raise ValueError('need at least one vertex')
        for a,b,w,m in self.edges:
            if not (0 <= a < b < vertices):
                raise ValueError('edge endpoints out of range or unordered')
            self.lifts.append(right_inverse(w,m))
        self.incident = [tuple(e for e,(a,b,_,_) in enumerate(self.edges) if v in (a,b))
                         for v in range(vertices)]
        self.tables = tables
        for v, inc in enumerate(self.incident):
            keys = set(product(*(range(1 << len(self.edges[e][3])) for e in inc)))
            if set(tables[v]) != keys or any(type(z) is not int for z in tables[v].values()):
                raise ValueError('integer tables must cover exactly the quotient domains')

    @property
    def discarded_bits(self):
        return sum(w-len(m) for _,_,w,m in self.edges)

    def contract(self, quotient=True):
        sizes = [len(m) if quotient else w for _,_,w,m in self.edges]
        mappings = None
        if not quotient:
            mappings = [[linear_readout(z,m) for z in range(1 << w)]
                        for _,_,w,m in self.edges]
        total = 0
        assignments = 0
        for z in product(*(range(1 << s) for s in sizes)):
            h = z if quotient else tuple(mappings[e][v] for e,v in enumerate(z))
            term = 1
            for v, inc in enumerate(self.incident):
                term *= self.tables[v][tuple(h[e] for e in inc)]
            total += term
            assignments += 1
        factor = 1 << self.discarded_bits if quotient else 1
        return total*factor, {'assignments': assignments,
                             'vertex_queries': assignments*self.vertices,
                             'recovery_shift_bits': self.discarded_bits if quotient else 0,
                             'original_readout_preprocessing_entries':
                                 0 if quotient else sum(1 << w for _,_,w,_ in self.edges)}


def rational_network(vertices, edges, tables):
    """Clear each supplied rational quotient vertex table exactly once.

    Returns integer network, denominator and representation parameters.
    The same denominator is used after the integer fibre multiplier is restored.
    """
    rational={v:{k:Fraction(x)for k,x in tab.items()}for v,tab in tables.items()}
    denominators={v:lcm(*(x.denominator for x in tab.values()))for v,tab in rational.items()}
    integer={v:{k:int(x*denominators[v])for k,x in tab.items()}for v,tab in rational.items()}
    net=QuotientNetwork(vertices,edges,integer)
    B=max(1,max((abs(x).bit_length()for tab in integer.values()for x in tab.values()),default=0))
    P=max(1,max((sum(len(net.edges[e][3])for e in inc)for inc in net.incident),default=0))
    return net,prod(denominators.values()),{'per_vertex_denominator':denominators,
      'strict_integer_entry_bits_B':B,'max_quotient_setting_bits_P':P,
      'two_ended_interface_bits_U':2*sum(len(e[3])for e in net.edges),
      'recovery_shift_bits':net.discarded_bits,
      'backend':'ordinary exact enumeration, not Anthropic recursion'}
