"""Independent exact references for the weighted adapter under test.

No producer arithmetic or elimination is used to obtain expected answers.
The production API is imported only to compare its results with them.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import importlib.util,random,json

if not __debug__:raise RuntimeError('Do not disable audit assertions.')

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('audited_weighted',HERE.parent/'weighted/weighted.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
rng=random.Random(706015)
def reference(n,fs):
 total=F(0)
 for x in product((0,1),repeat=n):
  val=F(1)
  for scope,table in fs:
   ix=sum(x[v]<<(len(scope)-j-1)for j,v in enumerate(scope));val*=table[ix]
  total+=val
 return total
models=0
for n in range(6):
 for _ in range(20):
  rows=[]
  for j in range(rng.randrange(7)):
   size=rng.randrange(min(n,3)+1);scope=tuple(rng.sample(range(n),size))
   table=tuple(F(rng.randint(-5,5),rng.randint(1,7))for k in range(1<<size));rows.append((scope,table))
  fs=[api.Factor(*row)for row in rows];want=reference(n,rows)
  got,receipt=api.contract_modular(n,fs)
  assert got==want and api.direct(n,fs)==want
  el,stats=api.eliminate(n,fs,order=list(reversed(range(n))))
  assert el==want
  Q=int(receipt['denominator']);z=want*Q;assert z.denominator==1
  assert int(receipt['residue'])==int(z)%(1<<receipt['precision_bits'])
  # Independently supplied narrow interval of width three around truth.
  # This is a test promise, not an algorithm deriving a bound from its result.
  tight,_=api.contract_modular(n,fs,interval=(int(z)-1,int(z)+2));assert tight==want
  models+=1

decode_checks=0
for P in range(1,8):
 M=2**P
 for lo in range(-20,21):
  for width in [0,1,max(0,M-1),M,M+1]:
   hi=lo+width
   for r in {lo%M,(hi+1)%M}:
    candidates=[z for z in range(lo,hi+1)if z%M==r]
    try:got=api.decode_interval(r,P,lo,hi)
    except ValueError:assert len(candidates)!=1
    else:assert candidates==[got]
    decode_checks+=1

# Independent port-by-port contraction of actual converted networks.
def port_ref(vs,edges):
 out=F(0)
 for bs in product((0,1),repeat=len(edges)):
  val=F(1)
  for i,v in enumerate(vs):
   ports=[None]*v['degree']
   for bit,(p,q)in zip(bs,edges):
    if p[0]==i:ports[p[1]]=bit
    if q[0]==i:ports[q[1]]=bit
   assert None not in ports
   index=0
   for b in ports:index=index*2+b
   val*=v['table'][index]
  out+=val
 return out
network_cases=[]
for n,rows in [(2,[((0,1),(F(1,2),F(-2,3),F(5,7),F(3,4)))]),
               (1,[((0,),(F(1,3),F(-2,5)))]*4),
               (3,[((),(F(-5,7),)),((0,),(F(2,3),F(4,5)))])]:
 fs=[api.Factor(*row)for row in rows];vs,es=api.as_boolean_network(n,fs)
 assert port_ref(vs,es)==reference(n,rows)
 assert len(es)<=4*sum(len(row[0])for row in rows)
 network_cases.append(dict(source_bits=n,network_wires=len(es),network_vertices=len(vs)))

# Independent exact HMM forward probabilities and initial-source posterior.
word=[1,0,1,1,0];P=[[F(4,5),F(1,5)],[F(1,5),F(4,5)]]
def forward(initial):
 v=[initial[i]*(F(6,7)if i==word[0]else F(1,7))for i in range(2)]
 for y in word[1:]:v=[sum(v[i]*P[i][j]for i in range(2))*(F(6,7)if j==y else F(1,7))for j in range(2)]
 return sum(v)
den=forward([F(1,2),F(1,2)]);num=forward([F(1,2),F(0)])
assert den==F(848,60025)and num/den==F(1501,7420)
result=dict(status='PASS',independent_random_models=models,interval_residue_checks=decode_checks,converted_port_networks=network_cases,HMM_word_probability=str(den),HMM_initial_posterior=str(num/den),scope='Exact arithmetic/reference backend audit; not a reproduction of the ETH contraction algorithm.')
(HERE/'weighted_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
