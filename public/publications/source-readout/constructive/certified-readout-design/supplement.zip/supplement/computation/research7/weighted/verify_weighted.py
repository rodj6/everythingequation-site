"""Exact tests for rational contraction adapter; standard backends, not ETH."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,random
from weighted import *
if not __debug__:raise RuntimeError('Do not disable certificate assertions.')

OUT=Path(__file__).resolve().parent
rng=random.Random(720261027)
cases=0
for n in range(0,7):
    for trial in range(20):
        fs=[]
        for _ in range(rng.randint(0,7)):
            scope=tuple(rng.sample(range(n),rng.randint(0,min(3,n))))
            fs.append(Factor(scope,tuple(F(rng.randint(-7,7),rng.randint(1,9))for _ in range(1<<len(scope)))))
        a=direct(n,fs);b,meta=eliminate(n,fs);c,cert=contract_modular(n,fs)
        assert a==b==c,(n,trial,a,b,c);cases+=1

# Explicit signed, rational cyclic contraction. Independent reference: matrix powers.
M=((F(1,2),F(-2,3)),(F(3,5),F(-7,11)))
def mm(A,B):return tuple(tuple(sum(A[i][k]*B[k][j]for k in range(2))for j in range(2))for i in range(2))
I=((F(1),F(0)),(F(0),F(1)))
loops=[]
for n in [3,5,6,40]:
    fs=[Factor((i,(i+1)%n),tuple(t for row in M for t in row))for i in range(n)]
    power=I
    for _ in range(n):power=mm(power,M)
    expected=power[0][0]+power[1][1]
    actual,cost=eliminate(n,fs);assert actual==expected
    if n<=6:
        modular,cert=contract_modular(n,fs);assert modular==actual
        assert direct(n,fs)==actual
    else:cert={'note':'No modular exhaustive run; elimination matches independent 2x2 power.'}
    loops.append(dict(bits=n,answer=str(actual),cost=cost,modular=cert,
                      exhaustive_assignments=str(1<<n)))

# Explicit Boolean-wire adapter (including high variable incidence, scalar/unused bits).
network_cases=[(0,[Factor((),(F(-2,3),))]),(1,[Factor((0,),(1,2))]*4),
               (2,[Factor((0,1),(F(1,2),F(-1,3),F(2,5),F(3,7))),Factor((1,0),(2,3,4,5))]),
               (3,[Factor((0,),(1,2))])]
network_records=[]
for n,fs in network_cases:
    vertices,edges=as_boolean_network(n,fs)
    got=network_direct(vertices,edges);want=direct(n,fs);assert got==want
    network_records.append(dict(source_bits=n,tensors=len(vertices),wires=len(edges),
                                max_degree=max((v['degree']for v in vertices),default=0),answer=str(got)))

# Independent finite HMM record calculation. One hidden bit at each clock tick.
n=5; word=(1,0,1,1,0)
P=((F(4,5),F(1,5)),(F(1,5),F(4,5)))
E=((F(6,7),F(1,7)),(F(1,7),F(6,7))) # rows hidden, columns emitted
fs=[Factor((0,),(F(1,2),F(1,2)))]
fs += [Factor((i,i+1),tuple(z for row in P for z in row))for i in range(n-1)]
fs += [Factor((i,),(E[0][word[i]],E[1][word[i]]))for i in range(n)]
for row in P+E:assert sum(row)==1 and min(row)>=0
alpha=[F(1,2)*E[i][word[0]]for i in range(2)]
for symbol in word[1:]:alpha=[sum(alpha[i]*P[i][j]for i in range(2))*E[j][symbol]for j in range(2)]
expected=sum(alpha);raw=direct(n,fs);assert raw==expected
ints,Q,bound,qs=clear_denominators(n,fs)
# Every emitted word factor<=6/7 and hidden-path weights are normalized.
upper=F(Q)*F(6,7)**n;event_upper=upper.numerator//upper.denominator
normal,normal_cert=contract_modular(n,fs,(0,event_upper));default,default_cert=contract_modular(n,fs)
assert normal==default==expected
joint_model=[Factor((0,),(F(1,2),F(1,2)))]+[Factor((i,i+1),tuple(z for row in P for z in row))for i in range(n-1)]
event=[Factor((0,),(1,0))];condition=fs[len(joint_model):]
posterior=conditional(n,joint_model,event,condition)
assert posterior is not None and 0<posterior<1
alpha0=[F(1,2)*E[0][word[0]],F(0)]
for symbol in word[1:]:alpha0=[sum(alpha0[i]*P[i][j]for i in range(2))*E[j][symbol]for j in range(2)]
assert posterior==sum(alpha0)/expected==F(1501,7420)
assert conditional(1,[Factor((0,),(1,0))],[],[Factor((0,),(0,1))])is None
try:conditional(1,[Factor((0,),(1,-1))],[])
except ValueError:pass
else:raise AssertionError('Signed source accepted as probability.')

# Sharp uniform interval criterion, including signed answers and impossible residues.
interval_checks=0
for L in range(-12,13):
    for U in range(L,L+16):
        p=precision_for_interval(L,U)
        for value in range(L,U+1):
            assert decode_interval(value%(1<<p),p,L,U)==value;interval_checks+=1
        if p>1 and U-L>=1<<(p-1):
            try:decode_interval(L%(1<<(p-1)),p-1,L,U)
            except ValueError:pass
            else:raise AssertionError('Insufficient modulus accepted.')
assert target_residue_consistent(range(0,32),lambda z:z%2,1)
assert not target_residue_consistent(range(0,32),lambda z:z==0,4)
assert target_residue_consistent(range(0,32),lambda z:z==0,5)

data=dict(status='PASS: exact rational, modular, interval and independent-reference checks',
 backend='ordinary exhaustive enumeration and variable elimination; no ETH routine implemented',
 random_exact_cases=cases,interval_decode_checks=interval_checks,boolean_network_examples=network_records,
 signed_cycles=loops,record_example=dict(hidden_bits=n,word=word,probability=str(expected),
  posterior_initial_zero=str(posterior),crude_precision=default_cert['precision_bits'],
  justified_probability_precision=normal_cert['precision_bits'],normalization_bound=str(event_upper),
  source_normalization='independently checked Markov initial/transition/emission tables',
  raw_modular_certificate=default_cert,normalized_modular_certificate=normal_cert),
 scope='Mathematical adapter and exact tests; no empirical or general runtime improvement claim.')
(OUT/'results.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
