"""Independent crossing, projection, rank and integer-factor checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from math import comb
import random,sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research8.tensor.target_crossing import octonion_piece,projected_octonion_pieces,binary_grouped_piece,grouped_integer_factor,pattern_count,QuotientNetwork

def sgn(p,q):
    a=[(p>>j)&1 for j in range(3)];b=[(q>>j)&1 for j in range(3)]
    e=sum(a[i]*b[j]for i in range(3)for j in range(i,3))+b[0]*a[1]*a[2]+a[0]*b[1]*a[2]+a[0]*a[1]*b[2]
    return (-1)**e

def direct_piece(t,i,x,y,u,v):
    # Direct subset expansion, independent of coefficient polynomial multiplication.
    ans=0
    for selected in combinations(range(t),i):
        selected=set(selected);term=1
        for j in range(t):
            a,b,c,d=[w>>j&1 for w in (x,y,u,v)]
            term*=(-(b-a)*(d-c))if j in selected else int(a==c and b==d)
        ans+=term
    return ans

def rank(a):
    a=[list(map(F,row))for row in a];k=0
    for j in range(len(a[0])):
        i=next((i for i in range(k,len(a))if a[i][j]),None)
        if i is None:continue
        a[k],a[i]=a[i],a[k];z=a[k][j];a[k]=[v/z for v in a[k]]
        for i in range(k+1,len(a)):
            z=a[i][j]
            if z:a[i]=[v-z*w for v,w in zip(a[i],a[k])]
        k+=1
    return k

def main():
    rng=random.Random(86532);oct_checks=0;fac_checks=0;rank_checks=0
    projected={name:{q:0 for q in product(range(2),repeat=4)}for name in ['R','C']}
    for x,y,u,v in product(range(8),repeat=4):
        r=int(x^y^u^v==0)*sgn(x,y)*sgn(v,u)
        c=int(x^y^u^v==0)*sgn(x,u)*sgn(v,y)
        assert r==octonion_piece('R',x,y,u,v)and c==octonion_piece('C',x,y,u,v)
        assert r+c==2*int(x==v and y==u);oct_checks+=1
        q=tuple(z&1 for z in (x,y,u,v));projected['R'][q]+=r;projected['C'][q]+=c
    assert projected==projected_octonion_pieces()
    for q in projected['R']:assert projected['R'][q]+projected['C'][q]==32*int(q[0]==q[3]and q[1]==q[2])
    for t in range(1,4):
        n=1<<t;pairs=list(product(range(n),repeat=2))
        for i in range(t+1):
            for direction in ['row','column']:
                matrix=[[direct_piece(t,i,x,y,u,v)for a,b in pairs for x,y,u,v in
                         ([(c,d,a,b)]if direction=='row'else[(c,a,d,b)])]
                        for c,d in pairs]
                expected=sum(comb(t,z)*3**z for z in range((t-i if direction=='row'else i)+1))
                assert rank(matrix)==expected==pattern_count(t,t-i if direction=='row'else i);rank_checks+=1
                cases=list(product(range(n),repeat=4))if t<=2 else [tuple(rng.randrange(n)for _ in range(4))for _ in range(40)]
                for q in cases:
                    assert binary_grouped_piece(t,i,*q)==direct_piece(t,i,*q)
                    values=[grouped_integer_factor(t,i,direction,j,*q)for j in range(expected)]
                    assert all(type(z)is int for pair in values for z in pair)
                    assert sum(a*b for a,b in values)==(1<<t)*direct_piece(t,i,*q);fac_checks+=1
    # Exact weighted-product rank bound underlying rho = log2(12)/4.
    for t in range(1,101):
        for i in range(t+1):assert pattern_count(t,i)*pattern_count(t,t-i)<=12**t
    network_checks=0
    for _ in range(12):
        edges=[(0,1,3,(1,)),(0,2,3,(3,)),(1,2,2,(1,))]
        tables=[{q:rng.randrange(-3,4)for q in product(range(2),repeat=2)}for _ in range(3)]
        net=QuotientNetwork(3,edges,tables)
        truth=0
        for a,b,c in product(range(8),range(8),range(4)):
            z=(a&1,(b&3).bit_count()%2,c&1)
            truth+=tables[0][z[0],z[1]]*tables[1][z[0],z[2]]*tables[2][z[1],z[2]]
        assert net.contract(False)[0]==truth==net.contract(True)[0];network_checks+=1
    result={'status':'PASS','octonion_truth_cases':oct_checks,'projected_boundary_basis_values':16,
            'independent_rank_checks':rank_checks,'integer_factor_inner_products':fac_checks,
            'rank_product_inequalities':sum(t+1 for t in range(1,101)),
            'signed_quotient_networks':network_checks,
            'scope':'Known crossing/rank hints with explicit integer factors; restricted supplied quotient contexts. Not a general ETH exponent improvement or physical resource minimum.'}
    (Path(__file__).parent/'tensor_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()
