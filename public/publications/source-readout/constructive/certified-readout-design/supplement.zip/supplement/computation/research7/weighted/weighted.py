"""Exact rational factor contraction and precision adapter.

Backends are explicit enumeration and ordinary variable elimination, NOT the
ETH paper's recursive subexponential contraction algorithm.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import lcm, prod

@dataclass(frozen=True)
class Factor:
    scope: tuple
    table: tuple

    def __post_init__(self):
        if len(set(self.scope)) != len(self.scope):
            raise ValueError('Factor scopes use distinct Boolean variables.')
        if len(self.table) != 1 << len(self.scope):
            raise ValueError('Truth table has the wrong size.')
        object.__setattr__(self, 'table', tuple(F(x) for x in self.table))

    def at(self, assignment):
        ix = 0
        for v in self.scope:
            ix = 2*ix + assignment[v]
        return self.table[ix]

def validate(n, factors):
    if n < 0 or any(not isinstance(v,int) or not 0 <= v < n for f in factors for v in f.scope):
        raise ValueError('Undeclared source variable.')

def direct(n, factors):
    validate(n, factors)
    return sum((prod((f.at(x) for f in factors), start=F(1))
                for x in product((0,1), repeat=n)), start=F(0))

def eliminate(n, factors, order=None):
    """Ordinary sum-product elimination, retaining explicit table cost counts."""
    validate(n, factors)
    order = list(range(n)) if order is None else list(order)
    if sorted(order) != list(range(n)): raise ValueError('Order is not a permutation.')
    fs = list(factors); evaluations = 0; max_scope = 0
    for v in order:
        bucket = [f for f in fs if v in f.scope]
        fs = [f for f in fs if v not in f.scope]
        if not bucket:
            fs.append(Factor((),(2,))); continue
        scope = tuple(sorted(set().union(*(set(f.scope) for f in bucket)) - {v}))
        max_scope = max(max_scope,len(scope)+1); table=[]
        for bits in product((0,1),repeat=len(scope)):
            a=dict(zip(scope,bits)); total=F(0)
            for bit in (0,1):
                a[v]=bit
                total += prod((f.at(a) for f in bucket),start=F(1))
                evaluations += len(bucket)
            table.append(total)
        fs.append(Factor(scope,tuple(table)))
    answer=prod((f.table[0] for f in fs),start=F(1))
    return answer, {'factor_entry_evaluations':evaluations,'max_bucket_scope':max_scope}

def clear_denominators(n, factors):
    validate(n,factors)
    qs=[lcm(*(x.denominator for x in f.table)) for f in factors]
    integer=[Factor(f.scope,tuple(int(x*q) for x in f.table)) for f,q in zip(factors,qs)]
    Q=prod(qs); A=[max(map(abs,f.table),default=0) for f in integer]
    bound=int((1<<n)*prod(A))
    return integer,Q,bound,qs

def precision_for_interval(lo,hi):
    if not isinstance(lo,int) or not isinstance(hi,int) or lo>hi:
        raise ValueError('Need a nonempty integer interval.')
    # P>=1 to match Theorem D.1; M>width is exact uniqueness condition.
    return max(1,(hi-lo).bit_length())

def decode_interval(residue,P,lo,hi):
    if P<1 or lo>hi:raise ValueError('Invalid precision/interval.')
    M=1<<P; r=residue%M
    first=r+((lo-r+M-1)//M)*M
    if first>hi:raise ValueError('Residue contradicts the promised interval.')
    if first+M<=hi:raise ValueError('Interval contains indistinguishable integers.')
    return first

def modular_integer(n,integer_factors,P):
    if P<1:raise ValueError('Need positive precision.')
    validate(n,integer_factors);M=1<<P;out=0
    for x in product((0,1),repeat=n):
        value=1
        for f in integer_factors:
            a=f.at(x)
            if a.denominator!=1:raise ValueError('Integer factors required.')
            value=value*int(a)%M
        out=(out+value)%M
    return out

def contract_modular(n,factors,interval=None):
    """Reference modular backend plus proved exact signed/interval recovery.

    A supplied interval is a premise for the scaled integer contraction. It
    must come from an independent bound; the modular residue cannot certify it.
    """
    ints,Q,bound,qs=clear_denominators(n,factors)
    lo,hi=(-bound,bound) if interval is None else interval
    P=precision_for_interval(lo,hi);res=modular_integer(n,ints,P)
    N=decode_interval(res,P,lo,hi)
    return F(N,Q),dict(denominator=str(Q),tensor_denominators=list(map(str,qs)),
                       absolute_integer_bound=str(bound),integer_interval=[str(lo),str(hi)],
                       precision_bits=P,residue=str(res),integer_answer=str(N))

def conditional(n,factors,event,condition=()):
    """Posterior event under supplied nonnegative likelihood factors.

    Source and observation model are external premises. ``condition`` entries
    lie in [0,1], allowing both exact event indicators and an admitted noisy
    record likelihood. Impossible conditioning returns None.
    """
    factors,event,condition=list(factors),list(event),list(condition)
    if any(x<0 for f in factors for x in f.table):
        raise ValueError('Signed weights do not define a source probability.')
    if any(x not in (0,1) for f in event for x in f.table):
        raise ValueError('Event factors must be indicators.')
    if any(not 0<=x<=1 for f in condition for x in f.table):
        raise ValueError('Condition factors must be indicators or likelihoods in [0,1].')
    denominator=direct(n,list(factors)+list(condition))
    if denominator==0:return None
    return direct(n,list(factors)+list(condition)+list(event))/denominator

def target_residue_consistent(values,target,P):
    """Exact finite-set descent test, not a proof for an unsupplied interval."""
    classes={}; M=1<<P
    for x in values:
        r=x%M; t=target(x)
        if r in classes and classes[r]!=t:return False
        classes[r]=t
    return True

def as_boolean_network(n,factors):
    """Construct a bounded-degree bipartite Boolean tensor network.

    Each original factor becomes a vertex. Variable occurrences are linked by
    equality trees of degree <=3. Every resulting edge is subdivided once by
    an equality tensor, so the whole graph is bipartite. Isolated variables
    contribute scalar two; isolated original scalar factors are retained.
    Returns vertices (side,table) and wires ((vertex,port),(vertex,port)).
    """
    validate(n,factors)
    vertices=[dict(side=0,table=f.table,degree=len(f.scope),kind='original') for f in factors]
    edges=[]
    def eq(degree,side=0):
        tab=tuple(F(int(all(b==bits[0] for b in bits))) if degree else F(1)
                  for bits in product((0,1),repeat=degree))
        vertices.append(dict(side=side,table=tab,degree=degree,kind='equality'))
        return len(vertices)-1
    for v in range(n):
        leaves=[(j,k) for j,f in enumerate(factors) for k,u in enumerate(f.scope) if u==v]
        d=len(leaves)
        if d==0:
            vertices.append(dict(side=0,table=(F(2),),degree=0,kind='unused-variable'));continue
        if d<=3:
            z=eq(d)
            edges.extend((leaf,(z,k)) for k,leaf in enumerate(leaves));continue
        chain=[eq(3) for _ in range(d-2)]
        edges.extend([(leaves[0],(chain[0],0)),(leaves[1],(chain[0],1))])
        for i in range(len(chain)-1):
            edges.append(((chain[i],2),(chain[i+1],0)))
        for i in range(1,len(chain)-1):edges.append((leaves[i+1],(chain[i],1)))
        edges.extend([(leaves[-2],(chain[-1],1)),(leaves[-1],(chain[-1],2))])
    subdivided=[]
    for a,b in edges:
        z=eq(2,1);subdivided.extend([(a,(z,0)),((z,1),b)])
    seen=[]
    for a,b in subdivided:
        assert vertices[a[0]]['side']!=vertices[b[0]]['side']
        seen.extend([a,b])
    assert len(seen)==len(set(seen))==sum(v['degree'] for v in vertices)
    return vertices,subdivided

def network_direct(vertices,edges):
    """Small-network exhaustive independent port interpretation."""
    answer=F(0)
    for bits in product((0,1),repeat=len(edges)):
        ports=[[None]*v['degree'] for v in vertices]
        for b,(a,z) in zip(bits,edges):ports[a[0]][a[1]]=ports[z[0]][z[1]]=b
        value=F(1)
        for v,bs in zip(vertices,ports):
            i=0
            for bit in bs:i=2*i+bit
            value*=v['table'][i]
        answer+=value
    return answer
