# Scoped executable inputs

Run the top-level Scientific/reproduce.py, two directory levels above this file, from the scientific package root:

```bash
python reproduce.py --check
python reproduce.py --output replay_new
```

The manifest declares20Python source/check files and12jobs. Both CLI consumers require the verify_solver producer; selected jobs automatically include it. No initial result-JSON data is required. The runner verifies source hashes and static module closure, executes disposable copies with each job's own directory as working directory, and snapshots generated outputs after every job. It preserves existing nonempty output directories.

The reviewed three-module numeric-schema/JSON repair is indexed separately. The recovered circuit loader is required by completion_design.py at import time, including --blocks and --table modes. It is now supplied. Exactly parsed decimal/exponent tokens and integer-index validation prevent rounded proof arithmetic. Assertions must stay enabled; optimized Python is rejected by the public certificate module and runner.

Regenerated example tables and saved certificates are in ../reviewed_outputs/research8/solver/. Chapter drafts, old stdout, historical results and superseded code are administrative preservation material, not executable inputs. See ../EVIDENCE_GUIDE.md and the top-level README for the scientific and backend boundaries. No ETH algorithm is implemented.
