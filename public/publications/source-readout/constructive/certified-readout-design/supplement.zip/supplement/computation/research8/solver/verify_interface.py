"""Check saved certificates through the public CLI and safe unknown separation."""
from pathlib import Path
import sys,subprocess,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research8.solver.certified import synthesize,verify_completion,compact_certificate
from research8.solver.instances import TableModel,PredictiveParityOracle
from research7.finite.completion import Circuit,Model


def main():
    here=Path(__file__).resolve().parent
    commands=[['--blocks','20','--verify',str(here/'certificate_predictive_20.json')],
              *[['--table',str(here/f'table_{m}.json'),'--verify',str(here/f'certificate_table_{m}.json')]for m in[24,32]],
              ['--table',str(here/'table_anytime.json'),'--verify',str(here/'certificate_anytime.json')]]
    for command in commands:
        p=subprocess.run([sys.executable,str(here/'completion_design.py'),*command],cwd=ROOT,text=True,capture_output=True)
        assert p.returncode==0,(command,p.stderr);assert json.loads(p.stdout)['status']=='certificate_verified'
    class Unknown:
        def __init__(self):
            self.model=PredictiveParityOracle(2).model;self.circuit=self.model.circuit;self.sensors=self.model.sensors
        def obstruction(self,selected=()):return{'status':'unknown'}
    r=synthesize(Unknown());assert r['status']=='incomplete'and r['lower_bound']==0 and r['upper_bound']is None
    assert verify_completion(Unknown(),compact_certificate(r))
    c=Circuit(1);false=c.const(False);empty=Model(c,false,(),(1,),())
    r=synthesize(empty);assert r['status']=='optimal'and r['upper_bound']==0
    assert verify_completion(empty,compact_certificate(r))
    malformed=0
    for args in[([],[],[],[]),([(0,)],[],[0],[1]),([(0,2)],[0],[1],[1,1])]:
        try:TableModel(*args)
        except ValueError:malformed+=1
        else:raise AssertionError('Malformed table accepted')
    result={'status':'PASS','saved_certificate_CLI_roundtrips':4,'unknown_separator_safe':True,
            'empty_admitted_source_safe':True,'malformed_tables_rejected':malformed}
    (here/'interface_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':main()
