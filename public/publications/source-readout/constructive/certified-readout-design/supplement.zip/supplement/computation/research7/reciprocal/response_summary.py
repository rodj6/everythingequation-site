"""Exact finite Boolean boundary-response summaries, not an ETH implementation.

Sparse vector-valued Walsh coefficients use integer masks and Fraction tuples.
All minimality claims concern linear parity summaries on the FULL Boolean cube.
"""
from fractions import Fraction


def _width(coefficients):
    if not coefficients:
        raise ValueError('supply at least a dimensioned zero coefficient')
    width = len(next(iter(coefficients.values())))
    if width < 1 or any(len(v) != width for v in coefficients.values()):
        raise ValueError('all response vectors must have the same positive width')
    if any(not isinstance(a, int) or a < 0 for a in coefficients):
        raise ValueError('frequency masks must be nonnegative integers')
    return width


def parity(mask, value):
    return (mask & value).bit_count() & 1


def independent_basis(masks):
    masks = tuple(masks)
    if any(not isinstance(a, int) or a < 0 for a in masks):
        raise ValueError('binary masks must be nonnegative integers')
    pivots = {}
    for mask in sorted(set(masks)):
        v = mask
        for p in sorted(pivots, reverse=True):
            if v >> p & 1:
                v ^= pivots[p]
        if v:
            pivots[v.bit_length()-1] = v
    return tuple(pivots[p] for p in sorted(pivots, reverse=True))


def coordinates(mask, basis):
    """Coordinates in an echelon basis returned by independent_basis."""
    z = 0
    for j, v in enumerate(basis):
        p = v.bit_length()-1
        if mask >> p & 1:
            mask ^= v
            z ^= 1 << j
    if mask:
        raise ValueError('frequency is outside the supplied row space')
    return z


def summarize(coefficients):
    """Return minimal parity rows and exact frequency-coordinate certificate."""
    _width(coefficients)
    coefficients = {int(a): tuple(map(Fraction, v)) for a, v in coefficients.items()
                    if any(v)}
    basis = independent_basis(coefficients)
    # Frequency zero is a constant and never contributes a row.
    return {'rows': basis, 'rank': len(basis),
            'coordinates': {a: coordinates(a, basis) for a in coefficients}}


def evaluate(coefficients, x):
    width = _width(coefficients)
    out = [Fraction(0)] * width
    for a, coeff in coefficients.items():
        sign = (-1) ** parity(a, x)
        for j, v in enumerate(coeff):
            out[j] += sign * v
    return tuple(out)


def evaluate_summary(coefficients, certificate, summary):
    width = _width(coefficients)
    out = [Fraction(0)] * width
    for a, coeff in coefficients.items():
        if not any(coeff):
            continue
        sign = (-1) ** parity(certificate['coordinates'][a], summary)
        for j, v in enumerate(coeff):
            out[j] += sign * v
    return tuple(out)


def measurement(rows, x):
    return sum(parity(mask, x) << j for j, mask in enumerate(rows))


def project(coefficients, matrix):
    """Apply a DECLARED linear output task before computing sufficient rows."""
    width = _width(coefficients)
    matrix = tuple(tuple(row) for row in matrix)
    if not matrix or any(len(row) != width for row in matrix):
        raise ValueError('a nonempty projection with matching input width is required')
    out = {}
    for a, coeff in coefficients.items():
        row = tuple(sum(Fraction(c)*v for c, v in zip(weights, coeff))
                    for weights in matrix)
        if any(row):
            out[a] = row
    return out or {0: tuple(Fraction(0) for _ in matrix)}


def record_marginals(b, alpha=Fraction(1, 2), beta=Fraction(1, 3)):
    """P(g=0|y), P(z_i=0|y); full positive noisy-record law described in text."""
    if b < 1 or not (0 < alpha < 1 and 0 < beta < 1):
        raise ValueError('positive noise and a nonempty boundary are required')
    out = {0: tuple([Fraction(1, 2)]*b)}
    out[(1 << b)-1] = tuple([alpha/2]+[Fraction(0)]*(b-1))
    for j in range(b-1):
        out[1 << j] = tuple([Fraction(0)]*(j+1)+[beta/2]+[Fraction(0)]*(b-j-2))
    return out


def compile_target_record(b, alpha=Fraction(1, 2), beta=Fraction(1, 3)):
    """Trace a factored nuisance description before building the full response.

    Two coefficient additions per nuisance bit certify a local polynomial
    cancellation; this routine never builds the b-by-b full response.
    """
    if b < 1 or not (0 < alpha < 1 and 0 < beta < 1):
        raise ValueError('positive noise and a nonempty boundary required')
    for j in range(b-1):
        n0 = (Fraction(1, 2), beta/2)
        n1 = (Fraction(1, 2), -beta/2)
        assert tuple(a+c for a, c in zip(n0, n1)) == (1, 0)
    target = {0: (Fraction(1, 2),), (1 << b)-1: (alpha/2,)}
    return target, summarize(target), 2*(b-1)


def markov_counts(b, kind='parity'):
    """Integer histogram for stationary T=[[9,3],[4,8]]/12.

    Common denominator is 7*12**(b-1). Every nonzero update is counted.
    kind='weight' retains exact Hamming weight; 'parity' retains only mod 2.
    """
    if b < 1 or kind not in ('parity', 'weight'):
        raise ValueError('invalid length or statistic')
    transition = ((9, 3), (4, 8))
    dp = {(0, 0): 4, (1, 1): 3}
    updates = 0
    max_cells = 2
    for t in range(1, b):
        nxt = {}
        for (last, stat), value in dp.items():
            for bit in (0, 1):
                newstat = (stat ^ bit) if kind == 'parity' else stat + bit
                key = (bit, newstat)
                nxt[key] = nxt.get(key, 0) + value*transition[last][bit]
                updates += 1
        dp = nxt
        max_cells = max(max_cells, len(dp))
    histogram = {}
    for (_, stat), value in dp.items():
        histogram[stat] = histogram.get(stat, 0) + value
    denominator = 7 * 12**(b-1)
    assert sum(histogram.values()) == denominator
    numerator = sum(value*((-1)**stat) for stat, value in histogram.items())
    # alpha=1/2: P(g=0)=(1+alpha*E[(-1)^stat])/2.
    probability = Fraction(2*denominator+numerator, 4*denominator)
    return dict(probability=probability, histogram=histogram, denominator=denominator,
                updates=updates, max_cells=max_cells,
                largest_integer_bits=max(value.bit_length() for value in dp.values()))


def markov_mass(word):
    if not word:
        raise ValueError('nonempty word required')
    trans = ((9, 3), (4, 8))
    numerator = (4, 3)[word[0]]
    for a, b in zip(word, word[1:]):
        numerator *= trans[a][b]
    return Fraction(numerator, 7 * 12**(len(word)-1))
