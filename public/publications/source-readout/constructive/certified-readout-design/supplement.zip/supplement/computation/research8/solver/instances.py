"""Declared finite classical model families and exact structural separators."""
from fractions import Fraction
from itertools import product
from pathlib import Path
import random,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research7.finite.completion import Sensor, future_register


class TableCircuit:
    def __init__(self,table):self.table=table;self.n=max(0,(len(table)-1).bit_length())
    def evaluate(self,x):
        i=sum(b<<j for j,b in enumerate(x))
        if len(x)!=self.n or any(b not in(0,1)for b in x)or i>=len(self.table):raise ValueError('Table source')
        return [None,*self.table[i]]


class TableModel:
    """Explicit source table; passive binary ports jointly read the same source.

    No target reader is added. The initial readout and target columns are
    declared separately. This separator enumerates table rows, not CNF.
    """
    def __init__(self,table,readout,target,costs):
        table=tuple(tuple(r)for r in table);costs=tuple(costs)
        if not table or any(len(r)!=len(costs)or any(b not in(0,1)for b in r)for r in table):raise ValueError('Nonempty binary table and matching port width required')
        if len(readout)!=len(table)or len(target)!=len(table):raise ValueError('Readout/target table length')
        for value in (*readout,*target):hash(value)
        self.circuit=TableCircuit(table);self.rows=tuple(tuple(r)for r in table)
        self.readouts=tuple(readout);self.targets=tuple(target)
        self.sensors=tuple(Sensor('port_'+str(j),(j+1,),Fraction(c))for j,c in enumerate(costs))
        self.sources=tuple(tuple((i>>j)&1 for j in range(self.circuit.n))for i in range(len(table)))
    def _index(self,x):return sum(b<<j for j,b in enumerate(x))
    def allowed(self,x):return len(x)==self.circuit.n and all(b in(0,1)for b in x)and self._index(x)<len(self.rows)
    def observe(self,x,selected=()):
        i=self._index(x);return(self.readouts[i],)+tuple(self.rows[i][j]for j in selected)
    def answer(self,x):return(self.targets[self._index(x)],)
    def obstruction(self,selected=(),with_count=False):
        selected=tuple(selected)
        if len(set(selected))!=len(selected)or any(not 0<=j<len(self.sensors)for j in selected):raise ValueError('Selection')
        groups={};first=None;count=0
        for i,row in enumerate(self.rows):
            key=(self.readouts[i],tuple(row[j]for j in selected));target=self.targets[i]
            if key in groups:
                for t,other in groups[key].items():
                    if t!=target:
                        if first is None:first=(other,i)
                        count+=2
                groups[key].setdefault(target,i)
            else:groups[key]={target:i}
        # The count is deliberately not exposed: groups retain witnesses, not multiplicities.
        out={'status':'sufficient'if first is None else'obstructed','selected':list(selected),
             'backend':'exact explicit-table grouping','admissible_source_count':len(self.rows)}
        if first is not None:out['witness']=[list(self.sources[i])for i in first]
        return out


def random_table(seed,m=16,n=40):
    rng=random.Random(seed)
    table=[tuple(rng.randrange(2)for _ in range(m))for _ in range(n)]
    readout=[i%3 for i in range(n)];target=[rng.randrange(2)for _ in range(n)]
    costs=[Fraction(rng.randrange(2,10),rng.choice([1,2,3]))for _ in range(m)]
    return TableModel(table,readout,target,costs)


class PredictiveParityOracle:
    """Same seventh-run circuit model, with a proved GF(2) separator.

    The only nonlinear target gate is x0 AND global parity. On x0=0 no
    collision exists. On x0=1 existence is exactly a linear difference system.
    """
    def __init__(self,blocks):
        self.blocks=blocks;self.model=future_register(blocks)
        self.circuit=self.model.circuit;self.sensors=self.model.sensors
    def obstruction(self,selected=(),with_count=False):
        selected=self.model._selection(selected);b=self.blocks;n=2*b-1
        rows=[]
        for j in selected:
            if j<n:rows.append((1<<j,0))
            else:
                pair=j-n
                mask=(1<<(2*pair-1))if pair else 0
                mask|=1<<(2*pair)
                rows.append((mask,0))
        rows.append(((1<<n)-1,1));basis={};bad=False
        for mask,value in rows:
            while mask:
                pivot=mask.bit_length()-1
                if pivot not in basis:basis[pivot]=(mask,value);break
                row,rhs=basis[pivot];mask^=row;value^=rhs
            if not mask and value:bad=True;break
        out={'status':'sufficient'if bad else'obstructed','selected':list(selected),
             'backend':'exact GF(2) difference system for inherited nonlinear register',
             'source_bits':n+1,'compiled_circuit_wires':self.circuit.wires}
        if bad:return out
        h=0
        for pivot,(mask,value)in sorted(basis.items()):
            if ((mask&h).bit_count()%2)^value:h|=1<<pivot
        x=(1,)+(0,)*n;xp=(1,)+tuple((h>>i)&1 for i in range(n))
        assert self.model.observe(x,selected)==self.model.observe(xp,selected)
        assert self.model.answer(x)!=self.model.answer(xp)
        out['witness']=[list(x),list(xp)];return out
