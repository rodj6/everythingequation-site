"""Independent Boolean-table references for minimal parity summaries.

The implementation is compared with explicit fibre constancy of every small
linear map, and with direct Markov path summation. No producer routine is
used to derive expected Fourier coefficients, minimality or source weights.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import importlib.util,random,json

if not __debug__:raise RuntimeError('Do not disable audit assertions.')

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('audited_response',HERE.parent/'reciprocal/response_summary.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
rng=random.Random(734111)
def dot(a,x):return sum((a>>i&1)*(x>>i&1)for i in range(max(a.bit_length(),x.bit_length())))%2
def factors(table,rows):
 seen={}
 for x,answer in enumerate(table):
  key=tuple(dot(a,x)for a in rows)
  if key in seen and seen[key]!=answer:return False
  seen[key]=answer
 return True
cases=0;mapchecks=0;zero_checks=0
for b in range(1,4):
 for trial in range(9):
  # Include structured low-rank responses as well as generic full-rank tables.
  a=rng.randrange(1<<b)
  table=[(F(rng.randrange(4),3),F(rng.randrange(4),5))for _ in range(1<<b)]if trial%3 else[(F(dot(a,x)),F(1-dot(a,x)))for x in range(1<<b)]
  coeff={}
  for mask in range(1<<b):
   vec=tuple(sum(table[x][j]*((-1)**dot(mask,x))for x in range(1<<b))/2**b for j in range(2))
   if any(vec):coeff[mask]=vec
  if not coeff:coeff={0:(F(0),F(0))}
  cert=api.summarize(coeff)
  minimum=None
  for rowcount in range(b+1):
   for rows in product(range(1<<b),repeat=rowcount):
    ok=factors(table,rows);mapchecks+=1
    if ok:minimum=rowcount if minimum is None else min(minimum,rowcount)
  assert minimum==cert['rank']and factors(table,cert['rows'])
  for x,answer in enumerate(table):
   assert api.evaluate(coeff,x)==answer
   m=api.measurement(cert['rows'],x)
   assert api.evaluate_summary(coeff,cert,m)==answer
  # A zero projection is an admissible target, not a malformed coefficient set.
  z=api.project(coeff,[[0,0]])
  zcert=api.summarize(z);assert zcert['rank']==0
  for x in range(1<<b):
   assert api.evaluate(z,x)==(0,)and api.evaluate_summary(z,zcert,0)==(0,);zero_checks+=1
  cases+=1

markov=[]
for b in range(1,9):
 exact=F(0)
 for word in product((0,1),repeat=b):
  p=F((4,3)[word[0]],7)
  for a,z in zip(word,word[1:]):p*=F(((9,3),(4,8))[a][z],12)
  exact+=p*(F(1,2)+F((-1)**sum(word),4))
 p=api.markov_counts(b,'parity');w=api.markov_counts(b,'weight')
 assert p['probability']==w['probability']==exact
 assert w['updates']==2*b*(b-1)
 if b>=2:assert p['updates']==8*b-12
 markov.append(dict(horizon=b,probability=str(exact),weight_updates=w['updates'],parity_updates=p['updates']))

invalid=0
for coeff,matrix in [({-1:(F(1),)},[[1]]),({0:(F(1),),1:(F(0),F(1))},[[1]]),({0:(F(1),F(0))},[[1]])]:
 try:api.project(coeff,matrix)
 except ValueError:invalid+=1
 else:raise AssertionError('Invalid mask/vector/projection width accepted')
result=dict(status='PASS',independent_table_responses=cases,complete_small_linear_map_checks=mapchecks,zero_projection_evaluations=zero_checks,invalid_inputs_rejected=invalid,direct_Markov_path_checks=markov,scope='Full Boolean cube and parity-summary class; structured DP improvement, not a new ETH exponent.')
(HERE/'reciprocal_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='direct_Markov_path_checks'},indent=2))
