"""Reproducible exact tests of the reciprocal task-restricted preprocessing.

Uses no ETH backend and no producer from other workstreams. Fractions are exact.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
from time import perf_counter
import json, random
from response_summary import (independent_basis, summarize, evaluate, evaluate_summary,
                              measurement, project, record_marginals, markov_counts,
                              markov_mass, compile_target_record)

OUT = Path(__file__).resolve().parent
rng = random.Random(731977)
evaluations = 0
for b in range(1, 8):
    F = record_marginals(b)
    full = summarize(F)
    target = project(F, [(1,)+tuple([0]*(b-1))])
    small = summarize(target)
    compiled, cert, projection_additions = compile_target_record(b)
    assert compiled == target and cert == small and projection_additions == 2*(b-1)
    assert full['rank'] == b and small['rank'] == 1
    for y in range(1 << b):
        raw = evaluate(F, y)
        assert evaluate_summary(F, full, measurement(full['rows'], y)) == raw
        assert evaluate_summary(target, small, measurement(small['rows'], y)) == (raw[0],)
        assert all(0 < p < 1 for p in raw)
        evaluations += 1
    # Exact source contraction by independent word enumeration.
    oracle = sum(markov_mass(word)*Q(2+(-1)**sum(word), 4)
                 for word in product([0, 1], repeat=b))
    A, B = markov_counts(b, 'weight'), markov_counts(b, 'parity')
    assert oracle == A['probability'] == B['probability']
    assert A['updates'] == 2*b*(b-1)
    assert B['updates'] == (0 if b == 1 else 8*b-12)
    if b > 1:
        assert A['max_cells'] == 2*b and B['max_cells'] == 4

# Exhaustive all parity maps for small random rational response tables. The
# factorization-by-fibres test is independent of the frequency-span criterion.
parity_maps = 0
for b in [2, 3]:
    for trial in range(10):
        F = {a: ((Q(rng.randrange(-2, 3), 3), Q(rng.randrange(-2, 3), 5))
                 if rng.random() < .35 else (Q(0), Q(0)))
             for a in range(1 << b)}
        for k in range(b+1):
            for rows in product(range(1 << b), repeat=k):
                bucket = {}
                factors = True
                for x in range(1 << b):
                    h = measurement(rows, x); v = evaluate(F, x)
                    if h in bucket and bucket[h] != v:
                        factors = False
                    bucket[h] = v
                span = independent_basis(rows)
                sufficient = all(len(independent_basis(span+(a,))) == len(span)
                                 for a, coeff in F.items() if any(coeff))
                assert factors == sufficient
                parity_maps += 1

# Scope counterexample: parity rank is not minimal arbitrary nonlinear summary.
b = 4
weight_coeff = {0: (Q(b, 2),), **{1 << j: (Q(-1, 2),) for j in range(b)}}
assert summarize(weight_coeff)['rank'] == b
assert len({evaluate(weight_coeff, y) for y in range(1 << b)}) == b+1

# A fully cancelling target is a valid constant response with no summary bits.
zero = project({0: (Q(1), Q(2)), 3: (Q(2), Q(4))}, [(2, -1)])
zero_certificate = summarize(zero)
assert zero == {0: (Q(0),)} and zero_certificate['rank'] == 0
for y in range(16):
    assert evaluate(zero, y) == evaluate_summary(zero, zero_certificate, 0) == (0,)
invalid_input_checks = 0
for action in [lambda: project({0: (Q(1), Q(2))}, [(1,)]),
               lambda: summarize({-1: (Q(1),)}),
               lambda: evaluate({0: (Q(1),), 1: (Q(1), Q(2))}, 0)]:
    try:
        action()
    except ValueError:
        invalid_input_checks += 1
    else:
        raise AssertionError('malformed input accepted')

benchmarks = []
for b in [4, 8, 16, 32, 64, 128, 256]:
    target, cert, projection_additions = compile_target_record(b)
    assert cert['rank'] == 1
    times = {}; data = {}
    for kind in ['weight', 'parity']:
        start = perf_counter(); row = markov_counts(b, kind)
        times[kind] = perf_counter()-start; data[kind] = row
    assert data['weight']['probability'] == data['parity']['probability']
    benchmarks.append(dict(b=b, raw_identity_summaries=2**b,
                           attainable_integer_weight_summaries=b+1,
                           target_parity_summaries=2,
                           common_local_projection_additions=projection_additions,
                           weight_updates=data['weight']['updates'],
                           parity_updates=data['parity']['updates'],
                           weight_live_integer_cells=data['weight']['max_cells'],
                           parity_live_integer_cells=data['parity']['max_cells'],
                           result=str(data['parity']['probability']),
                           timing_seconds=times))

report = dict(status='PASS (exact rational identities and exhaustive finite tests)',
              exact_response_checks=evaluations,
              exhaustive_parity_map_checks=parity_maps,
              zero_target_checks=16, invalid_input_checks=invalid_input_checks,
              markov_bruteforce_lengths=list(range(1, 8)),
              benchmark=benchmarks,
              classification='Known Fourier/finite-state methods newly applied as target-sensitive preprocessing; not an implementation or worst-case improvement of ETH algorithm.',
              caveats=['Full Boolean cube for Fourier minimality',
                       'Minimality only among parity summaries',
                       'Target output marginalized; full retained record law not replaced',
                       'Time data are floating wall-clock diagnostics; operation counts are exact',
                       'No automatic substitution of parity rows for ETH rational-linear design rows'])
(OUT/'results.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='benchmark'}, indent=2))
print('b  weight_updates  parity_updates  exact_ratio')
for row in benchmarks:
    print(row['b'], row['weight_updates'], row['parity_updates'],
          str(Q(row['weight_updates'], row['parity_updates'])))
