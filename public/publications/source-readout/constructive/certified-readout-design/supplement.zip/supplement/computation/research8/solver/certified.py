"""Exact rational bounded completion design, using conventional branch and bound.

No ETH algorithm is implemented.  Nonnegative costs are additive.  Search
certificates retain a binary covering tree, dual packing bounds, and open leaves.
"""
if not __debug__:
    raise RuntimeError('Certificate checks require assertions; do not use python -O')

from fractions import Fraction
from dataclasses import dataclass
from heapq import heappush, heappop
import time


def indices(mask):
    while mask:
        bit=mask & -mask
        yield bit.bit_length()-1
        mask-=bit


@dataclass
class Constraints:
    incompatibilities: tuple=()
    prerequisites: tuple=()  # (a,b): selecting a requires b
    max_selected: int|None=None
    feasible: object=None   # optional arbitrary, pure leaf predicate


class Problem:
    def __init__(self,costs,cuts=(),constraints=None):
        costs=tuple(costs)
        if any(not isinstance(c,(int,Fraction))or c<0 for c in costs):
            raise ValueError('Costs must be exact nonnegative rationals')
        self.costs=tuple(map(Fraction,costs));self.m=len(self.costs)
        self.all=(1<<self.m)-1;self.constraints=constraints or Constraints()
        self.cuts=tuple(sorted(set(self.mask(d)for d in cuts),key=lambda x:(x.bit_count(),x)))
        for pair in (*self.constraints.incompatibilities,*self.constraints.prerequisites):
            if len(pair)!=2 or any(type(j)is not int or not 0<=j<self.m for j in pair):
                raise ValueError('Constraint item index')
        if self.constraints.max_selected is not None and (type(self.constraints.max_selected)is not int or self.constraints.max_selected<0):
            raise ValueError('Selection cap')
    def mask(self,selection):
        s=tuple(selection)
        if len(set(s))!=len(s)or any(type(j)is not int or not 0<=j<self.m for j in s):
            raise ValueError('Invalid selection')
        return sum(1<<j for j in s)
    def cost(self,s):return sum((self.costs[j]for j in indices(s)),Fraction(0))
    def propagate(self,s,f):
        if (s|f)&~self.all:return None
        changed=True
        while changed:
            old=(s,f)
            if s&f:return None
            for a,b in self.constraints.prerequisites:
                if s>>a&1:s|=1<<b
                if f>>b&1:f|=1<<a
            for a,b in self.constraints.incompatibilities:
                if s>>a&1:f|=1<<b
                if s>>b&1:f|=1<<a
            cap=self.constraints.max_selected
            if cap is not None:
                if s.bit_count()>cap:return None
                if s.bit_count()==cap:f|=self.all^s
            if s&f:return None
            for d in self.cuts:
                if d&s:continue
                available=d&~f
                if not available:return None
                if available&(available-1)==0:s|=available
            changed=(s,f)!=old
        return s,f
    def valid(self,s):
        t=tuple(indices(s))
        return (all(s&d for d in self.cuts)
                and all(not(s>>a&1 and s>>b&1)for a,b in self.constraints.incompatibilities)
                and all(not(s>>a&1)or s>>b&1 for a,b in self.constraints.prerequisites)
                and(self.constraints.max_selected is None or s.bit_count()<=self.constraints.max_selected)
                and(self.constraints.feasible is None or self.constraints.feasible(t)))
    def bound(self,s,f):
        """Feasible dual of the residual weighted hitting-set LP."""
        residual=[self.costs[j]if not((s|f)>>j&1)else Fraction(0)for j in range(self.m)]
        uncovered=[(i,d&~f)for i,d in enumerate(self.cuts)if not d&s]
        dual=[]
        for i,d in sorted(uncovered,key=lambda t:(t[1].bit_count(),min((residual[j]for j in indices(t[1])),default=Fraction(0)),t[0])):
            q=min(residual[j]for j in indices(d))
            if q:
                dual.append((i,q))
                for j in indices(d):residual[j]-=q
        return self.cost(s)+sum((q for _,q in dual),Fraction(0)),dual


def optimize(problem,max_nodes=None,incumbent=None):
    """Exact or interrupted B&B. Limits count expanded, not merely created nodes.

    The incumbent need only satisfy accumulated necessary cuts. Its cost is an
    optimization upper bound, not automatically a source-sufficiency certificate.
    """
    if max_nodes is not None and(type(max_nodes)is not int or max_nodes<0):raise ValueError('Node limit')
    p=problem;nodes=[];heap=[];best=None;bestcost=None;expanded=0
    if incumbent is not None:
        best=p.mask(incumbent)
        if not p.valid(best):raise ValueError('Invalid incumbent')
        bestcost=p.cost(best)
    def add(s,f):
        i=len(nodes);node={'input':[s,f]};nodes.append(node)
        sf=p.propagate(s,f)
        if sf is None:node['kind']='infeasible';return i
        s,f=sf;lb,dual=p.bound(s,f)
        node.update(state=[s,f],lower=lb,dual=dual,kind='open')
        if bestcost is not None and lb>=bestcost:node['kind']='bound'
        else:heappush(heap,(lb,i))
        return i
    add(0,0)
    while heap:
        lb,i=heap[0];node=nodes[i]
        if bestcost is not None and lb>=bestcost:
            heappop(heap);node['kind']='bound';continue
        if max_nodes is not None and expanded>=max_nodes:break
        heappop(heap);expanded+=1;s,f=node['state']
        if p.valid(s):
            best=s;bestcost=p.cost(s);node['kind']='solution';continue
        free=p.all&~(s|f)
        if not free:node['kind']='infeasible_leaf';continue
        uncovered=[d&free for d in p.cuts if not d&s]
        if uncovered:
            d=min(uncovered,key=lambda d:(d.bit_count(),d))
            j=min(indices(d),key=lambda j:(p.costs[j],-sum(bool(x>>j&1)for x in uncovered),j))
        else:j=min(indices(free),key=lambda j:(p.costs[j],j))
        node['kind']='branch';node['variable']=j
        node['children']=[add(s|(1<<j),f),add(s,f|(1<<j))]
    open_lower=min((nodes[i]['lower']for _,i in heap),default=None)
    lower=(bestcost if open_lower is None else open_lower if bestcost is None else min(bestcost,open_lower))
    status='infeasible'if best is None and not heap else'optimal'if not heap else'bounded'
    result={'status':status,'selection':None if best is None else list(indices(best)),
            'upper_bound':bestcost,'lower_bound':lower,'expanded_nodes':expanded,
            'created_nodes':len(nodes),'frontier_nodes':len(heap),'certificate':nodes,
            'problem_cuts':[list(indices(d))for d in p.cuts]}
    return result


def _certificate_integer(value):
    """Proof masks and indices use genuine nonnegative integers, not bools."""
    assert type(value) is int and value >= 0
    return value


def _certificate_rational(value,nullable=False):
    """Forbid implicit float coercion in every proof-relevant arithmetic path."""
    if nullable and value is None:return value
    assert type(value) in (int,Fraction) and value >= 0
    return value


def verify_optimization(p,result):
    """Check the covering tree, local infeasibility, packing duals and final bounds.

    This checker does not optimize subsets. Opaque feasibility is re-evaluated;
    a consumer must supply the identical declared pure predicate.
    """
    for cut in result['problem_cuts']:p.mask(cut)
    assert result['problem_cuts']==[list(indices(d))for d in p.cuts]
    nodes=result['certificate'];seen=set();leaves=[]
    best=result['selection'];u=_certificate_rational(result['upper_bound'],nullable=True)
    _certificate_rational(result['lower_bound'],nullable=True)
    if best is not None:
        b=p.mask(best);assert p.valid(b)and p.cost(b)==u
    else:assert u is None
    def walk(i,expected):
        _certificate_integer(i)
        assert i not in seen and 0<=i<len(nodes);seen.add(i)
        n=nodes[i]
        assert len(n['input'])==2
        for value in n['input']:_certificate_integer(value)
        assert n['input']==list(expected)
        sf=p.propagate(*expected)
        if sf is None:assert n['kind']=='infeasible';return
        s,f=sf
        assert len(n['state'])==2
        for value in n['state']:_certificate_integer(value)
        assert n['state']==[s,f]
        _certificate_rational(n['lower'])
        # Independently verify the stored nonnegative dual capacity inequalities.
        dual=n['dual']
        for d,q in dual:_certificate_integer(d);_certificate_rational(q)
        assert len({i for i,q in dual})==len(dual)
        for d,q in dual:assert 0<=d<len(p.cuts)and q>=0 and not p.cuts[d]&s
        for j in indices(p.all&~(s|f)):
            assert sum((q for d,q in dual if p.cuts[d]>>j&1),Fraction(0))<=p.costs[j]
        lb=p.cost(s)+sum((q for d,q in dual),Fraction(0));assert lb==n['lower']
        kind=n['kind']
        if kind=='branch':
            j=_certificate_integer(n['variable']);assert 0<=j<p.m and not((s|f)>>j&1)
            a,b=n['children'];walk(a,(s|(1<<j),f));walk(b,(s,f|(1<<j)));return
        if kind=='infeasible_leaf':assert (s|f)==p.all and not p.valid(s);return
        if kind=='solution':assert p.valid(s)and u is not None and p.cost(s)>=u;leaves.append(p.cost(s));return
        if kind=='bound':assert u is not None and lb>=u;leaves.append(lb);return
        assert kind=='open';leaves.append(lb)
    walk(0,(0,0));assert len(seen)==len(nodes)
    l=result['lower_bound'];expected=min(([u]if u is not None else[])+leaves,default=None)
    assert l==expected
    open_count=sum(n['kind']=='open'for n in nodes)
    if result['status']=='optimal':assert not open_count and u is not None and l==u
    elif result['status']=='infeasible':assert not open_count and u is None and l is None
    else:assert result['status']=='bounded'and open_count
    return True


def synthesize(model,constraints=None,max_iterations=None,max_nodes=None,upper_selection=None):
    """Certified outer synthesis. Only complete separation certifies source access.

    max_nodes limits each optimizer call; max_iterations limits separating calls.
    Unknown/incomplete external separation is preserved as an incomplete result.
    """
    if max_iterations is not None and(type(max_iterations)is not int or max_iterations<0):raise ValueError('Iteration limit')
    costs=[s.cost for s in model.sensors];cuts=[];history=[];upper=None;uppercost=None
    oracle_calls=0;started=time.perf_counter();expanded=created=0
    def finish(status,lower=None,opt=None):
        return {'status':status,'lower_bound':lower,'upper_bound':uppercost,
                'selection':upper,'cuts':cuts,'history':history,'oracle_calls':oracle_calls,
                'expanded_nodes':expanded,'created_nodes':created,'seconds':time.perf_counter()-started,
                'last_optimization':opt}
    if upper_selection is not None:
        p=Problem(costs,(),constraints);mask=p.mask(upper_selection)
        if not p.valid(mask):raise ValueError('Upper selection infeasible')
        answer=model.obstruction(upper_selection);oracle_calls+=1
        if answer['status']!='sufficient':raise ValueError('Upper selection not certified sufficient')
        upper=list(upper_selection);uppercost=p.cost(mask)
    while True:
        p=Problem(costs,cuts,constraints)
        opt=optimize(p,max_nodes,upper);expanded+=opt['expanded_nodes'];created+=opt['created_nodes']
        assert verify_optimization(p,opt)
        lower=opt['lower_bound']
        if uppercost is not None and lower is not None and lower==uppercost:return finish('optimal',lower,opt)
        if opt['status']=='infeasible':return finish('no_feasible_sufficient_selection',None,opt)
        candidate=opt['selection']
        if candidate is None:return finish('incomplete',lower,opt)
        if max_iterations is not None and len(history)>=max_iterations:return finish('incomplete',lower,opt)
        answer=model.obstruction(candidate);oracle_calls+=1
        row={'selection':candidate,'cost':opt['upper_bound'],'oracle':answer,'optimization':opt};history.append(row)
        if answer['status']=='sufficient':
            value=opt['upper_bound']
            if uppercost is None or value<uppercost:upper=candidate;uppercost=value
            return finish('optimal'if lower==uppercost else'bounded',lower,opt)
        if answer['status']!='obstructed':return finish('incomplete',lower,opt)
        x,xp=answer['witness'];vx=model.circuit.evaluate(x);vp=model.circuit.evaluate(xp)
        d=[j for j,s in enumerate(model.sensors)if tuple(vx[w]for w in s.wires)!=tuple(vp[w]for w in s.wires)]
        assert not set(d)&set(candidate)
        row['distinguishing_menu']=d
        if not d:return finish('menu_insufficient',None,opt)
        cuts.append(d)


def compact_certificate(result):
    """Only the final B&B tree and one genuine witness per cut are necessary."""
    keep={k:v for k,v in result.items()if k not in ['history']}
    keep['cut_witnesses']=[{'witness':row['oracle']['witness'],'distinguishing_menu':row['distinguishing_menu']}
                           for row in result['history']if 'distinguishing_menu'in row]
    return keep


def verify_completion(model,result,constraints=None):
    """Recheck witnesses, final optimizer proof and nominated sufficient upper.

    The final no-collision statement is replayed using the declared exact oracle.
    This is an oracle-relative certificate, not a new proof-logging SAT format.
    """
    _certificate_rational(result['upper_bound'],nullable=True)
    _certificate_rational(result['lower_bound'],nullable=True)
    base=getattr(model,'model',model)
    costs=[s.cost for s in model.sensors]
    menu_problem=Problem(costs,(),constraints)
    for cut in result['cuts']:menu_problem.mask(cut)
    cuts=result['cuts'];witnesses=result.get('cut_witnesses')
    if witnesses is None:witnesses=compact_certificate(result)['cut_witnesses']
    checked_cuts=[]
    for row in witnesses:
        x,xp=row['witness'];assert base.allowed(x)and base.allowed(xp)
        assert base.observe(x)==base.observe(xp)and base.answer(x)!=base.answer(xp)
        v=base.circuit.evaluate(x);vp=base.circuit.evaluate(xp)
        d=[j for j,s in enumerate(base.sensors)if tuple(v[w]for w in s.wires)!=tuple(vp[w]for w in s.wires)]
        assert d==row['distinguishing_menu'];checked_cuts.append(d)
    assert all(cut in checked_cuts for cut in cuts)
    # A latest optimizer can precede one freshly appended valid cut.
    last=result['last_optimization']
    assert all(cut in checked_cuts for cut in last['problem_cuts'])
    p=Problem([s.cost for s in model.sensors],last['problem_cuts'],constraints)
    assert verify_optimization(p,last)
    assert result['lower_bound']is None or result['lower_bound']==last['lower_bound']
    if result['upper_bound']is not None:
        selected=result['selection'];p=Problem([s.cost for s in model.sensors],(),constraints)
        assert p.valid(p.mask(selected))and p.cost(p.mask(selected))==result['upper_bound']
        assert model.obstruction(selected)['status']=='sufficient'
    if result['status']=='optimal':assert result['upper_bound']==result['lower_bound']and result['upper_bound']is not None
    if result['status']=='menu_insufficient':assert []in checked_cuts
    if result['status']=='no_feasible_sufficient_selection':assert last['status']=='infeasible'
    if result['upper_bound']is not None and result['lower_bound']is not None:assert result['lower_bound']<=result['upper_bound']
    return True
