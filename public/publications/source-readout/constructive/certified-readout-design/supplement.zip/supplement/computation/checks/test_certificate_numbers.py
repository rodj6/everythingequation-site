"""Focused exact-schema regression tests for the bounded Paper5 checker repair."""
from pathlib import Path
from fractions import Fraction as F
import copy,json,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
ROOT=(HERE/'computation') if (HERE/'computation').is_dir() else HERE.parent
sys.path.insert(0,str(ROOT))
from research8.solver.certified import Problem,optimize,verify_optimization,verify_completion
from research8.solver.instances import TableModel

def rejects(fn):
    try:fn()
    except (AssertionError,ValueError,TypeError,RuntimeError,IndexError):return True
    raise AssertionError('Malformed proof number was accepted')

def main():
    p=Problem([10**100,1,1],[(0,),(1,2)])
    good=optimize(p,max_nodes=0)
    assert good['lower_bound']==10**100+1
    assert verify_optimization(p,good)
    cases=[]
    def case(name,mutate):
        bad=copy.deepcopy(good);mutate(bad)
        assert rejects(lambda:verify_optimization(p,bad));cases.append(name)
    def float_exploit(r):
        r['certificate'][0]['dual']=[(1,1.0)]
        r['certificate'][0]['lower']=float(10**100)+1.0
        r['lower_bound']=r['certificate'][0]['lower']
    case('Original upward float-coercion counterexample',float_exploit)
    case('Float lower bound',lambda r:r.update(lower_bound=float(r['lower_bound'])))
    case('Bool lower bound',lambda r:r.update(lower_bound=True))
    case('Float node lower',lambda r:r['certificate'][0].update(lower=float(r['lower_bound'])))
    case('Bool dual coefficient',lambda r:r['certificate'][0].update(dual=[(1,True)]))
    case('Float dual coefficient',lambda r:r['certificate'][0].update(dual=[(1,1.0)]))
    case('Float dual index',lambda r:r['certificate'][0].update(dual=[(1.0,F(1))]))
    case('Bool dual index',lambda r:r['certificate'][0].update(dual=[(True,F(1))]))
    case('Float input mask',lambda r:r['certificate'][0].update(input=[0.0,0]))
    case('Bool input mask',lambda r:r['certificate'][0].update(input=[False,0]))
    case('Float state mask',lambda r:r['certificate'][0].update(state=[1.0,0]))
    case('Bool state mask',lambda r:r['certificate'][0].update(state=[True,0]))
    case('Bool menu index',lambda r:r.update(problem_cuts=[[False],[1,2]]))
    branch=optimize(Problem([1,1],[(0,1)]),max_nodes=1)
    bp=Problem([1,1],[(0,1)])
    assert branch['certificate'][0]['kind']=='branch'
    for field,value in [('variable',False),('variable',0.0),('children',[True,2]),('children',[1.0,2])]:
        bad=copy.deepcopy(branch);bad['certificate'][0][field]=value
        assert rejects(lambda:verify_optimization(bp,bad));cases.append('Invalid branch '+field+' '+repr(value))
    solved=optimize(p)
    for name,value in [('float',float(solved['upper_bound'])),('bool',True)]:
        bad=copy.deepcopy(solved);bad['upper_bound']=value
        assert rejects(lambda:verify_optimization(p,bad));cases.append('Invalid upper bound '+name)

    # Same example as a complete finite source menu, so external JSON tests
    # exercise the actual public --table/--verify route, not just a helper.
    table={'ports':[[0,0,0],[1,0,0],[0,1,1]],'readout':[0,0,0],
           'target':[0,1,1],'costs':[10**100,1,1]}
    model=TableModel(table['ports'],table['readout'],table['target'],table['costs'])
    outer={'status':'incomplete','lower_bound':good['lower_bound'],'upper_bound':None,
           'selection':None,'cuts':[[0],[1,2]],'last_optimization':good,
           'cut_witnesses':[{'witness':[[0,0],[1,0]],'distinguishing_menu':[0]},
                            {'witness':[[0,0],[0,1]],'distinguishing_menu':[1,2]}],
           'seconds':1.2345}
    assert verify_completion(model,outer)
    cli=ROOT/'research8/solver/completion_design.py'
    cli_checks=[]
    with tempfile.TemporaryDirectory(prefix='p5_schema_') as temp:
        temp=Path(temp);tp=temp/'table.json';cp=temp/'certificate.json'
        tp.write_text(json.dumps(table))
        def run(cert,expect_ok):
            cp.write_text(json.dumps(cert,default=str))
            r=subprocess.run([sys.executable,str(cli),'--table',str(tp),'--verify',str(cp)],capture_output=True,text=True)
            assert (r.returncode==0)==expect_ok,(r.stdout,r.stderr)
        run(outer,True);cli_checks.append('Exact original integer/rational certificate plus decimal telemetry accepted')
        bad=copy.deepcopy(outer);float_exploit(bad['last_optimization']);bad['lower_bound']=bad['last_optimization']['lower_bound']
        run(bad,False);cli_checks.append('Original float-bound exploit rejected through exact JSON parser')
        for value in [float('nan'),float('inf'),float('-inf')]:
            bad=copy.deepcopy(outer);bad['seconds']=value
            run(bad,False);cli_checks.append('Non-finite JSON token rejected: '+repr(value))
        bad=copy.deepcopy(outer);bad['last_optimization']['certificate'][0]['input']=[0.0,0]
        run(bad,False);cli_checks.append('Decimal-encoded mask rejected as index even when integral')
        cp.write_text(json.dumps(outer,default=str))
        r=subprocess.run([sys.executable,'-O',str(cli),'--table',str(tp),'--verify',str(cp)],capture_output=True,text=True)
        assert r.returncode!=0 and 'require assertions' in r.stderr
        cli_checks.append('Direct python -O verifier invocation rejected')

        decimal_cost='0.10000000000000000000000000000000000001'
        weight0='0.20000000000000000000000000000000000003'
        weight1='0.70000000000000000000000000000000000009'
        mp=temp/'model.json'
        mp.write_text('{"source_bits":1,"target":[1],"sensors":[{"name":"raw","wires":[1],"cost":'+decimal_cost+'}],"prior":[{"source":[0],"weight":'+weight0+'},{"source":[1],"weight":'+weight1+'}]}')
        r=subprocess.run([sys.executable,str(cli),'--model',str(mp)],capture_output=True,text=True)
        assert r.returncode==0,r.stderr
        summary=json.loads(r.stdout)
        assert summary['status']=='optimal' and F(summary['upper_bound'])==F(decimal_cost)
        cli_checks.append('Circuit JSON long-decimal sensor cost preserved exactly')
        shadow=ROOT/'research7/root/shadow_tool.py'
        r=subprocess.run([sys.executable,str(shadow),'posterior','--model',str(mp)],capture_output=True,text=True)
        assert r.returncode==0,r.stderr
        posterior=json.loads(r.stdout)
        answer={tuple(x['target']):F(x['probability']) for x in posterior['posterior']}
        assert answer[(1,)]==F(weight1)/(F(weight0)+F(weight1))
        cli_checks.append('Circuit JSON long-decimal prior weights preserve exact posterior')
        tp.write_text('{"ports":[[0],[1]],"readout":[0,0],"target":[0,1],"costs":['+decimal_cost+']}')
        r=subprocess.run([sys.executable,str(cli),'--table',str(tp)],capture_output=True,text=True)
        assert r.returncode==0,r.stderr
        summary=json.loads(r.stdout)
        assert summary['status']=='optimal' and F(summary['upper_bound'])==F(decimal_cost)
        cli_checks.append('Table JSON long-decimal sensor cost preserved exactly')

    # All four generated saved certificate families must still validate through the
    # public CLI; their timing metadata uses ordinary JSON decimal literals.
    saved=[];home=ROOT/'research8/solver'
    commands=[['--blocks','20','--verify',str(home/'certificate_predictive_20.json')]]
    commands += [['--table',str(home/f'table_{m}.json'),'--verify',str(home/f'certificate_table_{m}.json')] for m in [24,32]]
    commands += [['--table',str(home/'table_anytime.json'),'--verify',str(home/'certificate_anytime.json')]]
    for command in commands:
        r=subprocess.run([sys.executable,str(cli),*command],capture_output=True,text=True)
        assert r.returncode==0,(command,r.stderr)
        saved.append(str(Path(command[-1]).relative_to(ROOT)))
    out={'status':'PASS','typed_number_and_index_rejections':len(cases),'cases':cases,
         'public_cli_checks':cli_checks,'saved_certificate_roundtrips':len(saved),'saved_certificates':saved,
         'original_counterexample':'Constructed here: costs[10^100,1,1], cuts[(0),(1,2)] and float-valued dual/bound.',
         'scope':'Bounded verifier/input repair only. Mathematical B&B theorem, exact generated optima and historical certificates unchanged.'}
    (HERE/'numeric_schema_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
