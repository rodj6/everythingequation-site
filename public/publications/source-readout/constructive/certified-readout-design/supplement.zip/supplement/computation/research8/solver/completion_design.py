#!/usr/bin/env python3
"""Run certified finite completion design with an explicit model/backend."""
from pathlib import Path
from fractions import Fraction
import argparse,json,sys,re
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research8.solver.certified import Constraints,synthesize,compact_certificate,verify_completion
from research8.solver.instances import PredictiveParityOracle,TableModel
from research7.root.shadow_tool import load_model


def exact_json(text):
    def reject_constant(value):
        raise ValueError('Non-finite JSON value: '+value)
    return json.loads(text,parse_float=Fraction,parse_constant=reject_constant)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--blocks',type=int,help='inherited nonlinear register with exact GF(2) separator')
    group.add_argument('--model',help='seventh-run circuit JSON; unchanged CNF separator')
    group.add_argument('--table',help='explicit finite source/readout/target/port JSON')
    p.add_argument('--max-nodes',type=int);p.add_argument('--max-iterations',type=int)
    p.add_argument('--output',help='save complete witness/tree certificate JSON')
    p.add_argument('--verify',help='verify a saved exact certificate against the same input model')
    a=p.parse_args();c=Constraints()
    if a.model:
        model,feasible,_=load_model(a.model);c.feasible=feasible
        backend='inherited circuit/CNF oracle; opaque declared feasibility callback'
    elif a.table:
        data=exact_json(Path(a.table).read_text())
        model=TableModel(data['ports'],data['readout'],data['target'],[Fraction(x)for x in data['costs']])
        c=Constraints(tuple(map(tuple,data.get('incompatibilities',[]))),tuple(map(tuple,data.get('prerequisites',[]))),data.get('max_selected'))
        backend='exact explicit-table grouping'
    else:
        blocks=20 if a.blocks is None else a.blocks
        if blocks<1:p.error('--blocks must be positive')
        model=PredictiveParityOracle(blocks);backend='proved GF(2) separator for inherited nonlinear register'
    if a.verify:
        def exact(x):
            if isinstance(x,list):return[exact(v)for v in x]
            if isinstance(x,dict):return{k:exact(v)for k,v in x.items()}
            if isinstance(x,str)and re.fullmatch(r'-?\d+(?:/\d+)?',x):return Fraction(x)
            return x
        # JSON decimal/exponent literals are exact rationals; telemetry may use
        # them, while proof indices must still be actual JSON integers.
        result=exact(exact_json(Path(a.verify).read_text()))
        assert verify_completion(model,result,c)
        print(json.dumps({'status':'certificate_verified','oracle_backend':backend}));return
    result=synthesize(model,c,a.max_iterations,a.max_nodes)
    result['oracle_backend']=backend
    if a.output:Path(a.output).write_text(json.dumps(compact_certificate(result),indent=2,default=str)+'\n')
    summary={k:v for k,v in result.items()if k not in ['history','last_optimization']}
    print(json.dumps(summary,indent=2,default=str))


if __name__=='__main__':main()
