"""Exact independent subset/source references and adversarial certificate tests."""
from pathlib import Path
import sys,json,random,copy,time,tracemalloc
from fractions import Fraction
from itertools import product
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research8.solver.certified import Problem,Constraints,optimize,verify_optimization,synthesize,compact_certificate,verify_completion
from research8.solver.instances import random_table,PredictiveParityOracle
from research7.finite.completion import synthesize as old_synthesize,future_register


def subsets(m):
    for bits in product((0,1),repeat=m):yield tuple(i for i,b in enumerate(bits)if b)


def feasible(s,c):
    s=set(s)
    return(all(not{a,b}<=s for a,b in c.incompatibilities)
           and all(a not in s or b in s for a,b in c.prerequisites)
           and(c.max_selected is None or len(s)<=c.max_selected)
           and(c.feasible is None or c.feasible(tuple(sorted(s)))))


def exact_reference(costs,cuts,c):
    rows=[(sum((costs[j]for j in s),Fraction(0)),s)for s in subsets(len(costs))
          if feasible(s,c)and all(set(s)&set(d)for d in cuts)]
    return min(rows,default=None)


def full_table_optimum(model,c):
    def sufficient(s):
        return all(model.readouts[i]!=model.readouts[j]or model.targets[i]==model.targets[j]
                   or any(model.rows[i][k]!=model.rows[j][k]for k in s)
                   for i in range(len(model.rows))for j in range(i))
    return min(((sum((model.sensors[j].cost for j in s),Fraction(0)),s)for s in subsets(len(model.sensors))
                if feasible(s,c)and sufficient(s)),default=None)


def run_tests():
    rng=random.Random(83419);checks=interrupted=0
    for case in range(160):
        m=rng.randrange(0,9);costs=[Fraction(rng.randrange(0,9),rng.randrange(1,5))for _ in range(m)]
        cuts=[tuple(j for j in range(m)if rng.randrange(3)==0)for _ in range(rng.randrange(8))]
        pairs=list(product(range(m),repeat=2))
        inc=tuple(rng.sample(pairs,min(len(pairs),rng.randrange(3))))
        pre=tuple(rng.sample(pairs,min(len(pairs),rng.randrange(3))))
        # Deliberately non-upward-closed, opaque parity feasibility.
        callback=(lambda s:len(s)%2==1)if case%4==0 else None
        c=Constraints(inc,pre,rng.randrange(m+1)if case%3==0 else None,callback)
        p=Problem(costs,cuts,c);want=exact_reference(costs,cuts,c)
        got=optimize(p);assert verify_optimization(p,got)
        assert got['upper_bound']==(None if want is None else want[0]),(case,want,got)
        assert got['status']==('infeasible'if want is None else'optimal');checks+=1
        for limit in [0,1,2,4]:
            got=optimize(p,max_nodes=limit);assert verify_optimization(p,got)
            if want is not None:
                assert got['lower_bound']<=want[0]
                if got['upper_bound']is not None:assert want[0]<=got['upper_bound']
            else:assert got['upper_bound']is None
            interrupted+=1
    # A cyclic prerequisite, a zero-price item, and mutually inconsistent endpoints.
    p=Problem([0,2,1],[(0,2)],Constraints(prerequisites=((0,1),(1,0)),incompatibilities=((0,2),)))
    assert optimize(p)['upper_bound']==1
    # Reject forged global lower bounds and forged dual capacity.
    p=Problem([1,1,1],[(0,1),(1,2)])
    r=optimize(p,max_nodes=0)
    for forged in ['lower','dual']:
        q=copy.deepcopy(r)
        if forged=='lower':q['lower_bound']=Fraction(9)
        else:q['certificate'][0]['dual']=[(0,Fraction(9))];q['certificate'][0]['lower']=Fraction(9)
        try:verify_optimization(p,q)
        except AssertionError:pass
        else:raise AssertionError('Forged certificate accepted')
    synth_checks=0
    for case in range(20):
        model=random_table(4100+case,m=7,n=15)
        c=Constraints(incompatibilities=((0,1),),prerequisites=((4,5),),
                      feasible=(lambda s:len(s)%2==0)if case%3==0 else None)
        want=full_table_optimum(model,c);r=synthesize(model,c)
        assert verify_completion(model,compact_certificate(r),c)
        assert r['upper_bound']==(None if want is None else want[0])
        assert r['status']in(['no_feasible_sufficient_selection','menu_insufficient']if want is None else['optimal'])
        for limit in [0,2]:
            q=synthesize(model,c,max_iterations=limit,max_nodes=20)
            assert verify_completion(model,compact_certificate(q),c)
            if q['lower_bound']is not None and want is not None:assert q['lower_bound']<=want[0]
            if q['upper_bound']is not None:
                assert model.obstruction(q['selection'])['status']=='sufficient'
                assert want is not None and want[0]<=q['upper_bound']
        synth_checks+=1
    # Structural oracle equals the actual inherited CNF model on every small subset.
    gf_checks=0
    for b in [1,2,3]:
        structural=PredictiveParityOracle(b);actual=future_register(b)
        for s in subsets(len(actual.sensors)):
            assert structural.obstruction(s)['status']==actual.obstruction(s)['status'];gf_checks+=1
    return dict(optimizer_exact_cases=checks,interrupted_bound_cases=interrupted,
                constrained_full_table_optima=synth_checks,GF2_vs_CNF_cases=gf_checks,
                forged_certificates_rejected=2)


def measured(fn):
    start=time.perf_counter();tracemalloc.start()
    out=fn();peak=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
    return out,dict(seconds=time.perf_counter()-start,peak_python_bytes=peak)


def benchmarks():
    rows=[]
    for name,model,c in [
        ('nonlinear_predictive_b4',PredictiveParityOracle(4),Constraints()),
        ('constrained_table_12ports',random_table(888,12,32),Constraints(incompatibilities=((1,2),(4,5)),prerequisites=((8,9),))),
        ('constrained_table_14ports',random_table(1219,14,40),Constraints(incompatibilities=((1,2),(4,5),(6,7)),prerequisites=((10,11),),max_selected=7)),
    ]:
        visits=[0]
        def f(s):visits[0]+=1;return feasible(s,c)
        old,oldstats=measured(lambda:old_synthesize(model,f))
        new,newstats=measured(lambda:synthesize(model,c))
        oldcost=old.get('cost');assert new['upper_bound']==oldcost,(name,old,new)
        rows.append(dict(name=name,menu_items=len(model.sensors),source_bits=model.circuit.n,
                         source_rows=len(model.rows)if hasattr(model,'rows')else None,
                         cost=oldcost,new_status=new['status'],
                         old_subset_visits=visits[0],new_expanded_nodes=new['expanded_nodes'],
                         new_created_nodes=new['created_nodes'],
                         old_oracle_calls=len(old['history']),new_oracle_calls=new['oracle_calls'],
                         old=oldstats,new=newstats))
    # Larger table problems: exact certificates, not exhaustive optimum references.
    large=[]
    for seed,m,n in [(722,24,60),(901,32,80)]:
        model=random_table(seed,m,n);c=Constraints(incompatibilities=tuple((j,j+1)for j in range(0,10,2)),prerequisites=((m-2,m-1),))
        data={'ports':model.rows,'readout':model.readouts,'target':model.targets,'costs':[s.cost for s in model.sensors],
              'incompatibilities':c.incompatibilities,'prerequisites':c.prerequisites,'seed':seed}
        (Path(__file__).resolve().parent/f'table_{m}.json').write_text(json.dumps(data,indent=2,default=str)+'\n')
        r,stats=measured(lambda:synthesize(model,c,max_iterations=100,max_nodes=10000))
        assert verify_completion(model,r,c)
        (Path(__file__).resolve().parent/f'certificate_table_{m}.json').write_text(json.dumps(compact_certificate(r),indent=2,default=str)+'\n')
        if r['selection']is not None:assert model.obstruction(r['selection'])['status']=='sufficient'
        large.append(dict(seed=seed,menu_items=m,source_rows=n,status=r['status'],lower_bound=r['lower_bound'],upper_bound=r['upper_bound'],
                          oracle_calls=r['oracle_calls'],expanded_nodes=r['expanded_nodes'],created_nodes=r['created_nodes'],measurement=stats))
    model=PredictiveParityOracle(20)
    r,stats=measured(lambda:synthesize(model,max_iterations=80,max_nodes=20000))
    assert verify_completion(model,r)
    (Path(__file__).resolve().parent/'certificate_predictive_20.json').write_text(json.dumps(compact_certificate(r),indent=2,default=str)+'\n')
    assert r['status']=='optimal'and r['upper_bound']==20
    large.append(dict(name='nonlinear_predictive_b20',menu_items=len(model.sensors),source_bits=40,status=r['status'],lower_bound=r['lower_bound'],upper_bound=r['upper_bound'],oracle_calls=r['oracle_calls'],expanded_nodes=r['expanded_nodes'],created_nodes=r['created_nodes'],measurement=stats))
    # A source-validated all-port incumbent keeps a real UB even before any cut.
    model=random_table(441,24,60)
    early=synthesize(model,max_iterations=0,max_nodes=0,upper_selection=tuple(range(24)))
    assert early['status']=='incomplete'and early['upper_bound']is not None and early['lower_bound']==0
    # Explicitly charge the greedy source-verified starting design separately.
    selected=list(range(24));seed_calls=0
    for j in sorted(selected,key=lambda j:model.sensors[j].cost,reverse=True):
        trial=[i for i in selected if i!=j];seed_calls+=1
        if model.obstruction(trial)['status']=='sufficient':selected=trial
    bounded=synthesize(model,max_iterations=40,max_nodes=16,upper_selection=selected)
    assert verify_completion(model,bounded)
    assert bounded['status']=='bounded'and bounded['lower_bound']==6 and bounded['upper_bound']==Fraction(26,3)
    (Path(__file__).resolve().parent/'table_anytime.json').write_text(json.dumps({'ports':model.rows,'readout':model.readouts,'target':model.targets,'costs':[s.cost for s in model.sensors],'seed':441},indent=2,default=str)+'\n')
    (Path(__file__).resolve().parent/'certificate_anytime.json').write_text(json.dumps(compact_certificate(bounded),indent=2,default=str)+'\n')
    anytime={'seed':441,'lower_bound':bounded['lower_bound'],'upper_bound':bounded['upper_bound'],
             'greedy_seed_oracle_calls':seed_calls,'synthesis_oracle_calls_including_revalidation':bounded['oracle_calls'],
             'total_source_oracle_calls':seed_calls+bounded['oracle_calls'],'expanded_nodes':bounded['expanded_nodes'],
             'max_nodes_per_optimizer':16,'status':bounded['status']}
    return rows,large,early,anytime


if __name__=='__main__':
    here=Path(__file__).resolve().parent
    checks=run_tests();print(json.dumps(checks),flush=True)
    small,large,early,anytime=benchmarks()
    out={'status':'PASS','backend':'Conventional exact branch and bound; not either ETH algorithm',
         'checks':checks,'controlled_comparisons':small,'larger_certified_examples':large,
         'early_stop_with_verified_upper':early,'nontrivial_interrupted_gap':anytime}
    (here/'results.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
    print(json.dumps(out,indent=2,default=str))
