"""Independent finite-source enumeration versus the public completion API.

The production module is imported only as the implementation under test.
Reference circuit evaluation, pair collisions and subset optimization below
do not call its evaluators, SAT routines or synthesis routines.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util, itertools as it, json, random, sys

if not __debug__:raise RuntimeError('Do not disable audit assertions.')

HERE=Path(__file__).resolve().parent
path=HERE.parent/'finite/completion.py'
spec=importlib.util.spec_from_file_location('audited_completion',path)
api=importlib.util.module_from_spec(spec);sys.modules[spec.name]=api;spec.loader.exec_module(api)
rng=random.Random(701802)

def clauses_hold(cnf,bits):
 return all(any(bits[abs(v)-1]==int(v>0)for v in clause)for clause in cnf)
def eval_ref(c,x):
 vals=[None]+list(x)
 for op,args in c.gates:
  a=[vals[i]for i in args]
  if op=='not':z=1-a[0]
  elif op=='and':z=int(a[0]==a[1]==1)
  elif op=='or':z=int(any(a))
  elif op=='xor':z=int(a[0]!=a[1])
  elif op=='true':z=1
  elif op=='false':z=0
  else:raise AssertionError(op)
  vals.append(z)
 return vals
def reference_states(model):
 return [(x,eval_ref(model.circuit,x))for x in it.product((0,1),repeat=model.circuit.n)if eval_ref(model.circuit,x)[model.admissible]]
def key_ref(model,vals,selected):
 return tuple(vals[w]for w in model.readout)+tuple(vals[w]for j in selected for w in model.sensors[j].wires)
def collisions_ref(model,rows,selected):
 counts={};answer_count=0
 for x,vals in rows:
  key=key_ref(model,vals,selected);a=tuple(vals[w]for w in model.target)
  d=counts.setdefault(key,{})
  answer_count+=2*sum(v for aa,v in d.items()if aa!=a)
  d[a]=d.get(a,0)+1
 return answer_count

# Every gate relation, including repeated-input aliases, has its exact truth table.
gate_checks=0
for op,arity in [('not',1),('and',2),('or',2),('xor',2),('true',0),('false',0)]:
 for alias in ([False,True]if arity==2 else[False]):
  args=(1,)*arity if alias else tuple(range(1,arity+1));out=max(args,default=0)+1
  cnf=api.gate_cnf(op,args,out)
  for bits in it.product((0,1),repeat=out):
   v=[bits[i-1]for i in args]
   expected=(not v[0])if op=='not'else(all(v)if op=='and'else(any(v)if op=='or'else(v[0]!=v[1]if op=='xor'else op=='true')))
   assert clauses_hold(cnf,bits)==(bits[out-1]==int(expected));gate_checks+=1

# Exact counts and witnesses for arbitrary small CNFs.
cnf_tests=0
for n in range(0,8):
 for _ in range(16):
  cnf=[]
  for __ in range(rng.randrange(12)):
   cnf.append(tuple(rng.choice((-1,1))*rng.randint(1,n)for k in range(rng.randrange(4)))if n else())
  expected=sum(clauses_hold(cnf,b)for b in it.product((0,1),repeat=n))
  assert api.count_cnf(cnf,n)==expected
  w=api.witness_cnf(cnf,n)
  assert (w is not None)==bool(expected)
  if w is not None:assert clauses_hold(cnf,[w[i+1]for i in range(n)])
  cnf_tests+=1

models=0;collision_checks=0;selection_checks=0;posterior_checks=0
for test in range(30):
 n=rng.randint(1,4);c=api.Circuit(n)
 for _ in range(4):
  op=rng.choice(('and','or','xor','not'))
  c.gate(op,*(rng.randint(1,c.wires)for j in range(1 if op=='not' else 2)))
 truth=c.const(1);adm=truth if test%3 else rng.randint(1,c.wires)
 ro=(rng.randint(1,c.wires),)
 target=tuple(rng.randint(1,c.wires)for j in range(test%3))
 sensors=[api.Sensor('s'+str(j),(rng.randint(1,c.wires),),F(rng.randint(0,9),2))for j in range(4)]
 model=api.Model(c,adm,ro,target,sensors);rows=reference_states(model)
 feasible=lambda s:len(s)<=3
 best=None
 for mask in range(16):
  selected=tuple(j for j in range(4)if mask>>j&1)
  count=collisions_ref(model,rows,selected);got=model.obstruction(selected,with_count=True)
  assert got['ordered_collision_count']==count
  assert (got['status']=='sufficient')==(count==0)
  collision_checks+=1
  if not count and feasible(selected):
   cost=sum((sensors[j].cost for j in selected),F(0));key=(cost,selected)
   if best is None or key<best:best=key
 for y in it.product((0,1),repeat=len(ro)):
  expected=[vals for _,vals in rows if key_ref(model,vals,())==y]
  assert model.compatible_count(y)==len(expected)
  post=model.posterior(y)
  if expected:
   d={}
   for vals in expected:a=tuple(vals[w]for w in target);d[a]=d.get(a,0)+1
   assert post['posterior']=={a:F(v,len(expected))for a,v in d.items()}
  else:assert post['status']=='impossible_or_zero_mass_readout'
  posterior_checks+=1
 got=api.synthesize(model,feasible=feasible)
 if best is None:assert got['status']in('menu_insufficient','no_feasible_sufficient_selection')
 else:assert got['status']=='optimal'and got['cost']==best[0]and tuple(got['selection'])==best[1]
 # Every returned cut is a necessary distinguishing set for its recorded pair.
 for row in got['history']:
  if row['oracle']['status']=='obstructed':
   x,xp=row['oracle']['witness'];vx,vxp=eval_ref(c,x),eval_ref(c,xp)
   expected=[j for j,sensor in enumerate(sensors)if tuple(vx[w]for w in sensor.wires)!=tuple(vxp[w]for w in sensor.wires)]
   assert row['distinguishing_menu']==expected
 selection_checks+=1;models+=1

future=[]
for blocks in range(1,5):
 model=api.future_register(blocks);rows=reference_states(model)
 optimal=None
 for mask in range(1<<len(model.sensors)):
  selected=tuple(j for j in range(len(model.sensors))if mask>>j&1)
  cost=len(selected)
  if optimal is not None and cost>=optimal:continue
  if collisions_ref(model,rows,selected)==0:optimal=cost
 assert optimal==blocks
 # Direct autonomous update check of the nominated paired completion.
 for x,_ in rows:
  parity=sum(x)%2;xp=(x[0]&parity,)+x[1:]
  pairs=[x[2*j]^x[2*j+1]for j in range(blocks)]
  next0=x[0]&int(sum(pairs)%2)
  predicted=[pairs[0]^x[0]^next0]+pairs[1:]
  assert next0==xp[0]and predicted==[xp[2*j]^xp[2*j+1]for j in range(blocks)]
 future.append(dict(blocks=blocks,source_bits=2*blocks,minimum_sensor_count=optimal,raw_sensor_baseline=2*blocks-1))

unequal=[]
for trial in range(12):
 blocks=3;model=api.future_register(blocks)
 costs=[F(rng.randint(1,13),rng.randint(1,4))for _ in model.sensors]
 sensors=[api.Sensor(s.name,s.wires,cost)for s,cost in zip(model.sensors,costs)]
 model=api.Model(model.circuit,model.admissible,model.readout,model.target,sensors)
 rows=reference_states(model);pred_opt=full_opt=None
 for mask in range(1<<len(sensors)):
  selected=tuple(j for j in range(len(sensors))if mask>>j&1)
  cost=sum((costs[j]for j in selected),F(0))
  if pred_opt is None or cost<pred_opt:
   if collisions_ref(model,rows,selected)==0:pred_opt=cost
  if full_opt is None or cost<full_opt:
   if len({key_ref(model,v,selected)for _,v in rows})==len(rows):full_opt=cost
 u={i:costs[i-1]for i in range(1,2*blocks)};v={j:costs[2*blocks-1+j]for j in range(blocks)}
 want_pred=min(u[1],v[0])+sum(min(u[2*j]+u[2*j+1],v[j])for j in range(1,blocks))
 want_full=min(u[1],v[0])+sum(min(u[2*j]+u[2*j+1],u[2*j]+v[j],u[2*j+1]+v[j])for j in range(1,blocks))
 assert (pred_opt,full_opt)==(want_pred,want_full)
 unequal.append(dict(trial=trial,predictive_optimum=str(pred_opt),full_source_optimum=str(full_opt)))

result=dict(status='PASS',gate_truth_table_checks=gate_checks,arbitrary_CNF_tests=cnf_tests,independent_models=models,collision_compiler_checks=collision_checks,global_selection_optima_checked=selection_checks,uniform_posterior_checks=posterior_checks,predictive_completion_family=future,unequal_cost_full_subset_checks=unequal,scope='Conventional public API tested against independent enumeration; no ETH algorithm was implemented or benchmarked.')
(HERE/'finite_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
