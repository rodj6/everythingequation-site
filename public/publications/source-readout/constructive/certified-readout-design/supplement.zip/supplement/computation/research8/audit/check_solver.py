"""Independent exhaustive reference for bounded hitting-set and source synthesis."""
from pathlib import Path
import sys,json,random
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from research8.solver.certified import Problem,Constraints,optimize,verify_optimization,synthesize,verify_completion,compact_certificate
from research8.solver.instances import TableModel,PredictiveParityOracle

def admitted(s,c):
    s=set(s)
    return (all(not(a in s and b in s)for a,b in c.incompatibilities)
            and all(a not in s or b in s for a,b in c.prerequisites)
            and(c.max_selected is None or len(s)<=c.max_selected)
            and(c.feasible is None or c.feasible(tuple(sorted(s)))))

def selections(m):
    for z in range(1<<m):yield tuple(j for j in range(m)if z>>j&1)

def reference(costs,cuts,c):
    vals=[sum((F(costs[j])for j in s),F(0))for s in selections(len(costs))
          if admitted(s,c)and all(set(s)&set(d)for d in cuts)]
    return min(vals,default=None)

def sufficient(table,readout,target,s):
    return all(target[i]==target[j]or readout[i]!=readout[j]
               or any(table[i][k]!=table[j][k]for k in s)
               for i in range(len(table))for j in range(i))

def main():
    rng=random.Random(826731);checks=0;certs=0;outer=0;gf=0
    for _ in range(120):
        m=rng.randrange(0,10);costs=[F(rng.randrange(5),rng.randrange(1,4))for j in range(m)]
        cuts=[tuple(j for j in range(m)if rng.randrange(2))for _ in range(rng.randrange(0,12))]
        pairs=tuple((a,b)for a in range(m)for b in range(a+1,m)if rng.randrange(15)==0)
        req=tuple((a,b)for a in range(m)for b in range(m)if a!=b and rng.randrange(35)==0)
        parity=rng.randrange(3)
        pred=None if parity==2 else lambda s,parity=parity:len(s)%2==parity
        c=Constraints(pairs,req,rng.choice([None,m//2,m]),pred)
        p=Problem(costs,cuts,c);truth=reference(costs,cuts,c)
        for limit in [0,1,3,None]:
            r=optimize(p,limit);assert verify_optimization(p,r);certs+=1
            if truth is None:
                assert r['upper_bound']is None
                if r['status']=='infeasible':assert r['lower_bound']is None
            else:
                assert r['status']!='infeasible'
                assert r['lower_bound']is not None and r['lower_bound']<=truth
                if r['upper_bound']is not None:assert truth<=r['upper_bound']
                if r['status']=='optimal':assert r['upper_bound']==truth==r['lower_bound']
            checks+=1
    for _ in range(30):
        m=rng.randrange(1,8);n=rng.randrange(1,12)
        table=[tuple(rng.randrange(2)for j in range(m))for i in range(n)]
        readout=[rng.randrange(2)for i in range(n)];target=[rng.randrange(2)for i in range(n)]
        costs=[F(rng.randrange(4))for j in range(m)]
        c=Constraints(prerequisites=tuple((j,j-1)for j in range(1,m)if rng.randrange(5)==0),
                      feasible=lambda s:len(s)%2==0)
        model=TableModel(table,readout,target,costs)
        vals=[sum((costs[j]for j in s),F(0))for s in selections(m)
              if admitted(s,c)and sufficient(table,readout,target,s)]
        truth=min(vals,default=None)
        r=synthesize(model,c)
        assert verify_completion(model,compact_certificate(r),c)
        assert (r['status']=='optimal')==(truth is not None)
        if truth is not None:assert r['upper_bound']==r['lower_bound']==truth
        outer+=1
    for b in range(1,5):
        model=PredictiveParityOracle(b);m=len(model.sensors)
        for s in selections(m):
            # Seventh circuit is only the implementation under test here;
            # direct truth enumeration independently defines expected descent.
            n=2*b;xs=[tuple((z>>j)&1 for j in range(n))for z in range(1<<n)]
            records={};collision=False
            for x in xs:
                values=model.circuit.evaluate(x)
                record=(x[0],tuple(values[model.sensors[j].wires[0]]for j in s))
                target=x[0]*(sum(x)%2)
                if record in records and records[record]!=target:collision=True;break
                records[record]=target
            assert (model.obstruction(s)['status']=='obstructed')==collision;gf+=1
    result={'status':'PASS','bounded_optimizer_comparisons':checks,'covering_tree_certificates':certs,
            'non_upward_source_synthesis_optima':outer,'structural_separator_queries':gf,
            'reference':'Independent all-subset costs and all-pair source sufficiency; includes zero costs, empty cuts, incompatibilities, prerequisites and non-upward feasibility.'}
    (Path(__file__).parent/'solver_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()
