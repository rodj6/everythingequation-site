# Reviewed Paper 5: certified target-sufficient design

**Certified Target-Sufficient Readout Design and Exact Finite-Model Reduction**  
Jeremy Rodgers, Independent Researcher, https://www.everythingequation.com

The reviewed draft contains a finite collision compiler, exact and interrupted minimum-cost completion design, a sharp nonlinear predictive-port cost formula, and exact rational/parity/tensor reductions. The finite algorithmic core is independent of the external ETH claims. The separate asymptotic corollaries remain conditional on the supplied preprint theorems and their representation assumptions.

This version tightens the circuit and wire/precision hypotheses, corrects a certificate-input arithmetic defect, preserves exact JSON decimal prices and priors, restores a missing CLI dependency, and improves citations and reproducibility. Existing exact cost formulas, benchmark optima and tensor calculations are unchanged. This is a theoretical manuscript with within-workflow proof and executable checks, not external peer review, empirical validation or an independent ETH refutation.

## Contents

- The readable manuscript PDF.
- `latex/`: the complete editable manuscript, five section/appendix sources and scoped bibliography.
- `supplement/computation/`: twenty inspected Python source inputs, the twelve-job manifest, hashes and producer dependencies.
- `supplement/reviewed_outputs/`: regenerated results, menu inputs, saved covering-tree certificates and focused numeric-schema checks.
- `supplement/EVIDENCE_GUIDE.md`: evidence classes, numerical outcomes and guarantee boundaries.
- `supplement/EXTERNAL_THEOREM_INPUTS.json`: supplied external PDF identities and the exact interfaces used, without redistributing them as original work.
- `build.py` and `reproduce.py`: portable entry points.

## Build

Use a TeX installation with `pdflatex`, `bibtex`, Latin Modern, AMS packages, `microtype`, `mathtools`, `geometry`, `booktabs`, `longtable`, `array`, `enumitem`, `xcolor`, `graphicx`, `natbib`, `xurl` and `hyperref`.

```bash
python build.py
```

The build works in a disposable copy. `--logs-dir PATH` optionally preserves build logs. It does not alter the editable sources.

## Reproduce

Python 3.10 or later; standard library only. Tested with Python 3.12.14. Assertions must stay enabled: do not use `python -O`. The public certificate module explicitly rejects optimized execution.

```bash
python reproduce.py --check
python reproduce.py --output replay_new
```

`--check` verifies the twenty source hashes, Python syntax, local namespace-module closure, twelve declared jobs and producer dependency order. It does not execute the mathematics. Full replay expands a disposable tree, retains a log and receipt for every job, and snapshots changed products immediately after each job. It preserves a nonempty output directory. No solver service, network, paused campaign job or live website is invoked.

Eleven jobs reproduce the original finite/weighted/summary/solver/tensor checks. The twelfth tests the bounded certificate/input repair. The solver producer regenerates the three table fixtures and four saved certificate families. The CLI interface and focused numeric-schema checks automatically include that producer when selected alone:

```bash
python reproduce.py --only checks/test_certificate_numbers.py --output replay_schema
```

All twelve jobs passed in the minimal package. The original uncorrected coordinated package had ten of eleven jobs pass: its CLI check failed because an imported parser module was omitted. That module was recovered from original evidence. Three reviewed modules now additionally enforce exact proof-number and JSON-decimal semantics; original versions and their counterexample remain in the separate review archive.

## Use the design CLI

The modules below operate on local inputs and exact finite models. For the recognized nonlinear source:

```bash
python supplement/computation/research8/solver/completion_design.py --blocks 4 --output design.json
python supplement/computation/research8/solver/completion_design.py --blocks 4 --verify design.json
```

For a supplied explicit table, use `--table PATH`. Example tables and matching certificates are under `supplement/reviewed_outputs/research8/solver/`. `--model PATH` uses the supplied circuit-JSON loader. The recovered loader is a required module even for the other CLI modes, because the CLI imports it at startup. Decimal/exponent numeric tokens are parsed directly as exact rational values, nonfinite constants are rejected, and proof masks/indices require actual JSON integers. Use `--max-nodes` or `--max-iterations` to request a bounded result; an interrupted run is not advertised as an optimum.

Weighted factor collections are reusable finite sequences such as lists or tuples. One-shot generators are outside that API contract. Signed factors are algebraic objects; the probability interface requires nonnegative supplied weights and reports zero conditioning mass as undefined.

## Scientific limits

The implementations use conventional exact DPLL, branch-and-bound, enumeration, Gaussian elimination and variable elimination. They do not implement either external ETH recursion. Runtime observations are synthetic prototype measurements, not universal speed claims. A covering-tree certificate is checked relative to the same declared exact source oracle and pure feasibility predicate; it is not a new proof-logging SAT/UNSAT format.

The menu, joint feasibility, preparation model, deadline, source prior and port costs are premises. A compatible witness does not identify the actual source. Boolean workspace is not physical quantum memory; computational tensor rank is not a causal-memory minimum. No simultaneous values for incompatible quantum observables are supplied. Born probabilities, the original measurement obligations, consciousness questions and the delayed-trine bounds retain their prior status.
