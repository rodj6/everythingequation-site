"""Replay reviewed finite-completion and tensor checks in a disposable expanded input tree.

python reproduce.py --check
python reproduce.py --output replay_new
python reproduce.py --only checks/test_certificate_numbers.py --output replay_one
"""
from pathlib import Path
import argparse, ast, gzip, hashlib, json, os, shutil, subprocess, sys, tempfile, time

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / 'supplement/computation'

def checked_inputs():
    rows = json.loads((INPUTS / 'INPUT_MANIFEST.json').read_text())
    jobs = json.loads((INPUTS / 'jobs.json').read_text())
    expanded = {}
    for row in rows:
        for field in ('path', 'expanded_path'):
            p = Path(row[field])
            if p.is_absolute() or '..' in p.parts:
                raise ValueError('Input paths must stay within the declared tree')
        raw = (INPUTS / row['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
        data = gzip.decompress(raw) if row['compressed'] else raw
        assert hashlib.sha256(data).hexdigest() == row['expanded_sha256'], row['expanded_path']
        assert row['expanded_path'] not in expanded, 'Duplicate expanded path'
        expanded[row['expanded_path']] = data
        if row['expanded_path'].endswith('.py'):
            compile(data, row['expanded_path'], 'exec')
    module_names = {Path(p).stem for p in expanded if p.endswith('.py')}
    for name, data in expanded.items():
        if not name.endswith('.py'):
            continue
        for node in ast.walk(ast.parse(data)):
            mods = [x.name for x in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
            for mod in mods:
                if mod.split('.')[0] in sys.stdlib_module_names:
                    continue
                if '.' in mod:
                    assert mod.replace('.', '/') + '.py' in expanded, (name, mod)
                else:
                    assert mod in module_names, (name, mod)
    assert len(jobs) == len(set(jobs)), 'Duplicate job'
    assert all(j in expanded for j in jobs), 'Missing job source'
    dependencies = json.loads((INPUTS / 'JOB_DEPENDENCIES.json').read_text())
    assert set(dependencies) == set(jobs), 'Incomplete dependency map'
    order = {job: i for i, job in enumerate(jobs)}
    for job, prerequisites in dependencies.items():
        assert all(dep in order and order[dep] < order[job] for dep in prerequisites), 'Dependencies must precede each job'
    return rows, jobs, expanded, dependencies

def main():
    if not __debug__:
        raise SystemExit('Do not use python -O: certificate assertions must remain enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Hashes, gzip integrity, syntax and static local-module closure only')
    parser.add_argument('--only', action='append', help='Exact job path relative to the expanded tree; required producer jobs are included automatically')
    parser.add_argument('--output', type=Path, help='New or empty output directory for logs, receipts and generated products')
    args = parser.parse_args()
    rows, jobs, expanded, dependencies = checked_inputs()
    selected = args.only or jobs
    if len(selected) != len(set(selected)) or any(j not in jobs for j in selected):
        raise SystemExit('Selected jobs must be distinct paths from jobs.json')
    requested = list(selected)
    required = set(selected)
    def include_prerequisites(job):
        for dep in dependencies[job]:
            if dep not in required:
                required.add(dep)
                include_prerequisites(dep)
    for job in requested:
        include_prerequisites(job)
    selected = [job for job in jobs if job in required]
    status = dict(status='PASS', input_files=len(rows), declared_jobs=len(jobs), byte_identity_and_static_closure='PASS', generated_input_dependencies='PASS', selected_jobs=selected)
    if args.check:
        print(json.dumps(status, indent=2))
        return
    if args.output is None:
        raise SystemExit('Supply --output with a new or empty directory')
    output = args.output.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise SystemExit('Output must be new or empty; existing evidence is preserved')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'logs').mkdir()
    receipts = []
    with tempfile.TemporaryDirectory(prefix='paper5_replay_') as tmp:
        work = Path(tmp)
        for name, data in expanded.items():
            p = work / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
        for i, job in enumerate(selected):
            p = work / job
            base = f'{i:02d}_{p.parent.name}_{p.stem}'
            before = {str(f.relative_to(work)): hashlib.sha256(f.read_bytes()).hexdigest()
                      for f in work.rglob('*') if f.is_file()}
            start = time.monotonic()
            with (output / 'logs' / (base + '.log')).open('w') as log:
                result = subprocess.run([sys.executable, '-B', str(p)], cwd=p.parent, stdout=log,
                                        stderr=subprocess.STDOUT, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            products = []
            for f in sorted(work.rglob('*')):
                if not f.is_file():
                    continue
                name = str(f.relative_to(work))
                data = f.read_bytes()
                digest = hashlib.sha256(data).hexdigest()
                if before.get(name) == digest:
                    continue
                dest = output / 'per_job' / base / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
                products.append(dict(expanded_path=name,
                                     snapshot=str(dest.relative_to(output)), sha256=digest))
            receipts.append(dict(script=job, returncode=result.returncode, seconds=time.monotonic()-start,
                                 script_sha256=hashlib.sha256(expanded[job]).hexdigest(),
                                 log='logs/' + base + '.log', products=products))
            (output / 'REPLAY_RECEIPT.json').write_text(json.dumps(receipts, indent=2) + '\n')
            print(job + ': ' + ('PASS' if result.returncode == 0 else 'FAIL'), flush=True)
            if result.returncode:
                raise SystemExit(result.returncode)
        products = []
        for p in sorted(work.rglob('*')):
            if not p.is_file():
                continue
            name = str(p.relative_to(work))
            data = p.read_bytes()
            if name in expanded and data == expanded[name]:
                continue
            dest = output / 'generated' / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            products.append(dict(path='generated/' + name, sha256=hashlib.sha256(data).hexdigest()))
        (output / 'GENERATED_PRODUCTS.json').write_text(json.dumps(products, indent=2) + '\n')
    print('Completed selected checks. Finite diagnostics and exact certificates have different scopes; consult supplement/EVIDENCE_GUIDE.md.')

if __name__ == '__main__':
    main()
