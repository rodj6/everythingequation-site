"""Independent exact spot checks of singular-pencil normal form and rank-count proof."""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
# Rational matrix rank implementation deliberately independent of supplied verifier.
def rank(a):
 a=[[Fraction(x) for x in row]for row in a];i=0
 for j in range(len(a[0])):
  p=next((p for p in range(i,len(a))if a[p][j]),None)
  if p is None:continue
  a[i],a[p]=a[p],a[i];v=a[i][j];a[i]=[x/v for x in a[i]]
  for k in range(len(a)):
   if k!=i:
    v=a[k][j];a[k]=[x-v*y for x,y in zip(a[k],a[i])]
  i+=1
  if i==len(a):break
 return i
A=[[1,0,0],[0,1,0],[0,0,0]];B=[[0,0,1],[0,0,0],[0,1,0]]
L=[]
for i,j in product(range(3),repeat=2):
 L.append([A[p][i]*A[q][j]+B[p][i]*B[q][j]for p,q in product(range(3),repeat=2)])
assert rank(L)==6
sets=[{i for i in range(3)if m>>i&1}for m in range(8)]
patterns=[]
for AA,BB in product(sets,repeat=2):
 if len(AA)+len(BB)<3:continue
 sex=[None]if len(AA)!=2 else [(k,j)for k in set(range(3))-AA for j in AA]
 fex=[None]if len(BB)!=2 else [(j,k)for j in BB for k in set(range(3))-BB]
 for se,fe in product(sex,fex):
  sr={(i,j):2+int(i in AA and j in AA)+int(se==(i,j))for i,j in product(range(3),repeat=2)}
  fr={(i,j):2+int(i in BB and j in BB)+int(fe==(i,j))for i,j in product(range(3),repeat=2)}
  r2=sum(sr[p]*fr[p]for p in sr)
  r3=sum(fr[a,b]*sr[b,c]for a,b,c in product(range(3),repeat=3))
  long=sum(sr.values())*sum(fr.values())
  patterns.append((r2,r3,long))
mins=[min(x[i]for x in patterns)for i in range(3)]
assert mins==[48,145,437]
out={'status':'PASS','singular_pencil_canonical_cp_linear_rank':rank(L),'minimal_labelled_rank_profiles':len(patterns),'R2_R3_long_minima':mins,'scope':'Exact spot-check and independent finite necessary-pattern enumeration. Does not certify global CP attainability or replace the analytic rank proof.'}
Path(__file__).with_name('rank_arguments_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
