# Quantum-source mathematical verification supplement

Run all nine certificate checks with one command:

```sh
python3 reproduce.py
```

Install the two dependencies first if needed (`python3 -m pip install -r requirements.txt`). Python 3.10 or later is recommended. The runner copies every checker into an isolated temporary directory, preserves the supplied source and reference JSON, and exports logs and regenerated certificates to `memory_verification_results/`. Use `--output /path/to/empty-directory` to change that destination. It stops on the first failed assertion or missing output and records the failure. It neither launches research searches nor contacts any external service.

For a fast packaging check without repeating the algebra:

```sh
python3 reproduce.py --check-only
```

## Contents and status

All source matrices, algebraic constants, rational Bernstein coefficients and support-count definitions are built directly inside the checkers. There are no hidden local modules or input-data files. `jobs.json` fixes each source hash and enumerates all ten expected JSON certificate outputs. `expected_outputs/` contains the certified output snapshots from successful inspected executions. The directory aliases `three`, `five` and `six` are stable code namespaces and do not impose mathematical dependencies between runs.

The tasks are: exact mixed-support CP/reset certificate; exhaustive support-pattern lower bound; analytic Weyl family identities; minimum-Kraus seed classification; reduced versus retained bath approximation; exact rational high-noise qutrit certificate; non-Weyl source deformation; optimal-generator reference-access distance; independent consolidated constants and twenty exhaustive rational finite-word/binomial checks. Analytical all-word proofs remain in the manuscript and technical companion. Finite word enumeration and randomized floating-reference diagnostics supplement, rather than replace, those proofs.

SymPy positivity and identity checks use exact algebraic arithmetic where stated. NumPy also supplies floating diagnostics and exact Fraction arrays; floating output fields can vary slightly across versions, so the runner relies on assertions rather than byte equality to snapshots. The checkers write only into the temporary copy. Expected source hashes and reference snapshots are packaging controls, not a claim of external peer review or formal verification.
