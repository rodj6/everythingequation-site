#!/usr/bin/env python3
"""Exact all-phase Choi reduction and minimum-Kraus-class characterization."""
import json
from pathlib import Path
import sympy as s
a,x,y,r,h,q,v=s.symbols('a x y r h q v',real=True)
om=(-1+s.I*s.sqrt(3))/2;z=x+s.I*y;zb=x-s.I*y;V2=x*x+y*y;D=3*a*a-3*a+1
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]]);Z=s.diag(1,om,om**2);VV=s.Matrix([[om**(p*k)for k in range(3)]for p in range(3)])/s.sqrt(3)
U=s.kronecker_product(VV,s.eye(3));D0=s.diag(0,a,1-a)
clean=lambda M:M.applyfunc(lambda w:s.cancel(s.expand_complex(w)))
Ds=[X**b*D0*X**(-b)for b in range(3)];DI=s.Matrix.hstack(*[s.Matrix([d[p,p]for p in range(3)])for d in Ds]).inv()
S=[]
for b in range(3):
 B=D0.copy();B[1,2]=z*om**(-b);B[2,1]=zb*om**b;S.append(clean(B))
J=s.zeros(9)
for p in range(3):
 for qq in range(3):
  if p==qq:M=sum((DI[b,p]*S[b]/3 for b in range(3)),s.zeros(3))
  else:
   for b in range(3):
    if (p,qq)==((b+1)%3,(b+2)%3):M=-r*S[b]/(6*z)
    if (qq,p)==((b+1)%3,(b+2)%3):M=-r*S[b]/(6*zb)
  J[3*p:3*p+3,3*qq:3*qq+3]=M
es=[s.Rational(1,3)-r*x/(3*V2),s.Rational(1,3)+r*(x-s.sqrt(3)*y)/(6*V2),s.Rational(1,3)+r*(x+s.sqrt(3)*y)/(6*V2)]
Fs=[x+s.sqrt(3)*y,-2*x,x-s.sqrt(3)*y];M=-1+s.I*s.sqrt(3)*(2*a-1)
cs=[(V2*M/D+r*f)/(6*zb)for f in Fs]
K=s.zeros(9);blocks=[]
for k in range(3):
 B=s.Matrix([[a*es[k],cs[k]],[s.conjugate(cs[k]),(1-a)*es[(k+1)%3]]]);blocks.append(B)
 ix=[3*k+1,3*((k+1)%3)+2]
 for p in range(2):
  for qq in range(2):K[ix[p],ix[qq]]=B[p,qq]
count=0
for w in clean(s.conjugate(U.T)*J*U-K):assert w==0;count+=1
us=[x,(-x+s.sqrt(3)*y)/2,(-x-s.sqrt(3)*y)/2]
for k,B in enumerate(blocks):
 u=us[(k+2)%3]
 # Here u=t*cos(phi+2pi*l/3); no square roots enter this identity.
 expr=a*(1-a)*(1+r*u/V2+r*r*(u*u-3*V2/4)/V2**2)-V2/D-r*r*u*u/V2-r*u/D
 assert s.cancel(s.expand_complex(9*B.det()-expr))==0;count+=1
# A+B*u+C*u² at normalized angular cosines.
DD=1-3*q;A=q*(1-3*h*h/4)-v/DD;B=h*(q-v/DD);C=h*h*(q-v)
odd=[s.together(A-B+C).as_numer_denom()[0],s.together(A+B/2+C/4).as_numer_denom()[0]]
even=[s.together(A+B+C).as_numer_denom()[0],s.together(A-B/2+C/4).as_numer_denom()[0]]
resodd=s.factor(s.resultant(*odd,v));reseven=s.factor(s.resultant(*even,v))
assert s.factor(resodd-9*h*h*q*(h-2)*(3*q-1)*(3*h*q-h+2*q))==0;count+=1
assert s.factor(reseven-9*h*h*q*(h+2)*(3*q-1)*(3*h*q-h-2*q))==0;count+=1
# A zero effect e0 forces c0=c2=0, whose difference forces y=0.
assert s.cancel((cs[0]-cs[2])-r*s.sqrt(3)*y/(3*zb))==0;count+=1
# With y=0, e0=0 => r=x>0; c0 cannot vanish: its imaginary numerator
# forces a=1/2, then the residual numerator is -3*x².
num=V2*M/D+r*Fs[0]
assert s.simplify(num.subs({y:0,r:x,a:s.Rational(1,2)})+3*x*x)==0;count+=1
out={'all_phase_exact_choi_and_scalar_checks':count,'odd_phase_resultant':str(resodd),'even_phase_resultant':str(reseven),'classification':'Every nondegenerate coordinate-plane Weyl exact-reset CP map with branch Choi rank3 belongs to the h-family (up to Weyl phase rotation and a<->1-a).','effect_obstruction':'Every admitted all-phase model has strictly positive one-step effects; horizon class cost 6*3^n for n>=2.','status':'passed; inequality/rank and case arguments in chapter.tex'}
Path(__file__).with_name('phase_classification_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
