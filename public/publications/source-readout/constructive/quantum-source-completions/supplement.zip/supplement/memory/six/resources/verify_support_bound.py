"""Exact integer enumeration of the strengthened universal rank constraints.
No optimization solver or floating-point rank thresholds are used.
Analytical input: a+b>=3; all ranks>=2; A*A/B*B force rank3;
if b=2 at least one additional F[j,k], j in B,k not in B, has rank3;
by stationary reversal, if a=2 at least one S[k,j], j in A,k not in A,
has rank3. Extra full pairs are harmless for lower bounds.
"""
from itertools import product
from pathlib import Path
import json

records=[]
for amask,bmask in product(range(8),repeat=2):
 A={i for i in range(3)if amask>>i&1};B={i for i in range(3)if bmask>>i&1}
 a,b=len(A),len(B)
 if a+b<3:continue
 rs=[[2+int(i in A and j in A)for j in range(3)]for i in range(3)]
 rf=[[2+int(i in B and j in B)for j in range(3)]for i in range(3)]
 sx=[None]if a!=2 else [(next(iter(set(range(3))-A)),j)for j in A]
 fx=[None]if b!=2 else [(j,next(iter(set(range(3))-B)))for j in B]
 for se,fe in product(sx,fx):
  s=[row[:]for row in rs];f=[row[:]for row in rf]
  if se is not None:s[se[0]][se[1]]=3
  if fe is not None:f[fe[0]][fe[1]]=3
  R2=sum(s[i][j]*f[i][j]for i,j in product(range(3),repeat=2))
  R3=sum(f[i][j]*s[j][k]for i,j,k in product(range(3),repeat=3))
  S=sum(map(sum,s));F=sum(map(sum,f))
  records.append(dict(A=sorted(A),B=sorted(B),state_extra=se,effect_extra=fe,S_state=S,S_effect=F,R2=R2,R3=R3,long_coefficient=S*F))
minima={key:min(r[key]for r in records)for key in ['R2','R3','long_coefficient']}
assert minima==dict(R2=48,R3=145,long_coefficient=437)
profiles=[]
for a,b in product(range(4),repeat=2):
 rows=[r for r in records if len(r['A'])==a and len(r['B'])==b]
 if rows:profiles.append(dict(a=a,b=b,**{key:min(r[key]for r in rows)for key in minima}))
result=dict(status='PASS (exact integer enumeration)',global_lower_bounds=minima,profile_minima=profiles,number_labelled_minimal_patterns=len(records),relaxed_equality_patterns=[r for r in records if r['long_coefficient']==437])
Path(__file__).with_name('support_bound_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='relaxed_equality_patterns'},indent=2))
