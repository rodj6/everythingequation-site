"""Exact algebraic isolation + numerical implementation tests, no campaign code."""
from fractions import Fraction as F
from pathlib import Path
import math,json
import numpy as np
OUT=Path(__file__).resolve().parent
def cubic(h):return 10*h**3-10*h*h-7*h-2
def r2(h):return h**3*(2-h)/(2*(h+1)*(3*h+2))
lo,hi=F(3,2),F(8,5)
assert cubic(lo)<0<cubic(hi)
for _ in range(100):
 mid=(lo+hi)/2
 if cubic(mid)<0:lo=mid
 else:hi=mid
assert hi-lo<F(1,2**100)
for h in [F(1,4),F(1,2),F(1),F(3,2),F(7,4)]:
 assert r2(h)-F(1,20)==-(h-1)*cubic(h)/(20*(h+1)*(3*h+2))
h1=1.;h2=float((lo+hi)/2)
assert abs(float(r2(F.from_float(h2)))-.05)<1e-15
w=np.exp(2j*np.pi/3);Z=np.diag([1,w,w*w]);X=np.roll(np.eye(3),1,axis=0)
def model(h):
 a=(1+math.sqrt((2-h)/(3*h+2)))/2;t=math.sqrt(h*(2-h)/(2*(h+1)*(3*h+2)));r=h*t
 seed=np.array([[0,0,0],[0,a,-t*w*w],[0,-t*w,1-a]],complex)
 states=[[np.linalg.matrix_power(Z,u)@np.linalg.matrix_power(X,v)@seed@np.linalg.matrix_power(X,v).conj().T@np.linalg.matrix_power(Z,u).conj().T for v in range(3)]for u in range(3)]
 enc=np.column_stack([s.reshape(-1)for row in states for s in row]);inv=np.linalg.inv(enc)
 T=np.full((3,3),(1+r/2)/3)-np.eye(3)*r/2
 maps=[];effects=[]
 for j in range(3):
  M=np.column_stack([T[u,j]*states[v][j].reshape(-1)for u in range(3)for v in range(3)])@inv
  maps.append(M);E=(M.conj().T@np.eye(3).reshape(-1)).reshape(3,3);effects.append(E)
 return maps,effects,T
m1,e1,T1=model(h1);m2,e2,T2=model(h2)
assert np.max(abs(T1-T2))<1e-15
projectors=[(E-(2-h1)/6*np.eye(3))/(h1/2)for E in e1]
for j,P in enumerate(projectors):
 assert np.max(abs(P@P-P))<1e-13
 assert np.max(abs(e2[j]-((2-h2)/6*np.eye(3)+h2/2*P)))<1e-13
assert np.max(abs(sum(projectors)-np.eye(3)))<1e-13
distance=abs(h2-h1)/3
td=lambda A:float(np.sum(abs(np.linalg.eigvalsh((A+A.conj().T)/2))))
refdist=.5*sum(td((a-b).T/3)for a,b in zip(e1,e2))
probedist=.5*sum(abs(np.trace((a-b)@projectors[0]))for a,b in zip(e1,e2))
assert abs(refdist-distance)<1e-14 and abs(probedist-distance)<1e-14
checks=0;maxerr=0.
for maps,T in [(m1,T1),(m2,T2)]:
 words=[((),np.eye(3)/3,1.)]
 for n in range(1,7):
  new=[]
  for word,rho,p in words:
   for j in range(3):
    z=(maps[j]@rho.reshape(-1)).reshape(3,3);pred=p*(1/3 if n<3 else T[word[-2],j]);err=abs(np.trace(z)-pred)
    assert err<1e-13;maxerr=max(maxerr,float(err));checks+=1;new.append((word+(j,),z,pred))
  words=new
result=dict(status='all exact root/isolation and numerical channel checks passed',h2_rational_bracket=[str(lo),str(hi)],h2=h2,
 lambda_value=1-math.sqrt(.05),pointer_half_diamond_exact_expression='(h2-1)/3',distance=distance,optimal_equal_prior_success=.5+distance/2,
 same_stationary_local_preparation='I3/3; common maximally entangled purifier allowed only in reference-readable task',
 maxent_reference_distance=refdist,known_pure_probe_distance=float(probedist.real),word_checks=checks,max_word_error=maxerr,
 scope='Exact proof in reference_access.tex; sampled numerical maps diagnose implementation, not empirical data')
(OUT/'reference_access_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
