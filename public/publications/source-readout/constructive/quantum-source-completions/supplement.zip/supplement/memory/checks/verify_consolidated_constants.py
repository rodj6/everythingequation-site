from fractions import Fraction as F
from math import comb,isqrt
from pathlib import Path
import json
# Exact low-noise contradictions.
l=F(3,10**8);s=F(1,2000)
assert F(36)*18*l*111**2==F(23952024,10**8)<F(49,100)**2
assert 18**2*s==F(162,1000)<F(49,100)**2
assert (1-l)/2>F(49,100)
# Exact complete-history count from the mixed source profile.
S=[[3,2,2],[2,2,2],[2,2,2]];E=[[2,2,2],[3,3,3],[3,3,3]]
assert sum(S[i][j]*E[i][j]for i in range(3)for j in range(3))==50
assert sum(E[i][j]*S[j][k]for i in range(3)for j in range(3)for k in range(3))==152
assert sum(map(sum,S))*sum(map(sum,E))==456
assert 19*23==437
# Exact declared typed-gap and nearby alternative CP source probe.
gap=F(800,30603);assert gap/3==F(800,91809)and gap/2==F(400,30603)
# Finite-record binomial likelihood reduction at rational parameters: exhaustive
# ordered words independently verify the closed binomial TV through n6.
from itertools import product
checks=0
for lam in [F(0),F(1,5),F(99,100),F(1)]:
 for n in range(2,7):
  exact=F(0);counts={}
  for w in product(range(3),repeat=n):
   rep=sum(w[k]==w[k+2]for k in range(n-2));p=F(1,9)
   for k in range(n-2):p*=lam/3 if w[k]==w[k+2]else(3-lam)/6
   exact+=abs(p-F(1,3**n));counts[rep]=counts.get(rep,F(0))+p
  k=n-2
  ref=sum(abs(F(comb(k,j))*(lam/3)**j*(1-lam/3)**(k-j)-F(comb(k,j))*F(1,3)**j*F(2,3)**(k-j))for j in range(k+1))/2
  assert exact/2==ref
  for j in range(k+1):assert counts.get(j,F(0))==F(comb(k,j))*(lam/3)**j*(1-lam/3)**(k-j)
  checks+=1
r={'status':'PASS','low_noise_constants':'exact rational','mixed_rank_profile':[50,152,456],'universal_long_lower':437,'allword_binomial_checks':checks,'access_probe_exact':str(gap)}
Path(__file__).with_name('consolidated_constant_results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
