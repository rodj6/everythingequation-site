#!/usr/bin/env python3
"""Portable certificate runner: originals unchanged; all checker writes are disposable."""
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parent

def closure():
    jobs=json.loads((ROOT/'jobs.json').read_text())
    required=set()
    for job in jobs:
        src=ROOT/job['script']
        assert src.is_file(),src
        assert hashlib.sha256(src.read_bytes()).hexdigest()==job['sha256'],src
        tree=ast.parse(src.read_text(),filename=str(src))
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):names=[n.name for n in node.names]
            elif isinstance(node,ast.ImportFrom):names=[node.module or '']
            else:continue
            for name in names:
                top=name.split('.')[0]
                assert top in sys.stdlib_module_names or top in {'numpy','sympy'},(src,name)
                if top in {'numpy','sympy'}:required.add(top)
        assert len(job['outputs'])==len(job['expected_outputs'])
        for rel in job['expected_outputs']:
            p=ROOT/rel
            assert p.is_file(),p
            json.loads(p.read_text())
    return jobs,sorted(required)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check-only',action='store_true',help='validate portable source/certificate closure without rerunning algebra')
    ap.add_argument('--output',type=Path,default=Path.cwd()/'memory_verification_results',help='directory receiving receipts, logs and generated certificate JSON')
    args=ap.parse_args();jobs,requires=closure()
    if args.check_only:
        print(json.dumps({'status':'PASS','jobs':len(jobs),'source_hashes_checked':len(jobs),'expected_certificate_files':sum(len(j['expected_outputs'])for j in jobs),'external_dependencies':requires,'algebra_reexecuted':False},indent=2));return 0
    missing=[name for name in requires if importlib.util.find_spec(name)is None]
    if missing:raise SystemExit('Missing packages: '+', '.join(missing)+'. Install requirements.txt first.')
    out=args.output.resolve()
    if out.exists() and any(out.iterdir()):raise SystemExit('Output directory must be absent or empty: '+str(out))
    out.mkdir(parents=True,exist_ok=True)
    receipt=[]
    with tempfile.TemporaryDirectory(prefix='quantum-memory-verification-')as tmp:
        work=Path(tmp)
        for job in jobs:
            dst=work/job['script'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/job['script'],dst)
        for index,job in enumerate(jobs,1):
            label=job['script'].replace('/','_');log=out/(label+'.log');start=time.monotonic()
            with log.open('w')as f:
                result=subprocess.run([sys.executable,'-B',str(work/job['script'])],cwd=work/job['cwd'],stdout=f,stderr=subprocess.STDOUT)
            generated=[]
            for rel in job['outputs']:
                src=work/rel
                if src.exists():
                    json.loads(src.read_text());dst=out/'certificates'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);generated.append(rel)
            ok=result.returncode==0 and len(generated)==len(job['outputs'])
            receipt.append({'script':job['script'],'returncode':result.returncode,'status':'PASS'if ok else'FAIL','seconds':round(time.monotonic()-start,3),'generated_certificates':generated,'log':log.name})
            (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
            print(f"{index}/{len(jobs)} {job['script']}: {'PASS'if ok else'FAIL'}",flush=True)
            if not ok:return result.returncode or 1
    print('All certificate checks passed. Results: '+str(out));return 0
if __name__=='__main__':raise SystemExit(main())
