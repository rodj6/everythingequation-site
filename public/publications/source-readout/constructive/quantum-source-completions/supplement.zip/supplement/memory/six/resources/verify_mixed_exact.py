"""Exact algebraic mixed-support delayed-trine source certificate.

Requires SymPy and NumPy. No search or previous producer modules imported.
All positivity comparisons are exact in Q(sqrt(6)); floating point is used
only for the separate all-word diagnostics printed at the end.
"""
from pathlib import Path
import itertools, json
import numpy as np
import sympy as s
from sympy.polys.matrices import DomainMatrix as DM

OUT=Path(__file__).resolve().parent
R=s.Rational; w=(-1+s.I*s.sqrt(3))/2; rt=s.sqrt(6)
K=s.QQ.algebraic_field(rt,w); KR=s.QQ.algebraic_field(rt)
def dm(M): return DM.from_Matrix(M).convert_to(K)
def normal(x): return K.to_sympy(K.from_sympy(x))
def conj(x): return K.from_sympy(s.conjugate(K.to_sympy(x)))
def positive(x):
    """Return exact real Q(sqrt6) expression, asserting its strict sign."""
    e=KR.to_sympy(KR.from_sympy(K.to_sympy(x)))
    a=s.expand(e).coeff(rt,0);b=s.expand(e).coeff(rt,1)
    assert a.is_Rational and b.is_Rational,(a,b)
    ok=(a>0 if b==0 else b>0 if a==0 else
        True if a>0 and b>0 else False if a<0 and b<0 else
        a*a>6*b*b if a>0 else 6*b*b>a*a)
    assert ok,e
    return str(e)
def hermitian(M):
    a=M.to_list();n=len(a)
    assert all(a[p][q]==conj(a[q][p]) for p in range(n) for q in range(n))

lam=R(99,100);p=R(32,35);c=R(7,20)
T=s.Matrix(3,3,lambda a,j:lam/3 if a==j else (3-lam)/6)
Wplus=s.Matrix([[R(3,35),4*rt/35,0],[4*rt/35,R(32,35),0],[0,0,0]])
Wminus=s.Matrix([[R(3,35),-4*rt/35,0],[-4*rt/35,R(32,35),0],[0,0,0]])
Wtwo=s.diag(0,0,1)
for W in [Wplus,Wminus,Wtwo]:
    hermitian(dm(W));assert dm(W).rank()==1 and s.trace(W)==1
base=[(Wplus+Wminus+Wtwo)/3,(Wminus+Wtwo)/2,(Wplus+Wtwo)/2]
# z_ab=sqrt2*(A_ab+B_ab*omega), after a rational search-point rounding.
AB=[(104,-112),(319,226),(-439,-1028),(-299,54),(269,597),(1119,714)]
states=[[None]*3 for _ in range(3)]
state_minor=[]
for a in range(3):
    states[a][0]=base[a]
    pp=R(33,35) if a==0 else R(67,70)
    for b in range(1,3):
        aa,bb=AB[a*2+b-1];z=R(aa,10000)+R(bb,10000)*w
        v=w**(b-1)
        S=s.Matrix([[1-pp,z,-z*s.conjugate(v)],
            [s.conjugate(z),pp/2,-pp*s.conjugate(v)/2],
            [-s.conjugate(z)*v,-pp*v/2,pp/2]])
        states[a][b]=S
        # Principal 2x2 minor positive proves rank exactly two on its plane.
        state_minor.append(positive(K.from_sympy((1-pp)*pp/2-z*s.conjugate(z))))
vec=lambda A:s.Matrix([A[i,j] for i in range(3) for j in range(3)])
E=dm(s.Matrix.hstack(*[vec(states[a][b]) for a in range(3) for b in range(3)]))
det=E.det();assert det!=K.zero
Einv=E.inv();Ms=[];Js=[];cp_minors=[];ranks=[]
counts={'reset_entries':0,'trace_preservation_entries':0,'stationarity_and_initial_entries':0,
        'strict_CP_principal_minors':0,'state_plane_minors':len(state_minor)}
for j in range(3):
    O=dm(s.Matrix.hstack(*[T[a,j]*vec(states[b][j]) for a in range(3) for b in range(3)]))
    M=O*Einv;Ms.append(M)
    assert M*E==O;counts['reset_entries']+=81
    ml=M.to_list()
    J=DM([[ml[3*(i%3)+(j2%3)][3*(i//3)+(j2//3)]
          for j2 in range(9)] for i in range(9)],(9,9),K)
    Js.append(J);hermitian(J)
    if j==0:
        # Exact rank-three measure-and-prepare branch.
        vs=[s.Matrix([0,1,w**a]) for a in range(3)]
        J0=s.zeros(9)
        for a,W in enumerate([Wplus,Wminus,Wtwo]):
            J0+=(2*c/3)*s.kronecker_product(s.conjugate(vs[a])*vs[a].T/2,W)
        assert (J-dm(J0)).is_zero_matrix and J.rank()==3
        ranks.append(3);cp_minors.append(['rank-three explicit measure-and-prepare'])
    else:
        # Raw support basis avoids square roots of two; congruence preserves positivity.
        Q=s.Matrix([[1,0],[0,1],[0,-w**(j-1)]])
        P=dm(s.kronecker_product(s.eye(3),Q))
        PH=dm(s.conjugate(s.kronecker_product(s.eye(3),Q)).T)
        block=PH*J*P;row=[]
        for n in range(1,7):
            row.append(positive(block.extract(range(n),range(n)).det()))
            counts['strict_CP_principal_minors']+=1
        # Output-range identities certify the complementary three-dimensional kernel.
        normalv=s.Matrix([0,1,w**(j-1)])
        N=dm(s.kronecker_product(s.eye(3),normalv))
        assert (J*N).is_zero_matrix,(j,(J*N).to_Matrix().evalf(5))
        ranks.append(6);cp_minors.append(row)

identity=s.eye(3);trrow=dm(s.Matrix([[int(i==j)for i in range(3)for j in range(3)]]))
assert trrow*sum(Ms[1:],Ms[0])==trrow;counts['trace_preservation_entries']+=9
tau=sum((S for row in states for S in row),s.zeros(3))/9;tv=dm(vec(tau))
assert sum((M*tv for M in Ms[1:]),Ms[0]*tv)==tv
counts['stationarity_and_initial_entries']+=9
for j in range(3):
    assert (trrow*Ms[j]*tv).to_list()[0][0]==K(R(1,3))
    for k in range(3):
        assert Ms[k]*Ms[j]*tv==dm(vec(states[j][k]/9))
        counts['stationarity_and_initial_entries']+=9

# Effects and pair-effect exact ranks, including supported positivity certificates.
effects=[(trrow*M).to_Matrix().reshape(3,3).T for M in Ms]
pair_ranks=[];pair_minors=[]
for j in range(3):
    row=[];certrow=[]
    for k in range(3):
        F=(trrow*Ms[k]*Ms[j]).to_Matrix().reshape(3,3).T
        FF=dm(F);hermitian(FF)
        rank=FF.rank();row.append(rank)
        # Every rank-three pair effect is strictly positive, the remaining
        # rank-two cases are PSD by CP and their exact rank is verified.
        certrow.append([positive(FF.extract(range(n),range(n)).det())for n in range(1,4)] if rank==3 else ['PSD by CP; exact rank two'])
    pair_ranks.append(row);pair_minors.append(certrow)
state_ranks=[[dm(S).rank() for S in row]for row in states]
assert state_ranks==[[3,2,2],[2,2,2],[2,2,2]],state_ranks
assert sum(map(sum,pair_ranks))==24,pair_ranks
Ssum=sum(map(sum,state_ranks));Fsum=sum(map(sum,pair_ranks))
R2=sum(state_ranks[j][k]*pair_ranks[j][k] for j in range(3)for k in range(3))
R3=sum(pair_ranks[i][j]*state_ranks[j][k]for i,j,k in itertools.product(range(3),repeat=3))

# Independent floating-point all-word diagnostics; reset induction proves full law.
mn=[np.array(M.to_Matrix().evalf(),complex)for M in Ms];tn=np.array(T,float)
sn=[[np.array(S.evalf(),complex)for S in row]for row in states]
front=[((),np.array(tau.evalf(),complex),1.)];checks=0;err=0.
for n in range(1,8):
    nxt=[]
    for wd,rho,prob in front:
        for j in range(3):
            out=(mn[j]@rho.reshape(-1)).reshape(3,3);word=wd+(j,)
            pred=prob*(1/3 if n<3 else tn[wd[-2],j]);delta=abs(np.trace(out)-pred)
            err=max(err,float(delta));assert delta<1e-11
            if n>=2:assert np.max(abs(out-pred*sn[word[-2]][word[-1]]))<1e-11
            checks+=1;nxt.append((word,out,pred))
    front=nxt
report={'status':'exact algebraic CP, TP, reset, stationary and rank certificates passed',
 'lambda':'99/100','p':'32/35','c':'7/20','coherence_integer_pairs':AB,
 'field':'Q(sqrt(6),omega), omega=(-1+i*sqrt(3))/2',
 'state_basis_determinant':str(K.to_sympy(det)),
 'state_plane_positive_minors':state_minor,'strict_supported_Choi_principal_minors':cp_minors,
 'pair_effect_positive_minors':pair_minors,'state_ranks':state_ranks,'pair_effect_ranks':pair_ranks,
 'state_rank_sum':Ssum,'pair_effect_rank_sum':Fsum,'branch_Choi_ranks':ranks,'one_step_rank':sum(ranks),
 'complete_history_R2':R2,'complete_history_R3':R3,'complete_history_n_ge_4':str(Ssum*Fsum)+'*3**(n-4)',
 'exact_checks':counts,'numeric_word_checks':checks,'max_word_probability_error':err,
 'scope':'One exact stationary autonomous qutrit source; no global optimality claim.'}
(OUT/'mixed_exact_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
