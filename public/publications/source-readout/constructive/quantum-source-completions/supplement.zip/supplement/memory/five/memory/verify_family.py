#!/usr/bin/env python3
"""Exact all-parameter algebra and independent full-word tests for optimal k=9 family.

Python 3.12, SymPy>=1.14, NumPy>=1.24. Run in this directory.
Exact symbolic identities are proofs of the displayed algebra; floating-point
word enumeration is an independent diagnostic, not a substitute for induction.
"""
import json,math
from pathlib import Path
import sympy as s
import numpy as np
OUT=Path(__file__).resolve().parent
I=s.I; om=(-1+I*s.sqrt(3))/2
simp=lambda z:s.cancel(s.expand_complex(z))
a,t,r,h=s.symbols('a t r h',real=True,nonzero=True)
q=a*(1-a);D=1-3*q;L=(a-1)+(2*a-1)*om
z=-t*om**2
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]]);Z=s.diag(1,om,om**2)
V=s.Matrix([[om**(p*k)for k in range(3)]for p in range(3)])/s.sqrt(3)
U=s.kronecker_product(V,s.eye(3));D0=s.diag(0,a,1-a)
Ds=[X**b*D0*X**(-b)for b in range(3)]
DC=s.Matrix.hstack(*[s.Matrix([d[p,p]for p in range(3)])for d in Ds]);DI=DC.inv()
def clean(M):return M.applyfunc(simp)
def state(aa,b):
 tau=D0.copy();tau[1,2]=z;tau[2,1]=s.conjugate(z)
 W=Z**aa*X**b
 return clean(W*tau*s.conjugate(W.T))
SS=[[state(aa,b)for b in range(3)]for aa in range(3)]
def phi0_E(p,qq):
 if p==qq:return clean(sum((DI[b,p]*SS[b][0]/3 for b in range(3)),s.zeros(3)))
 for b in range(3):
  if (p,qq)==((b+1)%3,(b+2)%3):return clean(-r*SS[b][0]/(6*z))
  if (qq,p)==((b+1)%3,(b+2)%3):return clean(-r*SS[b][0]/(6*s.conjugate(z)))
J=s.zeros(9)
for p in range(3):
 for qq in range(3):J[3*p:3*p+3,3*qq:3*qq+3]=phi0_E(p,qq)
em=s.Rational(1,3)-r/(6*t);ep=s.Rational(1,3)+r/(3*t)
c0=-om**2*(D*r+t*L)/(3*D);c1=-om**2*(-D*r+2*t*L)/(6*D)
B=[s.Matrix([[a*em,c0],[s.conjugate(c0),(1-a)*em]]),
   s.Matrix([[a*em,c1],[s.conjugate(c1),(1-a)*ep]]),
   s.Matrix([[a*ep,c1],[s.conjugate(c1),(1-a)*em]])]
K=s.zeros(9)
for k,bb in enumerate(B):
 ix=[3*k+1,3*((k+1)%3)+2]
 for p in range(2):
  for qq in range(2):K[ix[p],ix[qq]]=bb[p,qq]
counts={'choi_block_entries':0,'reset_entries':0,'stationary_and_initial_entries':0,'tp_entries':0,'scalar_identities':0}
for x in clean(s.conjugate(U.T)*J*U-K):assert x==0;counts['choi_block_entries']+=1
JS=[]
for j in range(3):
 W=s.kronecker_product(Z**(-j),X**j)
 JS.append(clean(W*J*s.conjugate(W.T)))
def apply(JJ,A):
 ans=s.zeros(3)
 for p in range(3):
  for qq in range(3):ans+=A[p,qq]*JJ[3*p:3*p+3,3*qq:3*qq+3]
 return clean(ans)
def eq(A,B,tag):
 for xx in clean(A-B):assert xx==0,xx;counts[tag]+=1
for aa in range(3):
 for b in range(3):
  for j in range(3):
   T=(1-r)/3 if aa==j else (1+r/2)/3
   eq(apply(JS[j],SS[aa][b]),T*SS[b][j],'reset_entries')
for j in range(3):
 eq(apply(JS[j],s.eye(3)/3),Ds[j]/3,'stationary_and_initial_entries')
 for k in range(3):eq(apply(JS[k],Ds[j]),SS[j][k]/3,'stationary_and_initial_entries')
for p in range(3):
 for qq in range(3):
  tr=sum(s.trace(JJ[3*p:3*p+3,3*qq:3*qq+3])for JJ in JS)
  assert simp(tr-(1 if p==qq else 0))==0;counts['tp_entries']+=1
# Exact scalar cone calculation, independently checked from the derived blocks.
d0=q*(2*t-r)**2/(36*t*t)-(D*r*r-r*t+t*t)/(9*D)
d1=q*(2*t-r)*(t+r)/(18*t*t)-(D*r*r+2*r*t+4*t*t)/(36*D)
for bb,dd in zip(B,[d0,d1,d1]):assert simp(bb.det()-dd)==0;counts['scalar_identities']+=1
Q=h/(3*h+2);DD=2/(3*h+2);v=h*(2-h)/(2*(h+1)*(3*h+2))
for expr in [Q*DD*(2-h)**2-4*v*(DD*h*h-h+1),2*Q*DD*(2-h)*(1+h)-v*(DD*h*h+2*h+4)]:
 assert s.factor(expr)==0;counts['scalar_identities']+=1
assert s.factor((2-h)*(DD*h*h+2*h+4)-8*(1+h)*(DD*h*h-h+1))==0
counts['scalar_identities']+=1
r2=h*h*v
assert s.factor(s.diff(r2,h)+3*h*h*(h+2)*(2*h*h-h-2)/(2*(h+1)**2*(3*h+2)**2))==0
counts['scalar_identities']+=1
hm=(1+s.sqrt(17))/4
assert s.simplify(r2.subs(h,hm)-(71-17*s.sqrt(17))/16)==0
counts['scalar_identities']+=1
# Independent numerical maps are rebuilt from the nine-state basis inverse.
def numerical(hh):
 aa=(1+math.sqrt((2-hh)/(3*hh+2)))/2
 tt=math.sqrt(hh*(2-hh)/(2*(hh+1)*(3*hh+2)));rr=hh*tt
 w=np.exp(2j*np.pi/3);xx=np.roll(np.eye(3,dtype=complex),1,axis=0);zz=np.diag([1,w,w*w])
 tau=np.diag([0.,aa,1-aa]).astype(complex);tau[1,2]=-tt*w*w;tau[2,1]=np.conj(tau[1,2])
 states=[]
 for av in range(3):
  row=[]
  for bv in range(3):
   ww=np.linalg.matrix_power(zz,av)@np.linalg.matrix_power(xx,bv)
   row.append(ww@tau@ww.conj().T)
  states.append(row)
 S=np.column_stack([states[av][bv].reshape(-1)for av in range(3)for bv in range(3)])
 T=np.full((3,3),(1+rr/2)/3)-np.eye(3)*rr/2
 maps=[];choiranks=[];effects=[];mineig=1.
 for j in range(3):
  O=np.column_stack([T[av,j]*states[bv][j].reshape(-1)for av in range(3)for bv in range(3)])
  MM=O@np.linalg.inv(S);maps.append(MM)
  JJ=MM.reshape(3,3,3,3).transpose(2,0,3,1).reshape(9,9);JJ=(JJ+JJ.conj().T)/2
  ee=np.linalg.eigvalsh(JJ);mineig=min(mineig,float(ee.min()));choiranks.append(int((ee>1e-9).sum()))
  E=np.empty((3,3),complex)
  for p in range(3):
   for qq in range(3):E[qq,p]=np.trace(JJ[3*p:3*p+3,3*qq:3*qq+3])
  effects.append(E)
 assert choiranks==[3,3,3],(hh,choiranks)
 assert mineig>-1e-10
 maxerr=0.;nchecks=0
 def act(j,rho):return (maps[j]@rho.reshape(-1)).reshape(3,3)
 eqrho=sum((act(j,np.eye(3)/3)for j in range(3)),np.zeros((3,3),complex))
 assert np.max(np.abs(eqrho-np.eye(3)/3))<1e-11
 frontier=[((),np.eye(3)/3,1.)]
 for n in range(1,8):
  nxt=[]
  for word,rho,prob in frontier:
   for j in range(3):
    got=act(j,rho);wrd=word+(j,)
    p=prob*(1/3 if n<=2 else T[word[-2],j])
    err=abs(np.trace(got)-p);maxerr=max(maxerr,float(err));nchecks+=1
    assert err<1e-10,(hh,wrd,err)
    if n>=2:
     assert np.max(np.abs(got-p*states[wrd[-2]][wrd[-1]]))<1e-10
    nxt.append((wrd,got,p))
  frontier=nxt
 # All nine two-step effects positive rank3, postpair rank2.
 minF=1.
 for j in range(3):
  for k in range(3):
   FF=(maps[j].conj().T@effects[k].reshape(-1)).reshape(3,3)
   minF=min(minF,float(np.linalg.eigvalsh((FF+FF.conj().T)/2).min()))
 assert minF>0
 return {'h':hh,'a':aa,'t':tt,'r':rr,'lambda':1-rr,'branch_choi_ranks':choiranks,'min_choi_eigenvalue_numerical':mineig,'word_checks_through_length_7':nchecks,'max_word_error':maxerr,'minimum_two_step_effect_eigenvalue':minF}
samples=[numerical(hh)for hh in [.01,.1,.3,.5,.8,1.,1.2,float(hm),4/3,1.6,1.9]]
results={'exact_symbolic_checks':counts,'exact_total':sum(counts.values()),'h_max_exact':'(1+sqrt(17))/4','r_max_squared_exact':'(71-17*sqrt(17))/16','lambda_min_decimal':1-math.sqrt((71-17*math.sqrt(17))/16),'branch_choi_rank_all_h_in_0_2':3,'record_choi_rank':9,'numerical_samples_only':samples,'numeric_total_word_checks':sum(x['word_checks_through_length_7']for x in samples),'status':'Exact scalar cone proof in chapter.tex; all symbolic identities and independent numerical diagnostics passed.'}
(OUT/'family_results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
