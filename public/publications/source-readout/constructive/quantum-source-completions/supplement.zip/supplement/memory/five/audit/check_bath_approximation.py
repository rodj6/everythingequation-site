"""Independent critical-Weyl bath approximation certificate.

The Kraus matrices are rebuilt from the printed charge blocks, not imported
from a producer's source. SymPy verifies exact identities. Random-reference
NumPy diagnostics corroborate the two distinct sharp distances.
"""
from pathlib import Path
import json
import numpy as np
import sympy as S

OUT=Path(__file__).resolve().parent
R=S.Rational
w=-R(1,2)+S.I*S.sqrt(3)/2
t=S.sqrt(14)/21
Z=S.diag(1,w,S.expand(w*w));X=S.Matrix([[0,0,1],[1,0,0],[0,1,0]])
I=S.eye(3)
simple=lambda M:M.applyfunc(S.simplify)
fourier=[S.Matrix([S.expand(w**(k*p))/S.sqrt(3) for p in range(3)]) for k in range(3)]
weights=[R(1,9),R(1,3),R(5,9)]
first=[R(2,27),R(2,27),R(14,27)]
c0=t*(w-2)/9;c1=-t*(8+5*w)/9
cross=[c0,c1,c1]
K=[]
for k in range(3):
    B=S.zeros(3)
    B[1,:]=S.sqrt(first[k])*fourier[k].T
    B[2,:]=S.conjugate(cross[k])/S.sqrt(first[k])*fourier[(k+1)%3].T
    orbit=[simple(X**j*B*Z**(-j)) for j in range(3)]
    assert simple(sum([A.H*A for A in orbit],S.zeros(3)))==weights[k]*I
    for A in orbit:
        assert S.simplify(S.trace(A.H*A)-weights[k])==0
    K.append(orbit)
assert sum(weights)==1
# Vectorization is input index first and output index second.
def choi_vector(A):return S.Matrix([A[o,i] for i in range(3) for o in range(3)])
for j in range(3):
    for k in range(3):
        for ell in range(3):
            inner=S.simplify((choi_vector(K[k][j]).H*choi_vector(K[ell][j]))[0])
            assert inner==(weights[k] if k==ell else 0)
# Full declared output is pointer x final memory; bath copies pointer and k.
def isometry(selected,normalization):
    V=S.zeros(81,3)
    for k in selected:
        for j in range(3):
            for o in range(3):
                for i in range(3):
                    row=(3*j+o)*9+3*k+j
                    V[row,i]=K[k][j][o,i]/S.sqrt(normalization)
    return simple(V)
V=isometry([0,1,2],S.Integer(1))
assert simple(V.H*V)==I
result=[]
for selected in ([2],[1,2],[0,1,2]):
    p=sum(weights[k] for k in selected)
    W=isometry(selected,p)
    assert simple(W.H*W)==I
    assert simple(V.H*W)==S.sqrt(p)*I
    # Exact Choi support and TP identities imply both universal optima.
    result.append(dict(pure_bath_dimension=3*len(selected),retained_orbits=list(selected),
        retained_weight=str(p),reduced_half_diamond_exact=str(1-p),
        full_retained_half_diamond_exact=str(S.sqrt(1-p))))
# Arbitrary-reference pure inputs: full distance and overlap are fixed.
rng=np.random.default_rng(5272026)
Vn=np.array(V.evalf(),complex)
diagnostics=[]
for selected in ([2],[1,2]):
    p=float(sum(weights[k] for k in selected))
    Wn=np.array(isometry(selected,sum(weights[k] for k in selected)).evalf(),complex)
    worst=0.
    for rdim in (1,2,5):
        for _ in range(20):
            psi=rng.normal(size=(3,rdim))+1j*rng.normal(size=(3,rdim))
            psi/=np.linalg.norm(psi)
            target=Vn@psi;approx=Wn@psi
            overlap=np.vdot(target,approx)
            distance=np.sqrt(max(0.,1-abs(overlap)**2))
            worst=max(worst,abs(distance-np.sqrt(1-p)))
    assert worst<3e-14
    diagnostics.append(dict(bath_dimension=3*len(selected),arbitrary_reference_trials=60,
        largest_absolute_full_distance_error=worst))
data=dict(status='all independent bath approximation identities passed',
    exact_orbit_TP_identities=3,exact_Choi_orthogonality_identities=27,
    normalized_Choi_eigenvalues=['5/27 (multiplicity 3)','1/9 (multiplicity 3)','1/27 (multiplicity 3)'],
    sharp_resource_points=result,random_reference_diagnostics=diagnostics,
    reduced_scope='Memory plus registered classical pointer channel, arbitrary input and inert reference; purifying bath unread.',
    retained_scope='Pure fixed-blank Stinespring outputs, arbitrary input and inert reference; bath-only isometric identification between dimensions.',
    limits='No global passive-word-law memory/bath frontier; mixed initial baths, returning baths and controller side information require a different ledger.')
(OUT/'bath_approximation_results.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
