#!/usr/bin/env python3
"""Exact rational Bernstein/LDL certificate for the noisy-trine qutrit source.

Only Python's standard library and NumPy are required. All cone certificates
use Fraction arithmetic; no floating-point PSD assertion is used. Floating
approximations in the JSON are descriptive only.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
import math
import numpy as np

OUT = Path(__file__).resolve().parent
ZERO=Q(0); ONE=Q(1)

def zmat(n):
    return np.full((n,n),ZERO,dtype=object)

def eye(n):
    x=zmat(n)
    for i in range(n):x[i,i]=ONE
    return x

def gaussian(real,imag=None):
    return (real, zmat(len(real)) if imag is None else imag)

def scale(x,c):return (x[0]*c,x[1]*c)
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def tr(x):return (x[0].T,x[1].T)
def kron(x,y):
    return (np.kron(x[0],y[0])-np.kron(x[1],y[1]),
            np.kron(x[0],y[1])+np.kron(x[1],y[0]))

def total(terms,n=3):
    out=gaussian(zmat(n))
    for term in terms:out=add(out,term)
    return out

def frame():
    out=[]
    for a,b in [(0,1),(0,2),(1,2)]:
        r=zmat(3);r[a,b]=r[b,a]=ONE
        t=zmat(3);t[a,b]=-ONE;t[b,a]=ONE
        out.extend([gaussian(r),gaussian(zmat(3),t)])
    out.extend([gaussian(np.diag([ONE,-ONE,ZERO])),
                gaussian(np.diag([ONE,ONE,-Q(2)]))])
    return out

F=frame(); A=F[:2]; B=F[2:4]; C=[[F[4+2*m+n] for n in range(2)] for m in range(2)]
FD=[scale(f,Q(1,2) if k<7 else Q(1,6)) for k,f in enumerate(F)]
AD=FD[:2];BD=FD[2:4];CD=[[FD[4+2*m+n] for n in range(2)] for m in range(2)]
X=[(ONE,ZERO),(-Q(1,2),Q(1,2)),(-Q(1,2),-Q(1,2))]
G=(ONE,Q(3)); ID=gaussian(eye(3))
AA,BB,CC=Q(3,8),Q(3,4),Q(3,4)
END=Q(7,20)

def combination(basis,coords):
    return total([scale(f,c) for f,c in zip(basis,coords)])

def choi_power(j):
    """J_j(e) = sum_{k=0}^3 e^k J[k], unnormalized Choi convention."""
    bj=combination(B,X[j])
    adj=combination(AD,[G[m]*X[j][m] for m in range(2)])
    cvj=[combination(C[v],X[j]) for v in range(2)]
    cdj=[combination([CD[m][v] for m in range(2)],
                     [G[m]*X[j][m] for m in range(2)]) for v in range(2)]
    j0=scale(gaussian(eye(9)),Q(1,9))
    j1=total([scale(kron(ID,bj),BB/3),
              scale(kron(tr(adj),ID),-ONE/(9*AA))]+[
              scale(kron(tr(BD[v]),A[v]),AA/(3*BB)) for v in range(2)],9)
    j2=total([scale(kron(tr(adj),bj),-BB/(3*AA))]+[
              scale(kron(tr(BD[v]),cvj[v]),CC/(3*BB)) for v in range(2)]+[
              scale(kron(tr(cdj[v]),A[v]),-AA/(3*CC)) for v in range(2)],9)
    j3=total([scale(kron(tr(cdj[v]),cvj[v]),-Q(1,3)) for v in range(2)],9)
    return [j0,j1,j2,j3]

def state_power(a,b):
    return [scale(ID,Q(1,3)),
            scale(combination(B,X[b]),BB),
            scale(combination(A,X[a]),AA),
            scale(total([scale(C[m][n],X[a][m]*X[b][n])
                         for m in range(2) for n in range(2)]),CC)]

def bernstein(power):
    # sum e^l P_l = sum B_{k,3}(e/END) M_k on [0,END].
    return [total([scale(power[l],Q(math.comb(k,l),math.comb(3,l))*END**l)
                   for l in range(k+1)],len(power[0][0])) for k in range(4)]

def realify(x):
    return np.block([[x[0],-x[1]],[x[1],x[0]]])

def exact_ldl(matrix):
    n=len(matrix)
    assert np.array_equal(matrix,matrix.T)
    l=eye(n);d=[]
    for k in range(n):
        pivot=matrix[k,k]-sum((l[k,j]**2*d[j] for j in range(k)),ZERO)
        assert pivot>0, ('nonpositive exact LDL pivot',k,pivot)
        d.append(pivot)
        for i in range(k+1,n):
            l[i,k]=(matrix[i,k]-sum((l[i,j]*l[k,j]*d[j] for j in range(k)),ZERO))/pivot
    # Exact reconstruction independently checks arithmetic/indexing.
    for i in range(n):
        for j in range(n):
            assert matrix[i,j]==sum((l[i,k]*d[k]*l[j,k] for k in range(n)),ZERO)
    return d

def serialize_gaussian(x):
    return {'real':[[str(v) for v in row] for row in x[0]],
            'imaginary':[[str(v) for v in row] for row in x[1]]}

def pivot_summary(pivots):
    low=min(pivots)
    rounded=Q((low.numerator*10**8)//low.denominator,10**8)
    return {'positive':True,'minimum_pivot_exact':str(low),
            'minimum_pivot_decimal':float(low),
            'certified_simple_lower_bound':str(rounded),
            'pivots_exact':[str(x) for x in pivots]}

def apply_choi(j,x):
    # J=sum_pq |p><q| tensor Phi(|p><q|), so coefficients are X_pq.
    out=gaussian(zmat(3))
    for p in range(3):
        for q in range(3):
            block=(j[0][3*p:3*p+3,3*q:3*q+3],j[1][3*p:3*p+3,3*q:3*q+3])
            out=add(out,(x[0][p,q]*block[0]-x[1][p,q]*block[1],
                         x[0][p,q]*block[1]+x[1][p,q]*block[0]))
    return out

def same(x,y):
    return np.array_equal(x[0],y[0]) and np.array_equal(x[1],y[1])

def exact_dynamics_checks():
    js=[choi_power(j) for j in range(3)]
    checks=0
    # Full polynomial identity Phi_j(e)[sigma_ab(e)] = T_aj(e) sigma_bj(e).
    for a in range(3):
        for b in range(3):
            source=state_power(a,b)
            for j in range(3):
                target=state_power(b,j)
                cosine=sum((G[m]*X[a][m]*X[j][m] for m in range(2)),ZERO)
                for k in range(7):
                    lhs=total([apply_choi(js[j][l],source[k-l]) for l in range(4)
                               if 0<=k-l<4])
                    rhs=gaussian(zmat(3))
                    if k<4:rhs=add(rhs,scale(target[k],Q(1,3)))
                    if 0<=k-3<4:rhs=add(rhs,scale(target[k-3],-cosine/3))
                    assert same(lhs,rhs),(a,b,j,k)
                    checks+=1
    # Trace preservation and stationarity as exact polynomial identities.
    for k in range(4):
        totalj=total([js[j][k] for j in range(3)],9)
        partial=gaussian(zmat(3))
        for p in range(3):
            for q in range(3):
                partial[0][p,q]=sum((totalj[0][3*p+i,3*q+i] for i in range(3)),ZERO)
                partial[1][p,q]=sum((totalj[1][3*p+i,3*q+i] for i in range(3)),ZERO)
        assert same(partial,ID if k==0 else gaussian(zmat(3)))
        stationary=total([apply_choi(js[j][k],scale(ID,Q(1,3))) for j in range(3)])
        assert same(stationary,scale(ID,Q(1,3)) if k==0 else gaussian(zmat(3)))
        checks+=2
    return checks

def main():
    certificates={'parameter_end':str(END),'noise_lower':str(ONE-END**3),
                  'frame':'raw rational Gell-Mann X01,Y01,X02,Y02,X12,Y12,D3,D8',
                  'state_scalings':['3e^2/8','3e/4','3e^3/4'],
                  'choi':[],'states':[]}
    certificates['exact_polynomial_dynamics_identities']=exact_dynamics_checks()
    matrices={'choi_bernstein':[], 'state_bernstein':[]}
    for j in range(3):
        entry=[];mat_entry=[]
        for k,matrix in enumerate(bernstein(choi_power(j))):
            pivots=exact_ldl(realify(matrix))
            table_bound=[Q(1,9),Q(9,100),Q(3,50),Q(1,100)][k]
            assert min(pivots)>=table_bound if k==0 else min(pivots)>table_bound
            entry.append(pivot_summary(pivots))
            mat_entry.append(serialize_gaussian(matrix))
        certificates['choi'].append(entry)
        matrices['choi_bernstein'].append(mat_entry)
    for a in range(3):
        for b in range(3):
            entry=[];mat_entry=[]
            for matrix in bernstein(state_power(a,b)):
                pivots=exact_ldl(realify(matrix))
                assert min(pivots)>Q(1,10)
                entry.append(pivot_summary(pivots))
                mat_entry.append(serialize_gaussian(matrix))
            certificates['states'].append({'a':a,'b':b,'pivots':entry})
            matrices['state_bernstein'].append({'a':a,'b':b,'matrices':mat_entry})
    certificates['status']='all48Bernstein matrices positive definite by exact rational LDL'
    (OUT/'qutrit_certificate.json').write_text(json.dumps(certificates,indent=2)+'\n')
    (OUT/'qutrit_bernstein_matrices.json').write_text(json.dumps(matrices,indent=2)+'\n')
    print(json.dumps({k:v for k,v in certificates.items() if k not in ['choi','states']},indent=2))
    print('Choi pivots lower bounds by j, Bernstein index k:')
    for j,row in enumerate(certificates['choi']):
        print(j,[x['certified_simple_lower_bound'] for x in row])
    print('Minimum state pivot:',min(x['minimum_pivot_decimal'] for z in certificates['states'] for x in z['pivots']))

if __name__=='__main__':main()
