"""Exact non-coordinate-plane qutrit source certificate and word diagnostics.

SymPy and NumPy; no producer/prior research modules imported.
"""
from pathlib import Path
import itertools,json
import numpy as np
import sympy as s
OUT=Path(__file__).resolve().parent
R=s.Rational;w=(-1+s.I*s.sqrt(3))/2
clean=lambda A:A.applyfunc(lambda x:s.simplify(s.expand_complex(x)))
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]]);Z=s.diag(1,w,w*w)
a=R(2,3);t=R(9,50);r=R(1,10)
seed=s.Matrix([[0,0,0],[0,a,-t*w*w],[0,-t*w,1-a]])
seed_minor=s.simplify(a*(1-a)-t*t);assert seed_minor>0
q=a*(1-a);D=1-3*q
base_d0=q*(2*t-r)**2/(36*t*t)-(D*r*r-r*t+t*t)/(9*D)
base_d1=q*(2*t-r)*(t+r)/(18*t*t)-(D*r*r+2*r*t+4*t*t)/(36*D)
assert base_d0>0 and base_d1>0 and 2*t>r
U=s.Matrix([[R(99,101),-R(20,101),0],[R(20,101),R(99,101),0],[0,0,1]])
Us=[U,s.eye(3),s.eye(3)]
assert clean(U.H*U)==s.eye(3)
base=[[clean(Z**i*X**j*seed*(Z**i*X**j).H)for j in range(3)]for i in range(3)]
states=[[clean(Us[j]*base[i][j]*Us[j].H)for j in range(3)]for i in range(3)]
vec=lambda A:s.Matrix([A[p,q]for p in range(3)for q in range(3)])
E=s.Matrix.hstack(*[vec(states[i][j])for i in range(3)for j in range(3)])
Einv=E.inv();basisdet=s.simplify(E.det());assert basisdet!=0
T=s.Matrix(3,3,lambda i,j:(1-r)/3 if i==j else (1+r/2)/3)
M=[];J=[];counts={'reset_entries':0,'TP_entries':0,'stationary_entries':0,'strict_CP_principal_minors':0}
minors=[]
for j in range(3):
 O=s.Matrix.hstack(*[T[i,j]*vec(states[b][j])for i in range(3)for b in range(3)])
 MM=clean(O*Einv);M.append(MM)
 for i,b in itertools.product(range(3),repeat=2):
  assert clean(MM*vec(states[i][b])-T[i,j]*vec(states[b][j]))==s.zeros(9,1)
  counts['reset_entries']+=9
 JJ=s.Matrix(9,9,lambda p,q:MM[3*(p%3)+(q%3),3*(p//3)+(q//3)])
 assert clean(JJ-JJ.H)==s.zeros(9)
 JJ=clean(JJ);J.append(JJ)
 # Undo only output rotation: resulting support omits coordinate j.
 W=s.kronecker_product(s.eye(3),Us[j].H)
 unrotated=clean(W*JJ*W.H)
 keep=[3*p+o for p in range(3)for o in range(3)if o!=j]
 omitted=[3*p+j for p in range(3)]
 assert all(unrotated[p,q]==0 for p in omitted for q in range(9))
 block=unrotated.extract(keep,keep)
 row=[]
 for k in range(1,7):
  d=s.simplify(block[:k,:k].det());assert d.is_Rational and d>0,(j,k,d)
  row.append(str(d));counts['strict_CP_principal_minors']+=1
 minors.append(row)
for p,q in itertools.product(range(3),repeat=2):
 tr=sum(sum(JJ[3*p+o,3*q+o]for o in range(3))for JJ in J)
 assert s.simplify(tr-(1 if p==q else 0))==0;counts['TP_entries']+=1
stationary=clean(sum((z for row in states for z in row),s.zeros(3))/9)
act=lambda j,A:s.Matrix(3,3,list(M[j]*vec(A)))
assert clean(sum((act(j,stationary)for j in range(3)),s.zeros(3))-stationary)==s.zeros(3)
counts['stationary_entries']+=9
for j in range(3):
 assert s.simplify(s.trace(act(j,stationary))-R(1,3))==0
 for k in range(3):
  assert clean(act(k,act(j,stationary))-states[j][k]/9)==s.zeros(3)
  counts['stationary_entries']+=9
P0=s.diag(1,0,0)
witness=s.simplify(s.trace(P0*states[0][0]));assert witness==R(800,30603)
assert s.trace(P0*base[0][0])==0
# All one-symbol effect matrices positive definite by Sylvester's criterion.
effects=[];effect_minors=[]
for JJ in J:
 EE=clean(s.Matrix(3,3,lambda p,q:sum(JJ[3*q+o,3*p+o]for o in range(3))))
 effects.append(EE)
 row=[]
 for k in range(1,4):
  d=s.simplify(EE[:k,:k].det());assert d>0;row.append(str(d))
 effect_minors.append(row)
# Independent numerical enumeration of all words through length 7.
Mn=[np.array(z.evalf(),complex)for z in M];Sn=[[np.array(z.evalf(),complex)for z in row]for row in states]
Tn=np.array(T,float);tau=np.array(stationary.evalf(),complex)
front=[((),tau,1.)];checks=0;err=0.
for n in range(1,8):
 nxt=[]
 for wd,rho,prob in front:
  for j in range(3):
   out=(Mn[j]@rho.reshape(-1)).reshape(3,3);word=wd+(j,)
   pred=prob*(1/3 if n<3 else Tn[wd[-2],j])
   err=max(err,float(abs(np.trace(out)-pred)));assert abs(np.trace(out)-pred)<1e-11
   if n>=2:assert np.max(abs(out-pred*Sn[word[-2]][word[-1]]))<1e-11
   checks+=1;nxt.append((word,out,pred))
 front=nxt
report={'status':'all exact non-Weyl CP/reset/stationary certificates and word checks passed',
 'parameters':{'a':'2/3','t':'9/50','r':'1/10','lambda':'9/10','rotation_cos':'99/101','rotation_sin':'20/101'},
 'strict_CP_leading_principal_minors':minors,'basis_determinant':str(basisdet),'exact_checks':counts,
 'parent_positive_charge_block_determinants':[str(base_d0),str(base_d1),str(base_d1)],
 'seed_rank_two_principal_minor':str(seed_minor),
 'strict_one_symbol_effect_principal_minors':effect_minors,
 'source_intervention_probability':str(witness),'baseline_probability':'0','plane_normal_overlap':'20/101',
 'branch_Choi_ranks':[6,6,6],'one_step_record_rank':18,'complete_horizon_rank':'6*3**n for n>=2',
 'numeric_word_checks':checks,'max_word_probability_error':err,
 'scope':'Exact full passive law, different normalized pair encoding; no memory/noise/resource improvement claimed.'}
(OUT/'nonweyl_results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
