# Mathematical audit of the v1.9 manuscript

## Verdict and scope

All seven propositions survive direct analytical rederivation under their stated premises. The endorsement inequality, finite joint-law transport bound and two-arm expected-score bound are correct. The two-channel extension is sound in its expressly decoupled specialization. No foundational Shadow claim or mathematical result needs replacement.

Two small repairs improve mathematical precision in the proposed experiment: replace a monotonic-sounding prediction by convergence language, and require disturbance means to be checked within conditional cue strata. Two further wording refinements clarify an already-correct comparison theorem and the source's acquisition-history premise. These do not change the argument or theorem conclusions.

The audit covers `main.tex`'s abstract; `sections/math.tex`, `identification_model.tex`, `agency_transport.tex`, `rebound_experiment.tex`, `introduction.tex`, `foundations.tex`, `conclusion.tex`, `human_recursive_loop.tex` and `scope.tex`; and the off-switch mathematical comparison in `current_alignment.tex`. All displayed equation locations were inventoried. Derivations below were performed directly from the equations. Previous scripts and agreement among model outputs were not used as validation. A fresh exact-arithmetic script checks selected constructions and assumption failures, separately from these proofs.

## Exact issues and smallest repairs

### M1. A vanishing identification limit is convergence, not monotonic decrease

**Passage:** `sections/rebound_experiment.tex`, paragraph beginning “The discriminating signature”: “A decrease of estimated identification towards zero predicts a decreasing contribution subject to Proposition ...'s moment bounds.”

Proposition 6 proves that the expectation tends to zero; it does not prove monotonic decrease. Even a deterministic decreasing sequence `ι_t=1/(t+1)` with salience alternating between `1` and `10` has uniformly bounded first and second moments, but its first action magnitudes are `1, 5, 1/3, 5/2`. The limit is zero despite intervening increases.

**Smallest replacement:**

```latex
A decrease of estimated identification towards zero predicts a contribution
tending to zero, subject to Proposition~\ref{prop:identification-limit}'s
moment bounds.
```

**Theorem status:** Proposition 6 remains correct without modification.

### M2. Conditional cue-stratum claims need conditional disturbance means

**Passage:** `sections/rebound_experiment.tex`, paragraph beginning “Randomize”: “Predeclare matched cue strata with nonzero conditional salience and examine signed action bias within them.” The preceding headline preparation supplies zero-mean execution disturbance without specifying whether this holds within the tested strata.

Zero unconditional execution mean does not ensure zero mean after conditioning on a cue. Let `ε_t` be a fair sign and let the cue equal that sign. At `ι=k=0`, unconditional expected bias is zero, but within the positive-cue stratum expected bias equals one. Within-step cue/execution correlation is allowed by Proposition 4. A conditional bias therefore cannot automatically be attributed to identification.

**Smallest addition immediately after the cited sentence:**

```latex
Verify execution and estimation means within each stratum, or use the
corresponding conditional means in the general action-bias formula.
```

For the exact Proposition 7 comparison, define cue strata exogenously, preserve the stipulated source means through the intervention, and establish zero execution mean within those strata. Conditioning on the realized trajectory or selecting lapse from its history requires a separate analysis of selected-state and disturbance means. The existing independently randomized schedule is appropriate.

**Theorem status:** Propositions 4, 5 and 7 remain correct. This repairs an experimental interpretation, not a theorem.

### M3. Acquisition-history indistinguishability: make the future-law premise explicit

**Passage:** `sections/foundations.tex`, paragraph beginning “Transparent persuasion”: “A current mediation certificate cannot recover an unobserved history with the same present law.”

As a claim about a current certificate, this is sound. If intended to cover all subsequent tests, the source's Proposition 8.1 also requires the same future boundary law conditional on complete present state, and the same admitted operations/interventions. Present-state equality alone does not equate different future environments or changed laws.

**Optional precise replacement:**

```latex
When complete present-state laws and admitted future joint laws agree, no
subsequent finite operational test can recover the erased history.
```

The source explicitly permits provenance records or expanded historical interventions to change the premises. The manuscript already explains the need for longitudinal records. This refinement prevents a broader reading; it does not overturn the stated separation of present mediation and historical acquisition.

### M4. Proposition 7's positive parameter belongs to the identified arm

**Passage:** `sections/identification_model.tex`, Proposition 7 opens with `0<ι≤1`, then describes the comparison arm with `ι=k=0`.

The intended comparative statement and proof are correct. A literal reader should be told that the positive `ι` is the identified arm's parameter, not a shared value for both arms.

**Optional minimal change:** replace “Suppose ... `0<ι≤1`” by “Let `0<ι≤1` denote the identified system's parameter, and suppose ...” while retaining all other premises.

## Direct rederivation of the seven propositions

### Proposition 1: state invariance

For fixed `x,q,z,r,e,x'`, action-independence of `E` and `U` permits their factors to be taken outside the action sum. Normalization gives `Σ_a A_i(a|x,q,z,r)=1`, so both arms have the identical joint retained-variable kernel `GR EU`. A common initial law and a common fixed or state-conditioned query rule then imply identical finite trajectory laws by induction. No equality of action laws is needed. If feedback, update or subsequent query choice depends on the displayed action, the premises fail; the manuscript's binary memory counterexample correctly illustrates that failure.

**Verdict:** correct. This does not assert that every output restriction leaves development unchanged.

### Proposition 2: observational nonidentifiability

At a common public history, the common adaptive query protocol supplies the same next-query distribution. Multiplying by equal observation kernels gives equal one-step history extensions. Induction yields `P_0=P_1` for every admitted finite transcript. With equal priors, a randomized transcript-only rule `d(h)` has success `(1/2)∫(1−d)dP_0+(1/2)∫d dP_1=1/2`. New inspection or intervention capabilities can enlarge the protocol and invalidate its equal-kernel premise.

**Verdict:** correct. Neither equal means nor similar self-reports are its premise; complete admitted observable laws must agree.

### Proposition 3: scalar control

Substitution gives `x_{t+1}=(α−k)x_t+d_t`. Repeated substitution yields `x_t=c^t x_0+Σ_{j<t}c^{t−1−j}d_j`. The unforced origin is globally asymptotically stable exactly for `|c|<1`: contraction gives convergence and Lyapunov stability, while any nonzero initial value fails to converge when `|c|≥1`. At `c=−1`, an unforced trajectory alternates without decay; it need not grow.

Taking absolute values and summing the geometric series gives the stated bounded-forcing inequality. Under the stipulated temporal, initial-state and component independence, `d_t=ξ_t−kν_t` is independent of `x_t` and has variance `σ_ξ²+k²σ_ν²`. Thus `Var x_t=c^{2t}Var x_0+vΣ_{j<t}c^{2j}`, and the limit is `v/(1−c²)`.

The numerical examples are consistent: `(11/10)^20`, `(7/10)^20` and `(−6/5)^20` round to the reported values. With noise standard deviations `1/100` and `1/5`, the reported variances round correctly. Constant estimate offset gives equilibrium `−kδ/(1−c)`, including `−4/15` for the stated example.

**Verdict:** correct; the noise-amplification example is a possibility, not a universal monotone relation between gain and error.

### Proposition 4: identification moments and estimation error

Write `h=ι−k` and `d_t=βε_t+γu_t+ξ_t−βkν_t`. Substitution gives `c=α+βh`. The noise vectors are independent across time and of the finite-second-moment initial state, so current noise is independent of `s_t`, which is a function of initial state and earlier vectors. Iteration yields the displayed mean and variance formulas. Independence between components is unnecessary for these formulas: `v_d` is the variance of the entire linear combination.

More explicitly, if `Z_t=(ε_t,u_t,ξ_t,ν_t)` and `b=(β,γ,1,−βk)`, then `v_d=b Cov(Z_t)b^T`. This includes every within-step covariance. The independent-components specialization is precisely `β²Var ε+γ²Var u+Var ξ+β²k²Var ν`.

For action, `a_t=h s_t+ε_t−kν_t`. Independence of current vector and state gives `Var a_t=h²Var s_t+Var ε_t+k²Var ν_t−2k Cov(ε_t,ν_t)`. Its expectation is `h E s_t+Eε_t−kEν_t`. Consequently stable salience has mean `[m+βEε−βkEν]/(1−c)`, not generally `m/(1−c)` without the specified zero-mean conditions.

**Verdict:** correct. Temporally correlated innovations or correlation with the initial state require extra covariance terms; these possibilities are excluded by the proposition, not overlooked by its proof.

### Proposition 5: zero-mean post-lapse forcing

After fixed-time lapse, `a_t=ιs_t+ε_t` and `s_{t+1}=c_L s_t+βε_t+γu_t+ξ_t`. The stated zero means imply `E s_{t+1}=c_L E s_t`; independence across future times is unnecessary for this mean calculation. Iteration gives `c_L^n E s_τ` and the stated action mean. Its magnitude grows for `|c_L|>1`, remains constant for `|c_L|=1`, and decays for `|c_L|<1`, provided the explicitly nonzero initial mean and positive identification hold.

The separate nonzero-mean paragraph correctly adds `(βμ_ε+μ_g)Σc_L^j` to salience and `μ_ε` to action. Its separate variance claim appropriately adds finite-second-moment and across-time/initial-state independence premises. At `c_L=−1`, independent positive innovation variance gives linear variance growth even though the zero-forcing mean only alternates.

**Verdict:** correct. The zero-source/residual case and the persistent-source case have different premises and do not conflict.

### Proposition 6: exact zero versus a limit

With no suppressive controller, `a_t=ι_t s_t+ε_t`. Zero-mean execution implies `|E a_t|≤ι_t E|s_t|`. The uniform first-moment bound therefore gives convergence of the expectation to zero. The uniform second-moment bound gives `E(ι_t s_t)²≤ι_t² sup_j E s_j²→0`, without any independence requirement. Exact `ι=0` removes the authority contribution pointwise; execution disturbance remains. The theorem does not claim that the entire noisy action converges to zero in mean square. The counterexample `s_t=1/ι_t` correctly explains why the moment bounds matter.

**Verdict:** correct. See M1 for the convergence-versus-monotonicity wording.

### Proposition 7: persistent generation

With perfect estimation and exact cancellation, `a_t=ε_t`; the exact de-identified/no-controller arm has the same equation. Under zero-mean execution both have mean recurrence `μ_{t+1}=αμ_t+m`. Preparation at `M_α=m/(1−α)` maintains that nonzero mean. Full distributional stationarity and noise independence are unnecessary.

After lapse, `μ_{τ+n}=c_L^n M_α+mΣ_{j<n}c_L^j`, and action mean is `ιμ_{τ+n}`. At `n=0`, the mean action is `ιM_α≠0`. For `c_L≠1`, write the mean as `M_L+c_L^n(M_α−M_L)`, with `M_L=m/(1−c_L)` and `M_α−M_L=−mβι/[(1−α)(1−c_L)]`. If `|c_L|>1`, then `c_L−α=βι≠0` because `|α|<1`; hence the growing-mode coefficient is nonzero. Its magnitude diverges, eventually alternating for `c_L<−1`.

At `c_L=1`, direct summation gives `M_α+nm`. At `c_L=−1`, it gives `m/2+(−1)^n(M_α−m/2)`, a bounded mean two-cycle. For stable `c_L`, the fixed-point difference is `mβι/[(1−c_L)(1−α)]`. The manuscript's signed comparison and nonnegative-coefficient monotonicity qualification are correct for the prepared mean. Arbitrary finite-mean preparation has error `α^τ(μ_0−M_α)`, so finite settling approximates rather than establishes exact preparation.

**Verdict:** correct, with optional notation clarification M4. “No residual assumption” means no surviving unforced remainder is needed; the ongoing source deliberately maintains nonzero live mean salience. Equality of content here is equality of the nominated mean, not equality of all phenomenal content. The manuscript correctly reserves pathwise equality for matched initial state and all driving realizations under perfect estimation.

## Two channels, calibration and acquisition routes

The self/goal equations are two copies of the scalar system. In the absence of cross-channel feedback, each proposition applies with its own indexed coefficients and its own premise set. Marginal mean results do not require independent channels. Total expected bias is additive. Total variance is `Var a_s+Var a_g+2Cov(a_s,a_g)`, so opposing means or correlated disturbances can conceal channel-specific bias. The v1.9 exact-zero statement correctly requires `ι_j=k_j=0` and zero execution means.

Cross-feedback requires the full transition matrix. For example, diagonal coefficients `1/2` do not make a matrix with off-diagonal entries `3/4` stable: the symmetric mode has eigenvalue `5/4`. The manuscript explicitly warns against separate scalar tests in that case.

With perfect estimation, ordinary pre-lapse state/action equations depend on `ι−k`, so exact cancellation and exact de-identification can be behaviorally identical before the selective lapse. Separate identification of the two parameters therefore needs an independently nominated, calibrated salience measurement and a validated intervention on the corrective route. A deadline can also change other parameters; v1.9 treats it as a candidate intervention and requires measurement of its effects. Merely observing lower bias does not establish lower identification.

Equal identification, initial laws and admitted transition/observation laws do not reveal whether acquisition was through training or cultivation. This follows from the same finite-law induction as Proposition 2 and the agency source's Proposition 8.1. New inspection can expand the protocol. Neither matching a functional coefficient nor successful transfer alone provides physical/phenomenal certification; Scope correctly keeps that obligation separate.

## Imported inequalities and physical transport

For disjoint endorsed sets `N_0,N_1`, `P_0(N_1)≤ε_0` and `P_1(N_1)=1−ε_1`, so testing event `N_1` gives `TV(P_0,P_1)≥max(0,1−ε_0−ε_1)`. If `P_i=H_i C` with a common Markov kernel, total variation contracts, giving the upper bound. High contrast alone permits systematic inversion. The fresh probe and common-kernel obligations are correctly retained.

For path transport, couple the initial joint laws and then each corresponding joint record/successor kernel while histories agree. Before the first mismatch, the adaptive controller selects matching operations. The probability of any mismatch is at most the initial error plus the sum of uniform stage errors, capped at one. The coupling inequality bounds trace total variation by that probability. For a common transported score in `[0,1]`, the expectation changes by at most the same total-variation bound; applying it to each side of an expected-score gap gives the displayed subtraction of the two arm errors. A difference of TV contrasts has different bookkeeping and cannot automatically use this two-score formula.

The original state-marginal abstraction condition alone is weaker; emitted records can differ even with identical endpoints. The manuscript expressly requires the stronger joint-law, intervention, timing, resource, access, initial-correlation and stopping contract. Endpoint approximation does not establish an exact SPC-2 certificate. The physical/phenomenal distinction is retained.

## Foundations and remaining mathematical displays

The original agency source supports the foundations' bounded-revision statement only under its finite composable model, charged continuation-composition policy class, stable contexts and leaf installation support condition. The manuscript states this conditional envelope and does not identify mere existence of a good amendment with access to it. The common-positive-support obstruction concerns finite conditional probability support, not arbitrary topological support. Its risk frontiers remain tied to the independent-noise and inquiry-allocation examples.

The reversible SWAP example is correct: `(x,g)→(g,x)` sets the plant target while retaining its previous state in the ready receiver. It neither erases the unknown input nor shows that receiver/actuator resources are irrelevant. The stated contrast with identity-only actuation is correct.

The complete-carrier/state-versus-object distinction matches the development source. Installed programs, memories and valuations can change state within a fixed complete predictive object; different laws/contracts or justified different realizations are required for a claim about changing the whole object. Native recoding must transport its actual intervention algebra; output agreement alone does not supply that stronger realization.

The serial deadline inequality is a necessary budget condition for the declared stages, not a proof of an RCO speed improvement. The reciprocal body/interpretation equations are a schematic coupling with no unstated stability claim. The association update is a convex combination for `0≤η≤1`; no general statistical-consistency or causal-transfer theorem is asserted. The A0--A3 interpretation and current-model admission remain constitutive/application claims, not consequences of these control equations.

The off-switch paragraph matches the primary theorem: rational deferral obtains `E max(U,0)`, compared with acting at `E U` and shutdown at zero. Its advantage is `min(E U^+, E U^−)≥0`, strictly positive when both positive and negative utility have positive probability under the game's integrable-utility model. It is a game-theoretic result, not a physical certification or universal interruption rule.

## Primary-source dependencies checked

- `Bounded Agency and Reflective Freedom`, supplied version 2.0: §2.5/Proposition 2.3 and Eq.2.2 for joint transport; §3.2/Proposition 3.2 for information/installed contrast/endorsement; Lemma 4.1 and Theorem 4.2 for bounded preservation; Proposition 5.1 for finite full-support obstruction; Proposition 8.1 and the following acquisition-history discussion.
- `Bounded Agency and Reversible Control`, supplied revised version 2.0: §1.1 for blind SWAP and receiver/actuation distinctions; §13.2/Theorem 13.1 for uniform half-diamond instrument error, correlated memory and path-score transfer.
- `Relational Development`, supplied editable text: “State, law, predictive history and capability” and “Why realization cannot be inferred from service behavior” for complete-carrier and intervention-algebra distinctions.
- `Relational Boundaries`, supplied editable text: §“Relational encapsulation through a causal interface” and its approximate joint-instrument transfer result for timing, initial correlations, resource ownership and matching comparison classes.
- `The Off-Switch Game`, primary IJCAI 2017 text, §3/Theorem 1 for rational deferral and the strict two-sided-utility condition.

## Fresh computations

`independent_math_checks.py` passed **941 exact-fraction checks**. The constructions use a fresh three-factor correlated innovation law rather than the earlier rank-one examples; direct state/action enumeration matches the stated moment formulas. Signed forced recurrences cover stable coefficients, both unit boundaries and unstable coefficients. A grid of common binary installation kernels checks the endorsement/contraction inequalities. An adaptive two-stage transcript checks finite summed-error transport. Explicit counterexamples illustrate temporal-correlation failure of an independence-based variance formula, conditional execution bias after cue stratification, and nonmonotone action under a monotone vanishing identification sequence.

These checks inspect formulas and assumptions. They do not prove the general theorems, establish device realization, constitute model experiments or validate artificial consciousness/RCO. The analytical arguments above are the basis of the audit verdict.
