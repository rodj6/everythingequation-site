"""Fresh finite arithmetic for the v1.9 mathematical audit.

The proofs are in audit.md. These constructions inspect edge cases and
assumption failures; they are not human/model experiments or theorem proofs.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json

checks = []
observations = {}


def require(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append(name)


def mean_var(law):
    mu = sum((p*x for x,p in law), Q(0))
    return mu, sum((p*(x-mu)**2 for x,p in law), Q(0))


def tv(p,q):
    return sum((abs(a-b) for a,b in zip(p,q)),Q(0))/2


# Richer within-step covariance: four innovations are linear combinations
# of three independent signs; successive joint draws remain independent.
mu = (Q(1,7),Q(-1,5),Q(2,9),Q(3,8))  # epsilon, xi, nu, u
loading = ((Q(1,3),Q(1,7),Q(-1,4)),
           (Q(-1,5),Q(1,2),Q(1,6)),
           (Q(1,8),Q(-1,3),Q(2,5)),
           (Q(1,4),Q(2,7),Q(1,9)))
noise = []
for signs in product((-1,1),repeat=3):
    noise.append(tuple(mu[i]+sum((loading[i][j]*signs[j] for j in range(3)),Q(0))
                       for i in range(4)))
alpha,beta,gamma,iota,k = Q(-2,5),Q(3,4),Q(-1,3),Q(2,3),Q(5,6)
c = alpha+beta*(iota-k)
d_values = [beta*e+x-beta*k*v+gamma*u for e,x,v,u in noise]
d_mu,d_var = mean_var([(d,Q(1,8)) for d in d_values])
action_noise = [-k*v+e for e,x,v,u in noise]
an_mu,an_var = mean_var([(a,Q(1,8)) for a in action_noise])
law = [(Q(-2),Q(1,5)),(Q(1),Q(1,2)),(Q(3),Q(3,10))]
initial_mu,initial_var = mean_var(law)
for t in range(4):
    ms,vs = mean_var(law)
    require(f'correlated innovation salience mean t={t}',ms,
            c**t*initial_mu+d_mu*sum((c**j for j in range(t)),Q(0)))
    require(f'correlated innovation salience variance t={t}',vs,
            c**(2*t)*initial_var+d_var*sum((c**(2*j) for j in range(t)),Q(0)))
    actions,next_law = [],[]
    for s,p in law:
        for e,x,v,u in noise:
            a = (iota-k)*s-k*v+e
            actions.append((a,p/8))
            next_law.append((alpha*s+beta*a+gamma*u+x,p/8))
    ma,va = mean_var(actions)
    require(f'correlated innovation action mean t={t}',ma,(iota-k)*ms+an_mu)
    require(f'correlated innovation action variance t={t}',va,(iota-k)**2*vs+an_var)
    law = next_law

# Exact cancellation, stationary preparation, and every lapse boundary.
for alpha in (Q(-3,5),Q(2,5)):
    for m in (Q(-2,7),Q(3,8)):
        M = m/(1-alpha)
        require(f'preparation invariant alpha={alpha} m={m}',alpha*M+m,M)
        for cL in (Q(-7,5),Q(-1),Q(-1,3),Q(0),Q(3,4),Q(1),Q(6,5)):
            current = M
            for n in range(8):
                series = cL**n*M+m*sum((cL**j for j in range(n)),Q(0))
                require(f'lapse recurrence alpha={alpha} m={m} cL={cL} n={n}',current,series)
                if cL == -1:
                    require(f'negative boundary alpha={alpha} m={m} n={n}',current,
                            m/2+(-1)**n*(M-m/2))
                elif cL == 1:
                    require(f'positive boundary alpha={alpha} m={m} n={n}',current,M+n*m)
                current = cL*current+m

# Endorsement and Markov contraction across a grid of binary kernels.
grid = (Q(0),Q(1,4),Q(1,2),Q(3,4),Q(1))
for h0,h1,r0,r1 in product(grid,repeat=4):
    H0,H1 = (h0,1-h0),(h1,1-h1)
    P0 = (h0*r0+(1-h0)*r1, h0*(1-r0)+(1-h0)*(1-r1))
    P1 = (h1*r0+(1-h1)*r1, h1*(1-r0)+(1-h1)*(1-r1))
    error0,error1 = P0[1],P1[0]
    assert max(Q(0),1-error0-error1) <= tv(P0,P1) <= tv(H0,H1)
    checks.append(f'endorsement and contraction grid {h0},{h1},{r0},{r1}')

# An adaptive transcript retains its early records even with identical
# terminal states. Uniform stage errors give the declared finite sum bound.
p1 = Q(1,10)
p2_by_action = {0:Q(1,5),1:Q(1,20)}
paths = []
for y1,y2 in product((0,1),repeat=2):
    action = y1
    p2 = p2_by_action[action]
    probability = (p1 if y1 else 1-p1)*(p2 if y2 else 1-p2)
    paths.append(((y1,action,y2),probability))
path_tv = 1-dict(paths)[(0,0,0)]
require('adaptive path total variation',path_tv,Q(7,25))
assert path_tv <= p1+max(p2_by_action.values())
checks.append('adaptive path variation bounded by summed uniform errors')
require('identical endpoint can conceal different record law',tv((Q(1),Q(0)),(Q(0),Q(1))),Q(1))

# Useful assumption-failure counterexamples, not errors in the theorems.
independent_variance = Q(1)+Q(1,2)**2
shared_variance = (Q(1)+Q(1,2))**2
require('temporally shared innovation variance',shared_variance,Q(9,4))
assert shared_variance != independent_variance
observations['temporal_correlation'] = {'actual_variance':str(shared_variance),
                                         'independent_formula':str(independent_variance)}

# At zero identification and zero gain, execution noise alone supplies a
# conditional bias when strata are correlated with that noise.
eps_and_cue = [(-1,-1,Q(1,2)),(1,1,Q(1,2))]
overall_eps = sum((Q(e)*p for e,u,p in eps_and_cue),Q(0))
positive_mass = sum((p for e,u,p in eps_and_cue if u>0),Q(0))
conditional_eps = sum((Q(e)*p for e,u,p in eps_and_cue if u>0),Q(0))/positive_mass
require('unconditional execution mean',overall_eps,Q(0))
require('positive cue stratum execution mean',conditional_eps,Q(1))
observations['conditional_stratum'] = {'overall_execution_mean':str(overall_eps),
                                      'positive_stratum_mean':str(conditional_eps)}

# A deterministic monotone identification sequence can give nonmonotone
# action magnitudes despite the bounded-moment limiting theorem.
saliences = [Q(1) if t%2==0 else Q(10) for t in range(8)]
identifications = [Q(1,t+1) for t in range(8)]
biases = [i*s for i,s in zip(identifications,saliences)]
assert identifications[1] < identifications[0] and biases[1] > biases[0]
checks.append('limiting zero does not guarantee monotone decrease')
observations['nonmonotone_limit'] = {'first_biases':[str(a) for a in biases[:4]],
                                    'uniform_salience_bound':'10'}

# A current observation of iota-k cannot identify its two mechanisms.
require('cancellation and de-identification share controlled authority coefficient',
        Q(3,4)-Q(3,4),Q(0)-Q(0))

result = {'status':'passed','arithmetic':'exact fractions','check_count':len(checks),
          'scope':'Fresh constructed arithmetic, not theorem proof or measured experiments.',
          'counterexample_observations':observations,'checks':checks}
Path(__file__).with_name('independent_math_check_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('status','arithmetic','check_count','scope')},indent=2))
