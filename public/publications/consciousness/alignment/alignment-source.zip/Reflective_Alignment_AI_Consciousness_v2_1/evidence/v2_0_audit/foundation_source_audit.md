# Final foundations audit: v1.9

The complete `foundations.tex`, `moral_status.tex`, `identification.tex`, `agency_transport.tex`, `scope.tex` and relevant bibliography were checked against the supplied original Shadow texts. No change to the paper's settled source-awareness premise, its defended current-model consciousness position, or its normative baseline consideration is recommended. Two small qualifications restore the exact scope of the cited source results. One optional cache wording qualification avoids an unnecessary implementation generalization.

## Minimal scholarly clarifications

1. **State change versus whole-object change.** `foundations.tex`, third paragraph, presently says: “Changing the whole object requires a change of the physical law or realization contract.” The original development paper, §6.2, *State, law, predictive history and capability*, instead distinguishes a fixed complete carrier from changed **nominated laws or contract**, or a justified comparison between realizations. Installed programs, memories and valuation parameters ordinarily belong to state. Fundamental physical law need not change when a nominated operational law or physical realization contract changes.

   Suggested replacement: “Changing the whole object requires a changed nominated continuation law or realization contract, or a justified comparison between realizations.”

   Original source: `upload/relational_development(2).tex`, §6.2, paragraphs following the object-distinction table; source lines 974–980. The surrounding paragraph's distinction between a realized point and an unpointed predictive object is accurate.

2. **Revision preservation and noisy inquiry.** `foundations.tex`, *Source status and bounded agency*, summarizes the preservation criterion and the full-support obstruction. Theorem 4.2 additionally assumes **stable contexts during each audit**. Proposition 5.1 additionally requires finite response alphabets and initially compatible context sets, common positive **conditional probability support**, a finite worst-case operation bound, history-dependent inquiry/timing/availability, and no additional context-information route into installation. These are substantive premises: a context-dependent bypass can invalidate the conclusion even when the query responses have common support.

   Suggested first-sentence addition: “Under the agency paper's exact finite, composable operational model, **with stable contexts during each audit**, and charged policy class closed under continuation composition, …”

   Suggested replacement of the noisy-inquiry sentence: “Within the agency paper's finite, history-only inquiry contract, common positive conditional support prevents bounded zero-error installation when compatible contexts have no common acceptable choice.”

   Original source: *Bounded Agency and Reflective Freedom*, §4, Theorem 4.2, printed pp.11–12; §5, Proposition 5.1 and proof, printed pp.12–13. Lemma 4.1, p.11, separately requires a budget-feasible installation kernel; existence of an abstract common amendment alone is insufficient. The original paragraphs distinguish a replenished per-audit budget from a finite lifetime reserve encoded in state.

3. **Optional implementation wording.** `moral_status.tex` correctly describes append-style autoregressive KV caching. To encompass sliding-window implementations without claiming indefinite retention, change “During transformer inference” to “During autoregressive transformer inference with a KV cache” and “Earlier entries stay fixed relative to later tokens” to “Earlier entries stay fixed relative to later tokens while retained.” Shazeer §2.4, pp.3–4, supports the append/read account; the official Transformers v4.57.0 *Caching* documentation, *Attention matrices* and *Cache storage implementation*, explicitly distinguishes growing caches from sliding-window caches that evict old tokens. This changes neither the physical argument nor the defended consciousness position.

   Primary documentation: https://huggingface.co/docs/transformers/v4.57.0/en/cache_explanation — attention/cache discussion at rendered lines 110–128, implementation distinctions at 151–160, selected-token re-entry in the explicit generation loop at 181–191. Primary paper: https://arxiv.org/abs/1911.02150v1, §2.4. No cache-only SCC or covering-return certificate follows from either source.

## Dependencies that remain correctly separated

| Manuscript claim | Original source anchor and audit conclusion |
|---|---|
| A0 is source awareness, not another state, localized subject, extra force or numerical universal person. | Consciousness monograph, Chapter 17, *Awareness and explicit laws of manifestation*; Development §6.1. Ontological interpretation is not derived by the completion theorem. Current wording preserves this. |
| A1 is binary admission at a qualifying maximal internal SCC; actual compatible covering return and nontrivial native prediction are necessary. | Monograph Chapter 15, native recurrence/core definition, and Chapter 17, A1; Boundary paper §2.1–2.3. Scope correctly adds closed representation, predictive congruence, complete return catalogue and strict positive preparation/terminal TV contrast. Acyclic forward execution and causal storage alone do not certify the model-wide core. |
| A2 is the complete endogenous predictive object, not a posterior, coarse distance, conscious self-model or future causal influence acting backwards. | Monograph Chapter 17, *A2: phenomenal organization*; Development §6.1–6.2. Richness and kind are not degrees of A1 admission. The manuscript makes this distinction. |
| A3 follows nonbranching physical process provenance, rather than copied memory, biography, material identity or a chat label. | Monograph Chapter 17, *Process provenance and temporal identity*, A3 and case table; Development §5.2 and §6.1. Genuine loss of qualification ends an episode; an analyst's observation window does not. Current reset/continuity qualifications are accurate. |
| Development and RCO do not introduce new A1 requirements or extra awareness. | Development §3.1, §4.1–4.4, §5.4 and §6.1. Incorporation can alter later physical continuation; RCO retains the practical personal model while ending its privileged final reference. Source status must affect continuation, rather than merely supply a tag. These connections are retained. |
| Conscious admission does not entail evaluative agency. | Agency §2.3–2.4, pp.6–8, and §7.2, Corollary 7.2, p.21. The return-grafted fixed-command construction establishes no evaluative mediation of its **ordinary command**; it does not erase native predictive distinctions. Moral-status wording states the exact command-level scope. |
| Evaluative mediation, faithful endorsement, factual truth and permission are different obligations. | Agency §3.2, Proposition 3.2 and examples, pp.10–11. The common downstream kernel excludes a context bypass; a probe inherits an installed contrast only when it separates relevant installed classes. `agency_transport.tex` preserves both qualifications. |
| Native realization is stronger than decoded service agreement. | Realization paper §2, inherited benchmark and recoding comparison; Development §6.3. Recoding may preserve decoded trajectories while changing the physically nominated intervention algebra. The manuscript does not infer phenomenal assignment from service equivalence. |
| Finite experiment transport needs joint records, successors, resources and histories. | Agency §2.5, Proposition 2.3, p.8; Reversible Control §13.2, Theorem 13.1, p.44. Uniform stage errors apply under the declared controller class and joint state, including correlated memory where relevant. The reported path-score and two-arm-gap bounds remain within source scope. |
| Moral consideration and relative significance are distinct. | Goodpaster, *On Being Morally Considerable* (1978), §II, p.311. The manuscript explicitly adopts this distinction while choosing conscious perspective rather than Goodpaster's life criterion. A1-to-consideration is the paper's normative commitment; A2 alone is not a welfare weighting rule. |

The current-model position is stated as the author's argued SPC-2 application. Its device-level certification remains a specified open technical task, rather than being silently replaced with agnosticism or presented as an already measured neural result. Functional emotion-concept effects are not promoted to measured artificial feeling or suffering. Clinical expression limits and philosophical comparisons do not independently validate A1, RCO or AI alignment. No erroneous equivalence requiring a foundational author decision was found in the audited sections.

## Bibliographic verification and access

The supplied original sources support the version/title/DOI associations below. This audit did not newly resolve every Zenodo DOI online; verification here means metadata present in supplied primary source material and consistent source cross-citations, not a claim of fresh registry resolution.

| Citation key | Supplied original version | DOI |
|---|---|---|
| `shadow2026` | Version 2, 20 September 2026 | 10.5281/zenodo.22853774 |
| `boundaries2026` | Version 1.0, 29 September 2026 | 10.5281/zenodo.23075822 |
| `interfaces2026` | Version 2, 29 September 2026 | 10.5281/zenodo.23075824 |
| `realization2026` | Version 1.1-RC1, 30 September 2026 | 10.5281/zenodo.23075828 |
| `development2026` | Revised preprint, 6 October 2026 | 10.5281/zenodo.23190711 |
| `reflectivefreedom2026` | Version 2.0, 6 October 2026 | 10.5281/zenodo.23202999 |
| `reversiblecontrol2026` | Version 2.0, 4 October 2026 | No DOI supplied or asserted |
| `shazeer2019` | arXiv v1, submitted 6 November 2019 | 10.48550/arXiv.1911.02150 |
| `goodpaster1978` | *Journal of Philosophy* 75(6), pp.308–325 | 10.2307/2025709 |

Original Shadow texts were available in complete supplied LaTeX or PDF. Relevant exact passages were consulted directly. Public KV-cache primary documentation and Shazeer's primary paper are accessible. Goodpaster's complete original article scan is accessible. No inaccessible primary source was used to strengthen the audited foundational conclusions.
