"""Exact-arithmetic constructed checks of the persistent-generation extension.

These are mathematical examples, not measured human or AI experiments.
Only the Python standard library is required.
"""
from fractions import Fraction as F
from pathlib import Path
import json
from itertools import product

checks = []
cases = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append(name)


def geom(c, n):
    return sum((c**j for j in range(n)), F(0))


def moments(law):
    mean = sum((p*x for x, p in law), F(0))
    variance = sum((p*(x-mean)**2 for x, p in law), F(0))
    return mean, variance


# Prop4's extended mean/variance, including within-step covariance.
# Two jointly correlated innovations are independent across successive draws.
alpha, beta, gamma, iota = F(3, 5), F(4, 5), F(3, 5), F(3, 4)
mu_e, mu_x, mu_n, mu_u = F(1, 10), F(1, 20), F(-1, 5), F(2, 3)
e, x, v, u = F(1, 10), F(1, 5), F(3, 10), F(2, 5)
initial = [(F(-1), F(1, 4)), (F(1), F(3, 4))]
mean0, var0 = moments(initial)
for k in (F(0), F(2, 5), iota):
    c = alpha + beta*(iota-k)
    m = gamma*mu_u + mu_x
    drift = m + beta*mu_e - beta*k*mu_n
    d_amplitude = beta*e + gamma*u + x - beta*k*v
    action_amplitude = e-k*v
    law = initial
    for t in range(6):
        mean_s, var_s = moments(law)
        expected_mean = c**t*mean0 + drift*geom(c, t)
        expected_var = c**(2*t)*var0 + d_amplitude**2*geom(c*c, t)
        check(f"extended mean k={k} t={t}", mean_s, expected_mean)
        check(f"extended variance k={k} t={t}", var_s, expected_var)
        action_law, next_law = [], []
        for salience, prob in law:
            for sign in (-1, 1):
                eps, xi, nu, cue = (mu_e+sign*e, mu_x+sign*x,
                                    mu_n+sign*v, mu_u+sign*u)
                action = (iota-k)*salience-k*nu+eps
                successor = alpha*salience+beta*action+gamma*cue+xi
                action_law.append((action, prob/2))
                next_law.append((successor, prob/2))
        mean_a, var_a = moments(action_law)
        check(f"extended action mean k={k} t={t}", mean_a,
              (iota-k)*mean_s-k*mu_n+mu_e)
        check(f"extended action variance k={k} t={t}", var_a,
              (iota-k)**2*var_s+action_amplitude**2)
        law = next_law


# Independent-component specialization of the extended innovation variance.
for k in (F(0), F(2, 5), iota):
    innovation_law = []
    action_noise_law = []
    for signs in product((-1, 1), repeat=4):
        se, sx, sn, su = signs
        innovation = beta*se*e + sx*x - beta*k*sn*v + gamma*su*u
        innovation_law.append((innovation, F(1, 16)))
        action_noise_law.append((se*e-k*sn*v, F(1, 16)))
    check(f"independent component innovation variance k={k}",
          moments(innovation_law)[1], beta**2*e**2+x**2+beta**2*k**2*v**2+gamma**2*u**2)
    check(f"independent component action noise variance k={k}",
          moments(action_noise_law)[1], e**2+k**2*v**2)


# Prop7: every stable, boundary, and unstable signed case is compared with
# direct recurrence; special boundary formulas are checked independently.
for alpha in (F(3, 5), F(-3, 5)):
    for m in (F(2, 5), F(-2, 5)):
        M = m/(1-alpha)
        iota = F(3, 4)
        for cL in (F(-2), F(-1), F(-3, 4), F(-1, 4),
                   F(0), F(1, 4), F(3, 4), F(1), F(3, 2)):
            beta = (cL-alpha)/iota
            direct = M
            means = []
            for n in range(21):
                formula = cL**n*M + m*geom(cL, n)
                check(f"persistent direct recurrence alpha={alpha} m={m} cL={cL} n={n}",
                      direct, formula)
                check(f"persistent action bias alpha={alpha} m={m} cL={cL} n={n}",
                      iota*direct, iota*formula)
                if cL == 1:
                    check(f"positive boundary linear alpha={alpha} m={m} n={n}",
                          direct, M+n*m)
                elif cL == -1:
                    check(f"negative boundary cycle alpha={alpha} m={m} n={n}",
                          direct, m/2+(-1)**n*(M-m/2))
                    check(f"negative boundary two-periodicity alpha={alpha} m={m} n={n}",
                          cL*(cL*direct+m)+m, direct)
                else:
                    ML = m/(1-cL)
                    check(f"fixed-point decomposition alpha={alpha} m={m} cL={cL} n={n}",
                          direct, ML+cL**n*(M-ML))
                    check(f"signed steady shift alpha={alpha} m={m} cL={cL} n={n}",
                          ML-M, m*beta*iota/((1-cL)*(1-alpha)))
                means.append(direct)
                direct = cL*direct+m
            cases.append({"alpha": str(alpha), "m": str(m), "cL": str(cL),
                          "beta": str(beta), "pre_lapse_mean": str(M),
                          "salience_means_n0_n1_n2_n3_n10":
                              [str(means[n]) for n in (0, 1, 2, 3, 10)]})


# Constant first moments alone give mean equality; coupled realizations give
# the stronger pre-lapse trajectory equality under perfect estimation.
alpha, beta, gamma, iota = F(3, 5), F(4, 5), F(3, 5), F(3, 4)
s_control = s_deidentified = F(7, 5)
for t in range(12):
    eps = F((-1)**t, 7)
    cue = F(t % 3, 5)
    xi = F(2-t % 4, 9)
    a_control = iota*s_control-iota*s_control+eps
    a_deidentified = eps
    check(f"coupled pre-lapse action t={t}", a_control, a_deidentified)
    s_control = alpha*s_control+beta*a_control+gamma*cue+xi
    s_deidentified = alpha*s_deidentified+beta*a_deidentified+gamma*cue+xi
    check(f"coupled pre-lapse salience t={t}", s_control, s_deidentified)


# Requested statements requiring qualifications: exact counterexamples.
alpha, beta, iota, k = F(3, 5), F(4, 5), F(3, 4), F(2, 5)
m, mu_e, mu_n = F(1, 2), F(1, 10), F(-1, 5)
c = alpha+beta*(iota-k)
true_stationary_mean = (m+beta*mu_e-beta*k*mu_n)/(1-c)
naive_stationary_mean = m/(1-c)
assert true_stationary_mean != naive_stationary_mean
check("noise means alter drift", true_stationary_mean, F(161, 30))
check("noise-free proposed drift is distinct", naive_stationary_mean, F(25, 6))

# Stable negative cL can oscillate while approaching a higher positive mean.
alpha, cL, m = F(-3, 5), F(-1, 4), F(2, 5)
M, ML = m/(1-alpha), m/(1-cL)
assert ML > M
sequence = [ML+cL**n*(M-ML) for n in range(4)]
assert sequence[0] < ML < sequence[1] and sequence[2] < ML < sequence[3]
checks.append("higher stable limit need not imply monotone rise")

# Arbitrary preparation approaches the proposed pre-lapse mean; it need not
# equal it at a finite lapse time. The stable error has exact geometric form.
alpha, m, mean0 = F(3, 5), F(2, 5), F(0)
M = m/(1-alpha)
for tau in range(6):
    current = alpha**tau*mean0 + m*geom(alpha, tau)
    check(f"preparation mean offset tau={tau}", current-M, alpha**tau*(mean0-M))
assert mean0 == 0 and M != 0
checks.append("immediate nonzero jump requires stationary-mean preparation or a nonzero actual mean")

# Exact cancellation with biased estimation has nonzero mean action. Exact
# de-identification also leaves a nonzero mean execution disturbance intact.
check("biased estimation defeats zero cancellation bias", -F(3,4)*F(1,5), F(-3,20))
check("de-identification retains execution mean", F(1,10), F(1,10))

result = {
    "status": "passed",
    "arithmetic": "exact fractions",
    "check_count": len(checks),
    "persistent_regime_case_count": len(cases),
    "scope": "Constructed mathematical checks, not measured human or AI experiments.",
    "checks": checks,
    "regime_cases": cases,
    "noise_mean_counterexample": {"true_mean": str(true_stationary_mean),
                                  "mean_ignoring_execution_and_estimation": str(naive_stationary_mean)},
}
destination = Path(__file__).with_name('persistent_generation_math_check_results.json')
destination.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ('status', 'arithmetic', 'check_count',
                                        'persistent_regime_case_count', 'scope')}, indent=2))
