"""Constructed exact-rational checks of the optional decoupled channels."""
from fractions import Fraction as F
from pathlib import Path
import json

checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append(name)


def mean(c, source, initial, n):
    return c**n*initial+source*sum((c**j for j in range(n)), F(0))


# One unstable self channel and one stable goal channel after lapse.
channels = {
    'self': (F(3, 5), F(4, 5), F(3, 4), F(2, 5)),
    'goal': (F(1, 2), F(1, 4), F(1, 2), F(1, 5)),
}
direct = {j: m/(1-alpha) for j, (alpha,beta,iota,m) in channels.items()}
for n in range(16):
    expected_total = F(0)
    direct_total = F(0)
    for j, (alpha,beta,iota,m) in channels.items():
        c = alpha+beta*iota
        initial = m/(1-alpha)
        theoretical = mean(c,m,initial,n)
        check(f'{j} recurrence n={n}', direct[j], theoretical)
        expected_total += iota*theoretical
        direct_total += iota*direct[j]
        direct[j] = c*direct[j]+m
    check(f'total mean bias n={n}', direct_total, expected_total)
check('immediate two-channel bias', F(3,4)*F(1)+F(1,2)*F(2,5), F(19,20))

# Removing self-identification does not remove goal-priority bias.
check('goal-only immediate bias', F(0)*F(1)+F(1,2)*F(2,5), F(1,5))

# Signed mean contributions can cancel without either channel disappearing.
self_bias, goal_bias = F(3,4)*F(1), F(1,2)*F(-3,2)
assert self_bias != 0 and goal_bias != 0
check('opposing channel means cancel', self_bias+goal_bias, F(0))

# Total variance includes the covariance term. Same/opposite Rademacher
# disturbances have equal marginal variances and different total variances.
for sign in (1,-1):
    covariance = F(sign)
    total_variance = F(1)+F(1)+2*covariance
    check(f'total variance correlation sign={sign}', total_variance,
          F((1+sign)**2))

# Cross-feedback defeats separate diagonal stability tests.
diagonal, off_diagonal = F(1,2), F(3,4)
spectral_mode = diagonal+off_diagonal
check('coupled unstable eigenvalue', spectral_mode, F(5,4))
assert abs(diagonal) < 1 and spectral_mode > 1
state = (F(1),F(1))
for n in range(10):
    check(f'coupled growing mode n={n}', state,
          (spectral_mode**n,spectral_mode**n))
    state = (diagonal*state[0]+off_diagonal*state[1],
             off_diagonal*state[0]+diagonal*state[1])

# Matched systems carry no acquisition label in their equations. Coupling
# their initial state and innovations gives identical finite trajectories.
trained, proposed = F(2,3),F(2,3)
alpha,beta,gamma,iota,k = F(3,5),F(4,5),F(1,2),F(1,4),F(0)
for n in range(12):
    eps,nu,cue,xi = F((-1)**n,9),F(n%2,10),F(2+n%3,7),F(1,20)
    action_trained = iota*trained-k*(trained+nu)+eps
    action_proposed = iota*proposed-k*(proposed+nu)+eps
    check(f'matched organization action n={n}',action_trained,action_proposed)
    trained = alpha*trained+beta*action_trained+gamma*cue+xi
    proposed = alpha*proposed+beta*action_proposed+gamma*cue+xi
    check(f'matched organization salience n={n}',trained,proposed)

results = {
    'status':'passed',
    'arithmetic':'exact fractions',
    'check_count':len(checks),
    'scope':'Constructed mathematical checks; no measured model or human experiments.',
    'checks':checks,
}
Path(__file__).with_name('channel_math_check_results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:results[k] for k in ('status','arithmetic','check_count','scope')},indent=2))
