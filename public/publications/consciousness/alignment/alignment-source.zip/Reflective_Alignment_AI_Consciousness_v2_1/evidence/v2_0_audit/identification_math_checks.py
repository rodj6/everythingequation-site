from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import json

checks = []
def record(name, condition, detail):
    assert condition, (name, detail)
    checks.append({"name": name, "passed": True, "detail": detail})
def moments(dist):
    mean = sum(x*p for x,p in dist.items())
    var = sum((x-mean)**2*p for x,p in dist.items())
    return mean, var

a, b, iota = F(3,5), F(4,5), F(3,4)
mu_e, mu_x, mu_n = F(3,100), F(1,50), F(1,10)
centered = [(F(1,10),F(1,5),F(3,10)),(-F(1,10),-F(1,5),-F(3,10))]
noise = [(mu_e+e, mu_x+x, mu_n+n, F(1,2)) for e,x,n in centered]
initial = {F(1):F(3,4), F(-1):F(1,4)}
m0, v0 = moments(initial)
for k in [F(3,4), F(2,5), F(0)]:
    c = a+b*(iota-k)
    d_values = {b*e+x-b*k*n: p for e,x,n,p in noise}
    md, vd = moments(d_values)
    states = initial
    for t in range(7):
        ms, vs = moments(states)
        formula_m = c**t*m0+md*sum(c**j for j in range(t))
        formula_v = c**(2*t)*v0+vd*sum(c**(2*j) for j in range(t))
        actions = defaultdict(F)
        next_states = defaultdict(F)
        for s,ps in states.items():
            for e,x,n,pn in noise:
                act=(iota-k)*s-k*n+e
                actions[act]+=ps*pn
                next_states[a*s+b*act+x]+=ps*pn
        ma, va = moments(actions)
        formula_ma=(iota-k)*ms-k*mu_n+mu_e
        formula_va=(iota-k)**2*vs+k*k*F(9,100)+F(1,100)-2*k*F(3,100)
        record(f"correlated_moments_gain_{k}_step_{t}",
               (ms,vs,ma,va)==(formula_m,formula_v,formula_ma,formula_va),
               {"state_mean":str(ms),"state_variance":str(vs),"action_mean":str(ma),"action_variance":str(va)})
        states=dict(next_states)

controlled_c=a+b*(iota-F(3,4))
lapsed_c=a+b*iota
s_tau=controlled_c**3
for n in range(9):
    controlled_bias=iota*lapsed_c**n*s_tau
    deidentified_salience=a**n*s_tau
    record(f"lapse_step_{n}", controlled_bias==iota*F(6,5)**n*F(3,5)**3,
           {"identified_bias":str(controlled_bias),"deidentified_bias":"0", "deidentified_salience":str(deidentified_salience)})
record("negative_alpha_counterexample", F(-6,5)<1 and abs(F(-6,5))>1,
       "alpha=-1.2 meets alpha<1 but increases unforced magnitude")
record("stable_lapse_counterexample", abs(F(1,5)+F(1,5)*F(1,2))<1,
       "alpha=beta=.2, iota=.5 yields post-lapse factor .3; no growing rebound")
record("mean_zero_is_not_zero_variance", moments({F(1):F(1,2),F(-1):F(1,2)})==(F(0),F(1)),
       "Opposite signed biases cancel in expectation while variance remains one")
record("vanishing_identification_needs_bound", all(F(1,n+1)*F(n+1)==1 for n in range(100)),
       "iota_n=1/(n+1), s_n=n+1 keeps identification contribution one")
record("biased_execution_breaks_zero_mean", F(0)*F(17)+F(1,10)==F(1,10),
       "At iota=k=0, positive execution-disturbance mean remains")
record("active_biased_suppressor_breaks_zero_mean", F(0)*F(0)-F(3,4)*F(1,10)!=0,
       "At iota=0, k=.75 and mean estimate error .1 inject nonzero bias")
Path(__file__).with_name("identification_math_check_results.json").write_text(json.dumps({"constructed_checks":len(checks), "all_passed":True,"checks":checks},indent=2))
print(f"{len(checks)} exact constructed checks passed")
