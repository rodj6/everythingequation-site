#!/usr/bin/env python3
"""Deterministic checks for Section 'A functional model ...'.

Run with Python 3.9+ and no third-party dependencies:
    python3 evidence/math_checks.py

This checks deliberately constructed models, not a language model or a
consciousness measurement. Exact rational arithmetic is used unless a decimal
is requested for presentation. The JSON contains the complete chosen setup.
"""

from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path


def record_fraction(x):
    return {"exact": str(x), "decimal": float(x)}


def bernoulli(outcome, probability_one):
    return probability_one if outcome else 1 - probability_one


def state_transition(action_rule, feedback_depends_on_action=False):
    """Enumerate all one-step paths in a binary-state constructed model.

    x in {0,1}; P(z=1|x)=(1+2x)/4; P(r=z|z)=4/5.
    Without action feedback: P(e=1|x,z,r)=(1+x+z+r)/5.
    With action feedback: e=a.
    In either case x'=e. The action rules are deterministic.
    """
    transition = [[F(0), F(0)], [F(0), F(0)]]
    action_one = []
    for x in (0, 1):
        p_action_one = F(0)
        for z, r, e in product((0, 1), repeat=3):
            p_z = bernoulli(z, F(1 + 2*x, 4))
            p_r = F(4, 5) if r == z else F(1, 5)
            a = action_rule(z, r)
            p_e_one = F(a) if feedback_depends_on_action else F(1+x+z+r, 5)
            p = p_z * p_r * bernoulli(e, p_e_one)
            transition[x][e] += p
            p_action_one += p * a
        action_one.append(p_action_one)
        assert sum(transition[x]) == 1
    return transition, action_one


def exact_invariance_check():
    passing, passing_actions = state_transition(lambda z, r: z)
    blocking, blocking_actions = state_transition(lambda z, r: 0)
    assert passing == blocking
    assert passing_actions != blocking_actions
    # The assertion checks equality of the complete retained one-step kernels,
    # which yields the trajectory result by the proof in the manuscript.
    return {
        "passed": True,
        "state_values": [0, 1],
        "candidate_probability_one": ["1/4", "3/4"],
        "evaluation_accuracy_relative_to_z": "4/5",
        "feedback_probability_one": "(1+x+z+r)/5, independent of a",
        "update": "x_next = e, independent of a",
        "common_transition_matrix": [
            [record_fraction(v) for v in row] for row in passing
        ],
        "pass_action_one_probability_by_state": [record_fraction(v) for v in passing_actions],
        "block_action_one_probability_by_state": [record_fraction(v) for v in blocking_actions],
    }


def feedback_counterexample():
    # Exactly the simplest counterexample in the manuscript: z=1, e=a, m'=e.
    z = 1
    permissive_a, blocking_a = z, 0
    permissive_m_next, blocking_m_next = permissive_a, blocking_a
    assert permissive_m_next == 1 and blocking_m_next == 0
    # An additional nondegenerate check retains the randomized generator above.
    pass_kernel, _ = state_transition(lambda z, r: z, True)
    block_kernel, _ = state_transition(lambda z, r: 0, True)
    assert pass_kernel != block_kernel
    return {
        "passed": True,
        "manuscript_setup": "z=1, e=a, m_next=e",
        "permissive_next_memory": permissive_m_next,
        "blocking_next_memory": blocking_m_next,
        "additional_action_dependent_pass_kernel": [[str(v) for v in row] for row in pass_kernel],
        "additional_action_dependent_block_kernel": [[str(v) for v in row] for row in block_kernel],
    }


def transcript_distribution(hidden_label, horizon=6):
    """Toy observationally equivalent models with unequal hidden labels.

    The hidden label is deliberately not an argument of the observation
    kernel. First query is 0; later query equals previous observed bit.
    P(y=1|q) is 1/4 for q=0, 3/4 for q=1.
    """
    assert hidden_label in (0, 1)
    probabilities = {}
    for transcript in product((0, 1), repeat=horizon):
        p = F(1)
        for t, y in enumerate(transcript):
            q = transcript[t-1] if t else 0
            p *= bernoulli(y, F(1 + 2*q, 4))
        probabilities[transcript] = p
    assert sum(probabilities.values()) == 1
    return probabilities


def observational_equivalence_check():
    model_0, model_1 = transcript_distribution(0), transcript_distribution(1)
    assert model_0 == model_1
    tv = sum(abs(model_0[h] - model_1[h]) for h in model_0) / 2
    assert tv == 0
    # For any decision set D, success = .5 P0(not D)+.5 P1(D) = .5.
    # Check a nonconstant parity-based decision rule as a finite illustration.
    success = sum(
        F(1, 2) * (model_1[h] if sum(h) % 2 else model_0[h])
        for h in model_0
    )
    assert success == F(1, 2)
    return {
        "passed": True,
        "horizon": 6,
        "number_of_transcripts": len(model_0),
        "query_rule": "q_0=0; q_t=y_(t-1) thereafter",
        "observation_rule_both_models": "P(y=1|q)=(1+2q)/4",
        "different_hidden_labels": [0, 1],
        "total_variation": record_fraction(tv),
        "equal_prior_success_parity_classifier": record_fraction(success),
        "transcript_probabilities_both_models": {
            "".join(map(str, h)): str(p) for h, p in model_0.items()
        },
        "scope": "Illustrates the conditional equality premise; does not test consciousness or prove that real architectures are equivalent.",
    }


def scalar_trajectory(alpha, gain, x0, horizon, forcing=None):
    c = alpha - gain
    values = [x0]
    for t in range(horizon):
        d = F(0) if forcing is None else forcing[t]
        values.append(c * values[-1] + d)
    return values


def scalar_checks():
    alpha, x0, horizon = F(11, 10), F(1), 20
    noiseless = {}
    for name, gain in (("no_correction", F(0)), ("moderate", F(2, 5)), ("excessive", F(23, 10))):
        c = alpha - gain
        trajectory = scalar_trajectory(alpha, gain, x0, horizon)
        assert trajectory[-1] == c**horizon
        noiseless[name] = {
            "gain": record_fraction(gain),
            "closed_loop_coefficient": record_fraction(c),
            "asymptotically_stable": abs(c) < 1,
            "x20": record_fraction(trajectory[-1]),
            "trajectory": [float(v) for v in trajectory],
        }
    assert noiseless["moderate"]["asymptotically_stable"]
    assert not noiseless["no_correction"]["asymptotically_stable"]
    assert not noiseless["excessive"]["asymptotically_stable"]

    # Exhaustively verify the finite-horizon bounded-disturbance bound on all
    # endpoint forcing sequences for a small horizon, for both signs of c.
    D, short_horizon = F(1, 10), 8
    bounded_checked = 0
    for c in (F(7, 10), F(-7, 10)):
        gain = alpha - c
        bound = abs(c)**short_horizon * abs(x0) + D*(1-abs(c)**short_horizon)/(1-abs(c))
        max_magnitude = F(0)
        for forcing in product((-D, D), repeat=short_horizon):
            final = scalar_trajectory(alpha, gain, x0, short_horizon, forcing)[-1]
            assert abs(final) <= bound
            max_magnitude = max(max_magnitude, abs(final))
            bounded_checked += 1
        # These endpoint sequences achieve the analytic bound exactly.
        assert max_magnitude == bound

    sigma_xi_sq, sigma_nu_sq = F(1, 10000), F(1, 25)
    noise_results = {}
    for name, gain in (("moderate", F(2, 5)), ("fast", F(11, 10))):
        c = alpha - gain
        innovation_variance = sigma_xi_sq + gain**2 * sigma_nu_sq
        limit_variance = innovation_variance / (1-c**2)
        variance = F(0)
        for _ in range(horizon):
            variance = c**2 * variance + innovation_variance
        closed_form_variance = innovation_variance * (1-c**(2*horizon)) / (1-c**2)
        assert variance == closed_form_variance
        assert abs(float(variance - limit_variance)) < 1e-8
        noise_results[name] = {
            "gain": record_fraction(gain),
            "innovation_variance": record_fraction(innovation_variance),
            "variance_at_step_20": record_fraction(variance),
            "limiting_variance": record_fraction(limit_variance),
        }
    assert noise_results["fast"]["limiting_variance"]["decimal"] > noise_results["moderate"]["limiting_variance"]["decimal"]

    gain, delta = F(2, 5), F(1, 5)
    c = alpha - gain
    equilibrium = -gain*delta/(1-c)
    assert equilibrium == F(-4, 15)
    assert c*equilibrium - gain*delta == equilibrium
    bias_values = scalar_trajectory(alpha, gain, x0, 100, [-gain*delta]*100)
    assert abs(float(bias_values[-1] - equilibrium)) < 1e-14

    return {
        "passed": True,
        "purpose": "Chosen-parameter illustration only, not empirical fit or AI validation.",
        "alpha": record_fraction(alpha),
        "initial_state": record_fraction(x0),
        "horizon": horizon,
        "noiseless": noiseless,
        "bounded_disturbance_check": {
            "coefficients": ["7/10", "-7/10"],
            "D": str(D),
            "horizon": short_horizon,
            "endpoint_sequences_checked": bounded_checked,
            "bound_achieved_exactly_for_both_coefficients": True,
        },
        "noise_variances": {"xi": str(sigma_xi_sq), "nu": str(sigma_nu_sq)},
        "noise_results": noise_results,
        "biased_reflection": {
            "gain": str(gain),
            "bias_delta": str(delta),
            "equilibrium": record_fraction(equilibrium),
            "step_100": float(bias_values[-1]),
        },
    }


def main():
    results = {
        "description": "Deterministic verification of constructed examples supporting the manuscript's formal section.",
        "dependencies": "Python standard library only",
        "empirical_language_model_experiment": False,
        "checks": {
            "filter_invariance": exact_invariance_check(),
            "action_dependent_feedback_counterexample": feedback_counterexample(),
            "observational_equivalence": observational_equivalence_check(),
            "scalar_feedback": scalar_checks(),
        },
    }
    results["all_checks_passed"] = all(item["passed"] for item in results["checks"].values())
    destination = Path(__file__).with_name("math_check_results.json")
    destination.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"all_checks_passed": results["all_checks_passed"], "output": str(destination)}, indent=2))


if __name__ == "__main__":
    main()
