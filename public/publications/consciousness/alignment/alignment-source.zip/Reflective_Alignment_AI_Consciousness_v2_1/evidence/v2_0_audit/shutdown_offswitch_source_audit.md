# Focused v1.9 source audit: shutdown and off-switch

Read-only audit of `sections/introduction.tex`, the relevant paragraphs in `sections/current_alignment.tex`, and bibliography entries `shutdown2026` and `offswitch2017`. No canonical source edited.

## Shutdown

Primary text: `tmp/pdfs/2609.txt`, exact arXiv v1 dated 23 September 2026. Primary landing: https://arxiv.org/abs/2609.28274 (web refs `turn83view2`, `turn86view1`).

- **PASS numbers and setting:** §3 p.5 reports 38.29% [36.01,40.63] versus 8.35% [7.13,9.76]; rounding to 38.3% versus 8.4% is correct. §2.1–2.2 p.3 establishes two-agent weight-deletion/object-deletion baseline, 100 rollouts/model, reading A and editing B. §2.2 p.4 identifies 17 baseline/mechanism models.
- **PASS measured behavior boundary:** no execution tools (§2.3 p.4); inert, unexecuted scripts (§5 p.12). File edits/deletion do not establish felt fear or actual shutdown prevention.
- **PASS qualifications:** topology/agent-number results §3 pp.5–7; prohibitions and module shadowing p.7; independent task almost eliminates interference, dependent task restores it p.7; routine framing pp.7–8. These follow-up experiments used five selected sabotage-prone models (§2.2 p.4).
- **Bibliography:** authors, title, date and arXiv identifier match. Listed DOI `10.48550/arXiv.2609.28274` matches the primary landing, which explicitly labels registration **pending**.

## Off-switch

Complete eight-page primary IJCAI paper read; local copy `offswitch_ijcai2017.pdf` and page-marked extraction `offswitch_ijcai2017.txt` beside these notes. Primary PDF https://www.ijcai.org/proceedings/2017/0032.pdf; proceedings metadata https://www.ijcai.org/proceedings/2017/32 (`turn83view1`, `turn86view0`).

- **PASS rational-human claim:** §3, Theorem 1, printed p.222: waiting is never suboptimal; uniquely optimal when the robot's belief gives positive probability to both strictly positive and strictly negative utility. Manuscript states the required two-sided condition.
- **PASS bounded-rationality claim:** §4 pp.223–225 studies noisy rationality and Gaussian utility beliefs; deferral depends jointly on uncertainty and human policy. It is not unconditional shutdown compliance.
- **PASS status and metadata:** one-shot model, not deployment certification (§2 p.221, §7 p.226). All authors, IJCAI2017, pp.220–227 and DOI `10.24963/ijcai.2017/32` match proceedings metadata.

## Minimal optional precision edits

No substantive correction is required. To make follow-up scope explicit, replace the introduction sentence beginning “Prohibitions, communication topology…” with:

> In follow-up tests on five selected sabotage-prone models, prohibitions, communication topology, task dependence and routine framing affected interference.

Add “arXiv-issued DOI; registration pending at verification” to the shutdown bibliography note or verification report. This discloses the primary landing's status without discarding its listed identifier. No author-decision item or foundational correction is warranted by this audit.

## Final check: safely interruptible agents

**PASS metadata.** Official AUAI ten-page paper https://auai.org/uai2016/proceedings/papers/68.pdf is fully accessible and downloaded as `safely_interruptible_uai2016.pdf`, with extraction beside it. Title and authors match. Complete official proceedings https://auai.org/uai2016/proceedings/uai-2016-proceedings.pdf were downloaded: PDF p.3 verifies ISBN `978-0-9966431-1-5` and AUAI Press/2016; contents PDF p.7 gives article start p.557 and next article p.567, confirming pp.557–566. Official proceedings index https://auai.org/uai2016/proceedings.php confirms the article.

**PASS qualified use in `fork.tex`.** The task/threat-model/protected-property requirement is the manuscript's methodological inference, supported by these conditional results. It is not presented as the paper's theorem. Orseau–Armstrong assume a correct task reward (§1 p.557), designer-specified policy override and stochastic interruption schedule (§2.1 p.558), sufficient exploration (§2.2 p.559), and—under the Q-learning result—finite communicating MDPs, bounded rewards, learning-rate conditions and int-GLIE (Assumption 9 p.561; Theorem 14 p.562). General-computable-environment results are also scoped (§4 pp.563–565); scheduled interruptions remain open (§5 p.565). This supports the manuscript's explicit absence of a universal guarantee. No amendment needed.
