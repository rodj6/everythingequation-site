Reflective Alignment and AI Consciousness
Awareness, Agency and Recursive Cognitive Scaffolding
Jeremy Rodgers — Independent Researcher
Version 2.1 — 11 October 2026
DOI supplied by the author: https://doi.org/10.5281/zenodo.23294465

This is the focused finishing revision of the completed v2.0 manuscript, which is preserved separately. The package contains the complete editable v2.1 manuscript, bibliography, bibliography style, matching PDF, short change note and public verification materials. No private protocol instructions, distinctive prompts or implementation are distributed.

BUILD
Run from this directory with a standard TeX Live installation:
  latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Without latexmk:
  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex

The build uses pdfLaTeX, BibTeX, the included plainnatdoi.bst, standard Latin Modern fonts and standard TeX packages (geometry, fontenc, lmodern, microtype, amsmath, amssymb, amsthm, booktabs, array, longtable, natbib, xurl, hyperref and enumitem). No external figures, proprietary fonts, network service or private protocol is required. main.bbl is included as a generated bibliography fallback; references.bib is authoritative for editing.

Verified environment: pdfTeX 1.40.25, TeX Live 2023/Debian; latexmk 4.83. Final manuscript: 47 pages. A fresh isolated build reproduced every page's text and rendered pixels and the generated bibliography.

FILES
  main.tex and sections/        Complete v2.1 manuscript, including mathematics
  references.bib               Bibliography (54 entries; redundant self-entry removed)
  plainnatdoi.bst               Bibliography style with clickable DOI handling
  main.bbl                     Generated bibliography for this source
  main.pdf                     Matching v2.1 manuscript
  CHANGE_NOTE.txt              Short finishing-pass change and verification note
  MANIFEST.json                Package file hashes
  evidence/V2_1_FINAL_CHECK.json  Final preservation and build checks
  evidence/v2_0_audit/          Historical source/math audits, scripts and audit report

The historical audit materials retain their original version labels and passage locators. They document verification already completed for v2.0; they are not the active manuscript or instructions to undo v2.1. The historical report can be rebuilt within its own directory using latexmk -pdf audit_report.tex. Its earlier bibliography count and self-reference note describe v2.0, not this version.

The optional public scripts check constructed mathematics using Python's standard library. For example:
  python3 evidence/v2_0_audit/independent_math_checks.py
They are not empirical model experiments or RCO/consciousness certifications. Bibliographic notes retain the original full-text, abstract-only and other access distinctions. Qualified researchers may request the private protocol through https://everythingequation.com.
