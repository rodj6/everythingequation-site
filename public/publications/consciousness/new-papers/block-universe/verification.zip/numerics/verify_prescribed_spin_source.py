#!/usr/bin/env python3
"""Prescribed autonomous spin-chain readout and completion checks.

The analytic proof is in the prescribed-source section of the paper. This script corroborates it;
it is not an experimental spin-chain realization or a novelty certificate.
Requires numpy and scipy, no source-package code.
"""
from pathlib import Path
from math import pi, sqrt, comb
import json
import numpy as np
from scipy.linalg import expm
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent.parent/'verification'/'numerical'
HERE.mkdir(parents=True,exist_ok=True)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
NUM=np.diag([0.,1.]).astype(complex)

def td(a,b):
    return float(np.abs(np.linalg.eigvalsh(a-b)).sum()/2)

def kron_all(xs):
    z=np.ones((1,1),complex)
    for x in xs:z=np.kron(z,x)
    return z

def site_op(op,j,N):
    xs=[I]*N;xs[j]=op
    return kron_all(xs)

def chain(N,omega=1.):
    B=omega*N
    couplings=np.array([omega*sqrt(j*(N-j))/2 for j in range(1,N)])
    h=np.zeros((2**N,2**N),complex)
    for j,J in enumerate(couplings):
        xs=[I]*N;xs[j]=X;xs[j+1]=X
        ys=[I]*N;ys[j]=Y;ys[j+1]=Y
        h+=J*(kron_all(xs)+kron_all(ys))/2
    for j in range(N):h+=B*site_op(NUM,j,N)
    return h,couplings,B

def single_matrix(N,omega=1.):
    B=omega*N
    h=B*np.eye(N)
    for j in range(1,N):h[j-1,j]=h[j,j-1]=omega*sqrt(j*(N-j))/2
    return h

def reduced_s(psi,N):
    m=psi.reshape(2,2**(N-1))
    return m@m.conj().T

def reduced_rs(psi,N):
    m=psi.reshape(4,2**(N-1))
    return m@m.conj().T

def deficiency(p,q):
    # Variables: probability output1 on input0, probability output1 on input1, error.
    sol=linprog([0.,0.,1.],A_ub=[[1,0,-1],
                  [1-p,p,-1],[-(1-p),-p,-1]],b_ub=[0,q,-q],
                bounds=[(0,1),(0,1),(0,1)],method='highs')
    assert sol.success
    analytic=max(0.,(q-p)/(2-p))
    assert abs(sol.fun-analytic)<1e-9,(p,q,sol.fun,analytic)
    return float(sol.fun)

def main():
    chain_checks=[];max_amp_err=0.;max_population_err=0.
    # Many finite-chain one-excitation checks against closed amplitudes.
    for N in range(2,16):
        h=single_matrix(N)
        for t in np.linspace(0,2*pi,17):
            u=expm(-1j*t*h)[:,0]
            theta=t/2
            pred=np.array([np.exp(-1j*N*t)*sqrt(comb(N-1,j))*
                           (-1j*np.sin(theta))**j*np.cos(theta)**(N-1-j)
                           for j in range(N)])
            err=float(np.max(np.abs(u-pred)))
            assert err<2e-12,(N,t,err)
            max_amp_err=max(max_amp_err,err)
        at_T=expm(-1j*pi*h)[:,0]
        at_2T=expm(-2j*pi*h)[:,0]
        assert np.allclose(abs(at_T[-1]),1)
        assert np.allclose(at_T[:-1],0,atol=1e-12)
        assert np.allclose(at_2T[1:],0,atol=1e-12)
        assert np.allclose(at_2T[0],(-1)**(N-1),atol=1e-12)
        chain_checks.append({'N':N,'T_endpoint_population':float(abs(at_T[0])**2),
                 'T_remote_population':float(abs(at_T[-1])**2),
                 'return_population':float(abs(at_2T[0])**2)})
    full_checks=[];deadline_checks=[];cap_checks=[]
    bell=np.array([1,0,0,1],complex)/sqrt(2)
    Bell=np.outer(bell,bell.conj())
    rng=np.random.default_rng(20261022)
    for N in (3,5,7):
        h,J,B=chain(N)
        eig=np.linalg.eigvalsh(h)
        assert eig[0]>-1e-10 and eig[1]>0
        assert B>max(np.r_[0,J]+np.r_[J,0])
        vac=np.eye(2**N)[:,0];first=np.eye(2**N)[:,2**(N-1)]
        U=expm(-1j*pi*h);V=expm(-2j*pi*h)
        rs_T=reduced_rs(np.kron([1,0],U@vac)/sqrt(2)+np.kron([0,1],U@first)/sqrt(2),N)
        rs_2T=reduced_rs(np.kron([1,0],V@vac)/sqrt(2)+np.kron([0,1],V@first)/sqrt(2),N)
        fixed=np.kron(I/2,np.diag([1.,0.]))
        assert td(rs_T,fixed)<1e-11 and td(rs_2T,Bell)<1e-11
        # Random input states: sender is fixed at T, identity returns at2T for oddN.
        errs=[]
        for _ in range(20):
            a=rng.normal(size=2)+1j*rng.normal(size=2);a/=np.linalg.norm(a)
            psi=a[0]*vac+a[1]*first
            errs.append(td(reduced_s(U@psi,N),np.diag([1.,0.])))
            errs.append(td(reduced_s(V@psi,N),np.outer(a,a.conj())))
        assert max(errs)<1e-11
        for delta in np.linspace(0,pi,9):
            t=pi+delta;Ut=expm(-1j*t*h)
            raw=reduced_rs(np.kron([1,0],Ut@vac)/sqrt(2)+np.kron([0,1],Ut@first)/sqrt(2),N)
            correct=np.kron(I,np.diag([1.,np.exp(1j*B*t)]))
            corrected=correct@raw@correct.conj().T
            fe=float(np.real(np.vdot(bell,corrected@bell)))
            amp=np.sin(delta/2)**(N-1)
            pred=(1+amp)**2/4
            assert abs(fe-pred)<1e-11
            deadline_checks.append({'N':N,'delta_over_T':float(delta/pi),
                    'population':float(amp**2),'Bell_overlap':fe,'predicted_Bell_overlap':float(pred)})
        delta_crit=2*np.arcsin((sqrt(2)-1)**(1/(N-1)))
        assert abs((1+np.sin(delta_crit/2)**(N-1))**2/4-.5)<1e-12
        cap_omega=4/sqrt(N*N-1)
        cap_J=[cap_omega*sqrt(j*(N-j))/2 for j in range(1,N)]
        assert abs(max(cap_J)-1)<1e-12
        cap_checks.append({'N':N,'coupling_cap_g':1.,'omega':cap_omega,
                 'T':pi/cap_omega,'classical_Bell_threshold_delta_over_T':float(delta_crit/pi)})
        full_checks.append({'N':N,'full_H_dimension':2**N,
                 'ready_ground_energy':float(eig[0]),'ground_gap':float(eig[1]-eig[0]),
                 'mid_RS_product_trace_error':td(rs_T,fixed),
                 'return_Bell_trace_error':td(rs_2T,Bell),
                 'return_Bell_overlap':float(np.real(np.vdot(bell,rs_2T@bell))),
                 'random_state_checks':20,'max_random_state_error':max(errs)})
    lp_count=0;lp_samples=[]
    for p in np.linspace(0,1,21):
        for q in np.linspace(0,1,21):
            val=deficiency(float(p),float(q));lp_count+=1
            if (p,q) in [(0.,1.),(.5,1.),(.5,.75),(1.,1.)]:
                lp_samples.append({'p':p,'q':q,'error':val,'half_TV_bound':max(0.,q-p)/2})
    # Reference-assisted and classical-completion benchmarks, dimensions2,4,8.
    quantum=[]
    for d in (2,4,8):
        phi=np.eye(d).reshape(d*d)/sqrt(d)
        target=np.outer(phi,phi)
        product=np.eye(d*d)/(d*d)
        D=td(target,product)
        assert abs(D-(1-1/d**2))<1e-12
        dephased=np.zeros((d*d,d*d))
        for j in range(d):dephased[j*d+j,j*d+j]=1/d
        assert abs(np.vdot(phi,dephased@phi)-1/d)<1e-12
        randommin=1.
        for _ in range(20):
            a=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
            sigma=a@a.conj().T;sigma/=np.trace(sigma)
            rho=np.kron(np.eye(d)/d,sigma)
            ov=float(np.real(np.vdot(phi,rho@phi)))
            assert abs(ov-1/d**2)<1e-12
            dist=td(target,rho);assert dist>=1-1/d**2-1e-12
            randommin=min(randommin,dist)
        quantum.append({'d':d,'memoryless_Bell_overlap':1/d**2,
                  'exact_min_memoryless_trace_error':D,
                  'classical_completion_Bell_bound':1/d,
                  'attaining_classical_dephased_overlap':float(np.real(np.vdot(phi,dephased@phi))),
                  'random_memoryless_states_checked':20,'minimum_random_trace_error':randommin})
    # Duhamel robustness check for an independent perturbation, not source-specific attainment.
    N=5;h,_,_=chain(N);a=rng.normal(size=h.shape)+1j*rng.normal(size=h.shape)
    v=(a+a.conj().T)/2;v*=.002/np.linalg.norm(v,2);nu=float(np.linalg.norm(v,2))
    robust=[]
    for t in (0.2,1.,pi,2*pi):
        U=expm(-1j*t*h);Ut=expm(-1j*t*(h+v))
        err=float(np.linalg.norm(U-Ut,2))
        assert err<=t*nu+1e-12
        robust.append({'t':t,'unitary_operator_error':err,'duhamel_bound':t*nu})
    result={'status':'PASS','scope':'prescribed finite autonomous Hamiltonian and analytic-deficiency checks; no experiment',
            'single_excitation_chain_checks':chain_checks,'max_analytic_amplitude_error':max_amp_err,
            'full_Hilbert_checks':full_checks,'post_ready_deadline_checks':deadline_checks,
            'bounded_coupling_checks':cap_checks,'binary_deficiency_LPs':lp_count,
            'selected_LP_outputs':lp_samples,'coherent_completion_checks':quantum,
            'perturbation_norm':nu,'perturbation_checks':robust,
            'coupling_cap_formula':'T=pi*sqrt(N^2-1)/(4*g) for oddN; maxJ=g',
            'interpretive_limit':'Ordinary quantum chain is a compatible completion; no unique Ground or eternalism inference.'}
    (HERE/'prescribed_spin_source_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','one_excitation_chains':len(chain_checks),
          'amplitude_checks':len(chain_checks)*17,'max_amplitude_error':max_amp_err,
          'full_Hilbert_chains':len(full_checks),'binary_deficiency_LPs':lp_count,
          'midpoint_scalar_minimax_error':deficiency(0.,1.),
          'qubit_reference_minimax_error':quantum[0]['exact_min_memoryless_trace_error'],
          'output':'prescribed_spin_source_results.json'},indent=2))

if __name__=='__main__':main()
