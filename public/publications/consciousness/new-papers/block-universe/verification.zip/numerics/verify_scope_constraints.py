#!/usr/bin/env python3
"""Finite corroboration of history-assignment and local-deadline scope lemmas.

These are independently specified mathematical models, not human measurements.
The historical lemma adds strict well-foundedness only in its stated case.
"""
from itertools import product
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)


def history_checks():
    n=4
    edges=[(v,u) for v in range(n) for u in range(n) if u!=v]
    fixedpoint_cases=0;acyclic_cases=0;multiple_cases=0
    for flags in range(1<<len(edges)):
        pred=[0]*n
        for i,(v,u) in enumerate(edges):
            if flags>>i&1:pred[v]|=1<<u
        def update(E,L):
            return sum(1<<v for v in range(n) if L>>v&1 and pred[v]&E)
        for L in range(1<<n):
            fixed=[E for E in range(1<<n) if update(E,L)==E]
            assert 0 in fixed
            g=L
            while True:
                h=update(g,L)
                if h==g:break
                assert h&~g==0
                g=h
            assert g in fixed and all(E&~g==0 for E in fixed)
            # A path in the qualifying predecessor subgraph can persist iff it
            # reaches a directed cycle. Exhaust lengths 0,...,n to detect this.
            reaches_cycle=0
            for v in range(n):
                if not L>>v&1:continue
                frontier=1<<v
                for _ in range(n):
                    previous=frontier
                    frontier=_union(pred[u]&L for u in range(n) if previous>>u&1)
                if frontier:reaches_cycle|=1<<v
            assert reaches_cycle==g
            if g==0:
                assert fixed==[0];acyclic_cases+=1
            if len(fixed)>1:multiple_cases+=1
            fixedpoint_cases+=1
    return {'vertices':n,'loop_free_graphs':1<<len(edges),
            'local_qualification_cases':fixedpoint_cases,
            'empty_greatest_assignment_cases':acyclic_cases,
            'multiple_admissible_assignment_cases':multiple_cases,
            'scope':'Finite predecessor graphs; empty assignment and greatest fixed point; no claim to identify actual experiences'}


def _union(values):
    out=0
    for value in values:out|=value
    return out


def deadline_checks():
    cases=0
    for first,second,latency,memory in product(range(6),range(6),range(1,5),range(1,10)):
        lo=max(first,second)+latency;hi=min(first,second)+memory
        feasible=lo<=hi
        assert feasible==(abs(first-second)+latency<=memory)
        cases+=1
    # Given independent symmetric delay-error intervals, both signs remain
    # possible inside the uncertainty band; outside it the sign is guaranteed.
    cal_cases=0
    for estimated,error1,error2 in product(range(-6,7),range(4),range(4)):
        radius=error1+error2
        interval=(estimated-radius,estimated+radius)
        guaranteed=interval[0]>0 or interval[1]<0
        assert guaranteed==(abs(estimated)>radius)
        cal_cases+=1
    return {'exact_schedule_cases':cases,'calibration_interval_cases':cal_cases}


def main():
    result={'status':'PASS','history_assignment':history_checks(),
            'finite_occasion':deadline_checks(),
            'scope':'Finite corroboration of proofs; no empirical fit or phenomenal assignment'}
    (ROOT/'scope_constraints_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
