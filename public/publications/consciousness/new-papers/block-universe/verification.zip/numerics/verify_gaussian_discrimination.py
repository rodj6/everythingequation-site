#!/usr/bin/env python3
"""Gaussian sign-discrimination arithmetic for the causal-release example.

This checks the analytic probability and TV formulas. It is not a numerical
QFT simulation or evidence of a realized material detector.
"""
import json
import math
from pathlib import Path
from scipy.integrate import quad

OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)

def density(x,mu):
    return math.exp(-0.5*(x-mu)**2)/math.sqrt(2*math.pi)

def main():
    checks=[]
    for ratio in [0.5,1.0,2.0]:
        delta=0.5*math.erfc(ratio/math.sqrt(2))
        expected_tv=1-2*delta
        numerical_tv,quad_err=quad(
            lambda x:density(x,ratio)-density(x,-ratio),
            0,math.inf,epsabs=1e-12,epsrel=1e-12)
        assert abs(numerical_tv-expected_tv)<1e-11
        checks.append({'mean_to_sd_ratio':ratio,'sign_error':delta,
                       'tv_formula':expected_tv,'tv_quadrature':numerical_tv,
                       'common_predictor_radius':expected_tv/2,
                       'quadrature_error_estimate':quad_err})
    result={'status':'PASS','gaussian_checks':checks,
            'scope':'Gaussian discrimination arithmetic; no QFT dynamics or apparatus calibration'}
    (OUT/'gaussian_discrimination_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
