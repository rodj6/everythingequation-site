#!/usr/bin/env python3
"""Constructive arithmetic checks for reciprocal geometry; analytic proofs are separate.
Not Lean verification, empirical evidence, or a test of an actuality premise.
"""
from fractions import Fraction as F
from pathlib import Path
import json,math,random
ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)

def b_exact(l,v):
 c=(l+1/l)/2;s=(l-1/l)/2
 return c*v[0]+s*v[1],s*v[0]+c*v[1]
def q(v):return v[0]**2-v[1]**2

def exact_checks():
 n=0
 for l in [F(1,3),F(1,2),F(1),F(3,2),F(2),F(3)]:
  for t in range(-3,4):
   for x in range(-3,4):
    v=(F(t),F(x));bv=b_exact(l,v)
    assert q(bv)==q(v)
    assert b_exact(1/l,bv)==v
    assert bv[0]-bv[1]==(v[0]-v[1])/l
    assert bv[0]+bv[1]==l*(v[0]+v[1]);n+=1
 p=(F(0),F(0));r=(F(0),F(2));s=(F(1),F(0))
 spacelike=lambda a,b:q((b[0]-a[0],b[1]-a[1]))<0
 assert spacelike(p,r) and spacelike(r,s) and not spacelike(p,s)
 # Same coordinate time is not fixed-relation boost invariant.
 assert (p[0]==r[0]) and b_exact(F(2),p)[0]!=b_exact(F(2),r)[0]
 # Minkowski norm equality is not translation invariant.
 a=(F(1),F(0));b=(F(-1),F(0));shift=(F(1),F(0))
 assert q(a)==q(b) and q((a[0]+shift[0],0))!=q((b[0]+shift[0],0))
 # A null equivalence class survives boosts but not spatial reflection.
 v=(F(1),F(1));assert v[0]-v[1]==0 and v[0]-(-v[1])!=0
 # Indexed simultaneity family is covariant, not fixed-u boost invariant.
 u=(F(1),F(0));d=(F(0),F(1));bu=b_exact(F(2),u);bd=b_exact(F(2),d)
 inner=lambda a,b:a[0]*b[0]-a[1]*b[1]
 assert inner(u,d)==0 and inner(bu,bd)==0 and inner(u,bd)!=0
 return {'boost_inverse_metric_nullcoordinate_cases':n,'countermodel_checks':5,
         'indexed_family_covariance':'exact Minkowski innerproduct preserved; fixed-u relation changes'}

def boost(l,v):
 c=(l+1/l)/2;s=(l-1/l)/2
 return c*v[0]+s*v[1],s*v[0]+c*v[1]
def sub(v,w):return tuple(x-y for x,y in zip(v,w))
def add(v,w):return tuple(x+y for x,y in zip(v,w))
def construct(v,target):
 # Reflection of v and subgroup +,- yield one nonzero pureaxis.
 if abs(v[0])>=abs(v[1]):axis=0;a=2*v[0]
 else:axis=1;a=2*v[1]
 assert a!=0
 pure=(a,0.) if axis==0 else (0.,a)
 def opposite(y):
  s=y/a;root=math.hypot(s,2.)
  l=(s+root)/2 if s>=0 else 2/(root-s)
  return sub(boost(l,pure),boost(1/l,pure))
 def original(y):
  z=y/.75
  return sub(boost(2.,opposite(z)),opposite(1.25*z))
 result=add(original(target[axis]),opposite(target[1-axis]))
 return max(abs(result[i]-target[i]) for i in (0,1))

def constructive_checks():
 rng=random.Random(503);cases=[]
 for v in [(1.,1.),(1.,-1.),(2.,.3),(.3,2.),(-1.,0.),(0.,-1.)]:
  for target in [(0.,0.),(1.,0.),(0.,1.),(-3.,4.),(7.,-2.)]:cases.append((v,target))
 for _ in range(200):
  v=(rng.uniform(-5,5),rng.uniform(-5,5));target=(rng.uniform(-10,10),rng.uniform(-10,10))
  cases.append((v,target))
 errs=[construct(v,t) for v,t in cases];assert max(errs)<1e-10
 # Proper pi rotation about z flips x and y: its restriction to tx-plane
 # is the reflection used by the1+1 proof, with determinant(+1).
 R=(-1,-1,1);assert math.prod(R)==1
 assert (R[0]*2,R[1]*0,R[2]*0)==(-2,0,0)
 return {'finite_generator_constructions':len(cases),'max_absolute_error':max(errs),
         'proper_spatial_rotation_restricts_to_plane_reflection':True,
         'scope':'Floating arithmetic corroborates a constructive proof; separate Lean modules provide real1+1 and3+1 kernel verification'}

def main():
 result={'status':'PASS','exact':exact_checks(),'constructive':constructive_checks(),
         'scope':'Countermodel/arithmetic corroboration only; complete analytic proof and Lean status separate'}
 (ROOT/'reciprocal_geometry_results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
