#!/usr/bin/env python3
"""Concrete countermodels to marginal-only and diagonal-only overclaims.

These are exact finite-model checks, not experimental data or an experience test.
"""
from pathlib import Path
from fractions import Fraction as F
import json
import numpy as np

ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)


def diagonal_countermodel():
    # Shared independent coin: keep both bits or reset both to zero.
    rows=[]
    targets=[0,1,-1,0]
    for ab in range(4):
        row=[F(0)]*4
        row[0]+=F(1,2)
        row[ab]+=F(1,2)
        rows.append(row)
    marginal_checks=[]
    for ab,row in enumerate(rows):
        a,b=divmod(ab,2)
        p_m=sum(row[z] for z in range(4) if z//2)
        p_l=sum(row[z] for z in range(4) if z%2)
        assert p_m==F(a,2) and p_l==F(b,2)
        marginal_checks.append([str(p_m),str(p_l)])
    score=sum(rows[ab][z]/4 for ab in range(4) for z in range(4)
              if z%2-z//2==targets[ab])
    assert score==F(3,4)
    return {'local_survivals':[.5,.5], 'joint_survival_on_11':.5,
            'conditional_law':[[str(x) for x in row] for row in rows],
            'local_marginals':marginal_checks,
            'directed_score':float(score),'incorrect_product_prediction':.625,
            'scope':'Refutes inference of independent joint law from local calibrations alone.'}


def coherent_countermodel():
    eye=np.eye(4,dtype=complex)
    ket=[eye[:,i] for i in range(4)]
    plus=(ket[1]+ket[2])/np.sqrt(2)
    minus=(ket[1]-ket[2])/np.sqrt(2)
    proj=lambda v:np.outer(v,v.conj())
    rho=[proj(ket[0]),.5*(proj(ket[0])+proj(ket[1])),
         .5*(proj(ket[0])+proj(ket[2])),proj(plus)]
    effects={0:proj(ket[0])+proj(plus)+proj(ket[3]),
             1:proj(minus),-1:np.zeros((4,4),complex)}
    assert np.allclose(sum(effects.values()),eye)
    for e in effects.values():assert np.linalg.eigvalsh(e).min()>-1e-12
    marginal_diagonals=[]
    for ab,r in enumerate(rho):
        a,b=divmod(ab,2)
        reshaped=r.reshape(2,2,2,2)
        m=np.trace(reshaped,axis1=1,axis2=3)
        l=np.trace(reshaped,axis1=0,axis2=2)
        assert np.allclose(m,np.diag([1-a/2,a/2]))
        assert np.allclose(l,np.diag([1-b/2,b/2]))
        marginal_diagonals.append([np.diag(m).real.tolist(),np.diag(l).real.tolist()])
    target=[0,1,-1,0]
    score=sum(np.trace(r@effects[d]).real/4 for r,d in zip(rho,target))
    assert abs(score-9/16)<1e-12
    assert abs(rho[3][3,3])<1e-12
    return {'local_survivals':[.5,.5],'joint_11_population':0,
            'local_marginals':marginal_diagonals,
            'explicit_POVM_score':float(score),
            'incorrect_diagonal_joint_prediction':.5,
            'scope':'Refutes use of a diagonal joint-law formula after dropping joint diagonality.'}


def main():
    result={'status':'PASS','shared_coin':diagonal_countermodel(),
            'coherent_joint_state':coherent_countermodel(),
            'scope':'Internal adversarial finite countermodels, not laboratory observations.'}
    (ROOT/'adversarial_joint_resources_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
