#!/usr/bin/env python3
"""Exact finite matrix implementation of the three-qubit witness.

Numerical matrix identities verify code, not a material autonomous apparatus.
Basis order is |S,E,R>, most significant bit first. No third-party source code.
"""
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)
import numpy as np
from scipy.linalg import expm


def gate(action):
    out = np.zeros((8, 8))
    for k in range(8):
        bits = [(k >> shift) & 1 for shift in (2, 1, 0)]
        nxt = action(bits.copy())
        j = 4*nxt[0]+2*nxt[1]+nxt[2]
        out[j, k] = 1
    return out


def cnot(c, t):
    def action(bits):
        bits[t] ^= bits[c]
        return bits
    return gate(action)


def swap(a, b):
    def action(bits):
        bits[a], bits[b] = bits[b], bits[a]
        return bits
    return gate(action)


def reduced_s(psi):
    mat = psi.reshape(2, 4)
    return mat @ mat.conj().T


def trace_distance(a, b):
    return float(np.abs(np.linalg.eigvalsh(a-b)).sum()/2)


def main():
    gates = [cnot(0, 1), swap(0, 2), cnot(1, 0)]
    gate_checks = []
    for u in gates:
        assert np.allclose(u, u.T)
        assert np.allclose(u @ u, np.eye(8))
        h = np.pi*(np.eye(8)-u)/2  # hbar=tau=1
        eig = np.linalg.eigvalsh(h)
        err = float(np.max(np.abs(expm(-1j*h)-u)))
        assert eig.min() >= -1e-12 and err < 1e-12
        gate_checks.append({'H_eigenvalues': eig.tolist(), 'exp_identity_max_error': err})
    runs = []
    before, after = [], []
    for x in (0, 1):
        psi = np.eye(8)[:, 4*x]
        path = [4*x]
        for j, u in enumerate(gates):
            psi = u @ psi
            path.append(int(np.argmax(np.abs(psi))))
            if j == 1:
                before.append(reduced_s(psi))
        after.append(reduced_s(psi))
        runs.append({'x': x, 'basis_index_path': path})
    d0 = trace_distance(*before)
    d1 = trace_distance(*after)
    assert d0 == 0 and d1 == 1
    result = {'status': 'PASS', 'basis_order': '|S,E,R>', 'runs': runs,
              'present_reduced_trace_distance': d0,
              'after_retrieval_trace_distance': d1, 'gate_checks': gate_checks,
              'scope': 'unitary gate and reduced-state calculation; no autonomous clock or laboratory verification'}
    target = OUT/'quantum_retrieval_results.json'
    target.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': 'PASS', 'before': d0, 'after': d1,
                      'maximum_gate_error': max(x['exp_identity_max_error'] for x in gate_checks),
                      'output': target.name}, indent=2))


if __name__ == '__main__':
    main()
