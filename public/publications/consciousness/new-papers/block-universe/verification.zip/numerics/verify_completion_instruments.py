#!/usr/bin/env python3
"""Independent exact-form construction checks for the robust ready-cut bound.

This verifies finite matrices against the analytic coherent-completion frontier.
All q-subset instruments preserve the maximally mixed reference marginal.
"""
from itertools import combinations
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)
import json
import math
import numpy as np


def run_case(d, q, epsilon):
    s=d  # Match the manuscript theorem: current S and reference R both have dimension d.
    memory_dim=s*q
    subsets=list(combinations(range(d),q))
    m=len(subsets)
    effective=min(epsilon,1-q/d)
    total=np.zeros((d,d))
    ref=np.zeros(d)
    scores=[]
    ready=[]
    for A in subsets:
        A=set(A); Ac=[i for i in range(d) if i not in A]
        V=np.zeros((memory_dim,d))
        for z,i in enumerate(sorted(A)):V[z,i]=1
        for z,i in enumerate(Ac):V[q+z,i]=1
        assert np.allclose(V.T@V,np.eye(d))
        weights=np.array([math.sqrt((1-effective)/q) if i in A else
                          math.sqrt(effective/(d-q)) for i in range(d)])
        K=math.sqrt(d/m)*V@np.diag(weights)
        total+=K.T@K
        # Normalized branch following the maximally entangled input.
        psi=(K.T/math.sqrt(d)).reshape(d,memory_dim)
        probability=float(np.linalg.norm(psi)**2)
        assert abs(probability-1/m)<1e-12
        psi/=math.sqrt(probability)
        ready_probability=float(np.linalg.norm(psi[:,:q])**2)
        assert abs(ready_probability-(1-effective))<1e-12
        ref+=probability*np.sum(np.abs(psi)**2,axis=1)
        # Decoder V† is isometric on the branch's support; its CPTP extension is free.
        returned=psi@V
        bell_amplitude=float(np.trace(returned)/math.sqrt(d))
        scores.append(probability*bell_amplitude**2)
        ready.append(ready_probability)
    assert np.allclose(total,np.eye(d),atol=1e-12)
    assert np.allclose(ref,np.ones(d)/d,atol=1e-12)
    actual=sum(scores)
    predicted=(math.sqrt((q/d)*(1-epsilon))+math.sqrt((1-q/d)*epsilon))**2 if epsilon<=1-q/d else 1.
    assert abs(actual-predicted)<2e-12
    return {'d':d,'q':q,'S_dimension':s,'epsilon_upper_bound':epsilon,
            'realized_nonready_probability':effective,'classical_labels':m,
            'entanglement_fidelity':actual,'analytic_bound':predicted,
            'completeness_max_error':float(np.max(np.abs(total-np.eye(d)))),
            'reference_marginal_max_error':float(np.max(np.abs(ref-np.ones(d)/d)))}


def main():
    cases=[]
    for d in range(2,8):
        for q in range(1,d):
            edge=1-q/d
            for epsilon in sorted(set([0,.01,.1,edge/2,edge,min(1,edge+.1)])):
                cases.append(run_case(d,q,epsilon))
    result={'status':'PASS','scope':'free-design hybrid ready-cut frontier; not attainment for a prescribed source',
            'cases':cases,'case_count':len(cases),
            'max_fidelity_error':max(abs(c['entanglement_fidelity']-c['analytic_bound']) for c in cases)}
    target=OUT/'completion_instruments_results.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','cases':len(cases),'max_fidelity_error':result['max_fidelity_error']},indent=2))


if __name__=='__main__':main()
