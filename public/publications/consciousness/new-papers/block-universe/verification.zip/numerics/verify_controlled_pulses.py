#!/usr/bin/env python3
"""Independent finite-pulse check for the common controlled-history intervention."""
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)
import json
import numpy as np
from scipy.linalg import expm

I=np.eye(2,dtype=complex)
W=np.array([[1.,1.],[1.,-1.]],complex)/np.sqrt(2)
P0=np.diag([1.,0.]).astype(complex)
P1=np.diag([0.,1.]).astype(complex)

def ptrace_e(r):
    return np.trace(r.reshape(2,2,2,2),axis1=0,axis2=2)

cases=[]
for T in (.1,1.,3.7):
    for tau in (.03,.5,2.):
        # Interaction is OFF during each pulse; S is protected during switching.
        pulse_h=np.pi*(I-W)/(2*tau)
        pulse=expm(-1j*tau*pulse_h)
        assert np.linalg.eigvalsh(pulse_h).min()>-1e-12
        assert np.max(np.abs(pulse-W))<1e-13
        dwell_h=np.pi*np.kron(P1,P1)/T
        dwell=expm(-1j*T*dwell_h)
        total=np.kron(I,pulse)@dwell@np.kron(I,pulse)
        errors=[]
        for lam,Pe in enumerate((P0,P1)):
            final=ptrace_e(total@np.kron(Pe,P0)@total.conj().T)
            target=(P0,P1)[lam]
            errors.append(float(np.max(np.abs(final-target))))
        assert max(errors)<1e-13
        cases.append({'dwell_T':T,'pulse_duration':tau,'total_duration':T+2*tau,
                      'pulse_norm':float(np.linalg.norm(pulse_h,2)),
                      'interaction_norm':float(np.linalg.norm(dwell_h,2)),
                      'output_max_entry_error':max(errors)})
report={'status':'PASS','cases':cases,
        'assumptions':'Common finite pulses, E-S interaction isolated during pulses, protected S between operations; input-independent control schedule',
        'scope':'Matrix corroboration of existing analytic finite-pulse implementation, not an apparatus calibration'}
(OUT/'controlled_pulses_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
