#!/usr/bin/env python3
"""Independent implementation of finite temporal-model checks.

The finite observer is an explicit toy interpreter, not a human, a consciousness
detector, an empirical fit, or a quantum memory witness.
Only the observer's admitted registers enter its query/update operations; the
experimenter's input lists and immutable snapshots are not decoder resources.
Core calculations use the Python standard library only.
"""
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from itertools import permutations, product
from math import exp, isclose, log, log2, sqrt
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)


def assert_close(actual, expected, tolerance=1e-10):
    assert abs(actual-expected) <= tolerance, (actual, expected, tolerance)


def binary_entropy(p):
    return 0. if p in (0., 1.) else -p*log2(p)-(1-p)*log2(1-p)


def order_code_checks():
    """Optimize the decision independently by counting code/label fibers."""
    pairs = list(permutations(('C', 'E', 'G'), 2))
    def score(code):
        groups = defaultdict(Counter)
        for pair in pairs:
            unordered = tuple(sorted(pair))
            orientation = int(pair[0] != unordered[0])
            groups[(code(pair), unordered)][orientation] += 1
        return sum(max(count.values()) for count in groups.values())/len(pairs)
    ordered = {pair:pair for pair in pairs}
    bags = {pair:tuple(sorted(pair)) for pair in pairs}
    assert len(set(ordered.values())) == 6
    assert len(set(bags.values())) == 3
    assert_close(score(lambda pair:pair), 1.)
    assert_close(score(lambda pair:tuple(sorted(pair))), .5)
    # Enumerate the joint BSC law, rather than only evaluating the Fano formula.
    probability = {(q,y,x): (1/3)*.5*(.9 if x==y else .1)
                   for q in range(3) for y in range(2) for x in range(2)}
    pxq = defaultdict(float)
    for (q,y,x),p in probability.items(): pxq[(x,q)] += p
    h_conditional = -sum(p*log2(p/pxq[(x,q)])
                        for (q,y,x),p in probability.items())
    mutual_information = 1-h_conditional
    assert_close(mutual_information, 1-binary_entropy(.1))
    return {'ordered_cases':6, 'ordered_codes':6, 'bag_codes':3,
            'optimal_balanced_bag_accuracy':score(lambda p:tuple(sorted(p))),
            'optimal_balanced_order_code_accuracy':score(lambda p:p),
            'equiprobable_ordered_pair_entropy_bits':log2(6),
            'fixed_length_binary_bits':3,
            'orientation_information_at_error_0_1_bits':mutual_information}


@dataclass(frozen=True)
class Signal:
    """Delivered data. No actual source timestamp is provided to the observer."""
    name: str
    arrival_ms: float
    estimated_delay_ms: float


@dataclass(frozen=True)
class Uptake:
    occasion_ms: float
    represented_order: tuple | None
    retained_names: tuple
    live_name: str
    taken_up: bool


class Observer:
    """Finite functional toy with admitted delivery, trace and uptake registers."""
    def __init__(self, latency_ms=5., resolution_ms=5., trace_window_ms=230.):
        self.latency_ms = latency_ms
        self.resolution_ms = resolution_ms
        self.trace_window_ms = trace_window_ms
        self.received = []
        self.last_uptake = None
        self.retained_construction = None
        self.phrase = None
        self.learned_continuation = {('C','E'):{'G':.75,'D':.25}}

    def receive(self, signal, uptake_gate=True):
        assert all(signal.name != old.name for old in self.received)
        assert not self.received or signal.arrival_ms >= self.received[-1].arrival_ms
        occasion = signal.arrival_ms+self.latency_ms
        # Registers outside the operative trace horizon cannot silently enter use.
        eligible = [old for old in self.received
                    if occasion-old.arrival_ms <= self.trace_window_ms]
        self.received.append(signal)
        if not eligible:
            self.last_uptake = None
            return None
        contributions = eligible+[signal]
        # Calibration uses delivered arrival and retained learned delay only.
        represented = sorted(contributions,
                             key=lambda s:s.arrival_ms-s.estimated_delay_ms)
        times = [s.arrival_ms-s.estimated_delay_ms for s in represented]
        unresolved = any(b-a <= self.resolution_ms for a,b in zip(times,times[1:]))
        order = None if unresolved else tuple(s.name for s in represented)
        self.retained_construction = order
        self.last_uptake = Uptake(occasion,order,tuple(s.name for s in eligible),
                                 signal.name,uptake_gate)
        # Explicit phrase consolidation is a separate executed operation.
        if len(contributions)>=3 and uptake_gate and order is not None:
            self.phrase = order
        return self.last_uptake

    def query(self):
        return self.retained_construction

    def prediction(self):
        key = None if self.last_uptake is None else self.last_uptake.represented_order
        return dict(self.learned_continuation.get(key,{}))

    def snapshot(self):
        return (tuple(self.received),self.last_uptake,self.retained_construction,
                self.phrase,tuple(sorted(self.prediction().items())))

    def erase_episode(self):
        self.received.clear()
        self.last_uptake = None
        self.retained_construction = None
        self.phrase = None


def enactment_checks():
    observer = Observer()
    observer.receive(Signal('C',10.,10.))
    pair = observer.receive(Signal('E',110.,10.))
    assert pair.occasion_ms == 115. < 210.
    assert pair.represented_order == ('C','E')
    assert pair.retained_names == ('C',) and pair.live_name == 'E'
    assert pair.taken_up
    prefix = observer.snapshot()
    prediction = observer.prediction()
    assert prediction == {'G':.75,'D':.25}
    # Two environments agree locally up to E, but then supply different futures.
    branches = {}
    for continuation in ('G','D'):
        branch = Observer()
        branch.receive(Signal('C',10.,10.))
        branch.receive(Signal('E',110.,10.))
        assert branch.snapshot() == prefix
        before = branch.prediction()
        assert before == prediction
        branch.receive(Signal(continuation,210.,10.))
        assert branch.phrase == ('C','E',continuation)
        branches[continuation] = {'surprise_nats':-log(before[continuation]),
                                  'phrase':list(branch.phrase)}
    assert branches['G']['phrase'] != branches['D']['phrase']
    omission = {'occasion_ms':216.,'kind':'expected note not received',
                'prediction':prediction,'received_future_note':False}
    assert omission['received_future_note'] is False
    # This route is optional later retrieval; no original source list is passed.
    assert observer.query() == ('C','E')
    previous = observer.last_uptake
    observer.erase_episode()
    assert observer.query() is None and observer.received == []
    assert previous.represented_order == ('C','E') and previous.taken_up
    # A dormant route can preserve the order while the current uptake gate is off.
    dormant = Observer()
    dormant.receive(Signal('C',10.,10.))
    dormant_pair = dormant.receive(Signal('E',110.,10.),uptake_gate=False)
    assert dormant.query() == ('C','E') and not dormant_pair.taken_up
    # Equal and sub-resolution gaps do not receive order from identifiers or input order.
    unresolved_cases = []
    for gap in (0.,1.,5.):
        for first,second in (('C','E'),('E','C')):
            test = Observer()
            test.receive(Signal(first,10.,10.))
            result = test.receive(Signal(second,10.+gap,10.))
            assert result.represented_order is None
            unresolved_cases.append({'gap_ms':gap,'arrival_order':[first,second]})
    # A one-event response does not manufacture its own predecessor.
    singleton = Observer()
    assert singleton.receive(Signal('C',10.,10.)) is None
    # Exhaust the six named order cases through the same event-driven update.
    all_pairs = []
    for first,second in permutations(('C','E','G'),2):
        test = Observer();test.receive(Signal(first,10.,10.))
        result = test.receive(Signal(second,110.,10.))
        assert result.represented_order == (first,second)
        all_pairs.append(list(result.represented_order))
    return {'pair_uptake':asdict(pair),'third_reception_ms':210.,
            'all_six_pair_constructions':all_pairs,
            'identical_local_prefixes_checked':2,'continuations':branches,
            'omission':omission,'unresolved_cases':unresolved_cases,
            'retrieval_after_erasure':observer.query(),
            'earlier_snapshot_after_later_erasure':asdict(previous),
            'dormant_route':{'query_succeeds':True,'actual_pair_uptake':False},
            'scope':'Explicit functional toy; no experiential admission inferred'}


def calibration_checks():
    # Analyst supplies actual source schedule only to create delivered signals.
    actual_sources = {'C':0.,'E':50.}
    actual_delays = {'C':80.,'E':10.}
    received = [Signal(name,actual_sources[name]+actual_delays[name],actual_delays[name])
                for name in ('C','E')]
    received.sort(key=lambda s:s.arrival_ms)
    assert tuple(s.name for s in received) == ('E','C')
    corrected = Observer()
    for signal in received: result = corrected.receive(signal)
    assert result.represented_order == ('C','E')
    # Without learned correction, exactly the same delivered signals yield arrival order.
    raw = Observer()
    for signal in received: raw_result = raw.receive(Signal(signal.name,signal.arrival_ms,0.))
    assert raw_result.represented_order == ('E','C')
    # Independent interval check: Delta_hat = Delta_true + e2-e1.
    # Therefore |Delta_true-Delta_hat|<=eta1+eta2; every interval corner is tested.
    calibration_margin_cases = []
    for inferred in (-50.,-10.,0.,10.,50.):
        eta1,eta2 = 4.,7.
        possible = [inferred+e2-e1 for e1,e2 in product((-eta1,eta1),(-eta2,eta2))]
        guaranteed = abs(inferred)>eta1+eta2
        if guaranteed: assert all(v*inferred>0 for v in possible)
        else: assert min(possible)<=0<=max(possible)
        calibration_margin_cases.append({'inferred_gap_ms':inferred,
                                         'source_gap_interval_ms':[min(possible),max(possible)],
                                         'guaranteed_sign':guaranteed})
    return {'source_order':['C','E'],'arrival_order':[s.name for s in received],
            'arrivals_ms':{s.name:s.arrival_ms for s in received},
            'arrival_based_interpretation':list(raw_result.represented_order),
            'calibrated_interpretation':list(result.represented_order),
            'interpretation_occasion_ms':result.occasion_ms,
            'observer_receives_actual_source_timestamps':False,
            'uncertainty_cases':calibration_margin_cases}


def component_checks():
    resistance,capacitance = 250_000.,1e-6
    time_constant = resistance*capacitance
    threshold,initial = .4,1.
    tau_min = time_constant*.95**2
    tau_max = time_constant*1.05**2
    minimum_short = initial*exp(-.1/tau_min)
    maximum_long = initial*exp(-.3/tau_max)
    assert minimum_short>.42 and maximum_long<.38
    # Check all grid points as corroboration of analytic monotone endpoint bounds.
    grid = [0.95+i*.0125 for i in range(9)]
    checks = 0
    for r,c,th in product(grid,grid,(.38,.40,.42)):
        tau = time_constant*r*c
        assert exp(-.1/tau)>th
        assert exp(-.3/tau)<th
        checks += 1
    result = {'R_ohm':resistance,'C_farad':capacitance,'RC_seconds':time_constant,
              'maximum_nominal_detectable_gap_seconds':time_constant*log(initial/threshold),
              'trace_at_100ms_volt':exp(-.1/time_constant),
              'trace_at_300ms_volt':exp(-.3/time_constant),
              'minimum_short_trace_volt':minimum_short,
              'maximum_long_trace_volt':maximum_long,
              'worst_short_margin_volt':minimum_short-.42,
              'worst_long_margin_volt':.38-maximum_long,
              'tolerance_grid_cases':checks,
              'initial_capacitor_energy_joule':.5*capacitance*initial**2,
              'scope':'Component calculation; excludes whole-device energy and complete human uptake'}
    assert_close(result['maximum_nominal_detectable_gap_seconds'],.22907268296853878)
    assert_close(result['trace_at_100ms_volt'],.6703200460356393)
    assert_close(result['trace_at_300ms_volt'],.30119421191220214)
    return result


def pace_checks():
    alpha,beta,kappa,eta,rho = .8,.4,1.,1.,.15
    def model(boundaries,endpoint,B=20.):
        return alpha*B+beta*boundaries,kappa*log((boundaries/B)/rho)+eta*log(endpoint/B)
    cases = []
    for name,N,E in [('baseline',3,20),('more events',7,20),
                      ('earlier endpoint',3,10),('later endpoint',3,40)]:
        D,J = model(N,E)
        cases.append({'condition':name,'boundaries':N,'endpoint_seconds':E,
                      'duration_seconds':D,'pace_descriptor':J})
    assert_close(cases[0]['duration_seconds'],17.2)
    assert_close(cases[1]['duration_seconds'],18.8)
    assert_close(cases[1]['pace_descriptor'],log(7/3))
    assert_close(cases[2]['pace_descriptor'],-log(2))
    assert_close(cases[3]['pace_descriptor'],log(2))
    # Independent central finite differences in (N,ln E).
    step=1e-4;N=3.;ellE=log(20.)
    plusN,minusN=model(N+step,exp(ellE)),model(N-step,exp(ellE))
    plusE,minusE=model(N,exp(ellE+step)),model(N,exp(ellE-step))
    matrix = [[(plusN[i]-minusN[i])/(2*step),
               (plusE[i]-minusE[i])/(2*step)] for i in range(2)]
    determinant = matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0]
    assert_close(determinant,beta*eta,1e-8)
    return {'constructed_cases':cases,'finite_difference_jacobian':matrix,
            'determinant':determinant,'analytic_determinant':beta*eta,
            'empirical_fit':False,
            'warning':'Opposite slopes under one intervention alone do not establish two latent dimensions'}


def clock_checks():
    GM,R,h,c,omega=3.986004418e14,6378137.,400_000.,299792458.,7.292115e-5
    gravitational=GM/c**2*(1/R-1/(R+h))
    kinematic=((omega*R)**2-GM/(R+h))/(2*c**2)
    rate=gravitational+kinematic
    daily=rate*86400*1e6
    assert abs(gravitational*86400*1e6-3.5454)<.0001
    assert abs(kinematic*86400*1e6+28.1624)<.0001
    assert abs(daily+24.6170)<.0001
    # Any common proper-time accumulation cancels in a local process/watch ratio.
    for nu,tau in product((.2,1.,1000.),(.1,60.,100_000.)):
        assert_close((nu*tau)/tau,nu)
    return {'gravitational_microseconds_per_day':gravitational*86400*1e6,
            'kinematic_microseconds_per_day':kinematic*86400*1e6,
            'net_microseconds_per_day':daily,
            '340day_difference_milliseconds':daily*340/1000,
            '60second_difference_nanoseconds':rate*60*1e9,
            'common_proper_time_ratio_cases':9,
            'scope':'Illustrative weak-field trajectories, not a reconstructed mission or human timing fit'}


def admission_specification_checks():
    # Six other conditions plus U and R_later = 256 independent Boolean settings.
    names=('bounded_unit','D','I','C','M','H')
    def admission(values,U,Rlater):
        del Rlater
        return all(values) and U
    admitted=0;later_independence=0;absent_u=0
    for bits in product((False,True),repeat=8):
        other,U,Rlater=bits[:6],bits[6],bits[7]
        actual=admission(other,U,Rlater)
        assert actual==admission(other,U,not Rlater)
        later_independence+=1
        if not U: assert not actual;absent_u+=1
        if all(other) and U: assert actual
        admitted+=int(actual)
    assert admitted==2 and absent_u==128 and later_independence==256
    assert admission((True,)*6,True,False)
    assert not admission((True,)*6,False,True)
    return {'assignments':256,'other_condition_names':names,
            'admitted_assignments':admitted,'Rlater_independence_checks':later_independence,
            'absent_U_rejections':absent_u,
            'fleeting_U_with_no_later_access_admitted':True,
            'unused_later_capacity_without_U_admitted':False,
            'scope':'Formal constitutive specification only; no physical or experiential detection claim'}


def main():
    results={'status':'PASS',
             'implementation':'Independent finite temporal models; no experimental observations',
             'order_information':order_code_checks(),
             'temporal_enactment':enactment_checks(),
             'arrival_calibration':calibration_checks(),
             'finite_RC_component':component_checks(),
             'constructed_pace_model':pace_checks(),
             'proper_time_comparison':clock_checks(),
             'admission_dependency_specification':admission_specification_checks(),
             'experiment_performed':False}
    (ROOT/'temporal_models_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'status':'PASS','implementation':results['implementation'],
                      'ordered_pairs':6,'bag_orientation_accuracy':.5,
                      'pair_uptake_ms':115,'before_third_reception_ms':210,
                      'unresolved_gap_cases':6,'RC_tolerance_grid_cases':243,
                      'admission_assignments':256,
                      'pace_jacobian_determinant':results['constructed_pace_model']['determinant'],
                      'output':'temporal_models_results.json'},indent=2))


if __name__=='__main__':main()
