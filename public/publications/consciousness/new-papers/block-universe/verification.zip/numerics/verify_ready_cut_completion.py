#!/usr/bin/env python3
"""Checks ready-subsystem quantum completion bounds and a key countermodel.

Known ingredients: Schmidt-rank singlet-fraction bound and quantum one-time pad.
This checks their causal-cut composition; no laboratory experiment is simulated.
"""
from itertools import combinations
from pathlib import Path
import json
import numpy as np

ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)


def pure(v): return np.outer(v,v.conj())


def bell(d):
    v=np.eye(d,dtype=complex).reshape(-1)/np.sqrt(d)
    return v,pure(v)


def dist(a,b): return float(np.abs(np.linalg.eigvalsh(a-b)).sum()/2)


def partial_trace(rho,dims,keep):
    # The retained subsystem order is the original order.
    arr=rho.reshape(tuple(dims)+tuple(dims))
    remaining=list(dims)
    for k in reversed(range(len(dims))):
        if k not in keep:
            arr=np.trace(arr,axis1=k,axis2=k+len(remaining))
            remaining.pop(k)
    n=int(np.prod(remaining))
    return arr.reshape(n,n)


def subset_channel_test(d,q):
    _,phi=bell(d)
    subs=list(combinations(range(d),q))
    coverage=sum(0 in a for a in subs)
    total=np.zeros((d,d),dtype=complex)
    choi=np.zeros((d*d,d*d),dtype=complex)
    for a in subs:
        p=np.diag([float(j in a) for j in range(d)])
        k=p/np.sqrt(coverage)
        total+=k.conj().T@k
        m=np.kron(np.eye(d),k)
        choi+=m@phi@m.conj().T
    assert np.allclose(total,np.eye(d))
    f=float(np.trace(phi@choi).real)
    assert abs(f-q/d)<1e-12
    return {'d':d,'quantum_dimension':q,'classical_outcomes':len(subs),
            'entanglement_fidelity':f,'bound':q/d}


def random_rank_tests(rng):
    n=0
    for d in range(2,7):
        v,phi=bell(d)
        for q in range(1,d+1):
            for _ in range(30):
                # Any local channel preserves the rank bound on each pure branch.
                a=rng.normal(size=(d,q))+1j*rng.normal(size=(d,q))
                b=rng.normal(size=(d,q))+1j*rng.normal(size=(d,q))
                m=a@b.T
                psi=m.reshape(-1);psi/=np.linalg.norm(psi)
                f=abs(np.vdot(v,psi))**2
                assert f<=q/d+1e-12
                n+=1
    return n


def gentle_tests(rng):
    maximum_slack=-1
    count=0
    for _ in range(200):
        # Dimensions R=2,S=2,Q=2. Verify normalized pure-ready projection.
        psi=rng.normal(size=8)+1j*rng.normal(size=8)
        psi/=np.linalg.norm(psi)
        p=np.kron(np.eye(2),np.kron(np.diag([1.,0.]),np.eye(2)))
        prob=float(np.vdot(psi,p@psi).real)
        proj=p@psi/np.sqrt(prob)
        actual=dist(pure(psi),pure(proj))
        bound=np.sqrt(1-prob)
        assert abs(actual-bound)<1e-12
        maximum_slack=max(maximum_slack,actual-bound)
        count+=1
    return {'cases':count,'maximum_error':maximum_slack}


def one_time_pad_test():
    _,phi=bell(2)
    paulis=[np.eye(2),np.array([[0,1],[1,0]]),
            np.array([[0,-1j],[1j,0]]),np.diag([1,-1])]
    encrypted=np.zeros((4,4),dtype=complex)
    decoded=np.zeros((4,4),dtype=complex)
    for u in paulis:
        a=np.kron(np.eye(2),u)
        rho=a@phi@a.conj().T
        encrypted+=rho/4
        decoded+=a.conj().T@rho@a/4
    assert np.allclose(encrypted,np.eye(4)/4)
    assert np.allclose(decoded,phi)
    return {'RS_marginal_distance_from_product':dist(encrypted,np.eye(4)/4),
            'outside_memory':'four-valued classical key, no outside quantum memory',
            'local_ready_probability':.5,
            'returned_entanglement_fidelity':float(np.trace(phi@decoded).real),
            'lesson':'product RS alone cannot localize coherent completion outside S; pure-ready premise matters'}


def sharp_nearly_ready_qubit():
    _,phi=bell(2)
    x=np.array([[0,1],[1,0]],dtype=complex)
    out=[]
    for eps in (0,.0001,.001,.01,.025,.05,.1,.2,.3,.4,.5):
        a,b=np.sqrt(1-eps),np.sqrt(eps)
        kraus=[np.diag([a,b]),np.array([[0,a],[b,0]])]
        assert np.allclose(sum(k.conj().T@k for k in kraus),np.eye(2))
        at_cut=np.zeros((4,4),dtype=complex)
        returned=np.zeros((4,4),dtype=complex)
        for c,k in enumerate(kraus):
            op=np.kron(np.eye(2),k)
            branch=op@phi@op.conj().T
            at_cut+=branch
            decoder=np.kron(np.eye(2),np.eye(2) if c==0 else x)
            returned+=decoder@branch@decoder.conj().T
        rho_s=partial_trace(at_cut,[2,2],[1])
        rho_r=partial_trace(at_cut,[2,2],[0])
        ready=float(rho_s[0,0].real)
        f=float(np.trace(phi@returned).real)
        predicted=.5+np.sqrt(eps*(1-eps))
        assert abs(ready-(1-eps))<1e-12
        assert np.allclose(rho_r,np.eye(2)/2)
        assert abs(f-predicted)<1e-12
        out.append({'epsilon':eps,'ready_probability':ready,
                    'fidelity':f,'sharp_bound':predicted,
                    'reference_stays_maximally_mixed':True})
    return out


def main():
    rng=np.random.default_rng(20261022)
    saturation=[subset_channel_test(d,q) for d in range(2,9) for q in range(1,d+1)]
    radii=[]
    for d in range(2,9):
        _,phi=bell(d)
        optimum=dist(phi,np.eye(d*d)/(d*d))
        assert abs(optimum-(1-1/d**2))<1e-12
        radii.append({'d':d,'minimum_S_only_entangled_test_error':optimum,
                      'formula':1-1/d**2})
    result={'status':'PASS','subset_memory_saturation':saturation,
            'rank_bound_random_checks':random_rank_tests(rng),
            'ready_projection_checks':gentle_tests(rng),
            'S_only_trace_distance':radii,'one_time_pad_countermodel':one_time_pad_test(),
            'sharp_nearly_ready_qubit':sharp_nearly_ready_qubit(),
            'scope':'finite numerical corroboration of analytic proofs; no experimental confirmation'}
    (ROOT/'ready_cut_completion_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','saturation_cases':len(saturation),
                      'rank_checks':result['rank_bound_random_checks'],
                      'projection_checks':result['ready_projection_checks']['cases'],
                      'qubit_S_only_error':radii[0]['minimum_S_only_entangled_test_error'],
                      'sharp_qubit_noise_cases':len(result['sharp_nearly_ready_qubit']),
                      'key_countermodel_fidelity':result['one_time_pad_countermodel']['returned_entanglement_fidelity']},indent=2))


if __name__=='__main__':main()
