#!/usr/bin/env python3
"""Exhaustive exact-rational checks of joint-record decision frontiers."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)
import json, math
import numpy as np
from scipy.linalg import expm

D=(0,1,-1,0)
def bayes(ch, target, prior=None):
    prior = [Q(1,4)]*4 if prior is None else prior
    labels=sorted(set(target))
    return sum(max(sum(prior[i]*ch[i][z] for i in range(4) if target[i]==y) for y in labels) for z in range(len(ch[0])))

def law(p,q,j):
    return [[Q(1),Q(0),Q(0),Q(0)], [1-q,q,Q(0),Q(0)], [1-p,Q(0),p,Q(0)], [1-p-q+j,q-j,p-j,j]]

def brute(ch,target):
    labels=sorted(set(target))
    return max(sum(ch[i][z] for i in range(4) for z in range(4) if d[z]==target[i])/4 for d in product(labels,repeat=4))

count=0
for ip,iq in product(range(7),repeat=2):
    p,q=Q(ip,6),Q(iq,6)
    for ij in range(max(0,ip+iq-6),min(ip,iq)+1):
        j=Q(ij,6);ch=law(p,q,j)
        assert all(x>=0 for row in ch for x in row)
        assert all(sum(row)==1 for row in ch)
        assert bayes(ch,D)==(1+j)/2==brute(ch,D)
        assert bayes(ch,range(4))==(1+p+q+j)/4==brute(ch,range(4))
        count+=1

# Marginally source-independent auxiliary; complete ML table stays product.
aux=[[Q(0)]*8 for _ in range(4)]
# Index is 2*ML+R.
for i,zs in enumerate([[(0,Q(1,2)),(1,Q(1,2))],[(2,Q(1,2)),(1,Q(1,2))],[(4,Q(1,2)),(1,Q(1,2))],[(0,Q(1,4)),(4,Q(1,4)),(3,Q(1,4)),(7,Q(1,4))]]):
    for z,v in zs:aux[i][z]=v
ml=[[row[2*z]+row[2*z+1] for z in range(4)] for row in aux]
assert ml==law(Q(1,2),Q(1,2),Q(1,4))
assert all(sum(row[r::2])==Q(1,2) for row in aux for r in range(2))
assert bayes(aux,D)==Q(11,16) and bayes(ml,D)==Q(5,8)
assert bayes(aux,range(4))==Q(5,8) and bayes(ml,range(4))==Q(9,16)

# In contrast, ordinary input-independent survival flags do not improve these
# particular uniform tasks; conditional on any flags, the native rule is MAP.
flag_cases=0
for ip,iq in product(range(7),repeat=2):
    p,q=Q(ip,6),Q(iq,6)
    for ij in range(max(0,ip+iq-6),min(ip,iq)+1):
        j=Q(ij,6)
        flag=[1-p-q+j,q-j,p-j,j] # index E_A,E_B
        ch=[[Q(0)]*16 for _ in range(4)]
        for a,b in product((0,1),repeat=2):
            for flagz,w in enumerate(flag):
                ea,eb=divmod(flagz,2);mlz=2*a*ea+b*eb
                ch[2*a+b][4*mlz+flagz]+=w
        assert bayes(ch,D)==(1+j)/2
        assert bayes(ch,range(4))==(1+p+q+j)/4
        flag_cases+=1

# Independent-trial discrimination, exact product overlap rather than simulation.
disc=[]
for n in range(1,13):
    # On the 2^n all-diagonal transcripts: product mass 4^-n each;
    # shared law mass 2^-n each. Off-diagonal shared probability is zero.
    overlap=Q(2**n,4**n)
    err=overlap/2
    assert err==Q(1,2**(n+1)) and err>0
    disc.append({'n':n,'equal_prior_error':str(err)})

# Independent one-excitation matrix exponentiation, separate from the full
# Hilbert calculation; field is a global phase in this sector.
physical=[]
for N,t in [(3,.2),(3,1.7),(5,.9),(5,math.pi),(7,1.3),(7,math.pi)]:
    h=np.diag([float(N)]*N)
    for z in range(N-1):h[z,z+1]=h[z+1,z]=.5*math.sqrt((z+1)*(N-z-1))
    psi=expm(-1j*t*h)[:,0]
    actual=float(abs(psi[-1])**2)
    target=math.sin(t/2)**(2*N-2)
    assert abs(actual-target)<3e-14
    physical.append({'N':N,'t':t,'far_port_population':actual,'analytic_population':target,'absolute_error':abs(actual-target)})

out={
 'status':'pass',
 'fresh_independent_exact_rational_joint_cases':count,
 'all_81_directed_and_256_pair_decoders_enumerated_per_case':True,
 'ordinary_flag_revelation_cases':flag_cases,
 'auxiliary_marginal_independence_counterexample':{
  'joint_ML_table_product':True,'R_independent_of_every_source_pair':True,
  'ML_directed_success':str(bayes(ml,D)),'MLR_directed_success':str(bayes(aux,D)),
  'ML_pair_success':str(bayes(ml,range(4))),'MLR_pair_success':str(bayes(aux,range(4))),
  'joint_rows_ML_times_2_plus_R':[[str(v) for v in row] for row in aux]},
 'finite_discrimination':disc,
 'source_matrix_cases':physical,
 'scope':'Exact rational enumeration corroborates proofs; finite source calculations are numerical checks. No empirical apparatus certification.'}
(OUT/'joint_frontier_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
