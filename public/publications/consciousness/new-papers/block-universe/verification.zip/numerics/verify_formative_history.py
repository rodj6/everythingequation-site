#!/usr/bin/env python3
"""Exhaustive finite checks of formative-history assignment rules.
No human observations and no empirical/phenomenal admission are inferred.
"""
from itertools import product
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)

def bits(x,n): return [i for i in range(n) if x>>i&1]
def submasks(x):
    y=x
    while True:
        yield y
        if not y: break
        y=(y-1)&x

def closure(seed,L,adj,n):
    out=seed
    while True:
        new=out
        for u in bits(out,n):
            for v in bits(L,n):
                if adj[u][v]: new|=1<<v
        if new==out: return out
        out=new

def cycles(L,adj,n):
    # Floyd reachability, independent of the predecessor-pruning algorithm.
    reach=[[bool(L>>u&1 and L>>v&1 and adj[u][v]) for v in range(n)] for u in range(n)]
    for k in bits(L,n):
        for u in bits(L,n):
            for v in bits(L,n): reach[u][v]|=reach[u][k] and reach[k][v]
    unseen=set(bits(L,n)); cyc=[]
    while unseen:
        u=min(unseen)
        comp={v for v in unseen if v==u or reach[u][v] and reach[v][u]}
        unseen-=comp
        if len(comp)>1 or adj[u][u]: cyc.append(sum(1<<v for v in comp))
    return cyc

def exhaustive(n,allow_loops):
    positions=[(u,v) for u in range(n) for v in range(n) if allow_loops or u!=v]
    unanchored=anchored=unique_nonempty=empty_only=0
    for graph in range(1<<len(positions)):
        adj=[[False]*n for _ in range(n)]
        for k,(u,v) in enumerate(positions): adj[u][v]=bool(graph>>k&1)
        for L in range(1<<n):
            cs=cycles(L,adj,n)
            def update(E,B=0):
                return B|sum(1<<v for v in bits(L,n) if any(adj[u][v] for u in bits(E,n)))
            fixed={E for E in submasks(L) if update(E)==E}
            generated=set()
            for selector in range(1<<len(cs)):
                seeds=0
                for k,C in enumerate(cs):
                    if selector>>k&1: seeds|=C
                generated.add(closure(seeds,L,adj,n))
            assert fixed==generated
            assert 0 in fixed
            assert (len(fixed)==1)==(len(cs)==0)
            assert (len(fixed-{0})==1)==(len(cs)==1)
            if len(fixed-{0})==1: unique_nonempty+=1
            if fixed=={0}: empty_only+=1
            unanchored+=1
            for B in submasks(L):
                afixed={E for E in submasks(L) if update(E,B)==E}
                R=closure(B,L,adj,n)
                agen=set()
                for selector in range(1<<len(cs)):
                    seeds=B
                    for k,C in enumerate(cs):
                        if selector>>k&1: seeds|=C
                    agen.add(closure(seeds,L,adj,n))
                assert afixed==agen
                assert R in afixed and all(R&~E==0 for E in afixed)
                unique=all(C&~R==0 for C in cs)
                assert (len(afixed)==1)==unique
                assert unique==(len(cycles(L&~R,adj,n))==0)
                anchored+=1
    return {'vertices':n,'self_loops':allow_loops,'graphs':1<<len(positions),
            'unanchored_cases':unanchored,'anchored_cases':anchored,
            'empty_only_cases':empty_only,'exactly_one_nonempty_fixed_point_cases':unique_nonempty}

def mutual_learning():
    # Each code is a binary operator's 4-bit truth table, index 2*x+y.
    ops=list(range(16)); xor_code=6
    examples_A={(0,0):0,(0,1):1}
    examples_B={(1,0):1,(1,1):0}
    def consistent(examples):
        return [h for h in ops if all((h>>(2*x+y)&1)==z for (x,y),z in examples.items())]
    assert len(consistent(examples_A))==len(consistent(examples_B))==4
    # Messages at t=0 contain only each learner's own partial examples.
    # Neither has the complete learned rule then. Actual delivery takes a step.
    complete={**examples_A,**examples_B}
    assert consistent(complete)==[xor_code]
    def eval_tree(tree,code):
        if isinstance(tree,int): return tree
        x,y=map(lambda t:eval_tree(t,code),tree)
        return code>>(2*x+y)&1
    novel=correct=0
    for length in range(3,10):
        for values in product((0,1),repeat=length):
            tree=values[0]
            for value in values[1:]: tree=(tree,value)
            predicted=eval_tree(tree,xor_code)
            assert predicted==sum(values)%2
            novel+=1;correct+=1
    # Two nominated locally qualified operator uses at t=3; the actual formative
    # senders lack this complete operator scaffold at t=0. This is not a claim
    # that those senders lack all experience or every other interpretive capacity.
    # The original strict-earlier experiencing-contributor admission excludes
    # t=0 and therefore cannot bootstrap the first qualifying t=3 activities.
    # Vertices A0,B0,A3,B3; only the later complete-operator uses locally qualify.
    formative={(0,3),(1,2)}; qualified=(1<<2)|(1<<3)
    def original_update(E):
        return sum(1<<v for v in (2,3) if any((u,v) in formative for u in bits(E,4)))
    old_fixed=[E for E in range(16) if E & ~qualified==0 and original_update(E)==E]
    revised_development={'A':(1,2) in formative,'B':(0,3) in formative}
    assert old_fixed==[0] and all(revised_development.values())
    return {'hypothesis_class_binary_operators':len(ops),
            'each_learner_initial_consistent_rules':4,'post_exchange_consistent_rules':[xor_code],
            'novel_compositional_queries':novel,'correct_queries':correct,
            'schedule':{'t0':'learners lacking the nominated complete operator scaffold send disjoint local examples',
                        't1':'messages arrive; both identify the same binary operator',
                        't2':'each performs novel nested compositional inference',
                        't3':'a new occurrence is interpreted using the learned operator'},
            'experiential_contributor_condition':'not established in this functional model',
            'nonrecursive_development_condition':'realized in this functional model',
            'phenomenal_scope':'No experience conclusion follows without a constitutive premise and independently justified unit/application conditions'}

def main():
    result={'status':'PASS','exhaustive_graph_checks':[exhaustive(3,True),exhaustive(4,False)],
            'mutual_development':mutual_learning(),
            'scope':'Mathematical corroboration and a constructed learning model; no empirical fit or consciousness test'}
    (ROOT/'formative_history_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
