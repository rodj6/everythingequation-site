#!/usr/bin/env python3
"""Exact finite physical countermodel: passive history is not an intervention law.
Constructed model only. No universal deeper-source or experimental claim.
"""
from pathlib import Path
import json
import numpy as np
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)
I=np.eye(2,dtype=complex);Z=np.diag([1.,-1.]);H=np.array([[1.,1.],[1.,-1.]],complex)/np.sqrt(2)
zero=np.array([1.,0.],complex);one=np.array([0.,1.],complex)
P0=np.outer(zero,zero);P1=np.outer(one,one)

def ptrace_e(rho):
 a=rho.reshape(2,2,2,2)
 return np.trace(a,axis1=0,axis2=2)

def td(a,b):return np.linalg.svd(a-b,compute_uv=False).sum()/2

def main():
 # E is first subsystem, S second. Positive local interaction strength pi/T, T=1.
 ham=np.pi*np.kron(P1,P1)
 initial=[np.kron(np.outer(v,v.conj()),P0) for v in (zero,one)]
 errs=[]
 for t in np.linspace(0.,4.,129):
  u=expm(-1j*t*ham)
  for rho in initial:errs.append(np.linalg.norm(ptrace_e(u@rho@u.conj().T)-P0))
 assert max(errs)<1e-14
 kick=np.kron(I,H);u=expm(-1j*ham)
 activated=[]
 for rho in initial:
  total=kick@u@kick
  activated.append(ptrace_e(total@rho@total.conj().T))
 dist=float(td(*activated));assert abs(dist-1)<1e-14
 assert np.linalg.norm(activated[0]-P0)<1e-14 and np.linalg.norm(activated[1]-P1)<1e-14
 # A single common Bernoulli law m has worst source-conditional TV max(m,1-m).
 grid=np.linspace(0.,1.,1001);worst=np.maximum(grid,1-grid)
 assert abs(worst.min()-.5)<1e-14
 # State stationarity does not imply conservation of its rank-one projector.
 gamma=.7;L=np.sqrt(gamma)*np.outer(zero,one)
 def schr(rho):return L@rho@L.conj().T-(L.conj().T@L@rho+rho@L.conj().T@L)/2
 def heis(A):return L.conj().T@A@L-(L.conj().T@L@A+A@L.conj().T@L)/2
 assert np.linalg.norm(schr(P0))<1e-14
 assert np.linalg.norm(heis(P0)-gamma*P1)<1e-14
 report={'status':'PASS','positive_interaction_eigenvalues':np.linalg.eigvalsh(ham).tolist(),
 'passive_history_times_checked':129,'max_passive_reduced_state_error':float(max(errs)),
 'analytic_passive_statement':'rho_S(t)=|0><0| for all real t under both E preparations',
 'activated_state0':np.real(activated[0]).tolist(),'activated_state1':np.real(activated[1]).tolist(),
 'activated_trace_distance':dist,'passive_history_only_minimax_tv_error':float(worst.min()),
 'stationarity_counterexample':{'schrodinger_ground_derivative_norm':float(np.linalg.norm(schr(P0))),
 'heisenberg_P0_derivative':np.real(heis(P0)).tolist()},
 'scope':'Active physical completion of a nominated passive reduced history; not noninjectivity of source-to-complete-physical-history F; no novelty priority asserted'}
 (ROOT/'controlled_history_results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
