#!/usr/bin/env python3
"""Exact-form flagged encoding construction for the ready-subsystem bound.
Numerical corroboration only. Proof in robust_completion_sharpness.md.
"""
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)
from math import sqrt
import json
import numpy as np


def bound(d,q,eps):
    if q>=d or eps>=1-q/d:return 1.
    return (sqrt((q/d)*(1-eps))+sqrt((1-q/d)*eps))**2


def verify(d,q,eps):
    used_eps=min(eps,1-q/d)
    alpha=sqrt((1-used_eps)/q)
    beta=sqrt(used_eps/(d-q))
    operators=[];ready=0.;complete=np.zeros((d,d))
    max_isometry_error=0.
    for j in range(d):
        good=tuple((j+k)%d for k in range(q))
        bad=tuple(k for k in range(d) if k not in good)
        D=np.diag([alpha if k in good else beta for k in range(d)])
        V=np.zeros((d*q,d))
        for r,k in enumerate(good):V[r,k]=1.
        for r,k in enumerate(bad):V[q+r,k]=1.
        iso_error=float(np.max(np.abs(V.T@V-np.eye(d))))
        max_isometry_error=max(max_isometry_error,iso_error)
        assert iso_error==0.
        K=V@D
        complete+=K.T@K
        ready+=float(np.trace(K[:q,:].T@K[:q,:]))/d
        # The partial-isometry decoder V^dagger acts exactly on the encoded range.
        assert np.allclose(V.T@K,D)
        operators.append(D)
    assert np.allclose(complete,np.eye(d))
    fe=sum(float(np.trace(D))**2 for D in operators)/(d*d)
    pred=bound(d,q,eps)
    assert abs(ready-(1-used_eps))<1e-12
    assert ready>=1-eps-1e-12
    assert abs(fe-pred)<1e-12
    # Trace preservation makes the reference marginal I/d.
    reference=complete.T/d
    assert np.allclose(reference,np.eye(d)/d)
    return {'d':d,'q':q,'epsilon':float(eps),'used_epsilon':float(used_eps),
            'ready_probability':ready,'entanglement_fidelity':fe,
            'analytic_bound':pred,'isometry_max_error':max_isometry_error,
            'completeness_max_error':float(np.max(np.abs(complete-np.eye(d))))}


def main():
    checks=[]
    for d in range(2,10):
        for q in range(1,d):
            threshold=1-q/d
            for eps in (0.,threshold/4,threshold/2,3*threshold/4,threshold,
                        min(1.,threshold+.1)):
                checks.append(verify(d,q,eps))
    result={'status':'PASS','scope':'free instrument/decoder sharpness, not attainment by every prescribed source',
            'checks':checks,'count':len(checks),
            'max_fidelity_error':max(abs(c['entanglement_fidelity']-c['analytic_bound']) for c in checks),
            'max_completeness_error':max(c['completeness_max_error'] for c in checks)}
    path=OUT/'flagged_completion_results.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))

if __name__=='__main__':main()
