#!/usr/bin/env python3
"""Independent finite check of the necessary-only admission repair."""
import itertools
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
OUT.mkdir(parents=True,exist_ok=True)

def post(nodes, edges, admitted):
    return {v for u, v in edges if u in admitted and v in nodes}

def acyclic(nodes, edges):
    remaining = set(nodes)
    while remaining:
        first = {v for v in remaining if not any(u in remaining and w == v for u, w in edges)}
        if not first:
            return False
        remaining -= first
    return True

graphs = 0
assignments = 0
dag_graphs = 0
for n in range(1, 5):
    nodes = set(range(n))
    possible = [(u, v) for u in nodes for v in nodes if u != v]
    for code in range(1 << len(possible)):
        edges = [edge for i, edge in enumerate(possible) if code & (1 << i)]
        graphs += 1
        dag = acyclic(nodes, edges)
        dag_graphs += int(dag)
        for bits in range(1 << n):
            admitted = {v for v in nodes if bits & (1 << v)}
            p = post(nodes, edges, admitted)
            assignments += 1
            if dag and admitted <= p:
                assert not admitted, (nodes, edges, admitted)
            if admitted == p:
                assert admitted <= p

nodes = {0, 1, 2}
edges = [(0, 1), (1, 0), (1, 2)]
admitted = {0, 1}
p = post(nodes, edges, admitted)
assert admitted < p
result = {
    "status": "PASS",
    "loopless_graphs": graphs,
    "all_assignments": assignments,
    "acyclic_graphs": dag_graphs,
    "necessary_only_well_founded_nonempty_assignments": 0,
    "strict_inclusion_example": {
        "edges": edges,
        "admitted": sorted(admitted),
        "post": sorted(p),
        "necessary_only": True,
        "biconditional": False,
    },
    "scope": "Finite corroboration; the well-founded proof is analytic.",
}
(OUT/'necessary_only_admission_results.json').write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
