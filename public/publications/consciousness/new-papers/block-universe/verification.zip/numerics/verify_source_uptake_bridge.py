#!/usr/bin/env python3
"""Source-to-operative-order bounds: exact finite model corroboration.

No human experiment or consciousness detector. The analytic proofs and resource
inventory are in source_uptake_bridge.md. Requires numpy and scipy only.
"""
from pathlib import Path
from itertools import product
import json
import math
import numpy as np
from scipy.linalg import expm

ROOT=Path(__file__).resolve().parent.parent/'verification'/'numerical'
ROOT.mkdir(parents=True,exist_ok=True)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
n=np.diag([0.,1.]).astype(complex)


def kron_all(xs):
    out=np.ones((1,1),complex)
    for x in xs:out=np.kron(out,x)
    return out


def chain_h(N,omega=1.):
    h=np.zeros((2**N,2**N),complex)
    for j in range(N):
        terms=[I]*N;terms[j]=n;h+=omega*N*kron_all(terms)
    for j in range(N-1):
        J=omega/2*math.sqrt((j+1)*(N-j-1))
        for pauli in (X,Y):
            terms=[I]*N;terms[j]=pauli;terms[j+1]=pauli
            h+=J/2*kron_all(terms)
    return h


def partial_trace(rho,keep,dims):
    a=rho.reshape(tuple(dims)+tuple(dims)); current=list(dims)
    for j in range(len(dims)-1,-1,-1):
        if j not in keep:
            a=np.trace(a,axis1=j,axis2=j+len(current));current.pop(j)
    d=math.prod(current)
    return a.reshape(d,d)


def delivered_port(N,t,value):
    psi=np.zeros(2**N,complex);psi[value*2**(N-1)]=1
    v=expm(-1j*t*chain_h(N))@psi
    return partial_trace(np.outer(v,v.conj()),[N-1],[2]*N)


def memory_output(rho,theta):
    # Positive static two-qubit number-preserving memory Hamiltonian, kappa=1.
    h=.5*(np.kron(X,X)+np.kron(Y,Y))+2*(np.kron(n,I)+np.kron(I,n))
    u=expm(-1j*theta*h)
    init=np.kron(rho,np.diag([1.,0.]))
    return partial_trace(u@init@u.conj().T,[0],[2,2])


def law(p,q):
    # Row ab, column ML; independent amplitude-damping channels.
    out=np.zeros((4,4))
    for a,b in product((0,1),repeat=2):
        for m,l in product((0,1),repeat=2):
            pa=(p if m else 1-p) if a else float(m==0)
            pb=(q if l else 1-q) if b else float(l==0)
            out[2*a+b,2*m+l]=pa*pb
    return out


def optimal_success(channel,targets):
    labels=sorted(set(targets))
    weights=np.array([channel[np.array(targets)==y].sum(axis=0)/4 for y in labels])
    return float(weights.max(axis=0).sum())


def correlated_law(p,q,c):
    return np.array([[1,0,0,0],
                     [1-q,q,0,0],
                     [1-p,0,p,0],
                     [1-p-q+c,q-c,p-c,c]],float)


def joint_retention_checks():
    checks=[];D=[0,1,-1,0]
    for p in np.linspace(0,1,11):
        for q in np.linspace(0,1,11):
            lo=max(0.,p+q-1);hi=min(p,q)
            for c in np.linspace(lo,hi,5):
                channel=correlated_law(p,q,c)
                assert channel.min()>-1e-12
                exhaustive=max(sum(channel[i,z]/4 for i in range(4) for z in range(4)
                                   if decoder[z]==D[i])
                               for decoder in product((-1,0,1),repeat=4))
                pair=optimal_success(channel,list(range(4)))
                assert abs(exhaustive-(1+c)/2)<1e-12
                assert abs(pair-(1+p+q+c)/4)<1e-12
                checks.append({'p':float(p),'q':float(q),'co_retention_c':float(c),
                               'directed_success':exhaustive,'pair_success':pair})
    shared=.5*np.eye(4);shared[:,0]+=.5
    shared_score=optimal_success(shared,D)
    assert abs(shared_score-.75)<1e-12
    independent_11=law(.5,.5)[3]
    shared_11=shared[3]
    tv=float(np.abs(independent_11-shared_11).sum()/2)
    assert abs(tv-.5)<1e-12
    discrimination=[]
    for trials in range(1,7):
        error=.5*sum(min(math.prod(independent_11[z] for z in seq),
                          math.prod(shared_11[z] for z in seq))
                     for seq in product(range(4),repeat=trials))
        assert abs(error-2.**(-trials-1))<1e-12
        discrimination.append({'independent_trials':trials,'equal_prior_optimal_error':error})
    # Same local diagonal marginals need not give a jointly diagonal code.
    basis=np.eye(4,dtype=complex)
    psi_plus=(basis[1]+basis[2])/math.sqrt(2)
    psi_minus=(basis[1]-basis[2])/math.sqrt(2)
    rho=[np.outer(basis[0],basis[0]),
         .5*np.outer(basis[0],basis[0])+.5*np.outer(basis[1],basis[1]),
         .5*np.outer(basis[0],basis[0])+.5*np.outer(basis[2],basis[2]),
         np.outer(psi_plus,psi_plus)]
    zero=sum(np.outer(v,v.conj()) for v in (basis[0],basis[3],psi_plus))
    positive=np.outer(psi_minus,psi_minus.conj())
    negative=np.zeros((4,4),complex)
    effects={0:zero,1:positive,-1:negative}
    assert np.abs(sum(effects.values())-np.eye(4)).max()<1e-12
    coherent_score=float(sum(np.real(np.trace(effects[y]@state))/4
                             for y,state in zip(D,rho)))
    assert abs(coherent_score-9/16)<1e-12
    for a,b in product((0,1),repeat=2):
        state=rho[2*a+b]
        ma=partial_trace(state,[0],[2,2]);lb=partial_trace(state,[1],[2,2])
        assert np.abs(ma-np.diag([1-a*.5,a*.5])).max()<1e-12
        assert np.abs(lb-np.diag([1-b*.5,b*.5])).max()<1e-12
    assert abs(rho[3][3,3])<1e-12
    return {'case_count':len(checks),'cases':checks,
            'shared_noise_same_marginals_countermodel':{'p':.5,'q':.5,'c':.5,
                 'actual_D_success':shared_score,'incorrect_product_prediction':.625},
            'marginal_equivalence_joint_protocol_discrimination':{'prep':'a=b=1',
                 'joint_TV':tv,'one_shot_equal_prior_optimal_error':.25,
                 'independent_repeat_checks':discrimination},
            'diagonal_marginals_coherent_joint_countermodel':{'p':.5,'q':.5,'c':0.,
                 'achieved_D_success':coherent_score,'classical_c_formula':.5,
                 'scope':'Violates joint diagonality, not the stated theorem.'}}


def enumeration_checks():
    D=[b-a for a,b in product((0,1),repeat=2)]
    checks=[]
    for p in np.linspace(0,1,21):
        for q in np.linspace(0,1,21):
            channel=law(p,q)
            direct=sum(channel[ab,z]/4 for ab in range(4) for z in range(4)
                       if ((z%2)-(z//2))==D[ab])
            exhaustive=max(sum(channel[i,z]/4 for i in range(4) for z in range(4)
                               if decoder[z]==D[i])
                           for decoder in product((-1,0,1),repeat=4))
            pair_enum=max(sum(channel[i,z]/4 for i in range(4) for z in range(4)
                              if decoder[z]==i)
                          for decoder in product(range(4),repeat=4))
            bound=(1+p*q)/2; pair=(1+p)*(1+q)/4
            assert abs(direct-bound)<1e-12
            assert abs(exhaustive-bound)<1e-12
            assert abs(pair_enum-pair)<1e-12
            assert abs(optimal_success(channel,D)-bound)<1e-12
            checks.append({'p':float(p),'q':float(q),'directed_success':exhaustive,
                           'ordered_pair_success':pair_enum})
    return checks


def physical_checks():
    out=[]
    for N_A,N_B,t_A,t_B,theta in [
        (3,3,.4,.8,.2),(3,5,1.,2.,.5),(5,3,2.,1.,.9),
        (5,5,math.pi,math.pi,0.),(3,3,math.pi,math.pi,math.pi/2),
        (3,5,math.pi/2,math.pi/3,.4),(5,5,2.4,2.7,.7)]:
        qa=math.sin(t_A/2)**(2*N_A-2)
        qb=math.sin(t_B/2)**(2*N_B-2)
        r=math.cos(theta)**2;p=qa*r
        channel=[];maxoff=0.
        for a,b in product((0,1),repeat=2):
            A=memory_output(delivered_port(N_A,t_A,a),theta)
            B=delivered_port(N_B,t_B,b)
            rho=np.kron(A,B)
            maxoff=max(maxoff,float(np.abs(rho-np.diag(np.diag(rho))).max()))
            channel.append(np.real(np.diag(rho)))
        channel=np.array(channel)
        err=float(np.abs(channel-law(p,qb)).max())
        assert err<1e-12 and maxoff<1e-12
        accuracy=optimal_success(channel,[0,1,-1,0])
        assert abs(accuracy-(1+qa*r*qb)/2)<1e-12
        out.append({'N_A':N_A,'N_B':N_B,'source_delay_A':t_A,'source_delay_B':t_B,
                    'memory_kappa_Delta':theta,'delivery_A':qa,'delivery_B':qb,
                    'retention_r':r,'directed_success':accuracy,
                    'max_conditional_state_error':err})
    return out


def robustness_checks():
    rng=np.random.default_rng(6172026);out=[]
    for _ in range(200):
        p,q=rng.uniform(size=2);base=law(p,q);eps=float(rng.uniform(0,.12))
        arbitrary=rng.dirichlet(np.ones(4),size=4)
        actual=(1-eps)*base+eps*arbitrary
        eta=float(np.abs(actual-base).sum()/8)
        score=optimal_success(actual,[0,1,-1,0])
        assert score<=(1+p*q)/2+eta+1e-12
        out.append({'p':p,'q':q,'eta_bar':eta,'actual_success':score,
                    'upper_bound':(1+p*q)/2+eta})
    return out


def intervention_checks():
    out=[]
    for p,q in [(1.,1.),(.8,.7),(1.,0.),(0.,0.)]:
        channel=law(p,q)
        direct=swapped=0.
        for ab in range(4):
            a,b=divmod(ab,2);truth=b-a
            for z in range(4):
                m,l=divmod(z,2);prob=channel[ab,z]/4
                direct+=prob*((l-m)==truth)
                swapped+=prob*((m-l)==truth)
        assert abs(direct-(1+p*q)/2)<1e-12
        assert abs(swapped-(2-p-q+2*p*q)/4)<1e-12
        out.append({'p':p,'q':q,'intact_directed_success':direct,
                    'swapped_binding_success':swapped})
    bag=np.zeros((4,3))
    for ab in range(4):a,b=divmod(ab,2);bag[ab,a+b]=1
    bag_success=optimal_success(bag,[0,1,-1,0]);assert bag_success==.75
    hidden_archive=optimal_success(np.eye(4),[0,1,-1,0])
    assert hidden_archive==1.
    nonrepeat=law(1.,0.)[[1,2],:]
    nonrepeat_score=float((nonrepeat/2).max(axis=0).sum())
    assert nonrepeat_score==1.
    gates=[]
    for m,l in product((0,1),repeat=2):
        archive=(m,l)
        opened={'archive':archive,'directed':l-m,'forecast':2*l-m,
                'executed':True}
        closed={'archive':archive,'directed':None,'forecast':None,
                'executed':False}
        assert opened['archive']==closed['archive']
        assert opened['executed'] and not closed['executed']
        # Later deletion changes the later trace, not the already logged operation.
        later_deleted={**opened,'archive':None}
        assert opened['executed'] and later_deleted['executed']
        gates.append({'input_archive':archive,'gate_open':opened,'gate_closed':closed,
                      'after_later_deletion':later_deleted})
    return {'binding_cases':out,'ideal_unordered_feature_bag_D_success':bag_success,
            'gated_native_update_cases':gates,
            'analyst_log_is_not_an_available_decoder_resource':True,
            'hidden_label_archive_at_p_q_zero_permits_success':hidden_archive,
            'restricted_nonrepeated_inputs_a_known_q_zero_permits_success':nonrepeat_score,
            'scope':'The latter two change the resource/preparation premises, not counterexamples to the theorem.'}


def finite_gate_checks():
    swap=np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]],complex)
    Hswap=math.pi*(np.eye(4)-swap)/2
    swap_error=float(np.abs(expm(-1j*Hswap)-swap).max())
    assert swap_error<1e-12
    # 7 qubits: M,L, two D bits, two G bits, one valid-operation bit.
    U=np.zeros((128,128),complex)
    Dcode={0:0,1:1,-1:2}
    for m,l,d,g,valid in product(range(2),range(2),range(4),range(4),range(2)):
        source=((((m*2+l)*4+d)*4+g)*2+valid)
        dest=((((m*2+l)*4+(d^Dcode[l-m]))*4+(g^(2*l-m+1)))*2+(valid^1))
        U[dest,source]=1
    assert np.abs(U@U-np.eye(128)).max()<1e-12
    assert np.abs(U-U.conj().T).max()<1e-12
    Hnative=math.pi*(np.eye(128)-U)/2
    V=expm(-1j*Hnative)
    native_error=float(np.abs(V-U).max())
    assert native_error<1e-12
    for m,l in product(range(2),repeat=2):
        source=(m*2+l)*32
        dest=((((m*2+l)*4+Dcode[l-m])*4+(2*l-m+1))*2+1)
        assert abs(V[dest,source]-1)<1e-12
    return {'swap_dimension':4,'swap_generator_min_eigenvalue':float(np.linalg.eigvalsh(Hswap).min()),
            'swap_unitary_max_error':swap_error,'native_update_dimension':128,
            'native_generator_min_eigenvalue':float(np.linalg.eigvalsh(Hnative).min()),
            'native_unitary_max_error':native_error,
            'gate_duration_units':1.,'scope':'Finite scheduled gates; not an autonomous complete observer.'}


def main():
    enumerated=enumeration_checks();physical=physical_checks();robust=robustness_checks()
    joint=joint_retention_checks()
    result={'status':'PASS','scope':'Finite quantum-operational source/delivery/memory/transducer model; no human experiment or experiential detector',
            'grid_decoder_checks':enumerated,'grid_case_count':len(enumerated),
            'full_Hilbert_physical_cases':physical,'robustness_cases':robust,
            'interventions_and_countermodels':intervention_checks(),
            'finite_scheduled_gate_checks':finite_gate_checks(),
            'joint_retention_extension':joint}
    (ROOT/'source_uptake_bridge_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','grid_cases':len(enumerated),
                      'deterministic_D_decoders_per_case':81,
                      'ordered_pair_decoders_per_case':256,
                      'full_Hilbert_physical_cases':len(physical),
                      'max_physical_state_error':max(x['max_conditional_state_error'] for x in physical),
                      'robustness_cases':len(robust),
                      'joint_diagonal_retention_cases':joint['case_count'],
                      'shared_noise_D_success':.75,
                      'coherent_joint_countermodel_success':9/16,
                      'ideal_directed_success':1.,'ideal_unordered_bag_success':.75},indent=2))


if __name__=='__main__':main()
