# Block Universe and Shadow Theory: Source, History, and Enacted Temporal Reality

Verification supplement · Jeremy Rodgers · Version 1.0 · 23 October 2026  
Paper DOI: [10.5281/zenodo.23604713](https://doi.org/10.5281/zenodo.23604713)

This verification-only archive accompanies the paper PDF. It contains the sixteen numerical checks, pinned Lean project and axiom audits, run instructions, dependency licence, and one recorded result set. It does not contain manuscript sources, figures, or paper-build tools.

## Numerical checks

From this directory, with Python 3.12:

```sh
python3 -m pip install -r requirements.txt
python3 run_checks.py
```

All sixteen checks should report `PASS`. No external data files are needed. Results and actual package versions are written to `verification/numerical/`; rerunning replaces the included set. `run.json` records each check's source SHA-256, status, and environment. Keep the supplied package pins for reproducibility.

### Mapping to the paper

All numerical filenames below are in `numerics/`.

| Paper result | Check files |
| --- | --- |
| §5: prescribed spin source, return, deficit, deadlines | `verify_prescribed_spin_source.py` |
| §6: joint frontier, product realization, side resources, robustness | `verify_source_uptake_bridge.py`, `verify_joint_frontier.py`, `verify_adversarial_joint_resources.py` |
| §7: readiness/completion frontier and attaining instruments | `verify_ready_cut_completion.py`, `verify_completion_instruments.py`, `verify_flagged_completion_bound.py` |
| §8: temporal roles, timing, calibration | `verify_temporal_models.py`, `verify_scope_constraints.py` |
| §9: passive-history/control contrast and finite pulses | `verify_controlled_history.py`, `verify_controlled_pulses.py` |
| Appendix A: reciprocal geometry and countermodels | `verify_reciprocal_geometry.py` and the Lean project |
| Appendix B: fixed points, anchors, development, necessity | `verify_formative_history.py`, `verify_necessary_only_admission.py` |
| Appendix C: Gaussian discrimination and unitary retrieval | `verify_gaussian_discrimination.py`, `verify_quantum_retrieval.py` |

Representative exact values are directed-feature success 5/8 for independent half-survival records and 3/4 for shared loss; binary physical-postprocessing error 1/3 at p=1/2, q=1; and retrieval trace distance 0 before, 1 after the later gate. Floating-point discrepancies are reported in the results.

These are constructed checks, not experimental calibration or consciousness tests. The temporal checks independently implement the paper's models; the temporal article's separate original code package was unavailable. The Gaussian check verifies probability arithmetic, not a numerical QFT simulation.

## Lean verification

Use the official Lean toolchain pinned in `lean/lean-toolchain`: 4.36.0-rc1. The resolved `lean/lake-manifest.json` pins nine dependencies; `lean/lakefile.toml` fixes mathlib at commit `3d14fd9a313ac35ed4b5c653ed5d99157c9e29f6`. Do not update the manifest. Toolchain, dependency sources, and caches are not bundled; a fresh installation needs network access to obtain them. The mathlib Apache-2.0 licence is in `licenses/`.

After installing the specified toolchain, obtain the pinned dependencies and cache, then run:

```sh
cd lean
lake exe cache get
cd ..
python3 lean/verify.py
```

The verifier checks all dependency revisions, builds six modules, and executes both axiom audits. It replaces `verification/lean.txt` with the complete output, including source SHA-256 hashes. Alternatively, from `lean/`, run `lake build`, `lake env lean AxiomAuditAll.lean`, and `lake env lean DilationCountermodel.lean`.

`BlockUniverse.lean` and `BlockUniverse/HigherDim.lean` treat simultaneity/co-reality implications. `BlockUniverse/Stein.lean` gives the separately scoped 1+1 classification used by `BlockUniverse/Reciprocal.lean`. The direct real modules `BlockUniverse/ReciprocalNoDilation.lean` and `BlockUniverse/ReciprocalThreePlusOne.lean` prove the reciprocal-pair implication without dilation or classification; the latter uses coordinate-axis boosts and proper spatial half-turns.

The audit covers 65 named proofs and six countermodel proofs. Allowed axioms are `propext`, `Classical.choice`, and `Quot.sound`. Kernel verification does not supply an actuality interpretation or a reciprocal witness.

The recorded Lean run used the included narrow runtime adapter because its Linux host restricted `/proc/<pid>/exe`. The official compiler/kernel was unchanged. Ordinary installations do not need the adapter. Only if the same executable-path error occurs, build it with:

```sh
cc -shared -fPIC -O2 lean/readlink_self_workaround.c -ldl -o /tmp/lean_readlink.so
```

Then set `LD_PRELOAD=/tmp/lean_readlink.so` for the Lean/Lake commands. Nonfatal module-system and tactic-linter messages remain in the recorded log. The included log is evidence of its recorded run, not a new compilation performed by extracting this archive.
