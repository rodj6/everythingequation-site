#!/usr/bin/env python3
"""Run the self-contained numerical checks accompanying the paper."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys
import time
import numpy
import scipy
import matplotlib

ROOT=Path(__file__).resolve().parent
CHECKS=(
 ('verify_source_uptake_bridge.py','source_uptake_bridge_results.json'),
 ('verify_adversarial_joint_resources.py','adversarial_joint_resources_results.json'),
 ('verify_scope_constraints.py','scope_constraints_results.json'),
 ('verify_joint_frontier.py','joint_frontier_results.json'),
 ('verify_formative_history.py','formative_history_results.json'),
 ('verify_temporal_models.py','temporal_models_results.json'),
 ('verify_prescribed_spin_source.py','prescribed_spin_source_results.json'),
 ('verify_ready_cut_completion.py','ready_cut_completion_results.json'),
 ('verify_completion_instruments.py','completion_instruments_results.json'),
 ('verify_flagged_completion_bound.py','flagged_completion_results.json'),
 ('verify_reciprocal_geometry.py','reciprocal_geometry_results.json'),
 ('verify_controlled_history.py','controlled_history_results.json'),
 ('verify_controlled_pulses.py','controlled_pulses_results.json'),
 ('verify_necessary_only_admission.py','necessary_only_admission_results.json'),
 ('verify_quantum_retrieval.py','quantum_retrieval_results.json'),
 ('verify_gaussian_discrimination.py','gaussian_discrimination_results.json'),
)

def main():
    out=ROOT/'verification'/'numerical';out.mkdir(parents=True,exist_ok=True)
    checks=[]
    for script,result_name in CHECKS:
        path=ROOT/'numerics'/script;start=time.monotonic()
        p=subprocess.run([sys.executable,str(path)],cwd=ROOT,text=True,capture_output=True)
        if p.returncode:
            print(p.stdout,p.stderr,file=sys.stderr)
            raise SystemExit(script+' failed')
        returned=json.loads(p.stdout)
        assert str(returned.get('status','')).upper() in {'PASS','PASSED'},script
        result=out/result_name
        assert result.is_file(),result_name
        assert str(json.loads(result.read_text()).get('status','')).upper() in {'PASS','PASSED'},result_name
        checks.append({'script':'numerics/'+script,
                       'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                       'status':'PASS','exit_code':p.returncode,
                       'seconds':time.monotonic()-start,'result':result_name})
        print('PASS',script,flush=True)
    record={'status':'PASS','executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'environment':{'python':platform.python_version(),'numpy':numpy.__version__,
                           'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},
            'check_count':len(checks),'checks':checks,
            'scope':'Constructed numerical corroboration, not experimental or experiential certification'}
    (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    print('All sixteen numerical checks passed.')

if __name__=='__main__':main()
