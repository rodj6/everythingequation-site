/-
  The Rietdijk–Putnam argument, machine-checked
  =============================================

  Setting: (1+1)-dimensional Minkowski spacetime over any linearly ordered
  field K (the reals are one instance), in units with c = 1.

  An inertial frame is labelled by its velocity v with -1 < v < 1.
  Under a Lorentz boost, t' = γ (t - v x) with γ > 0, so two events are
  simultaneous in frame v exactly when Δt = v Δx. We use that condition
  directly, which avoids square roots.

  "R p q" is read as "q is real relative to p" (Putnam's "is real for").

  Main results
  * `simultaneous_iff_spacelike_or_eq` : simultaneous in some frame
       ⇔ spacelike-separated or identical.
  * `common_simultaneity_partner` : any two events share an event that
       is simultaneous with each of them in some frame.
  * `rietdijk_putnam` : if R contains every frame's simultaneity relation
       and is transitive, then R relates every pair of events (the block).
  * `transitivity_needed`, `relativity_of_reality_needed` : each hypothesis
       is independent; dropping either admits a non-block relation.
       The second witness is Stein's causal-past relation.
-/
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Algebra.Order.Field.Basic

namespace BlockUniverse

variable {K : Type*} [Field K] [LinearOrder K] [IsStrictOrderedRing K]

/-- An event: a time coordinate and a space coordinate. -/
@[ext] structure Event (K : Type*) where
  t : K
  x : K

/-- An admissible inertial-frame velocity: slower than light. -/
def Admissible (v : K) : Prop := -1 < v ∧ v < 1

/-- `p` and `q` are simultaneous in the frame moving with velocity `v`. -/
def Simul (v : K) (p q : Event K) : Prop := q.t - p.t = v * (q.x - p.x)

/-- Simultaneous according to *some* inertial observer. -/
def SimulSomeFrame (p q : Event K) : Prop := ∃ v, Admissible v ∧ Simul v p q

/-- Spacelike separation: Δt² < Δx². -/
def Spacelike (p q : Event K) : Prop := (q.t - p.t) ^ 2 < (q.x - p.x) ^ 2

/-! ### Geometry -/

theorem spacelike_simulSomeFrame {p q : Event K} (h : Spacelike p q) :
    SimulSomeFrame p q := by
  unfold Spacelike at h
  set a := q.t - p.t
  set b := q.x - p.x
  have hb : b ≠ 0 := by
    intro hb0; rw [hb0] at h; nlinarith [sq_nonneg a]
  refine ⟨a / b, ⟨?_, ?_⟩, ?_⟩
  · rcases lt_or_gt_of_ne hb with hneg | hpos
    · rw [lt_div_iff_of_neg hneg]; nlinarith
    · rw [lt_div_iff₀ hpos]; nlinarith
  · rcases lt_or_gt_of_ne hb with hneg | hpos
    · rw [div_lt_iff_of_neg hneg]; nlinarith
    · rw [div_lt_iff₀ hpos]; nlinarith
  · unfold Simul; field_simp; simp only [a, b]

theorem simulSomeFrame_spacelike_or_eq {p q : Event K} (h : SimulSomeFrame p q) :
    Spacelike p q ∨ p = q := by
  obtain ⟨v, ⟨h1, h2⟩, hs⟩ := h
  unfold Simul at hs
  by_cases hx : q.x - p.x = 0
  · right
    have ht : q.t - p.t = 0 := by rw [hs, hx, mul_zero]
    ext <;> linarith
  · left
    unfold Spacelike
    rw [hs, mul_pow]
    have hv : v ^ 2 < 1 := by nlinarith
    have hpos : 0 < (q.x - p.x) ^ 2 := by positivity
    nlinarith

/-- The two notions coincide (for distinct events, "simultaneous for someone"
    is exactly "spacelike"). -/
theorem simultaneous_iff_spacelike_or_eq (p q : Event K) :
    SimulSomeFrame p q ↔ Spacelike p q ∨ p = q := by
  constructor
  · exact simulSomeFrame_spacelike_or_eq
  · rintro (h | rfl)
    · exact spacelike_simulSomeFrame h
    · exact ⟨0, ⟨by norm_num, by norm_num⟩, by simp [Simul]⟩

/-- Key geometric lemma: any two events — even timelike-separated ones —
    have a common partner that each regards as simultaneous in some frame
    (frames ±1/2 suffice). -/
theorem common_simultaneity_partner (p q : Event K) :
    ∃ r, SimulSomeFrame p r ∧ SimulSomeFrame r q := by
  let rx : K := (p.x + q.x) / 2 + (q.t - p.t)
  let r : Event K := ⟨p.t + (rx - p.x) / 2, rx⟩
  refine ⟨r, ⟨1 / 2, ⟨by norm_num, by norm_num⟩, ?_⟩,
              ⟨-(1 / 2), ⟨by norm_num, by norm_num⟩, ?_⟩⟩
  · simp only [Simul, r]; ring
  · simp only [Simul, r, rx]; ring

/-! ### The argument -/

/-- **Rietdijk–Putnam.** Suppose
    (H1) whatever is simultaneous with `p` for some inertial observer is real
         relative to `p` (no privileged frame), and
    (H2) "real relative to" is transitive.
    Then every event is real relative to every event: the block universe. -/
theorem rietdijk_putnam (R : Event K → Event K → Prop)
    (H1 : ∀ p q, SimulSomeFrame p q → R p q)
    (H2 : ∀ p q r, R p q → R q r → R p r) :
    ∀ p q, R p q := by
  intro p q
  obtain ⟨r, hpr, hrq⟩ := common_simultaneity_partner p q
  exact H2 p r q (H1 p r hpr) (H1 r q hrq)

/-- Same conclusion with H1 stated in textbook form: spacelike-separated
    events are co-real, and "real relative to" is reflexive. -/
theorem rietdijk_putnam_spacelike (R : Event K → Event K → Prop)
    (Hrefl : ∀ p, R p p)
    (H1 : ∀ p q, Spacelike p q → R p q)
    (H2 : ∀ p q r, R p q → R q r → R p r) :
    ∀ p q, R p q := by
  apply rietdijk_putnam R _ H2
  intro p q h
  rcases simulSomeFrame_spacelike_or_eq h with hs | rfl
  · exact H1 p q hs
  · exact Hrefl p

/-! ### The hypotheses are consistent and independent -/

omit [IsStrictOrderedRing K] in
/-- Consistency: the block relation itself satisfies both hypotheses. -/
theorem hypotheses_consistent :
    ∃ R : Event K → Event K → Prop,
      (∀ p q, SimulSomeFrame p q → R p q) ∧ (∀ p q r, R p q → R q r → R p r) :=
  ⟨fun _ _ => True, fun _ _ _ => trivial, fun _ _ _ _ _ => trivial⟩

/-- Dropping transitivity: "spacelike or equal" satisfies H1 but fails
    to relate an event to its own future. -/
theorem transitivity_needed :
    ∃ R : Event K → Event K → Prop,
      (∀ p q, SimulSomeFrame p q → R p q) ∧ ¬ ∀ p q, R p q := by
  refine ⟨SimulSomeFrame, fun _ _ h => h, ?_⟩
  intro hall
  rcases simulSomeFrame_spacelike_or_eq (hall ⟨0, 0⟩ ⟨1, 0⟩) with h | h
  · simp [Spacelike] at h; linarith
  · have := congrArg Event.t h; simp at this

/-- Stein's relation: `q` lies in the causal past of `p`
    (in 1+1 dimensions: |Δx| ≤ Δt, with q earlier). -/
def CausalPast (p q : Event K) : Prop :=
  q.t ≤ p.t ∧ q.x - p.x ≤ p.t - q.t ∧ p.x - q.x ≤ p.t - q.t

/-- Dropping H1: Stein's causal-past relation is reflexive and transitive
    — a genuine "becoming" relation respecting relativity's causal structure —
    yet it does not make everything real. So H1 is doing real work, and
    it is exactly the hypothesis Stein rejects. -/
theorem relativity_of_reality_needed :
    (∀ p : Event K, CausalPast p p) ∧
    (∀ p q r : Event K, CausalPast p q → CausalPast q r → CausalPast p r) ∧
    ¬ (∀ p q : Event K, CausalPast p q) ∧
    ¬ (∀ p q : Event K, SimulSomeFrame p q → CausalPast p q) := by
  refine ⟨fun p => ⟨le_refl _, by simp, by simp⟩, ?_, ?_, ?_⟩
  · rintro p q r ⟨h1, h2, h3⟩ ⟨h4, h5, h6⟩
    exact ⟨by linarith, by linarith, by linarith⟩
  · intro hall
    have := (hall ⟨0, 0⟩ ⟨1, 0⟩).1; norm_num at this
  · intro hall
    have hs : SimulSomeFrame (⟨0, 0⟩ : Event K) ⟨0, 1⟩ :=
      ⟨0, ⟨by norm_num, by norm_num⟩, by simp [Simul]⟩
    have := (hall _ _ hs).2.1; norm_num at this

end BlockUniverse
