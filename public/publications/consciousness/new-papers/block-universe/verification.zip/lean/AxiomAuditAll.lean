import BlockUniverse.ReciprocalThreePlusOne
import BlockUniverse.Reciprocal
import BlockUniverse.ReciprocalNoDilation
import BlockUniverse
import BlockUniverse.HigherDim
import BlockUniverse.Stein
set_option pp.universes true
set_option pp.explicit false
#check BlockUniverse.spacelike_simulSomeFrame
#print axioms BlockUniverse.spacelike_simulSomeFrame
#check BlockUniverse.simulSomeFrame_spacelike_or_eq
#print axioms BlockUniverse.simulSomeFrame_spacelike_or_eq
#check BlockUniverse.simultaneous_iff_spacelike_or_eq
#print axioms BlockUniverse.simultaneous_iff_spacelike_or_eq
#check BlockUniverse.common_simultaneity_partner
#print axioms BlockUniverse.common_simultaneity_partner
#check BlockUniverse.rietdijk_putnam
#print axioms BlockUniverse.rietdijk_putnam
#check BlockUniverse.rietdijk_putnam_spacelike
#print axioms BlockUniverse.rietdijk_putnam_spacelike
#check BlockUniverse.hypotheses_consistent
#print axioms BlockUniverse.hypotheses_consistent
#check BlockUniverse.transitivity_needed
#print axioms BlockUniverse.transitivity_needed
#check BlockUniverse.relativity_of_reality_needed
#print axioms BlockUniverse.relativity_of_reality_needed
#check BlockUniverse.HigherDim.normSq_nonneg
#print axioms BlockUniverse.HigherDim.normSq_nonneg
#check BlockUniverse.HigherDim.normSq_zero_iff
#print axioms BlockUniverse.HigherDim.normSq_zero_iff
#check BlockUniverse.HigherDim.spacelike_simulSomeFrame
#print axioms BlockUniverse.HigherDim.spacelike_simulSomeFrame
#check BlockUniverse.HigherDim.simulSomeFrame_spacelike_or_eq
#print axioms BlockUniverse.HigherDim.simulSomeFrame_spacelike_or_eq
#check BlockUniverse.HigherDim.simultaneous_iff_spacelike_or_eq
#print axioms BlockUniverse.HigherDim.simultaneous_iff_spacelike_or_eq
#check BlockUniverse.HigherDim.dot_axisVel
#print axioms BlockUniverse.HigherDim.dot_axisVel
#check BlockUniverse.HigherDim.normSq_axisVel
#print axioms BlockUniverse.HigherDim.normSq_axisVel
#check BlockUniverse.HigherDim.common_simultaneity_partner
#print axioms BlockUniverse.HigherDim.common_simultaneity_partner
#check BlockUniverse.HigherDim.rietdijk_putnam
#print axioms BlockUniverse.HigherDim.rietdijk_putnam
#check BlockUniverse.HigherDim.rietdijk_putnam_spacelike
#print axioms BlockUniverse.HigherDim.rietdijk_putnam_spacelike
#check BlockUniverse.HigherDim.transitivity_needed
#print axioms BlockUniverse.HigherDim.transitivity_needed
#check BlockUniverse.HigherDim.relativity_of_reality_needed
#print axioms BlockUniverse.HigherDim.relativity_of_reality_needed
#check BlockUniverse.Stein.identity_iff_eq
#print axioms BlockUniverse.Stein.identity_iff_eq
#check BlockUniverse.Stein.causalPast'_iff
#print axioms BlockUniverse.Stein.causalPast'_iff
#check BlockUniverse.Stein.R_iff_origin
#print axioms BlockUniverse.Stein.R_iff_origin
#check BlockUniverse.Stein.scale
#print axioms BlockUniverse.Stein.scale
#check BlockUniverse.Stein.swap_uw
#print axioms BlockUniverse.Stein.swap_uw
#check BlockUniverse.Stein.add_uw
#print axioms BlockUniverse.Stein.add_uw
#check BlockUniverse.Stein.same_sign_ratio
#print axioms BlockUniverse.Stein.same_sign_ratio
#check BlockUniverse.Stein.stein_classification
#print axioms BlockUniverse.Stein.stein_classification
#check BlockUniverse.Stein.spacelike_forces_block
#print axioms BlockUniverse.Stein.spacelike_forces_block
#check BlockUniverse.Stein.stein_uniqueness
#print axioms BlockUniverse.Stein.stein_uniqueness
#check BlockUniverse.Stein.U_translate
#print axioms BlockUniverse.Stein.U_translate
#check BlockUniverse.Stein.W_translate
#print axioms BlockUniverse.Stein.W_translate
#check BlockUniverse.Stein.U_boost
#print axioms BlockUniverse.Stein.U_boost
#check BlockUniverse.Stein.W_boost
#print axioms BlockUniverse.Stein.W_boost
#check BlockUniverse.Stein.U_dilate
#print axioms BlockUniverse.Stein.U_dilate
#check BlockUniverse.Stein.W_dilate
#print axioms BlockUniverse.Stein.W_dilate
#check BlockUniverse.Stein.U_reflect
#print axioms BlockUniverse.Stein.U_reflect
#check BlockUniverse.Stein.W_reflect
#print axioms BlockUniverse.Stein.W_reflect
#check BlockUniverse.Stein.causalPast_satisfies_hypotheses
#print axioms BlockUniverse.Stein.causalPast_satisfies_hypotheses

#check @BlockUniverse.Reciprocal.U_swap
#print axioms BlockUniverse.Reciprocal.U_swap

#check @BlockUniverse.Reciprocal.W_swap
#print axioms BlockUniverse.Reciprocal.W_swap

#check @BlockUniverse.Reciprocal.ne_UW
#print axioms BlockUniverse.Reciprocal.ne_UW

#check @BlockUniverse.Reciprocal.mutual_core_trivial
#print axioms BlockUniverse.Reciprocal.mutual_core_trivial

#check @BlockUniverse.Reciprocal.symmetric_classification
#print axioms BlockUniverse.Reciprocal.symmetric_classification

#check @BlockUniverse.Reciprocal.reciprocal_forces_block
#print axioms BlockUniverse.Reciprocal.reciprocal_forces_block

#check @BlockUniverse.Reciprocal.one_reciprocal_pair_forces_block
#print axioms BlockUniverse.Reciprocal.one_reciprocal_pair_forces_block

#check @BlockUniverse.ReciprocalNoDilation.mutual_add
#print axioms BlockUniverse.ReciprocalNoDilation.mutual_add

#check @BlockUniverse.ReciprocalNoDilation.mutual_neg
#print axioms BlockUniverse.ReciprocalNoDilation.mutual_neg

#check @BlockUniverse.ReciprocalNoDilation.mutual_sub
#print axioms BlockUniverse.ReciprocalNoDilation.mutual_sub

#check @BlockUniverse.ReciprocalNoDilation.mutual_boost
#print axioms BlockUniverse.ReciprocalNoDilation.mutual_boost

#check @BlockUniverse.ReciprocalNoDilation.mutual_reflect
#print axioms BlockUniverse.ReciprocalNoDilation.mutual_reflect

#check @BlockUniverse.ReciprocalNoDilation.positive_boost_difference
#print axioms BlockUniverse.ReciprocalNoDilation.positive_boost_difference

#check @BlockUniverse.ReciprocalNoDilation.time_to_all_space
#print axioms BlockUniverse.ReciprocalNoDilation.time_to_all_space

#check @BlockUniverse.ReciprocalNoDilation.space_to_all_time
#print axioms BlockUniverse.ReciprocalNoDilation.space_to_all_time

#check @BlockUniverse.ReciprocalNoDilation.nonzero_mutual_universal
#print axioms BlockUniverse.ReciprocalNoDilation.nonzero_mutual_universal

#check @BlockUniverse.ReciprocalNoDilation.one_reciprocal_pair_forces_universal
#print axioms BlockUniverse.ReciprocalNoDilation.one_reciprocal_pair_forces_universal

#check @BlockUniverse.ReciprocalThreePlusOne.boost_zero
#print axioms BlockUniverse.ReciprocalThreePlusOne.boost_zero

#check @BlockUniverse.ReciprocalThreePlusOne.halfturn_zero
#print axioms BlockUniverse.ReciprocalThreePlusOne.halfturn_zero

#check @BlockUniverse.ReciprocalThreePlusOne.boost_mem
#print axioms BlockUniverse.ReciprocalThreePlusOne.boost_mem

#check @BlockUniverse.ReciprocalThreePlusOne.halfturn_mem
#print axioms BlockUniverse.ReciprocalThreePlusOne.halfturn_mem

#check @BlockUniverse.ReciprocalThreePlusOne.time_to_all_axes
#print axioms BlockUniverse.ReciprocalThreePlusOne.time_to_all_axes

#check @BlockUniverse.ReciprocalThreePlusOne.axes_to_all_time
#print axioms BlockUniverse.ReciprocalThreePlusOne.axes_to_all_time

#check @BlockUniverse.ReciprocalThreePlusOne.nonzero_mutual_universal
#print axioms BlockUniverse.ReciprocalThreePlusOne.nonzero_mutual_universal

#check @BlockUniverse.ReciprocalThreePlusOne.one_reciprocal_pair_forces_universal
#print axioms BlockUniverse.ReciprocalThreePlusOne.one_reciprocal_pair_forces_universal
