/- Direct real 1+1 reciprocal-pair universality: no dilation or classification. -/
import BlockUniverse.Stein
import Mathlib.Analysis.Real.Sqrt
namespace BlockUniverse.ReciprocalNoDilation
open BlockUniverse BlockUniverse.Stein
structure NoDilationInvariant (R : Event ℝ → Event ℝ → Prop) : Prop where
  trans_inv : ∀ a p q, R p q → R (translate a p) (translate a q)
  boost_inv : ∀ l, 0 < l → ∀ p q, R p q → R (boost l p) (boost l q)
  reflect_inv : ∀ p q, R p q → R (reflect p) (reflect q)
def addE (p q : Event ℝ) : Event ℝ := ⟨p.t+q.t,p.x+q.x⟩
def negE (p : Event ℝ) : Event ℝ := ⟨-p.t,-p.x⟩
def subE (p q : Event ℝ) : Event ℝ := addE p (negE q)
def timeE (a : ℝ) : Event ℝ := ⟨a,0⟩
def spaceE (a : ℝ) : Event ℝ := ⟨0,a⟩
def Mutual (R : Event ℝ → Event ℝ → Prop) (v : Event ℝ) : Prop := R O v ∧ R v O
variable {R : Event ℝ → Event ℝ → Prop}
lemma mutual_add (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    {v w : Event ℝ} (hv : Mutual R v) (hw : Mutual R w) : Mutual R (addE v w) := by
  have h1 := hI.trans_inv v O w hw.1
  have h2 := hI.trans_inv v w O hw.2
  have e0 : translate v O = v := by ext <;> simp [translate,O]
  have ew : translate v w = addE v w := by ext <;> simp [translate,addE] <;> ring
  rw [e0,ew] at h1 h2
  exact ⟨htrans _ _ _ hv.1 h1,htrans _ _ _ h2 hv.2⟩
lemma mutual_neg (hI : NoDilationInvariant R) {v : Event ℝ} (hv : Mutual R v) :
    Mutual R (negE v) := by
  have h1 := hI.trans_inv (negE v) v O hv.2
  have h2 := hI.trans_inv (negE v) O v hv.1
  have e0 : translate (negE v) O = negE v := by ext <;> simp [translate,O]
  have ev : translate (negE v) v = O := by ext <;> simp [translate,negE,O]
  rw [e0,ev] at h1 h2
  exact ⟨h1,h2⟩
lemma mutual_sub (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    {v w : Event ℝ} (hv : Mutual R v) (hw : Mutual R w) : Mutual R (subE v w) :=
  mutual_add hI htrans hv (mutual_neg hI hw)
lemma mutual_boost (hI : NoDilationInvariant R) {v : Event ℝ}
    (hv : Mutual R v) {l : ℝ} (hl : 0 < l) : Mutual R (boost l v) := by
  have e0 : boost l (O : Event ℝ) = O := by ext <;> simp [boost,O]
  constructor
  · simpa only [e0] using hI.boost_inv l hl O v hv.1
  · simpa only [e0] using hI.boost_inv l hl v O hv.2
lemma mutual_reflect (hI : NoDilationInvariant R) {v : Event ℝ}
    (hv : Mutual R v) : Mutual R (reflect v) := by
  have e0 : reflect (O : Event ℝ) = O := by ext <;> simp [reflect,O]
  constructor
  · simpa only [e0] using hI.reflect_inv O v hv.1
  · simpa only [e0] using hI.reflect_inv v O hv.2
lemma positive_boost_difference (s : ℝ) : ∃ l : ℝ, 0 < l ∧ l - 1/l = s := by
  let d := Real.sqrt (s*s+4)
  have hd : d*d = s*s+4 := by
    dsimp [d]
    nlinarith [Real.sq_sqrt (show 0 ≤ s*s+4 by nlinarith [sq_nonneg s])]
  have hd0 : 0 ≤ d := Real.sqrt_nonneg _
  have hds : -s < d := by nlinarith [sq_nonneg (d+s)]
  let l := (s+d)/2
  have hl : 0 < l := by dsimp [l]; linarith
  refine ⟨l,hl,?_⟩
  have hlne : l ≠ 0 := ne_of_gt hl
  have heq : l*l-s*l = 1 := by dsimp [l]; nlinarith [hd]
  field_simp
  nlinarith [heq]
lemma time_to_all_space (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    {a : ℝ} (ha : a ≠ 0) (h : Mutual R (timeE a)) : ∀ x : ℝ, Mutual R (spaceE x) := by
  intro x
  obtain ⟨l,hl,heq⟩ := positive_boost_difference (x/a)
  have hlne : l ≠ 0 := ne_of_gt hl
  have h1 := mutual_boost hI h hl
  have h2 := mutual_boost hI h (one_div_pos.mpr hl)
  have h3 := mutual_sub hI htrans h1 h2
  have ev : subE (boost l (timeE a)) (boost (1/l) (timeE a)) = spaceE x := by
    ext <;> simp only [subE,addE,negE,boost,timeE,spaceE]
    · field_simp; ring
    · have hx : a*(l-1/l)=x := by rw [heq]; field_simp
      field_simp at hx ⊢
      nlinarith [hx]
  rwa [ev] at h3
lemma space_to_all_time (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    {a : ℝ} (ha : a ≠ 0) (h : Mutual R (spaceE a)) : ∀ x : ℝ, Mutual R (timeE x) := by
  intro x
  obtain ⟨l,hl,heq⟩ := positive_boost_difference (x/a)
  have hlne : l ≠ 0 := ne_of_gt hl
  have h1 := mutual_boost hI h hl
  have h2 := mutual_boost hI h (one_div_pos.mpr hl)
  have h3 := mutual_sub hI htrans h1 h2
  have ev : subE (boost l (spaceE a)) (boost (1/l) (spaceE a)) = timeE x := by
    ext <;> simp only [subE,addE,negE,boost,timeE,spaceE]
    · have hx : a*(l-1/l)=x := by rw [heq]; field_simp
      field_simp at hx ⊢
      nlinarith [hx]
    · field_simp; ring
  rwa [ev] at h3
lemma nonzero_mutual_universal (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    {v : Event ℝ} (hne : v ≠ O) (hv : Mutual R v) : ∀ p q, R p q := by
  have hr := mutual_reflect hI hv
  have htime : Mutual R (timeE (2*v.t)) := by
    have h := mutual_add hI htrans hv hr
    have he : addE v (reflect v) = timeE (2*v.t) := by
      ext <;> simp [addE,reflect,timeE]; ring
    rwa [he] at h
  have hspace : Mutual R (spaceE (2*v.x)) := by
    have h := mutual_sub hI htrans hv hr
    have he : subE v (reflect v) = spaceE (2*v.x) := by
      ext <;> simp [subE,addE,negE,reflect,spaceE]; ring
    rwa [he] at h
  have hall : (∀ a, Mutual R (timeE a)) ∧ (∀ a, Mutual R (spaceE a)) := by
    by_cases ht : v.t = 0
    · have hx : v.x ≠ 0 := by
        intro hx
        apply hne
        ext <;> simp [O,ht,hx]
      have ha : 2*v.x ≠ 0 := mul_ne_zero (by norm_num) hx
      have hT := space_to_all_time hI htrans ha hspace
      have hS := time_to_all_space hI htrans (by norm_num : (1:ℝ) ≠ 0) (hT 1)
      exact ⟨hT,hS⟩
    · have ha : 2*v.t ≠ 0 := mul_ne_zero (by norm_num) ht
      have hS := time_to_all_space hI htrans ha htime
      have hT := space_to_all_time hI htrans (by norm_num : (1:ℝ) ≠ 0) (hS 1)
      exact ⟨hT,hS⟩
  intro p q
  have h := mutual_add hI htrans (hall.1 (q.t-p.t)) (hall.2 (q.x-p.x))
  have h1 := hI.trans_inv p O (addE (timeE (q.t-p.t)) (spaceE (q.x-p.x))) h.1
  have e0 : translate p O = p := by ext <;> simp [translate,O]
  have eq : translate p (addE (timeE (q.t-p.t)) (spaceE (q.x-p.x))) = q := by
    ext <;> simp [translate,addE,timeE,spaceE]
  rwa [e0,eq] at h1
theorem one_reciprocal_pair_forces_universal
    (hI : NoDilationInvariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    (p q : Event ℝ) (hne : p ≠ q) (hpq : R p q) (hqp : R q p) : ∀ a b, R a b := by
  let v : Event ℝ := ⟨q.t-p.t,q.x-p.x⟩
  let a : Event ℝ := ⟨-p.t,-p.x⟩
  have e0 : translate a p = O := by ext <;> simp [a,translate,O]
  have ev : translate a q = v := by ext <;> simp [a,v,translate] <;> ring
  have h1 := hI.trans_inv a p q hpq
  have h2 := hI.trans_inv a q p hqp
  rw [e0,ev] at h1 h2
  have hv : v ≠ O := by
    intro h
    have ht := congrArg Event.t h
    have hx := congrArg Event.x h
    apply hne
    ext <;> simp [v,O] at ht hx ⊢ <;> linarith
  exact nonzero_mutual_universal hI htrans hv ⟨h1,h2⟩
#print axioms one_reciprocal_pair_forces_universal
end BlockUniverse.ReciprocalNoDilation
