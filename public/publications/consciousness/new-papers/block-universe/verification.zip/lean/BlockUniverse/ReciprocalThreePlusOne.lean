/- Real 3+1 direct reciprocal universality under translations, axis boosts,
   and proper spatial half-turns. No dilation, continuity, or classification. -/
import BlockUniverse.ReciprocalNoDilation
import Mathlib.Tactic.FinCases
noncomputable section
namespace BlockUniverse.ReciprocalThreePlusOne
abbrev V := ℝ × (Fin 3 → ℝ)
def timeV (a : ℝ) : V := (a,0)
def axisV (i : Fin 3) (a : ℝ) : V := (0,fun j => if j=i then a else 0)
def halfturnV (i : Fin 3) (v : V) : V := (v.1,fun j => if j=i then v.2 j else -v.2 j)
def c (l : ℝ) : ℝ := (l+1/l)/2
def s (l : ℝ) : ℝ := (l-1/l)/2
def boostV (i : Fin 3) (l : ℝ) (v : V) : V :=
  (c l*v.1+s l*v.2 i, fun j => if j=i then s l*v.1+c l*v.2 i else v.2 j)
structure Invariant (R : V → V → Prop) : Prop where
  trans_inv : ∀ a p q, R p q → R (p+a) (q+a)
  boost_inv : ∀ i l, 0 < l → ∀ p q, R p q → R (boostV i l p) (boostV i l q)
  halfturn_inv : ∀ i p q, R p q → R (halfturnV i p) (halfturnV i q)
variable {R : V → V → Prop}
def mutualSubgroup (hI : Invariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r) (h0 : R 0 0) : AddSubgroup V where
  carrier := {v | R 0 v ∧ R v 0}
  zero_mem' := ⟨h0,h0⟩
  add_mem' := by
    intro a b ha hb
    constructor
    · have h := hI.trans_inv a 0 b hb.1
      have h' : R a (a+b) := by simpa [add_comm] using h
      exact htrans _ _ _ ha.1 h'
    · have h := hI.trans_inv a b 0 hb.2
      have h' : R (a+b) a := by simpa [add_comm] using h
      exact htrans _ _ _ h' ha.2
  neg_mem' := by
    intro a ha
    have h1 := hI.trans_inv (-a) a 0 ha.2
    have h2 := hI.trans_inv (-a) 0 a ha.1
    exact ⟨by simpa using h1,by simpa using h2⟩
lemma boost_zero (i : Fin 3) (l : ℝ) : boostV i l 0 = 0 := by
  apply Prod.ext
  · simp [boostV]
  · funext j; simp [boostV]
lemma halfturn_zero (i : Fin 3) : halfturnV i 0 = 0 := by
  apply Prod.ext
  · simp [halfturnV]
  · funext j; simp [halfturnV]
lemma boost_mem (hI : Invariant R) (htrans : ∀ p q r, R p q → R q r → R p r)
    (h0 : R 0 0) {v : V} (hv : v ∈ mutualSubgroup hI htrans h0)
    (i : Fin 3) {l : ℝ} (hl : 0 < l) : boostV i l v ∈ mutualSubgroup hI htrans h0 := by
  exact ⟨by simpa [boost_zero] using hI.boost_inv i l hl 0 v hv.1,
         by simpa [boost_zero] using hI.boost_inv i l hl v 0 hv.2⟩
lemma halfturn_mem (hI : Invariant R) (htrans : ∀ p q r, R p q → R q r → R p r)
    (h0 : R 0 0) {v : V} (hv : v ∈ mutualSubgroup hI htrans h0) (i : Fin 3) :
    halfturnV i v ∈ mutualSubgroup hI htrans h0 := by
  exact ⟨by simpa [halfturn_zero] using hI.halfturn_inv i 0 v hv.1,
         by simpa [halfturn_zero] using hI.halfturn_inv i v 0 hv.2⟩
lemma time_to_all_axes (hI : Invariant R) (htrans : ∀ p q r, R p q → R q r → R p r)
    (h0 : R 0 0) {a : ℝ} (ha : a ≠ 0) (hv : timeV a ∈ mutualSubgroup hI htrans h0) :
    ∀ i x, axisV i x ∈ mutualSubgroup hI htrans h0 := by
  intro i x
  obtain ⟨l,hl,heq⟩ := ReciprocalNoDilation.positive_boost_difference (x/a)
  have hn : l ≠ 0 := ne_of_gt hl
  have h1 := boost_mem hI htrans h0 hv i hl
  have h2 := boost_mem hI htrans h0 hv i (one_div_pos.mpr hl)
  have h3 := (mutualSubgroup hI htrans h0).sub_mem h1 h2
  have hx : a*(l-1/l)=x := by rw [heq]; field_simp
  have eq : boostV i l (timeV a) - boostV i (1/l) (timeV a) = axisV i x := by
    apply Prod.ext
    · simp [boostV,timeV,axisV,c,s]
      field_simp
      ring
    · funext j
      by_cases hj : j=i
      · simp [boostV,timeV,axisV,c,s,hj]
        field_simp at hx ⊢
        nlinarith [hx]
      · simp [boostV,timeV,axisV,hj]
  rwa [eq] at h3
lemma axes_to_all_time (hI : Invariant R) (htrans : ∀ p q r, R p q → R q r → R p r)
    (h0 : R 0 0) (h : ∀ i x, axisV i x ∈ mutualSubgroup hI htrans h0) :
    ∀ t, timeV t ∈ mutualSubgroup hI htrans h0 := by
  intro t
  have h1 := boost_mem hI htrans h0 (h 0 (4*t/3)) 0 (by norm_num : (0:ℝ)<2)
  have h2 := (mutualSubgroup hI htrans h0).sub_mem h1 (h 0 (5*t/3))
  have eq : boostV 0 2 (axisV 0 (4*t/3)) - axisV 0 (5*t/3) = timeV t := by
    apply Prod.ext
    · norm_num [boostV,axisV,timeV,c,s] <;> ring
    · funext j
      by_cases hj : j=0
      · simp [boostV,axisV,timeV,c,s,hj]; ring
      · simp [boostV,axisV,timeV,c,s,hj]
  rwa [eq] at h2
lemma nonzero_mutual_universal (hI : Invariant R) (htrans : ∀ p q r, R p q → R q r → R p r)
    (h0 : R 0 0) {v : V} (hne : v ≠ 0) (hv : v ∈ mutualSubgroup hI htrans h0) : ∀ p q, R p q := by
  let H := mutualSubgroup hI htrans h0
  have hp := halfturn_mem hI htrans h0 hv 0
  have hu := H.add_mem hv hp
  have hpu := halfturn_mem hI htrans h0 hu 1
  have he : (v + halfturnV 0 v) + halfturnV 1 (v + halfturnV 0 v) = timeV (4*v.1) := by
    apply Prod.ext
    · simp [halfturnV,timeV]; ring
    · funext j; fin_cases j <;> simp [halfturnV,timeV] <;> ring
  have htime : timeV (4*v.1) ∈ H := by simpa [he] using H.add_mem hu hpu
  have ht_nonzero : ∃ a, a ≠ 0 ∧ timeV a ∈ H := by
    by_cases ht : v.1 = 0
    · have hx : ∃ i, v.2 i ≠ 0 := by
        by_contra hc
        push Not at hc
        apply hne
        apply Prod.ext
        · exact ht
        · funext i; exact hc i
      obtain ⟨i,hi⟩ := hx
      have hb1 := boost_mem hI htrans h0 hv i (by norm_num : (0:ℝ)<2)
      have hb2 := boost_mem hI htrans h0 hv i (by norm_num : (0:ℝ)<1/2)
      have hd := H.sub_mem hb1 hb2
      have eq : boostV i 2 v - boostV i (1/2) v = timeV (3*v.2 i/2) := by
        apply Prod.ext
        · norm_num [boostV,timeV,c,s,ht]; ring
        · funext j
          by_cases hj : j=i
          · simp [boostV,timeV,c,s,ht,hj]; ring
          · simp [boostV,timeV,hj]
      refine ⟨3*v.2 i/2,by exact div_ne_zero (mul_ne_zero (by norm_num) hi) (by norm_num),?_⟩
      rwa [eq] at hd
    · exact ⟨4*v.1,mul_ne_zero (by norm_num) ht,htime⟩
  obtain ⟨a,ha,hA⟩ := ht_nonzero
  have haxes := time_to_all_axes hI htrans h0 ha hA
  have htimes := axes_to_all_time hI htrans h0 haxes
  have allmem : ∀ w : V, w ∈ H := by
    intro w
    have h := H.add_mem (H.add_mem (H.add_mem (htimes w.1) (haxes 0 (w.2 0)))
      (haxes 1 (w.2 1))) (haxes 2 (w.2 2))
    have eq : timeV w.1 + axisV 0 (w.2 0) + axisV 1 (w.2 1) + axisV 2 (w.2 2) = w := by
      apply Prod.ext
      · simp [timeV,axisV]
      · funext j; fin_cases j <;> simp [timeV,axisV]
    rwa [eq] at h
  intro p q
  have h : R 0 (q-p) := (allmem (q-p)).1
  have ht := hI.trans_inv p 0 (q-p) h
  simpa using ht

theorem one_reciprocal_pair_forces_universal (hI : Invariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    (p q : V) (hne : p ≠ q) (hpq : R p q) (hqp : R q p) : ∀ a b, R a b := by
  have hpp := htrans p q p hpq hqp
  have h0 : R 0 0 := by simpa using hI.trans_inv (-p) p p hpp
  have hv : q-p ∈ mutualSubgroup hI htrans h0 := by
    exact ⟨by simpa [sub_eq_add_neg] using hI.trans_inv (-p) p q hpq,
           by simpa [sub_eq_add_neg] using hI.trans_inv (-p) q p hqp⟩
  have hn : q-p ≠ 0 := sub_ne_zero.mpr (Ne.symm hne)
  exact nonzero_mutual_universal hI htrans h0 hn hv
#print axioms one_reciprocal_pair_forces_universal
end BlockUniverse.ReciprocalThreePlusOne
