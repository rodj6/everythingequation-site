/-
  A Stein-type classification theorem in 1+1 dimensions
  =====================================================

  Question: which "is real relative to" relations R are compatible with
  special relativity? We ask only that R be

    * reflexive and transitive, and
    * invariant under the symmetries of Minkowski spacetime that preserve
      the direction of time: translations, Lorentz boosts, dilations
      (rescaling all distances), and spatial reflection.

  Theorem (`stein_classification`): over any ordered field in which positive
  elements have square roots (e.g. ℝ), R must be exactly one of six relations:

      identity · chronological past · causal past
               · chronological future · causal future · universal (the block)

  Corollaries
  * `spacelike_forces_block` : if R relates even ONE pair of spacelike-
      separated events, R is universal. (A sharp Rietdijk–Putnam: symmetry
      plus transitivity spread a single spacelike link everywhere.)
  * `stein_uniqueness` : if R counts each event's causal past as real and
      is not the block, R is exactly the causal past: Stein's light-cone
      "becoming" relation is the unique non-trivial alternative.

  Coordinates: light-cone coordinates u = t + x, w = t − x of a displacement.
  Boosts and dilations act as u ↦ a·u, w ↦ b·w (a, b > 0); reflection swaps u, w.

  Note: Stein (1968, 1991) and Clifton–Hogarth (1995) work in 3+1 dimensions
  with slightly different hypotheses; this file captures the same
  classification idea in 1+1 dimensions.
-/
import BlockUniverse
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Algebra.Order.Field.Basic

namespace BlockUniverse.Stein

open BlockUniverse

variable {K : Type*} [Field K] [LinearOrder K] [IsStrictOrderedRing K]

/-! ### Symmetries -/

def translate (a e : Event K) : Event K := ⟨e.t + a.t, e.x + a.x⟩

/-- Lorentz boost with Doppler factor `l > 0`: u ↦ l·u, w ↦ w / l. -/
def boost (l : K) (e : Event K) : Event K :=
  ⟨(l * (e.t + e.x) + (e.t - e.x) / l) / 2, (l * (e.t + e.x) - (e.t - e.x) / l) / 2⟩

/-- Dilation by `c > 0`. -/
def dilate (c : K) (e : Event K) : Event K := ⟨c * e.t, c * e.x⟩

/-- Spatial reflection. -/
def reflect (e : Event K) : Event K := ⟨e.t, -e.x⟩

/-- Light-cone coordinates of the displacement from `p` to `q`. -/
def U (p q : Event K) : K := (q.t - p.t) + (q.x - p.x)
def W (p q : Event K) : K := (q.t - p.t) - (q.x - p.x)

/-- The symmetry hypotheses on R. -/
structure Invariant (R : Event K → Event K → Prop) : Prop where
  trans_inv : ∀ a p q, R p q → R (translate a p) (translate a q)
  boost_inv : ∀ l, 0 < l → ∀ p q, R p q → R (boost l p) (boost l q)
  dilate_inv : ∀ c, 0 < c → ∀ p q, R p q → R (dilate c p) (dilate c q)
  reflect_inv : ∀ p q, R p q → R (reflect p) (reflect q)

/-! ### The six candidate relations -/

def Identity (p q : Event K) : Prop := U p q = 0 ∧ W p q = 0
def ChronPast (p q : Event K) : Prop := (U p q = 0 ∧ W p q = 0) ∨ (U p q < 0 ∧ W p q < 0)
def CausalPast' (p q : Event K) : Prop := U p q ≤ 0 ∧ W p q ≤ 0
def ChronFuture (p q : Event K) : Prop := (U p q = 0 ∧ W p q = 0) ∨ (0 < U p q ∧ 0 < W p q)
def CausalFuture (p q : Event K) : Prop := 0 ≤ U p q ∧ 0 ≤ W p q
def Universal (_ _ : Event K) : Prop := True

lemma identity_iff_eq (p q : Event K) : Identity p q ↔ p = q := by
  unfold Identity U W
  constructor
  · rintro ⟨h1, h2⟩; ext <;> linarith
  · rintro rfl; constructor <;> ring

/-- Agrees with the causal-past relation used in `BlockUniverse`. -/
lemma causalPast'_iff (p q : Event K) : CausalPast' p q ↔ CausalPast p q := by
  unfold CausalPast' CausalPast U W
  constructor
  · rintro ⟨h1, h2⟩; exact ⟨by linarith, by linarith, by linarith⟩
  · rintro ⟨h1, h2, h3⟩; exact ⟨by linarith, by linarith⟩

/-! ### Reduction to displacements from the origin -/

/-- The event with light-cone coordinates (u, w). -/
def mk (u w : K) : Event K := ⟨(u + w) / 2, (u - w) / 2⟩

def O : Event K := ⟨0, 0⟩

section
variable (R : Event K → Event K → Prop) (hI : Invariant R)
include hI

/-- R p q depends only on the light-cone displacement (U, W). -/
lemma R_iff_origin (p q : Event K) : R p q ↔ R O (mk (U p q) (W p q)) := by
  have e1 : translate ⟨-p.t, -p.x⟩ p = O := by simp [translate, O]
  have e2 : translate ⟨-p.t, -p.x⟩ q = mk (U p q) (W p q) := by
    simp only [translate, mk, U, W]; congr 1 <;> ring
  have e3 : translate p O = p := by simp [translate, O]
  have e4 : translate p (mk (U p q) (W p q)) = q := by
    simp only [translate, mk, U, W]; ext <;> simp
  constructor
  · intro h; have := hI.trans_inv ⟨-p.t, -p.x⟩ p q h; rwa [e1, e2] at this
  · intro h; have := hI.trans_inv p _ _ h; rwa [e3, e4] at this

/-- Independent positive rescaling of u and w, using a square root. -/
lemma scale (hsqrt : ∀ y : K, 0 < y → ∃ s, 0 < s ∧ s * s = y)
    {a b : K} (ha : 0 < a) (hb : 0 < b) (u w : K) :
    R O (mk u w) → R O (mk (a * u) (b * w)) := by
  obtain ⟨s, hs, hss⟩ := hsqrt (a * b) (mul_pos ha hb)
  intro h
  have h1 := hI.dilate_inv s hs _ _ h
  have h2 := hI.boost_inv (a / s) (div_pos ha hs) _ _ h1
  have eO : boost (a / s) (dilate s (O : Event K)) = O := by
    simp [boost, dilate, O]
  have eM : boost (a / s) (dilate s (mk u w)) = mk (a * u) (b * w) := by
    have hb' : b = s * s / a := by rw [hss]; field_simp
    simp only [boost, dilate, mk]
    subst hb'
    ext <;> field_simp <;> ring
  rwa [eO, eM] at h2

lemma swap_uw (u w : K) : R O (mk u w) → R O (mk w u) := by
  intro h
  have := hI.reflect_inv _ _ h
  have eO : reflect (O : Event K) = O := by simp [reflect, O]
  have eM : reflect (mk u w) = mk w u := by
    simp only [reflect, mk]; ext <;> simp <;> ring
  rwa [eO, eM] at this

lemma add_uw (htrans : ∀ p q r, R p q → R q r → R p r) (u w u' w' : K) :
    R O (mk u w) → R O (mk u' w') → R O (mk (u + u') (w + w')) := by
  intro h1 h2
  have h2' := hI.trans_inv (mk u w) _ _ h2
  have eO : translate (mk u w) (O : Event K) = mk u w := by simp [translate, O, mk]
  have eM : translate (mk u w) (mk u' w') = mk (u + u') (w + w') := by
    simp only [translate, mk]; ext <;> simp <;> ring
  rw [eO, eM] at h2'
  exact htrans _ _ _ h1 h2'

end

/-- Ratio taking `x` to `y` when they have the same sign. -/
lemma same_sign_ratio {x y : K} (h1 : 0 < x ↔ 0 < y) (h2 : x < 0 ↔ y < 0) :
    ∃ a, 0 < a ∧ a * x = y := by
  rcases lt_trichotomy x 0 with hx | hx | hx
  · have hy := h2.mp hx
    exact ⟨y / x, div_pos_of_neg_of_neg hy hx, div_mul_cancel₀ y hx.ne⟩
  · have hy : y = 0 := by
      rcases lt_trichotomy y 0 with hy | hy | hy
      · exact absurd (h2.mpr hy) (by rw [hx]; exact lt_irrefl 0)
      · exact hy
      · exact absurd (h1.mpr hy) (by rw [hx]; exact lt_irrefl 0)
    exact ⟨1, one_pos, by rw [hx, hy, mul_zero]⟩
  · have hy := h1.mp hx
    exact ⟨y / x, div_pos hy hx, div_mul_cancel₀ y hx.ne'⟩

/-- Sign-matching side goals. -/
macro "sgn" : tactic => `(tactic| (constructor <;> intro <;> linarith))

/-! ### The classification -/

theorem stein_classification
    (hsqrt : ∀ y : K, 0 < y → ∃ s, 0 < s ∧ s * s = y)
    (R : Event K → Event K → Prop) (hI : Invariant R)
    (hrefl : ∀ p, R p p) (htrans : ∀ p q r, R p q → R q r → R p r) :
    (∀ p q, R p q ↔ Identity p q) ∨
    (∀ p q, R p q ↔ ChronPast p q) ∨
    (∀ p q, R p q ↔ CausalPast' p q) ∨
    (∀ p q, R p q ↔ ChronFuture p q) ∨
    (∀ p q, R p q ↔ CausalFuture p q) ∨
    (∀ p q, R p q ↔ Universal p q) := by
  -- S u w : the displacement with light-cone coordinates (u, w) is related to O
  let S : K → K → Prop := fun u w => R O (mk u w)
  have hRS : ∀ p q, R p q ↔ S (U p q) (W p q) := R_iff_origin R hI
  -- transport within a sign class
  have tr : ∀ u w u' w', (0 < u ↔ 0 < u') → (u < 0 ↔ u' < 0) →
      (0 < w ↔ 0 < w') → (w < 0 ↔ w' < 0) → S u w → S u' w' := by
    intro u w u' w' a1 a2 b1 b2 h
    obtain ⟨a, ha, hau⟩ := same_sign_ratio a1 a2
    obtain ⟨b, hb, hbw⟩ := same_sign_ratio b1 b2
    have := scale R hI hsqrt ha hb u w h
    rwa [hau, hbw] at this
  have sw : ∀ u w, S u w → S w u := swap_uw R hI
  have ad : ∀ u w u' w', S u w → S u' w' → S (u + u') (w + w') := add_uw R hI htrans
  have s00 : S 0 0 := by
    have := (hRS O O).mp (hrefl O); simpa [U, W, O] using this
  -- Flags for the sign classes (representatives)
  -- A: future timelike, B: past timelike, C: future null, D: past null, E: spacelike
  -- Characterisation of S by class
  have key : ∀ u w, S u w ↔
      (u = 0 ∧ w = 0) ∨ (0 < u ∧ 0 < w ∧ S 1 1) ∨ (u < 0 ∧ w < 0 ∧ S (-1) (-1)) ∨
      (((0 < u ∧ w = 0) ∨ (u = 0 ∧ 0 < w)) ∧ S 1 0) ∨
      (((u < 0 ∧ w = 0) ∨ (u = 0 ∧ w < 0)) ∧ S (-1) 0) ∨
      (((0 < u ∧ w < 0) ∨ (u < 0 ∧ 0 < w)) ∧ S 1 (-1)) := by
    intro u w
    have one : (0 : K) < 1 := one_pos
    have mone : (-1 : K) < 0 := by norm_num
    -- helper: move between a class member and its representative
    have T : ∀ u w u' w', (0 < u ↔ 0 < u') → (u < 0 ↔ u' < 0) →
        (0 < w ↔ 0 < w') → (w < 0 ↔ w' < 0) → (S u w ↔ S u' w') := fun u w u' w' a b c d =>
      ⟨tr u w u' w' a b c d, tr u' w' u w a.symm b.symm c.symm d.symm⟩
    constructor
    · intro h
      rcases lt_trichotomy u 0 with hu | hu | hu <;>
      rcases lt_trichotomy w 0 with hw | hw | hw
      · exact Or.inr (Or.inr (Or.inl ⟨hu, hw, tr _ _ _ _
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h⟩))
      · subst hw
        refine Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨Or.inl ⟨hu, rfl⟩, tr _ _ _ _ ?_ ?_ ?_ ?_ h⟩))))
          <;> constructor <;> intro <;> linarith
      · refine Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨Or.inr ⟨hu, hw⟩, ?_⟩))))
        apply sw
        exact tr _ _ _ _ (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h
      · subst hu
        refine Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨Or.inr ⟨rfl, hw⟩, ?_⟩))))
        apply sw
        exact tr _ _ _ _ (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h
      · exact Or.inl ⟨hu, hw⟩
      · subst hu
        refine Or.inr (Or.inr (Or.inr (Or.inl ⟨Or.inr ⟨rfl, hw⟩, ?_⟩)))
        apply sw
        exact tr _ _ _ _ (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h
      · refine Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨Or.inl ⟨hu, hw⟩, ?_⟩))))
        exact tr _ _ _ _ (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h
      · subst hw
        refine Or.inr (Or.inr (Or.inr (Or.inl ⟨Or.inl ⟨hu, rfl⟩, ?_⟩)))
        exact tr _ _ _ _ (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h
      · exact Or.inr (Or.inl ⟨hu, hw, tr _ _ _ _
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith)
          (by constructor <;> intro <;> linarith) (by constructor <;> intro <;> linarith) h⟩)
    · rintro (⟨rfl, rfl⟩ | ⟨hu, hw, h⟩ | ⟨hu, hw, h⟩ | ⟨(⟨hu, rfl⟩ | ⟨rfl, hw⟩), h⟩ |
          ⟨(⟨hu, rfl⟩ | ⟨rfl, hw⟩), h⟩ | ⟨(⟨hu, hw⟩ | ⟨hu, hw⟩), h⟩)
      · exact s00
      · exact tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h
      · exact tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h
      · exact tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h
      · exact sw _ _ (tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h)
      · exact tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h
      · exact sw _ _ (tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h)
      · exact tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h
      · exact sw _ _ (tr _ _ _ _ (by sgn) (by sgn) (by sgn) (by sgn) h)
  -- Closure facts
  have E_univ : S 1 (-1) → ∀ u w, S u w := by
    intro hE u w
    -- (u, w) = (u1, w1) + (u2, w2) with (+,-) and (-,+)
    set u1 : K := max u 0 + 1
    set w2 : K := max w 0 + 1
    have hu1 : 0 < u1 := by have := le_max_right u 0; linarith
    have hw2 : 0 < w2 := by have := le_max_right w 0; linarith
    have hu2 : u - u1 < 0 := by have := le_max_left u 0; linarith
    have hw1 : w - w2 < 0 := by have := le_max_left w 0; linarith
    have s1 : S u1 (w - w2) := (key _ _).mpr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
      ⟨Or.inl ⟨hu1, hw1⟩, hE⟩)))))
    have s2 : S (u - u1) w2 := (key _ _).mpr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
      ⟨Or.inr ⟨hu2, hw2⟩, hE⟩)))))
    have := ad _ _ _ _ s1 s2
    have e1 : u1 + (u - u1) = u := by ring
    have e2 : w - w2 + w2 = w := by ring
    rwa [e1, e2] at this
  have AB_E : S 1 1 → S (-1) (-1) → S 1 (-1) := by
    intro hA hB
    have h1 : S 2 1 := (key _ _).mpr (Or.inr (Or.inl ⟨by norm_num, by norm_num, hA⟩))
    have h2 : S (-1) (-2) := (key _ _).mpr (Or.inr (Or.inr (Or.inl ⟨by norm_num, by norm_num, hB⟩)))
    have := ad _ _ _ _ h1 h2
    rwa [show (2 : K) + -1 = 1 by norm_num, show (1 : K) + -2 = -1 by norm_num] at this
  have C_A : S 1 0 → S 1 1 := by
    intro hC; have := ad _ _ _ _ hC (sw _ _ hC)
    rwa [show (1 : K) + 0 = 1 by norm_num, show (0 : K) + 1 = 1 by norm_num] at this
  have D_B : S (-1) 0 → S (-1) (-1) := by
    intro hD; have := ad _ _ _ _ hD (sw _ _ hD)
    rwa [show (-1 : K) + 0 = -1 by norm_num, show (0 : K) + -1 = -1 by norm_num] at this
  have CB_E : S 1 0 → S (-1) (-1) → S 1 (-1) := by
    intro hC hB
    have h1 : S 2 0 := (key _ _).mpr (Or.inr (Or.inr (Or.inr (Or.inl
      ⟨Or.inl ⟨by norm_num, rfl⟩, hC⟩))))
    have := ad _ _ _ _ h1 hB
    rwa [show (2 : K) + -1 = 1 by norm_num, show (0 : K) + -1 = -1 by norm_num] at this
  have DA_E : S (-1) 0 → S 1 1 → S 1 (-1) := by
    intro hD hA
    have h1 : S 0 (-2) := (key _ _).mpr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl
      ⟨Or.inr ⟨rfl, by norm_num⟩, hD⟩)))))
    have := ad _ _ _ _ hA h1
    rwa [show (1 : K) + 0 = 1 by norm_num, show (1 : K) + -2 = -1 by norm_num] at this
  -- Case analysis on the flags
  by_cases hE : S 1 (-1)
  · right; right; right; right; right
    intro p q; simp only [Universal, iff_true]; exact (hRS p q).mpr (E_univ hE _ _)
  have nAB : ¬ (S 1 1 ∧ S (-1) (-1)) := fun h => hE (AB_E h.1 h.2)
  by_cases hA : S 1 1
  · have hB : ¬ S (-1) (-1) := fun hB => nAB ⟨hA, hB⟩
    have hD : ¬ S (-1) 0 := fun hD => hE (DA_E hD hA)
    by_cases hC : S 1 0
    · -- causal future
      have hk := key
      simp only [hA, hB, hC, hD, hE, and_true, and_false, or_false, false_or] at hk
      right; right; right; right; left
      intro p q; rw [hRS, hk]; unfold CausalFuture
      constructor
      · rintro (⟨h1, h2⟩ | ⟨h1, h2⟩ | (⟨h1, h2⟩ | ⟨h1, h2⟩)) <;> constructor <;> linarith
      · rintro ⟨h1, h2⟩
        rcases h1.lt_or_eq with h1 | h1 <;> rcases h2.lt_or_eq with h2 | h2
        · exact Or.inr (Or.inl ⟨h1, h2⟩)
        · exact Or.inr (Or.inr (Or.inl ⟨h1, h2.symm⟩))
        · exact Or.inr (Or.inr (Or.inr ⟨h1.symm, h2⟩))
        · exact Or.inl ⟨h1.symm, h2.symm⟩
    · -- chronological future
      have hk := key
      simp only [hA, hB, hC, hD, hE, and_true, and_false, or_false, false_or] at hk
      right; right; right; left; intro p q; rw [hRS, hk]; rfl
  · have hC : ¬ S 1 0 := fun hC => hA (C_A hC)
    by_cases hB : S (-1) (-1)
    · by_cases hD : S (-1) 0
      · -- causal past
        have hk := key
        simp only [hA, hB, hC, hD, hE, and_true, and_false, or_false, false_or] at hk
        right; right; left
        intro p q; rw [hRS, hk]; unfold CausalPast'
        constructor
        · rintro (⟨h1, h2⟩ | ⟨h1, h2⟩ | (⟨h1, h2⟩ | ⟨h1, h2⟩)) <;> constructor <;> linarith
        · rintro ⟨h1, h2⟩
          rcases h1.lt_or_eq with h1 | h1 <;> rcases h2.lt_or_eq with h2 | h2
          · exact Or.inr (Or.inl ⟨h1, h2⟩)
          · exact Or.inr (Or.inr (Or.inl ⟨h1, h2⟩))
          · exact Or.inr (Or.inr (Or.inr ⟨h1, h2⟩))
          · exact Or.inl ⟨h1, h2⟩
      · -- chronological past
        have hk := key
        simp only [hA, hB, hC, hD, hE, and_true, and_false, or_false, false_or] at hk
        right; left; intro p q; rw [hRS, hk]; rfl
    · -- identity
      have hD : ¬ S (-1) 0 := fun hD => hB (D_B hD)
      have hk := key
      simp only [hA, hB, hC, hD, hE, and_true, and_false, or_false, false_or] at hk
      left; intro p q; rw [hRS, hk]; rfl

/-! ### Corollaries -/

/-- One spacelike link is enough: an invariant, transitive relation that
    relates any spacelike-separated pair relates everything. -/
theorem spacelike_forces_block
    (hsqrt : ∀ y : K, 0 < y → ∃ s, 0 < s ∧ s * s = y)
    (R : Event K → Event K → Prop) (hI : Invariant R)
    (hrefl : ∀ p, R p p) (htrans : ∀ p q r, R p q → R q r → R p r)
    (p₀ q₀ : Event K) (hsp : Spacelike p₀ q₀) (h : R p₀ q₀) :
    ∀ p q, R p q := by
  have hsp' : U p₀ q₀ * W p₀ q₀ < 0 := by
    unfold Spacelike at hsp; unfold U W; nlinarith
  rcases stein_classification hsqrt R hI hrefl htrans with
    H | H | H | H | H | H
  all_goals try (intro p q; exact (H p q).mpr trivial)
  all_goals exfalso
  all_goals
    have := (H p₀ q₀).mp h
    simp only [Identity, ChronPast, CausalPast', ChronFuture, CausalFuture] at this
  · obtain ⟨h1, h2⟩ := this; rw [h1] at hsp'; simp at hsp'
  · rcases this with ⟨h1, h2⟩ | ⟨h1, h2⟩
    · rw [h1] at hsp'; simp at hsp'
    · nlinarith
  · obtain ⟨h1, h2⟩ := this; nlinarith
  · rcases this with ⟨h1, h2⟩ | ⟨h1, h2⟩
    · rw [h1] at hsp'; simp at hsp'
    · nlinarith
  · obtain ⟨h1, h2⟩ := this; nlinarith

/-- **Stein uniqueness.** If every event's causal past is real for it, and R
    is not the block universe, then R is exactly the causal past. -/
theorem stein_uniqueness
    (hsqrt : ∀ y : K, 0 < y → ∃ s, 0 < s ∧ s * s = y)
    (R : Event K → Event K → Prop) (hI : Invariant R)
    (htrans : ∀ p q r, R p q → R q r → R p r)
    (hpast : ∀ p q, CausalPast p q → R p q)
    (hnot : ¬ ∀ p q, R p q) :
    ∀ p q, R p q ↔ CausalPast p q := by
  have hrefl : ∀ p, R p p := fun p => hpast p p ⟨le_refl _, by simp, by simp⟩
  -- witnesses: a past-null and a past-timelike displacement
  let o : Event K := ⟨0, 0⟩
  have hn : R o ⟨-1, 1⟩ := hpast _ _ ⟨by norm_num, by norm_num, by norm_num⟩
  have ht : R o ⟨-1, 0⟩ := hpast _ _ ⟨by norm_num, by norm_num, by norm_num⟩
  rcases stein_classification hsqrt R hI hrefl htrans with
    H | H | H | H | H | H
  · have := (H _ _).mp hn; norm_num [Identity, U, W, o] at this
  · have := (H _ _).mp hn; norm_num [ChronPast, U, W, o] at this
  · intro p q; rw [H, causalPast'_iff]
  · have := (H _ _).mp ht; norm_num [ChronFuture, U, W, o] at this
  · have := (H _ _).mp ht; norm_num [CausalFuture, U, W, o] at this
  · exact absurd (fun p q => (H p q).mpr trivial) hnot

/-! ### Non-vacuity: Stein's relation really satisfies every hypothesis -/

lemma U_translate (a p q : Event K) : U (translate a p) (translate a q) = U p q := by
  simp only [U, translate]; ring
lemma W_translate (a p q : Event K) : W (translate a p) (translate a q) = W p q := by
  simp only [W, translate]; ring
lemma U_boost {l : K} (hl : 0 < l) (p q : Event K) :
    U (boost l p) (boost l q) = l * U p q := by
  simp only [U, boost]; field_simp; ring
lemma W_boost {l : K} (hl : 0 < l) (p q : Event K) :
    W (boost l p) (boost l q) = W p q / l := by
  simp only [W, boost]; field_simp; ring
lemma U_dilate (c : K) (p q : Event K) : U (dilate c p) (dilate c q) = c * U p q := by
  simp only [U, dilate]; ring
lemma W_dilate (c : K) (p q : Event K) : W (dilate c p) (dilate c q) = c * W p q := by
  simp only [W, dilate]; ring
lemma U_reflect (p q : Event K) : U (reflect p) (reflect q) = W p q := by
  simp only [U, W, reflect]; ring
lemma W_reflect (p q : Event K) : W (reflect p) (reflect q) = U p q := by
  simp only [U, W, reflect]; ring

/-- The causal-past relation is reflexive, transitive and invariant, so
    `stein_uniqueness` is not vacuous. -/
theorem causalPast_satisfies_hypotheses :
    Invariant (CausalPast' (K := K)) ∧ (∀ p : Event K, CausalPast' p p) ∧
    (∀ p q r : Event K, CausalPast' p q → CausalPast' q r → CausalPast' p r) := by
  refine ⟨⟨?_, ?_, ?_, ?_⟩, ?_, ?_⟩
  · intro a p q ⟨h1, h2⟩; exact ⟨by rw [U_translate]; exact h1, by rw [W_translate]; exact h2⟩
  · intro l hl p q ⟨h1, h2⟩
    refine ⟨by rw [U_boost hl]; nlinarith, by rw [W_boost hl]; exact div_nonpos_of_nonpos_of_nonneg h2 hl.le⟩
  · intro c hc p q ⟨h1, h2⟩
    exact ⟨by rw [U_dilate]; nlinarith, by rw [W_dilate]; nlinarith⟩
  · intro p q ⟨h1, h2⟩; exact ⟨by rw [U_reflect]; exact h2, by rw [W_reflect]; exact h1⟩
  · intro p; simp [CausalPast', U, W]
  · intro p q r ⟨h1, h2⟩ ⟨h3, h4⟩
    unfold CausalPast' U W at *; constructor <;> linarith

end BlockUniverse.Stein
