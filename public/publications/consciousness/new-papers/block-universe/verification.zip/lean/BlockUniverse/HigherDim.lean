/-
  Rietdijk–Putnam in (n+1)+1 dimensions
  =====================================

  Events have one time coordinate and `n+1` space coordinates (so at least
  one spatial dimension; `n = 2` is ordinary 3+1 spacetime), over any
  linearly ordered field K, with c = 1.

  An inertial frame is labelled by a velocity vector v with |v|² < 1.
  A Lorentz boost gives t' = γ (t - v·x) with γ > 0, so two events are
  simultaneous in frame v exactly when Δt = v·Δx. No square roots needed.

  Main results
  * `simultaneous_iff_spacelike_or_eq` : simultaneous for some inertial
      observer ⇔ spacelike-separated or identical (uses Cauchy–Schwarz).
  * `common_simultaneity_partner` : any two events share an event each
      counts as simultaneous in some frame.
  * `rietdijk_putnam` / `rietdijk_putnam_spacelike` : the block conclusion.
  * `transitivity_needed`, `relativity_of_reality_needed` : independence.
-/
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Algebra.BigOperators.Fin

namespace BlockUniverse.HigherDim

open Finset

variable {K : Type*} [Field K] [LinearOrder K] [IsStrictOrderedRing K] {n : ℕ}

/-- An event in spacetime with `n + 1` spatial dimensions. -/
@[ext] structure Event (n : ℕ) (K : Type*) where
  t : K
  x : Fin (n + 1) → K

/-- Euclidean dot product of spatial vectors. -/
def dot (a b : Fin (n + 1) → K) : K := ∑ i, a i * b i

/-- Squared Euclidean length. -/
def normSq (a : Fin (n + 1) → K) : K := ∑ i, a i ^ 2

/-- Spatial displacement from `p` to `q`. -/
def dx (p q : Event n K) : Fin (n + 1) → K := fun i => q.x i - p.x i

/-- An admissible frame velocity: slower than light. -/
def Admissible (v : Fin (n + 1) → K) : Prop := normSq v < 1

/-- Simultaneous in the frame with velocity `v`: Δt = v·Δx. -/
def Simul (v : Fin (n + 1) → K) (p q : Event n K) : Prop := q.t - p.t = dot v (dx p q)

def SimulSomeFrame (p q : Event n K) : Prop := ∃ v, Admissible v ∧ Simul v p q

/-- Spacelike separation: Δt² < |Δx|². -/
def Spacelike (p q : Event n K) : Prop := (q.t - p.t) ^ 2 < normSq (dx p q)

lemma normSq_nonneg (a : Fin (n + 1) → K) : 0 ≤ normSq a :=
  sum_nonneg fun i _ => sq_nonneg (a i)

lemma normSq_zero_iff (a : Fin (n + 1) → K) : normSq a = 0 ↔ ∀ i, a i = 0 := by
  unfold normSq
  rw [sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg (a i))]
  simp

/-! ### Geometry -/

theorem spacelike_simulSomeFrame {p q : Event n K} (h : Spacelike p q) :
    SimulSomeFrame p q := by
  unfold Spacelike at h
  set a := q.t - p.t
  set N := normSq (dx p q) with hN
  have hNpos : 0 < N := lt_of_le_of_lt (sq_nonneg a) h
  let c := a / N
  refine ⟨fun i => c * dx p q i, ?_, ?_⟩
  · -- |v|² = c² N = a² / N < 1
    have hv : normSq (fun i => c * dx p q i) = c ^ 2 * N := by
      unfold normSq; rw [hN, normSq, mul_sum]; congr 1; ext i; ring
    unfold Admissible; rw [hv]
    have : c ^ 2 * N = a ^ 2 / N := by simp only [c]; field_simp
    rw [this, div_lt_one hNpos]; exact h
  · unfold Simul dot
    have : ∑ i, c * dx p q i * dx p q i = c * N := by
      rw [hN, normSq, mul_sum]; congr 1; ext i; ring
    rw [this]; simp only [c]; field_simp; rfl

theorem simulSomeFrame_spacelike_or_eq {p q : Event n K} (h : SimulSomeFrame p q) :
    Spacelike p q ∨ p = q := by
  obtain ⟨v, hv, hs⟩ := h
  unfold Simul at hs
  unfold Admissible at hv
  -- Cauchy–Schwarz: (v·Δx)² ≤ |v|² |Δx|²
  have cs : (dot v (dx p q)) ^ 2 ≤ normSq v * normSq (dx p q) :=
    sum_mul_sq_le_sq_mul_sq univ v (dx p q)
  rcases (normSq_nonneg (dx p q)).lt_or_eq with hpos | hzero
  · left
    unfold Spacelike; rw [hs]
    nlinarith [normSq_nonneg v]
  · right
    have hx : ∀ i, dx p q i = 0 := (normSq_zero_iff _).mp hzero.symm
    have hd : dot v (dx p q) = 0 := by simp [dot, hx]
    ext
    · linarith
    · rename_i i; have := hx i; simp only [dx] at this; linarith

theorem simultaneous_iff_spacelike_or_eq (p q : Event n K) :
    SimulSomeFrame p q ↔ Spacelike p q ∨ p = q := by
  constructor
  · exact simulSomeFrame_spacelike_or_eq
  · rintro (h | rfl)
    · exact spacelike_simulSomeFrame h
    · exact ⟨0, by simp [Admissible, normSq], by simp [Simul, dot]⟩

/-- A velocity of size `c` along the first spatial axis. -/
def axisVel (c : K) : Fin (n + 1) → K := fun i => if i = 0 then c else 0

omit [LinearOrder K] [IsStrictOrderedRing K] in
lemma dot_axisVel (c : K) (a : Fin (n + 1) → K) : dot (axisVel c) a = c * a 0 := by
  simp [dot, axisVel, ite_mul]

omit [LinearOrder K] [IsStrictOrderedRing K] in
lemma normSq_axisVel (c : K) : normSq (axisVel (n := n) c) = c ^ 2 := by
  simp [normSq, axisVel, ite_pow]

/-- Key lemma: any two events (even timelike-separated) share a partner that
    each counts as simultaneous, using frames ±1/2 along one axis. -/
theorem common_simultaneity_partner (p q : Event n K) :
    ∃ r, SimulSomeFrame p r ∧ SimulSomeFrame r q := by
  let rx0 : K := (p.x 0 + q.x 0) / 2 + (q.t - p.t)
  let r : Event n K := ⟨p.t + (rx0 - p.x 0) / 2, Function.update p.x 0 rx0⟩
  have hadm : ∀ c : K, c = 1 / 2 ∨ c = -(1 / 2) → Admissible (axisVel (n := n) c) := by
    rintro c (rfl | rfl) <;> simp [Admissible, normSq_axisVel] <;> norm_num
  refine ⟨r, ⟨axisVel (1 / 2), hadm _ (Or.inl rfl), ?_⟩,
              ⟨axisVel (-(1 / 2)), hadm _ (Or.inr rfl), ?_⟩⟩
  · simp only [Simul, dot_axisVel, dx, r, Function.update_self]; ring
  · simp only [Simul, dot_axisVel, dx, r, Function.update_self]; ring

/-! ### The argument -/

theorem rietdijk_putnam (R : Event n K → Event n K → Prop)
    (H1 : ∀ p q, SimulSomeFrame p q → R p q)
    (H2 : ∀ p q r, R p q → R q r → R p r) :
    ∀ p q, R p q := by
  intro p q
  obtain ⟨r, hpr, hrq⟩ := common_simultaneity_partner p q
  exact H2 p r q (H1 p r hpr) (H1 r q hrq)

theorem rietdijk_putnam_spacelike (R : Event n K → Event n K → Prop)
    (Hrefl : ∀ p, R p p)
    (H1 : ∀ p q, Spacelike p q → R p q)
    (H2 : ∀ p q r, R p q → R q r → R p r) :
    ∀ p q, R p q := by
  apply rietdijk_putnam R _ H2
  intro p q h
  rcases simulSomeFrame_spacelike_or_eq h with hs | rfl
  · exact H1 p q hs
  · exact Hrefl p

/-! ### Independence of the hypotheses -/

theorem transitivity_needed :
    ∃ R : Event n K → Event n K → Prop,
      (∀ p q, SimulSomeFrame p q → R p q) ∧ ¬ ∀ p q, R p q := by
  refine ⟨SimulSomeFrame, fun _ _ h => h, ?_⟩
  intro hall
  rcases simulSomeFrame_spacelike_or_eq (hall ⟨0, 0⟩ ⟨1, 0⟩) with h | h
  · simp [Spacelike, normSq, dx] at h; linarith
  · have := congrArg Event.t h; simp at this

/-- Stein's relation: `q` is in the causal past of `p` (|Δx|² ≤ Δt², q earlier). -/
def CausalPast (p q : Event n K) : Prop :=
  q.t ≤ p.t ∧ normSq (dx q p) ≤ (p.t - q.t) ^ 2

/-- Dropping H1: the causal-past relation is reflexive and transitive but not
    the block, and it does not contain simultaneity. Transitivity in higher
    dimensions is the reverse triangle inequality, proved via Cauchy–Schwarz. -/
theorem relativity_of_reality_needed :
    (∀ p : Event n K, CausalPast p p) ∧
    (∀ p q r : Event n K, CausalPast p q → CausalPast q r → CausalPast p r) ∧
    ¬ (∀ p q : Event n K, CausalPast p q) ∧
    ¬ (∀ p q : Event n K, SimulSomeFrame p q → CausalPast p q) := by
  refine ⟨fun p => ⟨le_refl _, by simp [normSq, dx]⟩, ?_, ?_, ?_⟩
  · rintro p q r ⟨h1, h2⟩ ⟨h3, h4⟩
    refine ⟨le_trans h3 h1, ?_⟩
    -- |a + b|² = |a|² + 2 a·b + |b|² ≤ (α + β)² with |a|² ≤ α², |b|² ≤ β².
    set a := dx q p
    set b := dx r q
    set α := p.t - q.t
    set β := q.t - r.t
    have hα : 0 ≤ α := by simp only [α]; linarith
    have hβ : 0 ≤ β := by simp only [β]; linarith
    have hsum : dx r p = fun i => a i + b i := by
      ext i; simp only [dx, a, b]; ring
    have hexp : normSq (fun i => a i + b i) = normSq a + 2 * dot a b + normSq b := by
      simp only [normSq, dot]
      rw [mul_sum, ← sum_add_distrib, ← sum_add_distrib]
      congr 1; ext i; ring
    have cs : (dot a b) ^ 2 ≤ normSq a * normSq b := sum_mul_sq_le_sq_mul_sq univ a b
    have ha0 := normSq_nonneg a
    have hb0 := normSq_nonneg b
    -- a·b ≤ α β
    have hab : dot a b ≤ α * β := by
      have : (dot a b) ^ 2 ≤ (α * β) ^ 2 := by
        calc (dot a b) ^ 2 ≤ normSq a * normSq b := cs
          _ ≤ α ^ 2 * β ^ 2 := mul_le_mul h2 h4 hb0 (sq_nonneg _)
          _ = (α * β) ^ 2 := by ring
      exact abs_le_of_sq_le_sq' this (mul_nonneg hα hβ) |>.2
    rw [hsum, hexp]
    have : p.t - r.t = α + β := by simp only [α, β]; ring
    rw [this]
    nlinarith
  · intro hall
    have := (hall ⟨0, 0⟩ ⟨1, 0⟩).1; norm_num at this
  · intro hall
    let q : Event n K := ⟨0, fun i => if i = 0 then 1 else 0⟩
    have hs : SimulSomeFrame (⟨0, 0⟩ : Event n K) q :=
      ⟨0, by simp [Admissible, normSq], by simp [Simul, dot, q]⟩
    have h := (hall _ _ hs).2
    have : normSq (dx q (⟨0, 0⟩ : Event n K)) = 1 := by
      simp [normSq, dx, q, ite_pow]
    rw [this] at h; norm_num at h

end BlockUniverse.HigherDim
