import BlockUniverse.Stein

/- Project audit extension. Supplied modules remain unchanged.
A fixed proper-duration threshold shows why scale invariance cannot simply
be removed from this six-relation classification. This does not challenge
Stein's uniqueness result with its stronger causal-past inclusion premise. -/
namespace BlockUniverse.Audit
open BlockUniverse.Stein
variable {K : Type*} [Field K] [LinearOrder K] [IsStrictOrderedRing K]

def DurationPast (p q : Event K) : Prop :=
  p = q ∨ (U p q < 0 ∧ W p q < 0 ∧ (1 : K) ≤ U p q * W p q)

theorem duration_reflexive (p : Event K) : DurationPast p p := Or.inl rfl

theorem duration_transitive (p q r : Event K)
    (hpq : DurationPast p q) (hqr : DurationPast q r) : DurationPast p r := by
  rcases hpq with rfl | hpq
  · exact hqr
  rcases hqr with rfl | hqr
  · exact Or.inr hpq
  have hu : U p r = U p q + U q r := by unfold U; ring
  have hw : W p r = W p q + W q r := by unfold W; ring
  right
  rw [hu, hw]
  refine ⟨by linarith [hpq.1, hqr.1], by linarith [hpq.2.1, hqr.2.1], ?_⟩
  have hc1 : 0 ≤ U p q * W q r := mul_nonneg_of_nonpos_of_nonpos hpq.1.le hqr.2.1.le
  have hc2 : 0 ≤ U q r * W p q := mul_nonneg_of_nonpos_of_nonpos hqr.1.le hpq.2.1.le
  nlinarith [hpq.2.2, hqr.2.2]

theorem duration_translate (a p q : Event K) (h : DurationPast p q) :
    DurationPast (translate a p) (translate a q) := by
  rcases h with rfl | h
  · exact duration_reflexive _
  · right; simpa only [U_translate, W_translate] using h

theorem duration_boost (l : K) (hl : 0 < l) (p q : Event K)
    (h : DurationPast p q) : DurationPast (boost l p) (boost l q) := by
  rcases h with rfl | h
  · exact duration_reflexive _
  · right
    rw [U_boost hl, W_boost hl]
    have hprod : (l * U p q) * (W p q / l) = U p q * W p q := by field_simp
    exact ⟨mul_neg_of_pos_of_neg hl h.1, div_neg_of_neg_of_pos h.2.1 hl, by simpa only [hprod] using h.2.2⟩

theorem duration_reflect (p q : Event K) (h : DurationPast p q) :
    DurationPast (reflect p) (reflect q) := by
  rcases h with rfl | h
  · exact duration_reflexive _
  · right
    rw [U_reflect, W_reflect]
    exact ⟨h.2.1, h.1, by simpa only [mul_comm] using h.2.2⟩

theorem duration_not_dilation_invariant :
    ¬ (∀ c : K, 0 < c → ∀ p q, DurationPast p q →
       DurationPast (dilate c p) (dilate c q)) := by
  intro hall
  let o : Event K := ⟨0, 0⟩
  let q : Event K := ⟨-1, 0⟩
  have h : DurationPast o q := by right; norm_num [U, W, o, q]
  have hh := hall (1 / 2) (by norm_num) o q h
  rcases hh with heq | hh
  · have ht := congrArg Event.t heq
    norm_num [dilate, o, q] at ht
  · norm_num [U, W, dilate, o, q] at hh

end BlockUniverse.Audit

#print axioms BlockUniverse.Audit.duration_reflexive
#print axioms BlockUniverse.Audit.duration_transitive
#print axioms BlockUniverse.Audit.duration_translate
#print axioms BlockUniverse.Audit.duration_boost
#print axioms BlockUniverse.Audit.duration_reflect
#print axioms BlockUniverse.Audit.duration_not_dilation_invariant
