#!/usr/bin/env python3
"""Build the pinned Lean modules and check their complete named axiom audits."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
LOG = ROOT.parent / 'verification' / 'lean.txt'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
MODULES = ('BlockUniverse.lean', 'BlockUniverse/HigherDim.lean',
           'BlockUniverse/Stein.lean', 'BlockUniverse/Reciprocal.lean',
           'BlockUniverse/ReciprocalNoDilation.lean',
           'BlockUniverse/ReciprocalThreePlusOne.lean')


def check_axioms(output, expected_count):
    found = {}
    for name, items in re.findall(
            r"'([^\n]*?)' depends on axioms:\s*\[([^\]]*)\]", output):
        values = {re.sub(r'\.\{[^}]*\}', '', x.strip())
                  for x in items.split(',') if x.strip()}
        assert values <= ALLOWED, (name, values)
        found[name] = values
    for name in re.findall(r"'([^\n]*?)' does not depend on any axioms", output):
        found[name] = set()
    assert len(found) == expected_count, (len(found), expected_count)
    return found


def main():
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open('w') as log:
        def record(text):
            log.write(text.rstrip() + '\n')
            log.flush()

        def run(command):
            record('$ ' + ' '.join(command))
            result = subprocess.run(command, cwd=ROOT, text=True,
                                    capture_output=True)
            record(result.stdout)
            if result.stderr:
                record('stderr:\n' + result.stderr)
            if result.returncode:
                raise RuntimeError(f'{command} failed with exit code {result.returncode}')
            return result.stdout

        record('Formal verification, UTC ' + datetime.datetime.now(
            datetime.timezone.utc).isoformat())
        version = run(['lean', '--version']).strip()
        assert 'version 4.36.0-rc1,' in version, version
        manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
        for package in manifest['packages']:
            directory = ROOT / manifest['packagesDir'] / package['name']
            revision = subprocess.check_output(
                ['git', 'rev-parse', 'HEAD'], cwd=directory, text=True).strip()
            assert revision == package['rev'], package['name']
            record('Dependency ' + package['name'] + ': ' + revision)
        for name in (*MODULES, 'AxiomAuditAll.lean', 'DilationCountermodel.lean'):
            digest = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            record('Source SHA256 ' + name + ': ' + digest)
        run(['lake', 'build'])
        proofs = check_axioms(run(['lake', 'env', 'lean', 'AxiomAuditAll.lean']), 65)
        countermodels = check_axioms(run([
            'lake', 'env', 'lean', 'DilationCountermodel.lean']), 6)
        used = set().union(*proofs.values(), *countermodels.values())
        record('PASS: six modules; 65 named proofs; six countermodel proofs; '
               + str(len(manifest['packages'])) + ' dependency revisions checked.')
        record('Audited axiom union: ' + ', '.join(sorted(used)))
    print('PASS: six Lean modules, 65 named proofs and six countermodel proofs.')
    print('Complete build and axiom output: verification/lean.txt')


if __name__ == '__main__':
    main()
