#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
/* Runtime adapter only: the host exposes /proc/self/exe but not /proc/<pid>/exe.
   Redirect exactly the caller's own numeric executable link; all other paths
   are passed unchanged to libc. This does not alter Lean or proof checking. */
ssize_t readlink(const char *path, char *buf, size_t size) {
    static ssize_t (*real_readlink)(const char *, char *, size_t) = NULL;
    if (!real_readlink) real_readlink = dlsym(RTLD_NEXT, "readlink");
    char own[128];
    snprintf(own, sizeof(own), "/proc/%d/exe", (int)getpid());
    return real_readlink(strcmp(path, own) == 0 ? "/proc/self/exe" : path, buf, size);
}
