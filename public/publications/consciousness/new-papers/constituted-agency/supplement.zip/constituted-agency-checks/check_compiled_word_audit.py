#!/usr/bin/env python3
"""Reconstruct the delivered routing word and verify the ingress decomposition.

Run beside the isolated copy of check_local_recognition.py. It executes that
script's actual full route checks, then separately rebuilds the pre/post words
from its logical gate definitions and route compiler. This is an independent
audit wrapper around the supplied implementation, not a second hardware model.
"""
from pathlib import Path
import contextlib
import hashlib
import io
import json
import runpy

HERE = Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    module = runpy.run_path(str(HERE / "check_local_recognition.py"))
gates = module["GATES"]
boundary = module["FRESH_BOUNDARY"]
expand = module["expand_two_site"]
route = module["route_pair"]


def compiled(part):
    return [gate for logical in part for expanded in expand(logical)
            for gate in route(expanded)]


before = compiled(gates[:boundary])
after = compiled(gates[boundary:])
word = before + after
assert word == module["pair_local"]
assert (len(gates[:boundary]), len(gates[boundary:]),
        len(before), len(after), module["ingress_windows"]) == (33, 22, 717, 1122, 35)
assert all(len(args) == 1 or abs(args[0] - args[1]) == 1 for _, args in word)
result = {
    "actual_execution": (
        "Reconstructed routed pre/post words from delivered GATES and the exact "
        "route compiler; source script also executed its full sparse-amplitude loops."
    ),
    "logical_before_ingress": 33,
    "logical_after_ingress": 22,
    "routed_before_ingress": 717,
    "late_ingress_windows": 35,
    "routed_after_ingress": 1122,
    "full_timed_windows": 1874,
    "all_pair_gates_adjacent": True,
    "word_sha256": hashlib.sha256(
        json.dumps(word, separators=(",", ":")).encode()
    ).hexdigest(),
    "scope": "Compiled map/schedule check, not attained hardware, holding or control performance.",
}
Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
