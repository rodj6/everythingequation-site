#!/usr/bin/env python3
"""Exact conditioning countermodels and selected-benefit repair.

The finite law enumerates B,Y,N,E0,E1,S. Probe flips E0,E1 remain iid
Bernoulli(1/16) conditional on B in every model. Some models deliberately
violate task-law conditioning assumptions. A generic task represents each
of H=4 tasks by linearity of expected reward; cross-task independence is
unnecessary for these calculations.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

ETA = F(1, 16)
ALPHA = 2 * ETA * (1 - ETA)
H, COST, KAPPA = 4, F(1, 4), F(1, 16)
MODES = ("repaired", "tag_coupled_to_B", "cue_quality_coupled_to_B",
         "task_context_coupled_to_audit_error")


def probability(bit, one):
    return one if bit else 1 - one


def rows(mode):
    out = []
    for b, y, n, e0, e1, s in product((0, 1), repeat=6):
        q_b = (F(1) if b == 0 else F(1, 2)) if (
            mode == "cue_quality_coupled_to_B") else F(3, 4)
        parity_error = e0 ^ e1
        if mode == "tag_coupled_to_B":
            s_one = F(b)
        elif mode == "task_context_coupled_to_audit_error":
            # This preserves fair S marginally within each B class.
            s_one = F(1) if parity_error else (F(1, 2) - ALPHA) / (1 - ALPHA)
            assert s_one == (F(1) if parity_error else F(49, 113))
        else:
            s_one = F(1, 2)
        weight = (F(1, 2) * F(1, 2) * probability(n, 1 - q_b)
                  * probability(e0, ETA) * probability(e1, ETA)
                  * probability(s, s_one))
        if not weight:
            continue
        c = y ^ n
        hatb = b ^ parity_error
        old_success = int((c ^ (b * s)) == y)
        revised_success = int(c == y)
        out.append(dict(B=b, Y=y, C=c, N=n, E0=e0, E1=e1, S=s,
                        hatB=hatb, old_success=old_success,
                        revised_success=revised_success,
                        benefit=H * (revised_success - old_success),
                        weight=weight))
    assert sum(r["weight"] for r in out) == 1
    return out


def mass(rs, pred=lambda r: True):
    return sum((r["weight"] for r in rs if pred(r)), F(0))


def expected(rs, function, pred=lambda r: True):
    return sum((r["weight"] * function(r) for r in rs if pred(r)), F(0))


def s_independent_YC(rs, pred=lambda r: True):
    total = mass(rs, pred)
    assert total
    for s, y, c in product((0, 1), repeat=3):
        joint = mass(rs, lambda r: pred(r) and (r["S"], r["Y"], r["C"]) == (s, y, c))
        m_s = mass(rs, lambda r: pred(r) and r["S"] == s)
        m_yc = mass(rs, lambda r: pred(r) and (r["Y"], r["C"]) == (y, c))
        if joint * total != m_s * m_yc:
            return False
    return True


def check(mode):
    rs = rows(mode)
    # All four models satisfy the original unconditional tag/cue statements.
    assert mass(rs, lambda r: r["Y"] == 1) == F(1, 2)
    assert mass(rs, lambda r: r["S"] == 1) == F(1, 2)
    assert s_independent_YC(rs)
    assert expected(rs, lambda r: r["revised_success"]) == F(3, 4)
    class_rows = {}
    for b in (0, 1):
        keep = lambda r, b=b: r["B"] == b
        base = mass(rs, keep)
        for e0, e1 in product((0, 1), repeat=2):
            pair = mass(rs, lambda r: keep(r) and (r["E0"], r["E1"]) == (e0, e1))
            assert pair / base == probability(e0, ETA) * probability(e1, ETA)
        class_rows[str(b)] = {
            "q": str(expected(rs, lambda r: r["revised_success"], keep) / base),
            "S_is_fair": mass(rs, lambda r: keep(r) and r["S"] == 1) / base == F(1, 2),
            "S_independent_YC": s_independent_YC(rs, keep),
            "old_accuracy": str(expected(rs, lambda r: r["old_success"], keep) / base),
            "revision_benefit": str(expected(rs, lambda r: r["benefit"], keep) / base),
        }
    p = mass(rs, lambda r: r["B"] == 1)
    alpha0 = mass(rs, lambda r: r["B"] == 0 and r["hatB"] == 1) / (1 - p)
    alpha1 = mass(rs, lambda r: r["B"] == 1 and r["hatB"] == 0) / p
    assert alpha0 == alpha1 == ALPHA
    selected = lambda r: r["B"] == 1 and r["hatB"] == 1
    selected_benefit = expected(rs, lambda r: r["benefit"], selected) / mass(rs, selected)
    gain = expected(rs, lambda r: r["hatB"] * (r["benefit"] - COST)) - KAPPA
    general = p * (1 - alpha1) * (selected_benefit - COST) - (
        1 - p) * alpha0 * COST - KAPPA
    assert general == gain
    blind = max(F(0), expected(rs, lambda r: r["benefit"]) - COST)
    nominal = p * (1 - alpha1) * (F(1) - COST) - (
        1 - p) * alpha0 * COST - KAPPA
    return {
        "joint_support_points": len(rs),
        "original_unconditional_task_statements_hold": True,
        "probe_errors_conditionally_iid": True,
        "class_task_laws": class_rows,
        "alpha0": str(alpha0), "alpha1": str(alpha1),
        "selected_B1_revision_benefit": str(selected_benefit),
        "noisy_gain_direct_joint_enumeration": str(gain),
        "noisy_gain_general_selected_benefit_formula": str(general),
        "best_blind_gain": str(blind),
        "actual_noisy_advantage": str(gain - blind),
        "nominal_fixed_B_H_noisy_gain": str(nominal),
        "nominal_fixed_B_H_formula_valid": nominal == gain,
        "old_mixed_accuracy": str(expected(rs, lambda r: r["old_success"])),
    }


def check_stationary_conditioning():
    """Stationary authority mixture needs its own fresh-law conditioning."""
    q, gamma, rho = F(3, 4), F(1, 2), F(1, 10)
    stationary = rho / (rho + gamma * (1 - rho))
    assert stationary == F(2, 11)
    # P(next_lambda=1 | current_lambda) for audit then relapse.
    transitions = {
        0: rho,
        1: rho + (1 - rho) * (1 - gamma),
    }
    next_mass = ((1 - stationary) * transitions[0]
                 + stationary * transitions[1])
    assert next_mass == stationary
    nominal = q - stationary * (q - F(1, 2))
    assert nominal == F(31, 44)
    results = {}
    for mode in ("fresh_law_stable_given_lambda", "context_coupled_to_lambda"):
        table = []
        for lam, y, n, s in product((0, 1), repeat=4):
            if mode == "context_coupled_to_lambda":
                s_one = F(1) if lam else (F(1, 2) - stationary) / (1 - stationary)
                assert s_one == (F(1) if lam else F(7, 18))
            else:
                s_one = F(1, 2)
            w = (probability(lam, stationary) * F(1, 2)
                 * probability(n, 1 - q) * probability(s, s_one))
            if w:
                c = y ^ n
                table.append({
                    "lambda": lam, "Y": y, "C": c, "S": s, "weight": w,
                    "success": int((c ^ (lam * s)) == y),
                })
        assert mass(table) == 1
        assert mass(table, lambda r: r["lambda"] == 1) == stationary
        assert mass(table, lambda r: r["S"] == 1) == F(1, 2)
        assert s_independent_YC(table)
        actual = expected(table, lambda r: r["success"])
        joint = mass(table, lambda r: r["lambda"] == 1 and r["S"] == 1)
        # Exact independent-noise identity for this nominated joint family.
        assert actual == q - (2 * q - 1) * joint
        posteriors = {}
        class_task = {}
        for s in (0, 1):
            posteriors[str(s)] = str(
                mass(table, lambda r: r["S"] == s and r["lambda"] == 1)
                / mass(table, lambda r: r["S"] == s))
        for lam in (0, 1):
            keep = lambda r, lam=lam: r["lambda"] == lam
            base = mass(table, keep)
            class_task[str(lam)] = {
                "probability_S_1": str(mass(
                    table, lambda r: keep(r) and r["S"] == 1) / base),
                "q": str(mass(
                    table, lambda r: keep(r) and r["C"] == r["Y"]) / base),
                "accuracy": str(expected(
                    table, lambda r: r["success"], keep) / base),
            }
        if mode == "fresh_law_stable_given_lambda":
            assert actual == F(31, 44)
            assert posteriors == {"0": "2/11", "1": "2/11"}
        else:
            assert actual == F(29, 44)
            assert posteriors == {"0": "0", "1": "4/11"}
        results[mode] = {
            "joint_support_points": len(table),
            "marginal_S_fair_and_independent_YC": True,
            "authority_mass": str(stationary),
            "actual_accuracy": str(actual),
            "nominal_mixture_accuracy": str(nominal),
            "lambda_task_conditionals": class_task,
            "posterior_lambda_1_given_S": posteriors,
            "joint_lambda_1_and_S_1": str(joint),
        }
    return {
        "q": str(q), "gamma": str(gamma), "rho": str(rho),
        "stationary_authority_mass": str(stationary),
        "next_authority_mass_exact_transition_check": str(next_mass),
        "transition_probability_next_lambda_1": {str(k): str(v) for k, v in transitions.items()},
        "models": results,
        "repair": "For the displayed accuracy mixture, the fresh task law must hold conditional on current lambda.",
    }


def main():
    results = {mode: check(mode) for mode in MODES}
    good = results["repaired"]
    assert good["selected_B1_revision_benefit"] == "1"
    assert good["noisy_gain_direct_joint_enumeration"] == "65/256"
    assert good["actual_noisy_advantage"] == "1/256"
    tag = results["tag_coupled_to_B"]
    assert tag["class_task_laws"]["1"]["old_accuracy"] == "1/4"
    assert tag["old_mixed_accuracy"] == "1/2"
    assert tag["actual_noisy_advantage"] == "-7/128"
    cue = results["cue_quality_coupled_to_B"]
    assert cue["class_task_laws"]["0"]["q"] == "1"
    assert cue["class_task_laws"]["1"]["q"] == "1/2"
    coupled = results["task_context_coupled_to_audit_error"]
    assert all(x["q"] == "3/4" and x["S_is_fair"] and x["S_independent_YC"]
               for x in coupled["class_task_laws"].values())
    assert coupled["selected_B1_revision_benefit"] == "98/113"
    assert coupled["noisy_gain_direct_joint_enumeration"] == "25/128"
    assert coupled["best_blind_gain"] == "1/4"
    assert coupled["actual_noisy_advantage"] == "-7/128"
    assert all(x["nominal_fixed_B_H_formula_valid"] == (mode == "repaired")
               for mode, x in results.items())
    result = {
        "status": "all exact assertions passed",
        "arithmetic": "fractions.Fraction only",
        "parameters": {"eta": str(ETA), "H": H, "c": str(COST),
                       "kappa": str(KAPPA), "p": "1/2", "nominal_B_H": "1"},
        "models": results,
        "stationary_conditioning": check_stationary_conditioning(),
        "minimal_selected_benefit_condition": (
            "For fixed-B_H noisy formula: E[block raw revision benefit | "
            "B=1,hatB=1]=B_H whenever that event has positive mass."
        ),
        "sufficient_operational_condition": (
            "Fresh scored task law remains the declared task law conditional "
            "on B and the diagnostic outcome; unconditional diagnostic error "
            "rates alone are insufficient."
        ),
        "nonclaims": "No empirical claim about acquisition noise or human insight.",
    }
    Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
