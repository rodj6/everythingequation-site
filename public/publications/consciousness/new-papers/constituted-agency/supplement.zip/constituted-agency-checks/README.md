# Constituted Agency: executable finite checks

Jeremy Rodgers · DOI https://doi.org/10.5281/zenodo.23581587

These thirteen Python checks support the finite mathematical constructions in the complete web article. They use the Python standard library. Place the files together and run each `check_*.py` with Python 3. Each emits JSON beside its source. `check_compiled_word_audit.py` also inspects the local recognition program in the same directory.

The checks cover recognition, noisy and selected-benefit comparisons, history control, the 64-history ensemble, global constraints, forecasts, complete prior-data distinctions, the 31-bit compiled transaction, relativistic arguments, causal-order consistency and trace-contract counterexamples.

All thirteen scripts completed with exit code zero in the accompanying execution record. Mathematical proofs supply the general statements; finite executions supplement those proofs. These checks do not establish human insight, experiential admission, an awareness attribution, a manufactured physical implementation or metaphysical premises.

The original publication PDF remains the controlling scholarly edition. Older research archives and third-party texts are not redistributed in this supplement.
