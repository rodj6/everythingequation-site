#!/usr/bin/env python3
"""Exact finite causal-order check; standard library only.

This is a new application of the standard adjacent-incomparable-swap argument.
It checks the declared admitted input domain, not a relativistic apparatus or QFT.
Run: python research_v3/check_causal_order.py
"""
from __future__ import annotations

import hashlib
import itertools
import json
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Callable

State = dict[str, int]


@dataclass(frozen=True)
class Event:
    label: str
    data_support: tuple[str, ...]
    forward: Callable[[State], None]
    backward: Callable[[State], None]

    @property
    def log_support(self) -> tuple[str, ...]:
        return tuple(f"log:{self.label}:{i}" for i in range(2 * len(self.data_support)))

    @property
    def support(self) -> frozenset[str]:
        return frozenset(self.data_support + self.log_support)


def probe0(s: State) -> None:
    s["R0"] ^= s["X0"]


def probe1(s: State) -> None:
    s["R1"] ^= s["X1"]


def xor_combine(s: State) -> None:
    s["H"] ^= s["R0"] ^ s["R1"]


def commit_authority(s: State) -> None:
    s["W"] ^= s["L"]
    s["L"] ^= s["Commit"] * s["W"] * s["H"]


def uncommit_authority(s: State) -> None:
    s["L"] ^= s["Commit"] * s["W"] * s["H"]
    s["W"] ^= s["L"]


def fresh_ingress(s: State) -> None:
    for name in ("C", "D", "S", "P", "K"):
        s[name] ^= s[name + "_src"]


def fresh_action(s: State) -> None:
    s["R"] ^= s["C"] ^ (s["B"] * s["S"] * s["D"])
    s["A"] ^= s["K"] * (s["C"] ^ (s["L"] * (s["R"] ^ s["C"])) ^ s["P"])
    s["Valid"] ^= s["K"]


def unfresh_action(s: State) -> None:
    s["Valid"] ^= s["K"]
    s["A"] ^= s["K"] * (s["C"] ^ (s["L"] * (s["R"] ^ s["C"])) ^ s["P"])
    s["R"] ^= s["C"] ^ (s["B"] * s["S"] * s["D"])


EVENTS = (
    Event("probe0", ("X0", "R0"), probe0, probe0),
    Event("probe1", ("X1", "R1"), probe1, probe1),
    Event("xor_combine", ("R0", "R1", "H"), xor_combine, xor_combine),
    Event("authority_commit", ("H", "L", "W", "Commit"), commit_authority, uncommit_authority),
    Event("fresh_ingress", ("C_src", "D_src", "S_src", "P_src", "K_src", "C", "D", "S", "P", "K"), fresh_ingress, fresh_ingress),
    Event("fresh_action", ("B", "C", "D", "S", "P", "K", "L", "R", "A", "Valid"), fresh_action, unfresh_action),
)
BY_LABEL = {e.label: e for e in EVENTS}
EDGES = (
    ("probe0", "xor_combine"),
    ("probe1", "xor_combine"),
    ("xor_combine", "authority_commit"),
    ("authority_commit", "fresh_ingress"),
    ("fresh_ingress", "fresh_action"),
)
DATA_REGISTERS = tuple(sorted({r for e in EVENTS for r in e.data_support}))
ALL_REGISTERS = tuple(sorted(set(DATA_REGISTERS).union(*(e.log_support for e in EVENTS))))


def closure() -> set[tuple[str, str]]:
    reach = set(EDGES)
    while True:
        enlarged = reach | {(a, d) for a, b in reach for c, d in reach if b == c}
        if enlarged == reach:
            return reach
        reach = enlarged


def linear_extensions() -> list[tuple[str, ...]]:
    """Enumerate all topological orders by branching on every ready event."""
    predecessors = {e.label: set() for e in EVENTS}
    for a, b in EDGES:
        predecessors[b].add(a)
    result: list[tuple[str, ...]] = []

    def visit(prefix: tuple[str, ...]) -> None:
        done = set(prefix)
        if len(done) == len(EVENTS):
            result.append(prefix)
            return
        for label in sorted(predecessors):
            if label not in done and predecessors[label] <= done:
                visit(prefix + (label,))

    visit(())
    return result


def apply_event(state: State, e: Event, reverse: bool = False) -> None:
    """Write event-local before/after records to fresh event-specific XOR logs.

    The raw map is reversible for arbitrary incoming log values. On the ready-log
    domain the retained log equals the concatenated local before/after values.
    Later events do not touch these named archive registers.
    """
    if reverse:
        after = tuple(state[r] for r in e.data_support)
        e.backward(state)
        before = tuple(state[r] for r in e.data_support)
    else:
        before = tuple(state[r] for r in e.data_support)
        e.forward(state)
        after = tuple(state[r] for r in e.data_support)
    for name, bit in zip(e.log_support, before + after):
        state[name] ^= bit


def execute(initial: State, order: tuple[str, ...]) -> tuple[State, dict[str, tuple[int, ...]]]:
    state = initial.copy()
    for label in order:
        apply_event(state, BY_LABEL[label])
    retained_records = {e.label: tuple(state[r] for r in e.log_support) for e in EVENTS}
    return state, retained_records


INPUT_NAMES = ("baseline", "b", "lambda_old", "commit", "cue", "context", "ownership", "body", "available")


def prepare(bits: tuple[int, ...]) -> State:
    u, b, lam, commit, cue, context, ownership, body, available = bits
    s = dict.fromkeys(ALL_REGISTERS, 0)
    s.update(B=b, X0=u, X1=u ^ b, L=lam, Commit=commit,
             C_src=cue, D_src=context, S_src=ownership, P_src=body, K_src=available)
    return s


def expected_data(initial: State, bits: tuple[int, ...]) -> dict[str, int]:
    u, b, lam, commit, cue, context, ownership, body, available = bits
    want = {r: initial[r] for r in DATA_REGISTERS}
    new_lam = lam * (1 - commit * b)
    want.update(R0=u, R1=u ^ b, H=b, W=lam, L=new_lam,
                C=cue, D=context, S=ownership, P=body, K=available,
                R=cue ^ (b * ownership * context),
                A=available * (cue ^ (new_lam * b * ownership * context) ^ body),
                Valid=available)
    return want


def check_gate_inverses() -> dict[str, int]:
    counts: dict[str, int] = {}
    for e in EVENTS:
        count = 0
        for bits in itertools.product((0, 1), repeat=len(e.data_support)):
            state = dict.fromkeys(ALL_REGISTERS, 0)
            state.update(zip(e.data_support, bits))
            original = state.copy()
            # A nonzero log pattern checks that this is XOR retention, not overwrite.
            for i, name in enumerate(e.log_support):
                state[name] = (i + sum(bits)) % 2
                original[name] = state[name]
            apply_event(state, e)
            assert all(state[r] == original[r] for r in ALL_REGISTERS if r not in e.support)
            apply_event(state, e, reverse=True)
            assert state == original
            count += 1
        counts[e.label] = count
    return counts


def check_geometry(reach: set[tuple[str, str]]) -> dict:
    """Exact 1+1 placement, embedded in 3+1 by setting y=z=0; c=1 units.

    Small finite boxes are causally separated with slack. This checks placement,
    not the existence of a mediator that realizes each internal gate.
    """
    coordinates = {"probe0": (0, -3), "probe1": (0, 3), "xor_combine": (4, 0),
                   "authority_commit": (5, 0), "fresh_ingress": (6, 0), "fresh_action": (7, 0)}
    half_t = half_x = Fraction(1, 20)
    ordered = spacelike = 0
    for e, f in itertools.combinations(coordinates, 2):
        te, xe = coordinates[e]
        tf, xf = coordinates[f]
        if (e, f) in reach or (f, e) in reach:
            if (f, e) in reach:
                te, xe, tf, xf = tf, xf, te, xe
            assert tf - te - 2 * half_t > abs(xf - xe) + 2 * half_x
            ordered += 1
        else:
            assert abs(xf - xe) - 2 * half_x > abs(tf - te) + 2 * half_t
            spacelike += 1
    orders_by_boost = {}
    for velocity in (Fraction(-1, 2), Fraction(1, 2)):
        # gamma is positive, so t-vx alone suffices to compare Lorentz times.
        order = tuple(sorted(coordinates, key=lambda label: coordinates[label][0] - velocity * coordinates[label][1]))
        assert all(order.index(a) < order.index(b) for a, b in EDGES)
        orders_by_boost[str(velocity)] = order
    return {"units": "c=1; y=z=0", "event_centres_t_x": coordinates,
            "box_half_time_and_half_width": str(half_t),
            "strictly_future_timelike_region_pairs": ordered,
            "spacelike_region_pairs": spacelike,
            "orders_in_two_inertial_frames_v_over_c": orders_by_boost,
            "scope": "Finite causal packing only; mediator/control/holding implementation is assumed separately."}


def noncommuting_counterexample() -> dict:
    """Unordered shared-target qutrit permutations; deliberately inadmissible."""
    def gate_a(z: int) -> int:
        return (1, 0, 2)[z]  # transposition (0 1)

    def gate_b(z: int) -> int:
        return (0, 2, 1)[z]  # transposition (1 2)

    rows = []
    for z in range(3):
        a_then_b = gate_b(gate_a(z))
        b_then_a = gate_a(gate_b(z))
        assert a_then_b != b_then_a
        rows.append({"initial_z": z, "A_then_B": a_then_b, "B_then_A": b_then_a})
    return {"status": "violates the disjoint-support premise; not a legitimate spacelike gate model",
            "register": "one shared qutrit target z", "A": "swap0and1", "B": "swap1and2",
            "all_input_cases": rows, "differing_cases": len(rows)}


def main() -> dict:
    reach = closure()
    assert all(a != b for a, b in reach)
    orders = linear_extensions()
    assert len(orders) == 2
    incomparable = []
    for a, b in itertools.combinations(BY_LABEL, 2):
        if (a, b) not in reach and (b, a) not in reach:
            assert BY_LABEL[a].support.isdisjoint(BY_LABEL[b].support)
            incomparable.append((a, b))
    # Independently enumerate permutations to check the topological enumeration.
    assert set(orders) == {p for p in itertools.permutations(BY_LABEL)
                           if all(p.index(a) < p.index(b) for a, b in EDGES)}
    digester = hashlib.sha256()
    cases = executions = 0
    sample = None
    for bits in itertools.product((0, 1), repeat=len(INPUT_NAMES)):
        initial = prepare(bits)
        baseline_state, baseline_records = execute(initial, orders[0])
        assert {r: baseline_state[r] for r in DATA_REGISTERS} == expected_data(initial, bits)
        for order in orders:
            final, records = execute(initial, order)
            assert final == baseline_state  # every data and physical log register
            assert records == baseline_records  # keyed by event identity, not list position
            # Retained physical records are independent of later calendar positions.
            reverse = final.copy()
            for label in reversed(order):
                apply_event(reverse, BY_LABEL[label], reverse=True)
            assert reverse == initial
            executions += 1
        item = {"input": dict(zip(INPUT_NAMES, bits)),
                "final_registers": baseline_state, "event_records": baseline_records}
        digester.update(json.dumps(item, sort_keys=True, separators=(",", ":")).encode())
        if bits == (0, 1, 1, 1, 0, 1, 1, 0, 1):
            sample = item
        cases += 1
    result = {
        "status": "all assertions passed",
        "standard_result_applied": "Connectivity of finite-poset linear extensions by adjacent swaps of incomparable events.",
        "data_register_count": len(DATA_REGISTERS),
        "physical_event_log_bits": len(ALL_REGISTERS) - len(DATA_REGISTERS),
        "total_bits_in_this_simplified_example": len(ALL_REGISTERS),
        "events": [{"label": e.label, "data_support": e.data_support,
                    "dedicated_retained_log_bits": len(e.log_support)} for e in EVENTS],
        "DAG_edges": EDGES, "incomparable_pairs": incomparable,
        "all_linear_extensions": orders,
        "input_names": INPUT_NAMES,
        "all_permitted_input_cases": cases,
        "full_executions_compared": executions,
        "event_record_and_final_state_equality": True,
        "full_reverse_reconstruction_per_execution": True,
        "raw_local_gate_inverse_cases": check_gate_inverses(),
        "input_to_full_output_mapping_sha256": digester.hexdigest(),
        "geometry": check_geometry(reach),
        "sample_authority_revision_and_fresh_action": sample,
        "noncommuting_shared_target_counterexample": noncommuting_counterexample(),
        "limitations": [
            "Exhaustive map comparison covers the 512 declared preparations, not all arbitrary 84-bit raw states.",
            "Raw gate inverse checks enumerate data supports, with a fixed nonzero log pattern per case; general XOR-log invertibility is analytic.",
            "Physical logs add finite resources to this example; they are not included in the earlier 31-bit bank.",
            "Other linear extensions need not correspond to inertial frames in general; both do in this example.",
            "No actual gate mediator, retention lifetime, relativistic QFT, eternalism, consciousness, or human-agency claim is certified.",
        ],
    }
    assert cases == 512 and executions == 1024 and sample is not None
    output = Path(__file__).with_suffix(".json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    checked = main()
    print(json.dumps({key: checked[key] for key in (
        "status", "all_permitted_input_cases", "full_executions_compared",
        "data_register_count", "physical_event_log_bits", "total_bits_in_this_simplified_example",
        "input_to_full_output_mapping_sha256")}, indent=2))
