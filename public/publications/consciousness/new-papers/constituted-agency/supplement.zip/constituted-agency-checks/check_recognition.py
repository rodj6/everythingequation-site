#!/usr/bin/env python3
"""Exact finite checks: acquired self-mechanism model and selective authority.

Standard library only. Run from any directory. This tests stipulated functional
relations, not human insight, phenomenal presence or metaphysical premises.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json

def candidate(c, s, d, b):
    return c ^ (b & s & d)

def diagnose(b, c=0):
    r0 = candidate(c,0,1,b)
    r1 = candidate(c,1,1,b)
    return (r0,r1,r0 ^ r1)

def commit(lam, bhat, criterion=True):
    # Retain on exact ties; criterion q>1/2 and irrelevant-tag contract required.
    return lam & (1-bhat) if criterion else lam

def policy(c,s,d,p,k_available,b,lam,k):
    r = candidate(c,s,d,b)
    t = c ^ (lam & (r ^ c))
    corrected = t ^ (k & (t ^ c))
    return None if not k_available else corrected ^ p

def accuracy(b,lam,k,q=Q(3,4), mode='normal'):
    out = Q(0)
    # Active-task accuracy; Y,P,S uniform, D=1, C=Y xor N.
    for y,p,s,n in product((0,1),repeat=4):
        w = (q if n==0 else 1-q)/8
        c=y^n
        a=policy(c,s,1,p,1,b,lam,k)
        if mode=='forget_practical':
            a=policy(c,s,1,0,1,b,lam,k)
        if mode=='passive': a=None
        if mode=='constant': a=0
        out += w * (a==(y^p))
    return out

# Two sufficient internal probes identify the nominated mechanism class and
# predict all future C,D,S responses; no claim two probes are minimal.
prediction_cases=0
for b,c_probe in product((0,1),repeat=2):
    r0,r1,bhat=diagnose(b,c_probe)
    assert bhat==b
    for c,s,d in product((0,1),repeat=3):
        assert candidate(c,s,d,b)==candidate(c,s,d,bhat)
        prediction_cases += 1

# Action and practical/constraint preservation checks over complete Boolean cube.
cube_cases=0
for c,s,d,p,available,b,lam,k in product((0,1),repeat=8):
    cube_cases += 1
    r=candidate(c,s,d,b)
    direct = c ^ (lam & b & s & d)
    t = direct ^ (k & (direct ^ c))
    assert policy(c,s,d,p,available,b,lam,k) == (None if not available else t^p)
    if available:
        assert policy(c,s,d,p^1,1,b,lam,k) == (policy(c,s,d,p,1,b,lam,k)^1)
        assert policy(c^1,s,d,p,1,b,lam,k) == (policy(c,s,d,p,1,b,lam,k)^1)
    else:
        assert policy(c,s,d,p,0,b,lam,k) is None

arms={
 'baseline':(1,0,'normal'),
 'verbal_assent_only':(1,0,'normal'),
 'correct_self_description_only':(1,0,'normal'),
 'suppression_monitor_present':(1,1,'normal'),
 'suppression_monitor_cut':(1,0,'normal'),
 'authority_revision':(0,0,'normal'),
 'direct_write_without_recognition':(0,0,'normal'),
 'revision_but_practical_information_erased':(0,0,'forget_practical'),
 'passivity':(0,0,'passive'),
 'constant_command':(0,0,'constant')
}
arm_scores={name:accuracy(1,lam,k,mode=mode) for name,(lam,k,mode) in arms.items()}
expected={'baseline':Q(1,2),'verbal_assent_only':Q(1,2),
 'correct_self_description_only':Q(1,2),'suppression_monitor_present':Q(3,4),
 'suppression_monitor_cut':Q(1,2),'authority_revision':Q(3,4),
 'direct_write_without_recognition':Q(3,4),
 'revision_but_practical_information_erased':Q(1,2),
 'passivity':Q(0),'constant_command':Q(1,2)}
assert arm_scores==expected

# Exact risk formula, including failure when evidence is systematically worse
# than chance. New gate accuracy - old = b*lambda*(q-1/2) for S fair,D=1.
risk_cases=0
for q in (Q(0),Q(1,4),Q(1,2),Q(3,4),Q(1)):
    for b,lam in product((0,1),repeat=2):
        old=accuracy(b,lam,0,q)
        neutral=accuracy(b,0,0,q)
        assert neutral-old == b*lam*(q-Q(1,2))
        risk_cases+=1
for b,lam in product((0,1),repeat=2):
    new=commit(lam,b)
    assert new==0 if b else new==lam

# Read/model/commit mediation: b=1, but a common corrupted model or disabled
# commit path leaves lambda=1; description correctness alone does not change it.
assert accuracy(1,commit(1,0),0)==Q(1,2)
assert accuracy(1,commit(1,1),0)==Q(3,4)
assert accuracy(1,1,0)==Q(1,2)

# A reversible lambda write archives its old value. The raw 3-bit circuit is
# omega ^= lambda; lambda ^= omega & bhat, so all raw inputs form a permutation.
outputs=[]
for lam,omega,bhat in product((0,1),repeat=3):
    archived=omega ^ lam
    installed=lam ^ (archived & bhat)
    outputs.append((installed,archived,bhat))
    if omega==0:
        assert installed==commit(lam,bhat)
        assert archived==lam
assert len(set(outputs))==8

# Relapse/recertification: first available audit resets lambda, then a fault
# reinstates authority. Stationary r=rho/[rho+gamma(1-rho)].
relapse=[]
for rho,gamma in ((Q(1,10),Q(1,2)),(Q(1,10),Q(0)),(Q(0),Q(1,2)),(Q(1,4),Q(1))):
    r=rho/(rho+gamma*(1-rho))
    predicted=rho+r*(1-gamma)*(1-rho)
    assert predicted==r
    acc=Q(3,4)-r*Q(1,4)
    relapse.append({'rho':str(rho),'audit_probability':str(gamma),
                   'stationary_authority_probability':str(r),
                   'stationary_accuracy':str(acc)})

# Costed selective revision. Both source classes permit accurate neutral action,
# but a positive material revision charge makes retaining an already adequate
# rule uniquely preferable at b=0. This makes diagnosis useful rather than
# necessary for raw accuracy by stipulation.
voi_cases=0
for p in (Q(0),Q(1,4),Q(1,2),Q(3,4),Q(1)):
    for G,c,kappa in product((Q(1,4),Q(1,2),Q(1),Q(2)),
                             (Q(0),Q(1,8),Q(1,4)),
                             (Q(0),Q(1,16),Q(1,4))):
        if G <= c: continue
        informed=p*(G-c)-kappa
        blind=max(Q(0),p*G-c)
        assert informed-blind == min(p*(G-c),(1-p)*c)-kappa
        voi_cases+=1
p,G,c,kappa=Q(1,2),Q(1),Q(1,4),Q(1,16)
informed=p*(G-c)-kappa
blind=max(Q(0),p*G-c)
assert informed==Q(5,16) and blind==Q(1,4)
assert informed-blind==Q(1,16)

out={'prediction_cases':prediction_cases,'full_policy_cube_cases':cube_cases,
     'risk_formula_cases':risk_cases,'arm_active_task_accuracy':{k:str(v) for k,v in arm_scores.items()},
     'reversible_commit_raw_states':8,'relapse_examples':relapse,
     'costed_value_of_diagnosis_cases':voi_cases,
     'costed_example_gains':{'informed':str(informed),'best_blind':str(blind),
                           'net_advantage':str(informed-blind)},
     'status':'All exact assertions passed.',
     'limits':'Finite declared mechanism class and access/cost assumptions; no human insight or phenomenal inference.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
