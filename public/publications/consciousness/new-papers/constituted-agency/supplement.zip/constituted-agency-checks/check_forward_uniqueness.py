#!/usr/bin/env python3
"""Exact small-map checks for forward versus whole-history uniqueness.

These are finite implication checks, not a Poisson-process simulation or
evidence that the actual universe satisfies a uniqueness premise.
"""
from itertools import product
from pathlib import Path
import json


def fibre_constant(e, target):
    return all(e[i] != e[j] or target[i] == target[j]
               for i in range(len(e)) for j in range(len(e)))


def injective(e):
    return len(set(e)) == len(e)


def main():
    rows = []
    cases = 0
    forward_cases = 0
    for n in range(1, 5):
        local_cases = local_forward = 0
        for e in product((0, 1), repeat=n):
            for future in product((0, 1), repeat=n):
                forward = fibre_constant(e, future)
                for alpha in product((0, 1), repeat=2):
                    action = tuple(alpha[r] for r in future)
                    if forward:
                        assert fibre_constant(e, action)
                    local_cases += 1
                    local_forward += int(forward)
        rows.append({"history_count": n, "map_and_target_cases": local_cases,
                     "forward_unique_cases": local_forward})
        cases += local_cases
        forward_cases += local_forward

    # Complete histories over the DECLARED finite time interval {-1,0,1}.
    # The same deterministic, many-to-one update F(0)=F(1)=0 applies twice.
    coalescing = ((0, 0, 0), (1, 0, 0))
    update = {0: 0, 1: 0}
    assert all(h[t + 1] == update[h[t]]
               for h in coalescing for t in (0, 1))
    e0 = tuple(h[1] for h in coalescing)
    future = tuple(h[1:] for h in coalescing)
    assert not injective(e0)
    assert fibre_constant(e0, future)
    assert len({h[0] for h in coalescing}) == 2

    # Failure of forward uniqueness allows, but does not force, act variation.
    branching = ((0, 0, 0), (0, 0, 1))
    e_branch = tuple(h[1] for h in branching)
    r_branch = tuple(h[1:] for h in branching)
    action_branch = tuple(h[-1] for h in branching)
    assert not fibre_constant(e_branch, r_branch)
    assert not fibre_constant(e_branch, action_branch)

    # A future action can be fixed even when other future features are open.
    pair_histories = tuple(product((0, 1), repeat=2))
    e_pair = tuple(h[0] for h in pair_histories)
    r_pair = pair_histories
    action_pair = tuple(h[0] for h in pair_histories)
    assert not fibre_constant(e_pair, r_pair)
    assert fibre_constant(e_pair, action_pair)
    assert len(set(action_pair)) == 2  # Nonconstant across different data fibres.

    # A bank-only cut omits future ingress. Close the inventory by retaining w.
    def ingress(bank, w):
        return bank ^ w, w
    raw = tuple(product((0, 1), repeat=2))
    out = tuple(ingress(*s) for s in raw)
    assert len(set(out)) == 4
    assert all(ingress(*ingress(*s)) == s for s in raw)
    assert ingress(0, 0)[0] != ingress(0, 1)[0]

    result = {
        "status": "all exact assertions passed",
        "arithmetic": "integer finite maps only",
        "exhaustive_map_and_target_cases": cases,
        "forward_unique_cases": forward_cases,
        "case_rows": rows,
        "coalescing_histories": coalescing,
        "coalescing_domain": "declared complete finite histories at times -1,0,1",
        "coalescing_update": update,
        "coalescing_e0_injective": injective(e0),
        "coalescing_future_constant_on_e0_fibres": fibre_constant(e0, future),
        "branching_histories": branching,
        "target_fixed_despite_other_future_variation": {
            "histories": pair_histories, "data": e_pair,
            "action": action_pair,
        },
        "late_ingress_raw_states_checked": len(raw),
        "limits": [
            "The tests supplement general kernel/factorization proofs.",
            "The finite coalescing example does not posit a bi-infinite finite-state history.",
            "The Poisson sigma-field argument is analytic and was not simulated.",
            "No physical, metaphysical, agent-causal or consciousness premise is validated.",
        ],
    }
    path = Path(__file__).with_suffix(".json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
