#!/usr/bin/env python3
"""Exact arithmetic checks of the manuscript's elementary relativity claims.

Run with Python 3, using only the standard library. The default JSON report is
written next to this script. Finite checks supplement the proofs in the
accompanying note; they do not prove a theorem about all spacetimes or settle
the philosophical interpretation of actuality.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from itertools import product
import json
from math import isqrt
from pathlib import Path
from typing import NamedTuple


class Event(NamedTuple):
    t: Fraction
    x: Fraction


def require(condition: bool, message: str) -> None:
    """Retain verification even when Python is invoked with optimization."""
    if not condition:
        raise AssertionError(message)


def subtract(p: Event, q: Event) -> Event:
    return Event(p.t - q.t, p.x - q.x)


def interval2(delta: Event) -> Fraction:
    """Squared Minkowski interval, c=1, signature (+,-)."""
    return delta.t * delta.t - delta.x * delta.x


def boost(delta: Event, v: Fraction, gamma: Fraction) -> Event:
    return Event(
        gamma * (delta.t - v * delta.x),
        gamma * (delta.x - v * delta.t),
    )


def causal_past(p: Event, q: Event) -> bool:
    """B(p,q): q belongs to the closed causal past of p."""
    delta = subtract(p, q)
    return delta.t >= abs(delta.x)


def future_timelike(delta: Event) -> bool:
    return delta.t > abs(delta.x)


def exact_sqrt(value: Fraction) -> Fraction:
    require(value >= 0, f"Negative squared proper time: {value}")
    numerator_root = isqrt(value.numerator)
    denominator_root = isqrt(value.denominator)
    require(
        numerator_root**2 == value.numerator
        and denominator_root**2 == value.denominator,
        f"Non-rational square root requested: {value}",
    )
    return Fraction(numerator_root, denominator_root)


def proper_time(delta: Event) -> Fraction:
    require(future_timelike(delta), f"Not future timelike: {delta}")
    return exact_sqrt(interval2(delta))


def rational(value: Fraction) -> str:
    return str(value)


def event_record(event: Event) -> dict[str, str]:
    return {"t": rational(event.t), "x": rational(event.x)}


def verify() -> dict:
    boosts = (
        (Fraction(3, 5), Fraction(5, 4)),
        (Fraction(-3, 5), Fraction(5, 4)),
        (Fraction(4, 5), Fraction(5, 3)),
        (Fraction(-4, 5), Fraction(5, 3)),
    )
    grid = tuple(
        Event(Fraction(t), Fraction(x))
        for t, x in product(range(-2, 3), repeat=2)
    )

    interval_checks = 0
    inverse_checks = 0
    future_timelike_checks = 0
    past_timelike_checks = 0
    causal_covariance_checks = 0
    for v, gamma in boosts:
        require(abs(v) < 1, "The boost speed must be subluminal.")
        require(gamma > 0, "The boost must preserve time orientation.")
        require(
            gamma * gamma * (1 - v * v) == 1,
            f"Incorrect exact gamma for v={v}.",
        )
        for p, q in product(grid, repeat=2):
            delta = subtract(p, q)
            transformed = boost(delta, v, gamma)
            require(
                interval2(transformed) == interval2(delta),
                f"Interval invariance failed for {p}, {q}, v={v}.",
            )
            interval_checks += 1
            require(
                boost(transformed, -v, gamma) == delta,
                f"Inverse boost failed for {p}, {q}, v={v}.",
            )
            inverse_checks += 1
            if future_timelike(delta):
                require(
                    future_timelike(transformed),
                    f"Future timelike order failed for {p}, {q}, v={v}.",
                )
                future_timelike_checks += 1
            if future_timelike(Event(-delta.t, -delta.x)):
                require(
                    transformed.t < -abs(transformed.x),
                    f"Past timelike order failed for {p}, {q}, v={v}.",
                )
                past_timelike_checks += 1
            require(
                causal_past(p, q)
                == causal_past(boost(p, v, gamma), boost(q, v, gamma)),
                f"Causal-past covariance failed for {p}, {q}, v={v}.",
            )
            causal_covariance_checks += 1

    # Rietdijk's diagram in coordinates with the moving frame based at B.
    a = Event(Fraction(0), Fraction(0))
    b = Event(Fraction(0), Fraction(-4))
    p = Event(Fraction(1), Fraction(0))
    v, gamma = boosts[0]
    a_prime = boost(subtract(a, b), v, gamma)
    b_prime = boost(subtract(b, b), v, gamma)
    p_prime = boost(subtract(p, b), v, gamma)
    require(b_prime.t == 0, "B is not the moving-frame time origin.")
    require(p_prime.t < 0, "P should precede B in the moving coordinates.")
    require(p_prime.t - a_prime.t > 0, "A must remain earlier than P.")
    require(interval2(subtract(p, b)) < 0, "B and P must be spacelike.")
    require(future_timelike(subtract(p, a)), "P must be timelike future of A.")
    require(a_prime == Event(Fraction(-3), Fraction(5)), "Wrong transformed A.")
    require(
        p_prime == Event(Fraction(-7, 4), Fraction(17, 4)),
        "Wrong transformed P.",
    )

    # All 25 x 25 ordered grid pairs; the bridge need not lie on the grid.
    bridge_checks = 0
    strict_link_checks = 0
    bridge_example = None
    for first, second in product(grid, repeat=2):
        dt = second.t - first.t
        dx = second.x - first.x
        bound = (abs(dx) + abs(dt)) / 2
        radius = bound + 1
        bridge = Event(
            (first.t + second.t) / 2,
            (first.x + second.x) / 2 + radius,
        )
        require(radius > bound, "The bridge radius must strictly exceed the bound.")
        first_interval = interval2(subtract(bridge, first))
        second_interval = interval2(subtract(second, bridge))
        require(first_interval < 0, "The first bridge link is not spacelike.")
        require(second_interval < 0, "The second bridge link is not spacelike.")
        bridge_checks += 1
        strict_link_checks += 2
        if first == a and second == p:
            bridge_example = {
                "p": event_record(first),
                "q": event_record(second),
                "R": rational(radius),
                "r": event_record(bridge),
                "first_interval_squared": rational(first_interval),
                "second_interval_squared": rational(second_interval),
            }
    require(bridge_checks == 625, "The requested 625 grid pairs were not covered.")
    require(bridge_example is not None, "The recorded bridge example is missing.")

    # A finite check of reflexivity/transitivity supplements the all-point proof.
    for point in grid:
        require(causal_past(point, point), "Causal-past reflexivity failed.")
    transitivity_antecedents = 0
    for first, second, third in product(grid, repeat=3):
        if causal_past(first, second) and causal_past(second, third):
            require(causal_past(first, third), "Causal-past transitivity failed.")
            transitivity_antecedents += 1
    spacelike = Event(Fraction(0), Fraction(1))
    require(causal_past(p, a), "The asymmetric example must hold in one direction.")
    require(not causal_past(a, p), "The example must fail in the reverse direction.")
    require(not causal_past(a, spacelike), "Spacelike events must be excluded.")
    require(not causal_past(spacelike, a), "Spacelike exclusion must hold both ways.")

    # Two timelike inertial segments with instantaneous idealized turnaround.
    departure = a
    turnaround = Event(Fraction(5), Fraction(3))
    reunion = Event(Fraction(10), Fraction(0))
    outbound = subtract(turnaround, departure)
    inbound = subtract(reunion, turnaround)
    rest = subtract(reunion, departure)
    require(outbound.x / outbound.t == Fraction(3, 5), "Wrong outbound speed.")
    require(inbound.x / inbound.t == Fraction(-3, 5), "Wrong inbound speed.")
    outbound_tau = proper_time(outbound)
    inbound_tau = proper_time(inbound)
    traveler_tau = outbound_tau + inbound_tau
    rest_tau = proper_time(rest)
    require(outbound_tau == inbound_tau == 4, "Each travel leg must have proper time 4.")
    require(traveler_tau == 8, "The traveler must accumulate proper time 8.")
    require(rest_tau == 10, "The inertial rest observer must accumulate proper time 10.")
    require(traveler_tau < rest_tau, "The travel and rest proper times must differ.")

    return {
        "status": "pass",
        "arithmetic": "fractions.Fraction only; no floating-point tolerances",
        "units_and_signature": "c=1; squared interval dt^2-dx^2",
        "boosts": [
            {"v": rational(speed), "gamma": rational(gamma_value)}
            for speed, gamma_value in boosts
        ],
        "grid": {
            "t_values": list(range(-2, 3)),
            "x_values": list(range(-2, 3)),
            "event_count": len(grid),
            "ordered_pair_count": len(grid) ** 2,
        },
        "lorentz_checks": {
            "interval_invariance": interval_checks,
            "inverse_transformation": inverse_checks,
            "future_timelike_order": future_timelike_checks,
            "past_timelike_order": past_timelike_checks,
            "causal_past_covariance": causal_covariance_checks,
        },
        "rietdijk_example": {
            "A": event_record(a),
            "B": event_record(b),
            "P": event_record(p),
            "moving_frame_origin": "B",
            "A_prime": event_record(a_prime),
            "B_prime": event_record(b_prime),
            "P_prime": event_record(p_prime),
            "P_prime_time_minus_A_prime_time": rational(p_prime.t - a_prime.t),
            "P_minus_B_interval_squared": rational(interval2(subtract(p, b))),
            "P_minus_A_interval_squared": rational(interval2(subtract(p, a))),
            "conclusion": "P is coordinate-earlier than B but causally later than A.",
        },
        "two_spacelike_links": {
            "bridge_pairs_checked": bridge_checks,
            "strict_spacelike_links_checked": strict_link_checks,
            "radius_rule": "R=(abs(delta_x)+abs(delta_t))/2+1",
            "example": bridge_example,
        },
        "causal_past_relation": {
            "definition": "B(p,q) iff p.t-q.t >= abs(p.x-q.x)",
            "reflexivity_points_checked": len(grid),
            "triples_enumerated": len(grid) ** 3,
            "transitivity_antecedents_checked": transitivity_antecedents,
            "asymmetry_witness": {"p": event_record(p), "q": event_record(a)},
            "nonuniversality_witness": {
                "p": event_record(a),
                "q": event_record(spacelike),
            },
            "interpretive_limit": (
                "An invariant non-equivalence relation, not a countermodel to all "
                "Putnam premises: it rejects inclusion of every distant simultaneity "
                "hyperplane and does not establish an open-future ontology."
            ),
        },
        "proper_time_example": {
            "departure": event_record(departure),
            "turnaround": event_record(turnaround),
            "reunion": event_record(reunion),
            "outbound_speed": "3/5",
            "inbound_speed": "-3/5",
            "total_coordinate_time_in_rest_frame": rational(rest.t),
            "outbound_proper_time": rational(outbound_tau),
            "inbound_proper_time": rational(inbound_tau),
            "traveler_total_proper_time": rational(traveler_tau),
            "rest_observer_proper_time": rational(rest_tau),
            "idealization": (
                "Piecewise inertial worldline with an instantaneous turnaround; "
                "no finite-acceleration hardware or turnaround-time bound is claimed."
            ),
        },
        "scope": [
            "The finite computations check specified examples and grids exactly.",
            "All-point arguments are provided in check_relativistic_arguments_note.md.",
            "The two-link theorem uses global unbounded Minkowski spacetime.",
            "No assertion of the same construction on arbitrary GR spacetimes is made.",
            "Proper times require no universal present or preferred inertial frame.",
            "No computation here proves eternalism, determinism, or absence of agency.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_suffix(".json"),
        help="Path for the exact verification report.",
    )
    args = parser.parse_args()
    report = verify()
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "status": report["status"],
                "interval_invariance_checks": report["lorentz_checks"]["interval_invariance"],
                "spacelike_bridge_pairs": report["two_spacelike_links"]["bridge_pairs_checked"],
                "traveler_proper_time": report["proper_time_example"]["traveler_total_proper_time"],
                "rest_proper_time": report["proper_time_example"]["rest_observer_proper_time"],
                "output": str(args.output.resolve()),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
