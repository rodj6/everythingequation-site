#!/usr/bin/env python3
"""Exact finite checks for forecasting.tex; no external packages required.

This checks the declared binary and rational contracts. It is not an empirical
claim about people, universal prediction, or the metaphysics of natural law.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import product
import json
from pathlib import Path


def main() -> None:
    names = {
        (0, 0): "always_zero",
        (0, 1): "follow",
        (1, 0): "oppose",
        (1, 1): "always_one",
    }
    classifications = []
    for outputs in product((0, 1), repeat=2):
        fixed_points = [p for p in (0, 1) if outputs[p] == p]
        classifications.append({
            "policy": names[outputs],
            "outputs_d0_d1": list(outputs),
            "correct_disclosed_messages": fixed_points,
        })
    assert len(classifications) == 4
    assert [c["correct_disclosed_messages"] for c in classifications] == [
        [0], [0, 1], [], [1]
    ]
    assert [c["policy"] for c in classifications
            if not c["correct_disclosed_messages"]] == ["oppose"]

    opposition_runs = [
        {"forecast_p": p, "action_A": 1 - p, "correct": p == 1 - p}
        for p in (0, 1)
    ]
    assert all(not run["correct"] for run in opposition_runs)

    hidden_runs = [
        {"input_B": b, "hidden_forecast_P": b, "action_A": b,
         "correct": True, "disclosure_path": False}
        for b in (0, 1)
    ]
    assert all(run["hidden_forecast_P"] == run["action_A"]
               for run in hidden_runs)

    # Counterexamples if the installed timely-opposition contract is absent.
    missing_contract_examples = [
        {"case": "blocked_read", "forecast_p": 0, "action_A": 0,
         "opposition_active": False},
        {"case": "forecast_after_commit", "forecast_p": 1, "action_A": 1,
         "opposition_active": False},
        {"case": "only_zero_actuator_available", "forecast_p": 0,
         "action_A": 0, "opposition_active": False},
    ]
    assert all(case["forecast_p"] == case["action_A"]
               for case in missing_contract_examples)

    # Exact grid verification complements the symbolic equation r=1-r.
    rational_grid = [Fraction(n, 100) for n in range(101)]
    calibrated = [r for r in rational_grid if r == 1 - r]
    assert calibrated == [Fraction(1, 2)]
    half = Fraction(1, 2)
    # Independent fair hidden seed implements Bernoulli(1/2) exactly.
    half_actions = [1 - seed for seed in (0, 1)]
    half_probability_one = Fraction(sum(half_actions), len(half_actions))
    assert half_probability_one == half

    # Check generator prediction is preserved by authority revision, while
    # a behavior forecast that ignores a changed installed selector can fail.
    generator_checks = 0
    changed_behavior_witnesses = []
    for c, s, d, b in product((0, 1), repeat=4):
        recommendation = c ^ (b * s * d)
        model_recommendation = c ^ (b * s * d)
        assert model_recommendation == recommendation
        old_behavior = c ^ (1 * b * s * d)
        revised_behavior = c ^ (0 * b * s * d)
        generator_checks += 1
        if old_behavior != revised_behavior:
            changed_behavior_witnesses.append({
                "C": c, "S": s, "D": d, "b": b,
                "recommendation_R": recommendation,
                "forecast_under_old_lambda_1": old_behavior,
                "actual_under_new_lambda_0": revised_behavior,
            })
    assert generator_checks == 16
    assert len(changed_behavior_witnesses) == 2

    result = {
        "status": "all_checks_passed",
        "scope": "Exact finite checks of the explicitly declared contracts only",
        "binary_policy_classification": classifications,
        "announced_opposition_runs": opposition_runs,
        "hidden_correct_forecast_runs": hidden_runs,
        "missing_contract_success_examples": missing_contract_examples,
        "probability_forecast_check": {
            "response_probability_one": "1-r",
            "calibration_equation": "r=1-r",
            "unique_symbolic_solution": "1/2",
            "checked_grid": "0/100,...,100/100",
            "grid_calibrated_forecasts": [str(r) for r in calibrated],
            "independent_fair_seed_probability_one": str(half_probability_one),
            "claim_about_all_stochastic_response_maps": False,
        },
        "recommendation_model_checks": generator_checks,
        "old_behavior_forecast_invalidated_by_revision": changed_behavior_witnesses,
        "nonclaims": [
            "No universal unpredictability or indeterminism follows",
            "Hidden prediction need not fail",
            "Not every receiver can or should oppose",
            "No ultimate self-authorship or moral responsibility follows",
            "No all-probability-forecasts impossibility follows",
        ],
    }
    target = Path(__file__).with_suffix(".json")
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"],
                      "binary_maps": len(classifications),
                      "opposition_runs": len(opposition_runs),
                      "hidden_runs": len(hidden_runs),
                      "rational_probabilities": len(rational_grid),
                      "generator_cases": generator_checks,
                      "output": str(target)}, indent=2))


if __name__ == "__main__":
    main()
