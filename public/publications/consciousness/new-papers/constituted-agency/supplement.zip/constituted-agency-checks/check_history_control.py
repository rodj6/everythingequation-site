#!/usr/bin/env python3
"""Exact reversible history/control checks for a four-register circuit.

Registers are bits (R,A,C,F). A supplied schedule applies CX(R,A),
SWAP(A,C), CX(A,F). All 16 states are tested. Conditional command
comparisons use the four prepared inputs (r,0,a,0), not a fixed complete
initial state. This is a mathematical counterexample, not a model of human
choice, thermodynamics, autonomous clocking, or ultimate authorship.
"""
from __future__ import annotations

from itertools import product
import json
from pathlib import Path

State = tuple[int, int, int, int]


def cx_ra(state: State) -> State:
    r, a, c, f = state
    return r, a ^ r, c, f


def swap_ac(state: State) -> State:
    r, a, c, f = state
    return r, c, a, f


def cx_af(state: State) -> State:
    r, a, c, f = state
    return r, a, c, f ^ a


GATES = (cx_ra, swap_ac, cx_af)


def history(state: State) -> tuple[State, ...]:
    states = [state]
    for gate in GATES:
        states.append(gate(states[-1]))
    return tuple(states)


def forward(state: State) -> State:
    return history(state)[-1]


def inverse(state: State) -> State:
    for gate in reversed(GATES):
        state = gate(state)
    return state


def closed_form(state: State) -> State:
    r, a, c, f = state
    return r, c, a ^ r, f ^ c


def closed_inverse(state: State) -> State:
    r_out, a_out, c_out, f_out = state
    return r_out, c_out ^ r_out, a_out, f_out ^ a_out


def main() -> None:
    universe = tuple(product((0, 1), repeat=4))
    assert len(universe) == 16
    records = []
    for initial in universe:
        trajectory = history(initial)
        final = trajectory[-1]
        assert final == closed_form(initial)
        assert inverse(final) == initial
        assert forward(inverse(initial)) == initial
        assert closed_inverse(final) == initial
        assert inverse(initial) == closed_inverse(initial)
        for gate in GATES:
            assert gate(gate(initial)) == initial
        records.append({"initial": list(initial),
                        "history_t0_t1_t2_t3": [list(s) for s in trajectory],
                        "final": list(final),
                        "recovered_initial": list(inverse(final))})
    assert len({forward(s) for s in universe}) == 16

    # Each full intermediate slice labels a unique trajectory, given schedule.
    intermediate_slice_counts = []
    trajectories = [history(s) for s in universe]
    for stage in range(4):
        mapping = {trajectory[stage]: trajectory for trajectory in trajectories}
        assert len(mapping) == 16
        assert all(mapping[trajectory[stage]] == trajectory
                   for trajectory in trajectories)
        intermediate_slice_counts.append({"stage": stage,
                                          "distinct_complete_states": len(mapping),
                                          "unique_history_reconstruction": True})

    prepared = []
    conditional_comparisons = []
    for r in (0, 1):
        for command in (0, 1):
            initial = (r, 0, command, 0)
            trajectory = history(initial)
            expected = (r, command, r, command)
            assert trajectory[-1] == expected
            assert all(s[0] == r for s in trajectory)
            assert trajectory[2][1] == command
            assert trajectory[3][3] == command
            prepared.append({"record_r": r, "command_a": command,
                             "history_t0_t1_t2_t3": [list(s) for s in trajectory],
                             "final": list(expected)})
        low = history((r, 0, 0, 0))
        high = history((r, 0, 1, 0))
        assert low[0] != high[0]  # Complete initial states are not held fixed.
        assert low[0][0] == high[0][0] == r
        assert low[-1][3] == 0 and high[-1][3] == 1
        assert low[-1][3] != high[-1][3]
        assert all(l[0] == h[0] == r for l, h in zip(low, high))
        conditional_comparisons.append({
            "fixed_record_r": r,
            "initial_complete_states_equal": False,
            "initial_changed_registers": ["C"],
            "record_R_invariant_at_every_stage": True,
            "final_F_under_command_0": low[-1][3],
            "final_F_under_command_1": high[-1][3],
            "binary_success_under_prepared_contract": True,
        })

    # A dirty target bit changes the outcome law and is a concrete witness that
    # F=a is conditional on the prepared F=0 background.
    dirty_target = []
    for r, command in product((0, 1), repeat=2):
        final = forward((r, 0, command, 1))
        assert final[3] == 1 - command
        dirty_target.append({"record_r": r, "command_a": command,
                             "initial_F": 1, "final_F": final[3]})

    # The complete action-containing slice is injective over all histories,
    # while its A bit alone leaves both earlier R and other registers open.
    stage2_by_action = {}
    for action in (0, 1):
        compatible = [trajectory for trajectory in trajectories
                      if trajectory[2][1] == action]
        assert len(compatible) == 8
        possible_prior_records = sorted({trajectory[0][0]
                                         for trajectory in compatible})
        assert possible_prior_records == [0, 1]
        stage2_by_action[str(action)] = {
            "compatible_full_histories": len(compatible),
            "possible_prior_R": possible_prior_records,
        }

    result = {
        "status": "all_checks_passed",
        "register_order": ["R", "A", "C", "F"],
        "gate_schedule": ["CX(R,A)", "SWAP(A,C)", "CX(A,F)"],
        "closed_form": "(R,A,C,F) -> (R,C,A xor R,F xor C)",
        "inverse_closed_form": "(Rout,Aout,Cout,Fout) -> (Rout,Cout xor Rout,Aout,Fout xor Aout)",
        "all_16_states": records,
        "full_permutation_is_bijective": True,
        "each_gate_is_an_involution": True,
        "intermediate_slices": intermediate_slice_counts,
        "all_4_prepared_histories": prepared,
        "conditional_command_comparisons": conditional_comparisons,
        "dirty_target_counterexamples": dirty_target,
        "action_fragment_at_stage_2": stage2_by_action,
        "scope_limits": [
            "Command C differs in the initial preparations",
            "The entire microscopic past is not fixed across command comparisons",
            "The gate schedule and prepared scratch/target states are supplied",
            "Invertibility is not a general proof of time-reversal invariance",
            "Invariant selected record R is not invariant entire past",
            "Conditional efficacy is not sufficient for human agency or ultimate authorship",
            "No thermodynamic arrow or relativistic causal structure is derived",
        ],
    }
    target = Path(__file__).with_suffix(".json")
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"],
                      "full_states_checked": len(records),
                      "complete_slice_maps_checked": len(intermediate_slice_counts),
                      "prepared_histories_checked": len(prepared),
                      "conditional_command_comparisons": len(conditional_comparisons),
                      "output": str(target)}, indent=2))


if __name__ == "__main__":
    main()
