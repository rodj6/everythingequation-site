#!/usr/bin/env python3
"""Exact finite witness: one actual trace does not identify a native contract.

Physical state q is a bit and its emission is q. Inputs are u=0 (idle) and
u=1 (test). At each step the input updates q, then the new q is emitted.
The ready state is q=0. These finite checks do not certify A1, assign
consciousness, or infer distinct phenomenology.
"""
from __future__ import annotations

from itertools import product
from pathlib import Path
import json

OUT = Path(__file__).with_suffix('.json')
STATES = (0, 1)
INPUTS = (0, 1)


def step(law, q, u):
    assert law in ('L0', 'L1') and q in STATES and u in INPUTS
    q_next = q if law == 'L0' else q ^ u
    return q_next, q_next


def run(law, initial, word):
    state = initial
    states = [state]
    emissions = []
    for u in word:
        state, output = step(law, state, u)
        states.append(state)
        emissions.append(output)
    return tuple(states), tuple(emissions)


def native_graph(law):
    return {q: {step(law, q, u)[0] for u in INPUTS} for q in STATES}


def reachability(graph):
    result = {}
    for start in STATES:
        seen = {start}
        frontier = [start]
        while frontier:
            q = frontier.pop()
            for target in graph[q] - seen:
                seen.add(target)
                frontier.append(target)
        result[start] = seen
    return result


def strongly_connected_components(graph):
    reach = reachability(graph)
    todo = set(STATES)
    components = []
    while todo:
        q = min(todo)
        component = {r for r in todo if r in reach[q] and q in reach[r]}
        assert component
        components.append(sorted(component))
        todo -= component
    return components


def main():
    # All four state/input pairs in each law: eight exact transition checks.
    transition_tables = {}
    for law in ('L0', 'L1'):
        table = []
        for q, u in product(STATES, INPUTS):
            next_q, emitted_q = step(law, q, u)
            expected_q = q if law == 'L0' else (q + u) % 2
            assert next_q == expected_q and emitted_q == next_q
            table.append({'q': q, 'u': u, 'next_q': next_q,
                          'post_transition_emission': emitted_q})
        transition_tables[law] = table

    idle_prefixes = []
    for length in range(1, 9):
        word = (0,) * length
        trajectories = {law: run(law, 0, word) for law in ('L0', 'L1')}
        assert trajectories['L0'] == trajectories['L1']
        assert trajectories['L0'][0] == (0,) * (length + 1)
        assert trajectories['L0'][1] == (0,) * length
        idle_prefixes.append({'length': length, 'input_word': word,
                              'state_path_both': trajectories['L0'][0],
                              'emission_trace_both': trajectories['L0'][1]})

    # Exhaust all 31 words of lengths zero through four, from each physical
    # initial state. The independent closed form for L1 is cumulative parity.
    probe_results = []
    counts_by_initial = {}
    for initial in STATES:
        identical = distinguished = checked = 0
        for length in range(5):
            for word in product(INPUTS, repeat=length):
                path0, trace0 = run('L0', initial, word)
                path1, trace1 = run('L1', initial, word)
                assert trace0 == (initial,) * length
                expected1 = tuple(initial ^ (sum(word[:j]) % 2)
                                  for j in range(1, length + 1))
                assert trace1 == expected1
                equal = trace0 == trace1
                assert equal == all(u == 0 for u in word)
                first_difference = next((j for j, (a, b) in
                                         enumerate(zip(trace0, trace1), 1)
                                         if a != b), None)
                if 1 in word:
                    assert first_difference == word.index(1) + 1
                else:
                    assert first_difference is None
                identical += int(equal)
                distinguished += int(not equal)
                checked += 1
                probe_results.append({'initial_q': initial, 'input_word': word,
                                      'L0_state_path': path0, 'L1_state_path': path1,
                                      'L0_emissions': trace0, 'L1_emissions': trace1,
                                      'first_distinguishing_step': first_difference})
        assert (checked, identical, distinguished) == (31, 5, 26)
        counts_by_initial[str(initial)] = {
            'words_checked': checked, 'identical_emission_words': identical,
            'distinguishing_emission_words': distinguished}

    assert run('L0', 0, (1,))[1] == (0,)
    assert run('L1', 0, (1,))[1] == (1,)

    graphs = {law: native_graph(law) for law in ('L0', 'L1')}
    sccs = {law: strongly_connected_components(graphs[law])
            for law in ('L0', 'L1')}
    assert sccs['L0'] == [[0], [1]]
    assert sccs['L1'] == [[0, 1]]
    ready_reachable = {law: sorted(reachability(graphs[law])[0])
                       for law in ('L0', 'L1')}
    assert ready_reachable == {'L0': [0], 'L1': [0, 1]}

    # Emission preservation fixes the only possible cross-model identification:
    # state 0 must map to 0 and state 1 to 1. That map fails to preserve u=1
    # transitions. Hence the labelled, emission-preserving objects differ.
    for law in ('L0', 'L1'):
        assert {q: q for q in STATES} == {0: 0, 1: 1}
        # States remain distinguishable by a direct current-state emission,
        # and by an idle input followed by the next state emission.
        assert 0 != 1
        assert run(law, 0, (0,))[1] != run(law, 1, (0,))[1]
    failed_preservation = [
        {'q': q, 'u': u, 'L0_next_q': step('L0', q, u)[0],
         'L1_next_q': step('L1', q, u)[0]}
        for q, u in product(STATES, INPUTS)
        if step('L0', q, u)[0] != step('L1', q, u)[0]
    ]
    assert [(x['q'], x['u']) for x in failed_preservation] == [(0, 1), (1, 1)]

    actual_visited_state_inputs = {(0, 0)}
    full_native_state_inputs = set(product(STATES, INPUTS))
    uncovered = sorted(full_native_state_inputs - actual_visited_state_inputs)
    assert uncovered == [(0, 1), (1, 0), (1, 1)]

    output = {
        'status': 'passed',
        'conventions': {
            'physical_states': STATES, 'current_emission': 'e(q)=q',
            'native_inputs': {'0': 'idle', '1': 'test'}, 'ready_state': 0,
            'L0': "q_next=q for both inputs", 'L1': "q_next=q XOR u",
            'trace_timing': 'Apply input, update state, then emit the new q.',
            'initial_emission': 0,
        },
        'transition_pairs_checked_per_law': 4,
        'transition_pairs_checked_total': 8,
        'transition_tables': transition_tables,
        'eight_actual_idle_prefixes': idle_prefixes,
        'native_graphs': {law: {str(q): sorted(v) for q, v in graph.items()}
                          for law, graph in graphs.items()},
        'native_SCCs_full_declared_state_domain': sccs,
        'ready_reachable_states': ready_reachable,
        'probe_word_counts': counts_by_initial,
        'all_probe_word_results_lengths_zero_through_four': probe_results,
        'emission_distinguishable_states_both_laws': [[0], [1]],
        'labelled_object_mismatch_under_only_emission_preserving_bijection':
            failed_preservation,
        'actual_coverage': {
            'visited_state_input_pairs': sorted(actual_visited_state_inputs),
            'uncovered_native_state_input_pairs': uncovered,
            'A1_certified_by_actual_idle_trace': False,
            'reason': 'The actual idle run does not cover the native contract.'},
        'scope_limits': [
            'Equal actual idle emissions do not determine the admitted input-labelled transition law.',
            'The graph/SCC claim uses the full declared native state domain; ready reachability is separately reported.',
            'No conclusion assigning consciousness or different phenomenology follows from this witness.',
            'The finite exhaustive word check is through length four; the all-length parity characterization follows directly from the displayed law.'
        ],
    }
    OUT.write_text(json.dumps(output, indent=2) + '\n')
    print('PASS: eight transition-law pairs, eight idle prefixes, 62 probe words.')
    print('PASS: native SCCs, ready reachability, state distinguishability and labelled-object mismatch.')
    print('LIMIT: idle actual trace does not certify A1; no phenomenology assignment.')
    print(f'Results: {OUT}')


if __name__ == '__main__':
    main()
