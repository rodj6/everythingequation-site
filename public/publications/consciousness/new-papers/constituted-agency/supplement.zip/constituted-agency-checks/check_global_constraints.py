#!/usr/bin/env python3
"""Finite verification for the standard compatibility/counting application.

This checks finite images, fibres, profile projections and global feasibility.
It does not computationally verify infinite compactness or prove agency claims.
Run from any directory; output is adjacent to this script.
"""
from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

OUT = Path(__file__).with_suffix('.json')


def binary_profiles(n):
    return tuple(itertools.product((0, 1), repeat=n))


def profile_report(histories, readers, action_sets):
    """Read actions from each complete finite legal history, preserving fibres."""
    profiles = tuple(itertools.product(*action_sets))
    fibres = {p: [] for p in profiles}
    for h in histories:
        p = tuple(read(h) for read in readers)
        assert p in fibres
        fibres[p].append(h)
    image = tuple(p for p in profiles if fibres[p])
    missing = tuple(p for p in profiles if not fibres[p])
    return {
        'history_count': len(histories),
        'declared_profile_count': len(profiles),
        'image': image,
        'missing': missing,
        'fibre_sizes': {''.join(map(str, p)): len(fibres[p]) for p in profiles},
        'all_profiles_realizable': not missing,
    }


def projection_image(histories, positions):
    return set(tuple(h[i] for i in positions) for h in histories)


def surjection_count(m, k):
    # Standard inclusion-exclusion count, independent of enumerated fibre tests.
    return sum((-1) ** j * math.comb(k, j) * (k - j) ** m
               for j in range(k + 1))


def main():
    reports = {}
    local_only = ((0, 0), (1, 1))
    r = profile_report(local_only, (lambda h: h[0], lambda h: h[1]),
                       ((0, 1), (0, 1)))
    assert all(projection_image(local_only, (i,)) == {(0,), (1,)}
               for i in (0, 1))
    assert set(r['missing']) == {(0, 1), (1, 0)}
    reports['unary_availability_without_joint_compatibility'] = r

    even_parity = tuple(p for p in binary_profiles(3) if sum(p) % 2 == 0)
    r = profile_report(even_parity, tuple(lambda h, i=i: h[i] for i in range(3)),
                       ((0, 1),) * 3)
    assert all(projection_image(even_parity, pair) == set(binary_profiles(2))
               for pair in itertools.combinations(range(3), 2))
    assert set(r['missing']) == {p for p in binary_profiles(3) if sum(p) % 2}
    reports['pairwise_compatibility_without_triple_compatibility'] = r

    # Labelled histories can have identical action profiles: counts are of
    # complete legal histories, not merely of distinct profiles.
    duplicate_histories = tuple(range(6))
    assigned_profiles = ((0, 0), (0, 0), (0, 1), (1, 0), (1, 1), (1, 1))
    r = profile_report(duplicate_histories,
                       (lambda h: assigned_profiles[h][0],
                        lambda h: assigned_profiles[h][1]),
                       ((0, 1), (0, 1)))
    assert r['all_profiles_realizable'] and r['history_count'] >= 4
    assert sorted(r['fibre_sizes'].values()) == [1, 1, 2, 2]
    reports['surjective_map_with_duplicate_profile_histories'] = r

    # Exhaust all maps from m labelled histories to k binary profiles, for
    # n = 1, 2, 3 and m = 0,...,5. Enumerated surjection counts must agree with
    # inclusion-exclusion; every surjection must obey the cardinality bound.
    exhaustive = []
    total_maps = 0
    for n in (1, 2, 3):
        k = 2 ** n
        for m in range(6):
            found_surjections = 0
            map_count = 0
            for assignment in itertools.product(range(k), repeat=m):
                counts = [0] * k
                for image in assignment:
                    counts[image] += 1
                onto = all(counts)
                image_size = len(set(assignment))
                assert onto == (image_size == k)
                assert sum(counts) == m
                if onto:
                    assert k <= m
                    found_surjections += 1
                map_count += 1
            expected = surjection_count(m, k)
            assert found_surjections == expected
            assert map_count == k ** m
            total_maps += map_count
            exhaustive.append({'binary_regions': n, 'labelled_histories': m,
                               'maps_checked': map_count,
                               'surjective_maps': found_surjections,
                               'inclusion_exclusion_count': expected})

    # Direct finite pruning: the two possible first acts are each legal,
    # but after setting the first act to zero, setting second act to one fails.
    stages = [list(local_only)]
    retained = local_only
    for i, action in ((0, 0), (1, 1)):
        retained = tuple(h for h in retained if h[i] == action)
        stages.append(list(retained))
    assert [len(s) for s in stages] == [2, 1, 0]
    reports['incompatible_pruning_sequence'] = {
        'constraints_in_order': [[0, 0], [1, 1]],
        'retained_histories': stages,
        'nonempty_sizes': [len(s) for s in stages],
    }

    # These are finite witnesses illustrating the infinite finite-support
    # counterexample. The all-infinite claim is established by the text proof.
    prefix_witnesses = []
    for prefix in range(1, 13):
        witness_support = set(range(1, prefix + 1))
        assert all(i in witness_support for i in range(1, prefix + 1))
        assert len(witness_support) == prefix
        # Arbitrarily add later ones to obtain further compatible histories.
        extended = witness_support | {prefix + 7}
        assert all(i in extended for i in range(1, prefix + 1))
        prefix_witnesses.append({'prefix_ones': prefix,
                                 'finite_support_witness': sorted(witness_support),
                                 'another_finite_support_witness': sorted(extended)})

    output = {
        'status': 'passed',
        'scope': 'Finite image/fibre/profile and pruning checks; standard mathematics application.',
        'exhaustive_map_count': total_maps,
        'exhaustive_cases': exhaustive,
        'examples': reports,
        'finite_prefix_witnesses': prefix_witnesses,
        'not_computationally_verified': [
            'Infinite finite-support intersection is empty: follows from finite-support definition.',
            'Compact closed-set finite-intersection theorem: supplied standard proof in TeX.',
            'No inference from legal profile compatibility to caller ability or ultimate authorship.',
            'No physical probability, entropy, Hamiltonian selection mechanism, or free-will theorem.'
        ],
    }
    OUT.write_text(json.dumps(output, indent=2) + '\n')
    print(f'PASS: {total_maps:,} finite maps checked; inclusion-exclusion counts agree.')
    print('PASS: unary/pairwise/full compatibility, duplicate fibres, and pruning examples.')
    print(f'Results: {OUT}')


if __name__ == '__main__':
    main()
