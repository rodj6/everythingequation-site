#!/usr/bin/env python3
"""Finite recognition transaction and local reversible compilation.

Independent construction for second manuscript. Standard library only.
All Boolean/probability and sqrt-X algebra checks use exact arithmetic.
Physical primitive conformance, memory lifetime, and psychological interpretation
are assumptions, not certified by this script.
"""
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
from collections import Counter
import json

NAMES = ['B','C','D','S','P','K','lam','monitor','commit','read_open',
         'c_probe','d_probe','s_probe','r_probe','u_probe','R0','R1',
         'bhat','omega','candidate','install_delta','R','U','diff','T',
         'E','Tprime','W','action','valid','V']
INDEX = {name:i for i,name in enumerate(NAMES)}
GATES=[]
def gate(op,*names):
    args=tuple(INDEX[n] for n in names)
    assert len(set(args))==len(args)
    GATES.append((op,args))
def cx(source,target): gate('CX',source,target)
def ccx(a,b,target): gate('CCX',a,b,target)
def x(target): gate('X',target)
def generator(c,d,s,r,u):
    # r= c XOR B*s*d, with clean u restored. Its full input is preserved.
    return [('CCX',(INDEX[s],INDEX[d],INDEX[u])),
            ('CX',(INDEX[c],INDEX[r])),
            ('CCX',(INDEX['B'],INDEX[u],INDEX[r])),
            ('CCX',(INDEX[s],INDEX[d],INDEX[u]))]
def append(seq): GATES.extend(seq)

# Two paid actual generator probes at common c=0,d=1 and s=0,1.
gen_probe=generator('c_probe','d_probe','s_probe','r_probe','u_probe')
append(gen_probe)
ccx('read_open','r_probe','R0')
append(list(reversed(gen_probe)))
x('s_probe')
append(gen_probe)
ccx('read_open','r_probe','R1')
append(list(reversed(gen_probe)))
x('s_probe')
cx('R0','bhat');cx('R1','bhat')
cx('bhat','V')

# Current audit: q>1/2 and the stated irrelevant-tag task family.
# candidate=old_lam*(1-bhat). Preserve old_lam in omega. The physical
# installation control is the actual commit line, not a certificate bit.
cx('lam','omega')
cx('omega','candidate');ccx('omega','bhat','candidate')
cx('omega','install_delta');cx('candidate','install_delta')
ccx('commit','install_delta','lam')
cx('candidate','install_delta');cx('omega','install_delta')
ccx('omega','bhat','candidate');cx('omega','candidate')
FRESH_BOUNDARY=len(GATES)

# Fresh action, retaining generator and internal assessment records.
append(generator('C','D','S','R','U'))
cx('R','diff');cx('C','diff')
cx('C','T');ccx('lam','diff','T')
cx('T','E');cx('C','E')
cx('T','Tprime');ccx('monitor','E','Tprime')
cx('Tprime','W');cx('P','W')
ccx('K','W','action');cx('K','valid')
cx('P','W');cx('Tprime','W')
cx('C','E');cx('T','E')
cx('C','diff');cx('R','diff')

def apply(bits, instruction):
    op,args=instruction
    if op=='X':bits[args[0]]^=1
    elif op=='CX':bits[args[1]]^=bits[args[0]]
    elif op=='CCX':bits[args[2]]^=bits[args[0]] & bits[args[1]]
    elif op=='SWAP':bits[args[0]],bits[args[1]]=bits[args[1]],bits[args[0]]
    else:raise ValueError(op)

def route_to_prefix(instruction,m):
    """Stable extraction; all logical labels restored after this macro gate."""
    op,args=instruction
    support=sorted(args)
    labels=list(range(m));route=[]
    for dest,label in enumerate(support):
        pos=labels.index(label)
        while pos>dest:
            route.append(('SWAP',(pos-1,pos)))
            labels[pos-1],labels[pos]=labels[pos],labels[pos-1]
            pos-=1
    expected=sum(pos-j for j,pos in enumerate(support))
    assert len(route)==expected<=len(args)*(m-len(args))
    mapped=tuple(labels.index(label) for label in args)
    assert max(mapped)-min(mapped)<=2
    return route+[(op,mapped)]+list(reversed(route))

LOCAL=[]
for g in GATES:LOCAL.extend(route_to_prefix(g,len(NAMES)))

def prepare(values):
    bits=[0]*len(NAMES)
    for n,v in zip(['B','C','D','S','P','K','lam','monitor','commit','read_open'],values):
        bits[INDEX[n]]=v
    bits[INDEX['d_probe']]=1
    return bits

cases=0
for values in product((0,1),repeat=10):
    old=prepare(values);state=old.copy();local=old.copy()
    for g in GATES:apply(state,g)
    for g in LOCAL:apply(local,g)
    assert local==state
    B,C,D,S,P,K,lam,monitor,commit,read_open=values
    bhat=B*read_open
    revised=lam*(1-bhat) if commit else lam
    R=C^(B*S*D)
    T=C^(revised*(R^C))
    Tprime=T^(monitor*(T^C))
    expected={'R0':0,'R1':B*read_open,'bhat':bhat,'V':bhat,
              'omega':lam,'lam':revised,'R':R,'T':T,'Tprime':Tprime,
              'action':K*(Tprime^P),'valid':K}
    for n,v in expected.items():assert state[INDEX[n]]==v,(values,n)
    for n in ['candidate','install_delta','r_probe','u_probe','s_probe','U','diff','E','W']:
        assert state[INDEX[n]]==0,(values,n)
    for n in ['B','C','D','S','P','K','monitor','commit','read_open','c_probe','d_probe']:
        assert state[INDEX[n]]==old[INDEX[n]],(values,n)
    # Reversing the actual circuit recovers every initialized input bit.
    for g in reversed(GATES):apply(state,g)
    assert state==old
    cases+=1

# Generic support-routing check on all single gates and all input states,
# sizes up to 6, including every ordered target role.
routing_cases=0
for m in range(1,7):
    specs=[('X',(i,)) for i in range(m)]
    specs += [('CX',(a,t)) for a in range(m) for t in range(m) if a!=t]
    specs += [('CCX',(a,b,t)) for a in range(m) for b in range(a+1,m)
              for t in range(m) if t not in (a,b)]
    for g in specs:
        local=route_to_prefix(g,m)
        for word in product((0,1),repeat=m):
            direct=list(word);routed=list(word)
            apply(direct,g)
            for j in local:apply(routed,j)
            assert direct==routed
            routing_cases+=1

# Exact Gaussian-rational sqrt-X decomposition, no numerical tolerance.
Z=(Q(0),Q(0));ONE=(Q(1),Q(0))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
V=(((Q(1,2),Q(1,2)),(Q(1,2),Q(-1,2))),
   ((Q(1,2),Q(-1,2)),(Q(1,2),Q(1,2))))
VD=tuple(tuple((x,-y) for x,y in row) for row in V)
def apply_cv(vec,control,target,matrix):
    out=vec.copy()
    for i in range(8):
        if (i>>control)&1 and not ((i>>target)&1):
            j=i|(1<<target)
            out[i]=add(mul(matrix[0][0],vec[i]),mul(matrix[0][1],vec[j]))
            out[j]=add(mul(matrix[1][0],vec[i]),mul(matrix[1][1],vec[j]))
    return out
def apply_cx_vec(vec,a,b):
    out=[Z]*8
    for i,amp in enumerate(vec):out[i^((((i>>a)&1)<<b))]=amp
    return out
for basis in range(8):
    vec=[Z]*8;vec[basis]=ONE
    vec=apply_cv(vec,1,2,V)
    vec=apply_cx_vec(vec,0,1)
    vec=apply_cv(vec,1,2,VD)
    vec=apply_cx_vec(vec,0,1)
    vec=apply_cv(vec,0,2,V)
    expected=[Z]*8
    expected[basis ^ ((((basis>>0)&1)*((basis>>1)&1))<<2)]=ONE
    assert vec==expected

def expand_two_site(g):
    op,args=g
    if op!='CCX':return [g]
    a,b,t=args
    return [('CV',(b,t)),('CX',(a,b)),('CVD',(b,t)),
            ('CX',(a,b)),('CV',(a,t))]
pair_gates=[h for g in GATES for h in expand_two_site(g)]
def pair_route_cost(g):
    if g[0]=='X':return 1
    a,b=g[1]
    return 2*abs(a-b)-1
pair_route_count=sum(map(pair_route_cost,pair_gates))
def route_pair(g):
    op,args=g
    if op=='X':return [g]
    a,b=args
    swaps=[]
    if b>a:
        for pos in range(b,a+1,-1):swaps.append(('SWAP',(pos-1,pos)))
        near=a+1
    else:
        for pos in range(b,a-1):swaps.append(('SWAP',(pos,pos+1)))
        near=a-1
    result=swaps+[(op,(a,near))]+list(reversed(swaps))
    assert len(result)==pair_route_cost(g)
    assert all(len(aa)==1 or abs(aa[0]-aa[1])==1 for _,aa in result)
    return result
pair_local=[g for h in pair_gates for g in route_pair(h)]
assert len(pair_local)==pair_route_count
pair_before=[j for g in GATES[:FRESH_BOUNDARY]
             for h in expand_two_site(g) for j in route_pair(h)]
pair_after=[j for g in GATES[FRESH_BOUNDARY:]
            for h in expand_two_site(g) for j in route_pair(h)]
assert pair_before+pair_after==pair_local

def sparse_step(vec,g):
    op,args=g
    if op in ('CV','CVD'):
        c,t=args;matrix=V if op=='CV' else VD
        out={}
        for word,amp in vec.items():
            if not ((word>>c)&1):
                out[word]=add(out.get(word,Z),amp)
            else:
                old=(word>>t)&1
                for new in (0,1):
                    dest=(word&~(1<<t))|(new<<t)
                    part=mul(matrix[new][old],amp)
                    out[dest]=add(out.get(dest,Z),part)
        return {word:amp for word,amp in out.items() if amp!=Z}
    out={}
    for word,amp in vec.items():
        if op=='X':word^=1<<args[0]
        elif op=='CX':word^=((word>>args[0])&1)<<args[1]
        elif op=='SWAP':
            a,b=args
            if ((word>>a)^(word>>b))&1:word^=(1<<a)|(1<<b)
        else:raise ValueError(op)
        assert word not in out
        out[word]=amp
    return out

quantum_route_cases=0;max_terms=0
for values in product((0,1),repeat=10):
    bits=prepare(values)
    word=sum(v<<i for i,v in enumerate(bits))
    vec={word:ONE}
    for g in pair_local:
        vec=sparse_step(vec,g)
        max_terms=max(max_terms,len(vec))
    expected=bits.copy()
    for g in GATES:apply(expected,g)
    final=sum(v<<i for i,v in enumerate(expected))
    assert vec=={final:ONE}
    quantum_route_cases+=1

# Actual post-audit ingress. The five source bits exist in an external retained
# classical tape and are not copied into bank cells until this boundary.
# For each value, move its ready destination to site0, use the local boundary
# source->site0 CNOT (conditional X on the bank in a fixed classical source
# sector), and reverse the route. The source is preserved, not erased.
ingress_names=['C','D','S','P','K']
ingress_windows=sum(2*INDEX[n]+1 for n in ingress_names)
timed_cases=0
for values in product((0,1),repeat=10):
    full=prepare(values)
    ready=full.copy()
    for n in ingress_names:ready[INDEX[n]]=0
    word=sum(v<<i for i,v in enumerate(ready));vec={word:ONE}
    for g in pair_before:vec=sparse_step(vec,g)
    # All helpers are returned and all bank task destinations remain ready.
    for n in ingress_names:
        assert all(not ((w>>INDEX[n])&1) for w in vec)
        j=INDEX[n]
        route=[('SWAP',(p-1,p)) for p in range(j,0,-1)]
        for g in route:vec=sparse_step(vec,g)
        if full[j]:vec=sparse_step(vec,('X',(0,)))
        for g in reversed(route):vec=sparse_step(vec,g)
    for g in pair_after:vec=sparse_step(vec,g)
    expected=full.copy()
    for g in GATES:apply(expected,g)
    final=sum(v<<i for i,v in enumerate(expected))
    assert vec=={final:ONE}
    timed_cases+=1
counts=Counter(op for op,_ in GATES)
pair_counts=Counter(op for op,_ in pair_gates)
assert sum(counts.values())==55
assert counts=={'CCX':23,'CX':30,'X':2}
assert len(NAMES)==31
assert pair_route_count<=2+(len(pair_gates)-2)*(2*len(NAMES)-3)

# End-to-end ideal score gap at q=3/4, b=1, fair S,D and valid actuator.
q=Q(3,4)
old_correct=Q(0);new_correct=Q(0)
for s,d in product((0,1),repeat=2):
    old_correct += (q if not s*d else 1-q)/4
    new_correct += q/4
assert old_correct==Q(5,8) and new_correct==Q(3,4)
gap=new_correct-old_correct
assert gap==Q(1,8)
eta=Q(1,32)
assert gap-2*eta==Q(1,16)
# Useful practical-self information is not defined as correct by naming it P.
# Actual actuator mapping J is external; admitted preparation has P=J.
# Masking P to zero at fixed fair J loses that information.
masked_P_accuracy=Q(0)
wrong_P_accuracy=Q(0)
for J,noise in product((0,1),repeat=2):
    prob=(q if noise==0 else 1-q)/2
    # Set Y=0 without loss of binary symmetry; C=noise after revision.
    masked_P_accuracy += prob * (noise==J)
    wrong_P_accuracy += prob * ((noise^(1-J))==J)
assert masked_P_accuracy==Q(1,2)
assert wrong_P_accuracy==1-q

result={
  'register_count':len(NAMES),'register_names':NAMES,
  'logical_gate_count':len(GATES),'logical_gate_types':dict(counts),
  'three_site_prefix_routing_windows':len(LOCAL),
  'two_site_expanded_gate_count':len(pair_gates),
  'two_site_gate_types':dict(pair_counts),
  'nearest_neighbor_two_site_windows':pair_route_count,
  'post_audit_ingress_windows':ingress_windows,
  'full_timed_local_windows':pair_route_count+ingress_windows,
  'nearest_neighbor_crude_upper_bound':2+145*(2*31-3),
  'recognition_transaction_boolean_inputs_checked':cases,
  'generic_routing_cases_checked':routing_cases,
  'sqrt_X_Toffoli_basis_columns_checked_exactly':8,
  'full_nearest_neighbor_quantum_routes_checked_exactly':quantum_route_cases,
  'post_audit_ingress_quantum_routes_checked_exactly':timed_cases,
  'largest_sparse_superposition_terms':max_terms,
  'ideal_q':str(q),'old_accuracy':str(old_correct),'revised_accuracy':str(new_correct),
  'ideal_gap':str(gap),'gap_with_both_arm_TV_one_over_32':str(gap-2*eta),
  'masked_practical_record_P_at_fixed_fair_actual_mapping_J_accuracy':str(masked_P_accuracy),
  'wrong_practical_record_P_accuracy':str(wrong_P_accuracy),
  'scope':'Exact finite circuit and compilation checks; no primitive-device, consciousness, psychological-insight or global-energy certificate.',
  'status':'All assertions passed.'}
path=Path(__file__).with_suffix('.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
