#!/usr/bin/env python3
"""Exact extensions of the integrated recognition example.

Noisy paid diagnosis, a misspecified self-generator and its repair, and the
failure of common-carrier dependence to fix a prior-state outcome. Standard
library only. These checks do not establish human or metaphysical premises.
"""
from fractions import Fraction as Q
from itertools import product
from math import comb
from pathlib import Path
import json

def majority_error(n,delta):
    assert n>=1 and n%2==1
    return sum((Q(comb(n,k))*delta**k*(1-delta)**(n-k)
                for k in range(n//2+1,n+1)),Q(0))

def informed_gain(p,G,c,kappa,a0,a1):
    return p*(1-a1)*(G-c)-(1-p)*a0*c-kappa

# One paired contrast has error when exactly one return is corrupted.
noise_checks=0
for eta in [Q(0),Q(1,16),Q(1,8),Q(1,4),Q(1,2)]:
    delta=2*eta*(1-eta)
    for b in (0,1):
        error=Q(0)
        for c,n0,n1 in product((0,1),repeat=3):
            pr=Q(1,2)*(eta if n0 else 1-eta)*(eta if n1 else 1-eta)
            bhat=(c^n0)^((c^b)^n1)
            if bhat!=b:error+=pr
        assert error==delta
        noise_checks+=1

p=Q(1,2);q=Q(3,4);H=4;G=H*(q-Q(1,2));c=Q(1,4);kappa=Q(1,16)
blind=max(Q(0),p*G-c)
eta=Q(1,16);delta=2*eta*(1-eta)
perfect=informed_gain(p,G,c,kappa,0,0)-blind
noisy=informed_gain(p,G,c,kappa,delta,delta)-blind
assert perfect==Q(1,16)
assert delta==Q(15,128)
assert noisy==Q(1,256)
assert (perfect/(p*(G-c)+(1-p)*c))==Q(1,8)

# Test symmetric-error algebra across a grid, with each repeat's charged cost
# kept explicit rather than silently fixed while giving free extra probes.
formula_checks=0
for p,G,c,kappa,a in product([Q(1,4),Q(1,2),Q(3,4)],
                            [Q(1),Q(2)], [Q(1,4),Q(1,2)],
                            [Q(0),Q(1,16)],[Q(0),Q(1,8),Q(1,2)]):
    if not G>c:continue
    oracle=min(p*(G-c),(1-p)*c)-kappa
    predicted=oracle-a*(p*(G-c)+(1-p)*c)
    actual=informed_gain(p,G,c,kappa,a,a)-max(0,p*G-c)
    assert predicted==actual
    formula_checks+=1

# A two-probe fit of the restricted family cannot certify all mechanisms.
# Expanded actual family: R=C xor b*S*D xor h*C*S*D.
def gen(C,S,D,b,h=0):return C^(b*S*D)^(h*C*S*D)
model_failures=[]
for b,h in product((0,1),repeat=2):
    pair0=(gen(0,0,1,b,h),gen(0,1,1,b,h))
    bhat=pair0[0]^pair0[1]
    assert bhat==b
    if h:
        assert gen(1,1,1,b,h)!=gen(1,1,1,b,0)
        model_failures.append([b,h])
    pair1=(gen(1,0,1,b,h),gen(1,1,1,b,h))
    hhat=bhat^pair1[0]^pair1[1]
    assert hhat==h
    for C,S,D in product((0,1),repeat=3):
        assert gen(C,S,D,bhat,hhat)==gen(C,S,D,b,h)

# Common carrier: one prior state, two supported successors, action a(s_i)=i.
for prob in (Q(1,4),Q(1,2),Q(3,4)):
    successor={0:prob,1:1-prob}
    assert len([a for a,m in successor.items() if m>0])==2

result={
    'paired_noise_checks':noise_checks,
    'paired_error_eta_one_sixteenth':str(delta),
    'symmetric_error_formula_grid':formula_checks,
    'perfect_diagnosis_net_advantage':str(perfect),
    'noisy_diagnosis_net_advantage':str(noisy),
    'positive_advantage_requires_alpha_below':'1/8 (fixed stated cost ledger)',
    'misspecified_two_probe_examples':model_failures,
    'expanded_generator_fresh_predictions_checked':32,
    'common_carrier_open_rows_checked':3,
    'status':'All exact assertions passed; premises not empirically validated.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
