#!/usr/bin/env python3
"""Exact finite checks for the history-recognition connection.

No numerical sampling or floating-point entropy calculation is used. The source
measure describes uncertainty over 64 completed physical histories. It is not a
stochastic transition or an agent outside a history. Run with Python 3.10+.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

SOURCES = tuple(product((0, 1), (0, 1), range(4), (0, 1), (0, 1)))
# Source order is B, Y, R, S, J. R is a four-valued noise index, not a
# recommendation or probe return. Every source has probability 1/64.


def values(u):
    b, y, r, s, j = u
    n = int(r == 0)
    c = y ^ n
    return dict(B=b, Y=y, R=r, S=s, J=j, N=n, C=c, A=c ^ j,
                target_command=y ^ j,
                old_action=c ^ (b * s) ^ j,
                revised_action=c ^ j)


def history(u):
    """U -> (x_0,...,x_5), x_t=(latent physical source, controller registers).

    The controller readout at ready is constant. Source U is part of the
    physical environment throughout, not an initially readable register.
    Old register values survive in this finite logical trace. A physical
    reversible implementation additionally needs its stated history resources.
    """
    v = values(u)
    z = dict(phase="ready", lam=1)
    states = [(u, tuple(sorted(z.items())))]
    z.update(phase="probe0", probe0=0)
    states.append((u, tuple(sorted(z.items()))))
    z.update(phase="probe1", probe1=v["B"], bhat=v["B"])
    states.append((u, tuple(sorted(z.items()))))
    z.update(phase="install", omega=z["lam"], lam=1 - z["bhat"])
    states.append((u, tuple(sorted(z.items()))))
    z.update(phase="fresh", C=v["C"], S=v["S"], P=v["J"])
    states.append((u, tuple(sorted(z.items()))))
    # D=K=1 and k=0. B*lam is identically zero after selective installation.
    recommendation = v["C"] ^ (v["B"] * v["S"])
    assessment = v["C"] ^ (z["lam"] * (recommendation ^ v["C"]))
    z.update(phase="action", A=assessment ^ z["P"])
    assert z["A"] == v["A"]
    states.append((u, tuple(sorted(z.items()))))
    return tuple(states)


def access(u, stage):
    """Canonical atoms of cumulative accessible sigma fields."""
    v = values(u)
    if stage < 2:
        return ()
    if stage < 4:
        return (v["B"],)
    return (v["B"], v["C"], v["S"], v["J"])


def posterior_groups(target, stage):
    groups = defaultdict(Counter)
    for u in SOURCES:
        groups[access(u, stage)][values(u)[target]] += 1
    return groups


def bayes_accuracy(target, stage):
    groups = posterior_groups(target, stage)
    return Fraction(sum(max(counts.values()) for counts in groups.values()),
                    len(SOURCES))


def as_fraction(q):
    q = Fraction(q)
    return str(q.numerator) if q.denominator == 1 else f"{q.numerator}/{q.denominator}"


def exact_probability(predicate):
    return Fraction(sum(bool(predicate(values(u))) for u in SOURCES), len(SOURCES))


def main():
    assert len(SOURCES) == len(set(SOURCES)) == 64
    paths = tuple(history(u) for u in SOURCES)
    assert len(set(paths)) == 64
    assert len({p[0][1] for p in paths}) == 1  # constant ready readout
    assert all(len(p) == 6 for p in paths)
    assert all(dict(p[3][1])["omega"] == 1 for p in paths)
    assert all(dict(p[3][1])["lam"] == 1 - u[0]
               for u, p in zip(SOURCES, paths))

    # Verify each canonical sigma-field atom equals a cumulative readout fibre.
    for t in range(6):
        for u in SOURCES:
            cumulative_readout = tuple(state[1] for state in history(u)[:t + 1])
            fibre = {v for v in SOURCES if access(v, t) == access(u, t)}
            observed_fibre = {
                v for v in SOURCES
                if tuple(state[1] for state in history(v)[:t + 1]) == cumulative_readout
            }
            assert fibre == observed_fibre
    # Refinement of cumulative access, checked without invoking entropy.
    for t in range(5):
        for u in SOURCES:
            finer = {v for v in SOURCES if access(v, t + 1) == access(u, t + 1)}
            coarser = {v for v in SOURCES if access(v, t) == access(u, t)}
            assert finer <= coarser

    expected = {
        "B": [Fraction(1, 2)] * 2 + [Fraction(1)] * 4,
        "Y": [Fraction(1, 2)] * 4 + [Fraction(3, 4)] * 2,
        "A": [Fraction(1, 2)] * 4 + [Fraction(1)] * 2,
    }
    accuracy = {}
    for target, wanted in expected.items():
        got = [bayes_accuracy(target, t) for t in range(6)]
        assert got == wanted
        accuracy[target] = list(map(as_fraction, got))
        assert all(a <= b for a, b in zip(got, got[1:]))
    # Every fresh-readout cell still has three correct-cue source points and one
    # flipped-cue source point, even when the complete history has a definite Y.
    cue_posterior = []
    for key, counts in sorted(posterior_groups("Y", 4).items()):
        b, c, s, j = key
        assert sum(counts.values()) == 4
        assert counts[c] == 3 and counts[1 - c] == 1
        cue_posterior.append(dict(B=b, C=c, S=s, J=j, source_count=4,
                                  probability_Y_equals_C="3/4"))
    assert exact_probability(lambda v: v["N"] == 0) == Fraction(3, 4)
    old = exact_probability(lambda v: v["old_action"] == v["target_command"])
    revised = exact_probability(lambda v: v["revised_action"] == v["target_command"])
    assert old == Fraction(5, 8)
    assert revised == Fraction(3, 4)
    by_b = {}
    for b in (0, 1):
        subset = [values(u) for u in SOURCES if u[0] == b]
        q = Fraction(sum(v["old_action"] == v["target_command"] for v in subset),
                     len(subset))
        assert q == (Fraction(3, 4) if b == 0 else Fraction(1, 2))
        by_b[str(b)] = as_fraction(q)

    # Reversible memory toy: CNOT(X->M), then SWAP(M,Q).
    phase_space = tuple(product((0, 1), repeat=3))
    copy = lambda state: (state[0], state[1] ^ state[0], state[2])
    swap = lambda state: (state[0], state[2], state[1])
    assert len({copy(x) for x in phase_space}) == 8
    assert len({swap(x) for x in phase_space}) == 8
    memory_paths = tuple(((x, 0, 0), copy((x, 0, 0)), swap(copy((x, 0, 0))))
                         for x in (0, 1))
    assert memory_paths == (((0, 0, 0), (0, 0, 0), (0, 0, 0)),
                            ((1, 0, 0), (1, 1, 0), (1, 0, 1)))
    joint_supports = [Counter(p[t] for p in memory_paths) for t in range(3)]
    assert all(len(d) == 2 and sorted(d.values()) == [1, 1] for d in joint_supports)
    # Each joint distribution consists of two equiprobable distinct states, so
    # H(X,M,Q)=log2(2)=1 bit exactly at every stage. M is deterministic in X;
    # its support is two equiprobable values only at the middle stage.
    m_support_sizes = [len({p[t][1] for p in memory_paths}) for t in range(3)]
    assert m_support_sizes == [1, 2, 1]
    assert len({tuple(state[1] for state in p) for p in memory_paths}) == 2
    assert all(p[1][1] == p[0][0] for p in memory_paths)
    assert all(p[2][1] == 0 and p[2][2] == p[0][0] for p in memory_paths)

    result = dict(
        verification="all exact assertions passed",
        arithmetic="integer counting and fractions.Fraction; no floating point",
        source=dict(order=["B", "Y", "R", "S", "J"], count=64,
                    probability_each="1/64", noise_definition="N=1{R=0}",
                    q="3/4", D=1, K=1, compensation_k=0),
        histories=dict(count=64, stages=6, unique_complete_paths=64,
                       ready_readout_count=1,
                       explanation="source is fixed in physical environment, not initially readable"),
        cumulative_access=["constant", "constant", "B", "B", "B,C,S,J", "B,C,S,J"],
        bayes_optimal_prediction_accuracy=accuracy,
        bayes_optimal_prediction_error={k: [as_fraction(1 - Fraction(x)) for x in v]
                                       for k, v in accuracy.items()},
        fresh_readout_Y_posterior=cue_posterior,
        actual_policy_accuracy=dict(old_lambda_1=as_fraction(old),
                                    old_by_B=by_b,
                                    selective_lambda_1_minus_B=as_fraction(revised),
                                    gain=as_fraction(revised - old),
                                    averaging="fair B; D fixed 1"),
        reversible_memory=dict(
            state_order=["X", "M", "Q"], ready_M=0, ready_Q=0,
            paths=memory_paths, all_phase_space_maps_are_permutations=True,
            exact_joint_entropy_bits=[1, 1, 1],
            exact_current_M_mutual_information_with_X_bits=[0, 1, 0],
            cumulative_M_transcript_reveals_X=True,
            explanation="cumulative observations differ from current register access; ready boundary supplied"),
        limitations=[
            "probability is over complete comparison histories, not extra randomness during protocol",
            "Bayes-risk monotonicity requires nested cost-free access and an unchanged decision problem",
            "no pointwise posterior-entropy monotonicity asserted",
            "logical trace is not an additional reversible compilation or gate-count result",
            "physical stage order and predictive uncertainty do not establish phenomenal flow or A0-A3",
        ],
    )
    output = Path(__file__).with_suffix(".json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"verification": result["verification"], "histories": 64,
                      "old_policy_accuracy": as_fraction(old),
                      "revised_policy_accuracy": as_fraction(revised),
                      "report": str(output)}))


if __name__ == "__main__":
    main()
