# Einstein 1916: source–readout reconstruction — Release 1.0

**The Foundations of General Relativity: A Source–Readout Reconstruction of Einstein’s 1916 Theory**  
Jeremy Rodgers · Independent Researcher  
Website: https://everythingequation.com  
Intended publication DOI: https://doi.org/10.5281/zenodo.24064553  
Manuscript date: 8 November 2026 · No external funding

The DOI was supplied by the author as reserved. This archive does not assert that its repository record is published, and its production did not upload or modify a repository record.

## Read the paper

`manuscript/main.pdf` is the complete 48-page paper, including all essential proofs, source qualifications, original-equation correspondence and assumption/theorem registers. `audit/audit.pdf` is the separate nine-page mathematical and reproducibility audit. The manuscript is a conditional reconstruction of Einstein’s stated classical theory, not a claim of native-only physical law selection, a new gravitational theory or a quantum-gravity solution. Established coframe and connection methods are identified and cited.

The public package is self-contained for the supplied calculations. No ChatGPT conversation, private protocol, original research ZIP, proprietary input or downloaded astronomical dataset is needed to run the checks. All designed fixtures are encoded in the Python files.

## Reproduce the calculations

The executed environment was CPython 3.13.5, SymPy 1.14.0 and mpmath 1.3.0. Other Python versions were not tested for this release. From this directory, in a suitable virtual environment:

```sh
python -m pip install -r verification/requirements.txt
python verification/run_all.py --output replay --jobs 2
```

On Windows, use the installed Python command (`python` or `py`) as appropriate. The runner accepts one through eight concurrent suites and writes fresh results, logs and `replay/replay_receipt.json`. Its per-suite safety timeout can be changed with `--timeout`; an interrupted or timed-out suite is never recorded as a completed pass. It does not require network access after the packages are installed.

The six unchanged research suites contain **530 exact check groups**, including **88 expected-failure controls**. The separately written final audit contains **40 exact groups**, including **11 expected-failure controls**. Combined: **570 exact groups, all passing, including 99 controls**. There are also **eight separately reported numerical diagnostics**, all passing. An expected-failure control passes when the deliberately invalid claim is rejected or distinguished, not when an incorrect formula is accepted.

The numerical diagnostics use 65-digit mpmath arithmetic and test the strict inequalities `0 < error < analytic_bound` for declared dimensionless inputs. They are not interval-arithmetic certificates or reanalyses of astronomical observations. General assertions rely on the manuscript’s proofs, not finite test counts. Multiple components can occur within one group. None of the checks constitutes independent peer review or proof-assistant certification.

The runner compares complete result objects with `verification/expected/` and separately reports equality after environment-only metadata is removed. Full equality was obtained in the recorded release environment. A future metadata-only difference is reported explicitly and is not silently called byte equality. Retained executed objects are in `verification/results/`; logs are in `verification/logs/`. Do not overwrite these while conducting a new replay.

## Rebuild and edit the documents

The editable manuscript entry point is `manuscript/main.tex`, with section files in `manuscript/sections/` and references in `manuscript/references.bib`.

```sh
cd manuscript
bash build.sh
```

A conventional TeX Live or MiKTeX installation with pdfLaTeX and the named packages is required. The script uses BibTeX when available; the generated `main.bbl` is included as a fallback. The explicit sequence is pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX. Without BibTeX, retain the supplied `.bbl` and run pdfLaTeX twice. Update the bibliography with BibTeX after changing references. No font files are distributed.

The audit can be rebuilt with `cd audit && bash build.sh`; its bibliography is `../manuscript/references.bib`, and its generated `.bbl` is also included. Build logs from the inspected release are retained in `provenance/build_logs/`. PDF byte hashes may change on rebuilding because of timestamps or engine versions; compare the scientific content, resolved references and layout rather than expecting identical PDF bytes on a different system.

## Registers and provenance

- `registers/equation_correspondence.csv`: 101 entries covering Einstein’s 75 principal numbered equations and 26 lettered variants, with source printed pages, manuscript equation locations and exactness qualifications.
- `registers/assumptions.csv`: the inherited and additional mathematical hypotheses, and their scope.
- `registers/theorem_status.csv`: the 15 labelled recovery results, final numbering and proof/test status.
- `registers/source_qualifications.csv`: verified printed discrepancies and mathematical qualifications.
- `registers/resolved_manuscript_labels.json`: final LaTeX label/number/page map.
- `provenance/input_integrity.json`: hashes and manifest checks of the six original inputs, including their unchanged nested predecessors. The original nested research archives themselves are not redistributed here.
- `provenance/script_provenance.json`: public script hashes and their correspondence to the retained suites.
- `provenance/sources.json`: primary-source access and use scope.
- `provenance/clean_replay_receipt.json`: the completed clean-extraction replay.
- `provenance/layout_receipt.json`: actual build and visual-inspection record.
- `RELEASE_RECEIPT.json`: final release disposition and manifest binding.

Historical nonpassing controls are preserved as clearly labelled development material under `audit/development/`, not executed as release tests. Their existence and repairs are explained in the audit. A complete result-object replay establishes implementation continuity, not mathematical truth.

## Verify payload integrity

```sh
python verification/check_manifest.py
```

`SHA256SUMS.json` binds every immutable payload member. It excludes itself, the release receipt and the clean-replay receipt to avoid circular self-hashing; those scope exclusions are explicit in the manifest and receipt. Replay outputs, Python caches and new compilation intermediates are not part of the recorded immutable payload. The checker verifies every listed file and reports unlisted files separately rather than quietly extending the original manifest claim.

## Scope, redistribution and review

The archive contains authored manuscript/code/fixtures and provenance. Private protocols, third-party page images and PDFs, access credentials and font files are excluded. Historical sources are cited rather than bundled. The mathematical and computational work was AI-assisted; its status is an internal audit, not independent external review. No empirical confirmation or journal acceptance is asserted. Repository publication and licence selection remain actions for the author; see `RIGHTS_NOTICE.md`.
