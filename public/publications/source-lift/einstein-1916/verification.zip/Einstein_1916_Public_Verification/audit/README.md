# Final mathematical audit

Read `audit.pdf`. Editable source is `audit.tex`; its theorem table is `theorem_table.tex`. Build with `bash build.sh` from this directory. The bibliography uses `../manuscript/references.bib`; the generated `audit.bbl` is also supplied as a fallback.

The report distinguishes internal proof review, executable tests, source fidelity, source-hash continuity and clean-extraction reproducibility. It does not claim independent external peer review or proof-assistant certification. The `development/` directory preserves the two initially ineffective I05 negative controls and their actual failed run, clearly separated from the successful final suites.
