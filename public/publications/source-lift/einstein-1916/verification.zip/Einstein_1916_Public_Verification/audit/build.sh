#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error audit.tex
if command -v bibtex >/dev/null 2>&1; then bibtex audit
elif command -v bibtex.original >/dev/null 2>&1; then bibtex.original audit
elif command -v bibtex8 >/dev/null 2>&1; then bibtex8 audit
elif [[ ! -f audit.bbl ]]; then echo 'BibTeX unavailable and audit.bbl missing' >&2; exit 1
fi
pdflatex -interaction=nonstopmode -halt-on-error audit.tex
pdflatex -interaction=nonstopmode -halt-on-error audit.tex
