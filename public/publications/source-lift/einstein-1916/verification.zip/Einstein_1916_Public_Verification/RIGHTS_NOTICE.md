# Rights and publication notice

This release was prepared at the author's request for a public scholarly manuscript and verification package. It contains the new manuscript, its editable source, the authored verification code and fixtures, and audit/provenance records. It does not redistribute the private research protocols, original third-party article scans, publisher PDFs, or font files.

The source-code portions retained from the six research checkpoints were supplied as part of this project and are identified by hash. Their public inclusion was explicitly requested by the author. The source bibliography identifies the third-party literature used to verify and compare the reconstruction; those references are not a claim of ownership of that literature.

No repository-specific licence has been selected or asserted on the author's behalf. The author should apply the desired manuscript and software/data licences when depositing the release. The included reproduction instructions explain the intended scholarly use; this notice does not substitute for a chosen licence or legal advice.
