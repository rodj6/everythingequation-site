"""Matter readout and chart-tagged conservation operations for I04.
All routines retain raw field residuals. No Einstein equation is enforced here.
Indices use x^4 as time. Matrices with mixed indices have upper index as row.
"""
from itertools import product
import sympy as s
from core import IDX, ETA, sm, simp

def reverse(A,g,q):
    """Four-dimensional trace reversal, with the metric kept explicit."""
    return sm(A-g*s.trace(q*A)/2)

def covariant_divergence(T,g,q,C,dT,dq):
    mixed=q*T
    dm=[dq[a]*T+q*dT[a] for a in IDX]
    return sm(s.Matrix([sum(dm[a][a,mu] for a in IDX)
        +sum(s.trace(C[b])*mixed[b,mu] for b in IDX)
        -sum(C[a][b,mu]*mixed[a,b] for a,b in product(IDX,repeat=2)) for mu in IDX]))

def frame_divergence(Sigma,F,w,dSigma):
    mixed=ETA*Sigma
    D=[sm(ETA*dSigma[m]+w[m]*mixed-mixed*w[m]) for m in IDX]
    return sm(s.Matrix([sum(F[m,a]*D[m][a,b] for m,a in product(IDX,repeat=2)) for b in IDX]))

def potentials(G,x):
    """Original P and an antisymmetric potential K with the same divergence at nu=1."""
    q,g,C=G['q'],G['g'],G['C']
    dq=[q.diff(v) for v in x];dg=[g.diff(v) for v in x]
    v=s.Matrix([-sum(q[l,b]*C[l][a,b] for l,b in product(IDX,repeat=2)) for a in IDX])
    divq=s.Matrix([sum(dq[b][a,b] for b in IDX) for a in IDX])
    Z=[];P=[];L=[];K=[]
    for mu in IDX:
        zz=sm(s.Matrix(4,4,lambda a,sig:-sum(q[sig,b]*C[mu][a,b] for b in IDX)))
        ll=sm(s.Matrix(4,4,lambda a,sig:sum(q[a,l]*q[sig,b]*(dg[l][mu,b]-dg[b][mu,l])/2 for l,b in product(IDX,repeat=2))))
        pp=sm(s.Matrix(4,4,lambda a,sig:zz[a,sig]-(v[a]/2 if sig==mu else 0)))
        kk=sm(s.Matrix(4,4,lambda a,sig:ll[a,sig]+(divq[sig]/2 if a==mu else 0)-(divq[a]/2 if sig==mu else 0)))
        Z.append(zz);L.append(ll);P.append(pp);K.append(kk)
    return dict(Z=Z,L=L,P=P,K=K,v=v,divq=divq)

def field_quantities(G,Sigma,x,kappa):
    E,F,w,g,q,C= (G[k] for k in ('E','F','w','g','q','C'))
    T=sm(E.T*Sigma*E);mixed=sm(q*T);tr=simp(s.trace(mixed))
    Einstein=sm(G['Ric']-g*G['scalar']/2)
    Z=sm(G['Ric']-kappa*reverse(T,g,q))
    Kcov=sm(Einstein-kappa*T)
    U=sm(G['W']+kappa*reverse(T,g,q))
    t=G['tau']/kappa;total=sm(t+mixed)
    dT=[T.diff(v) for v in x];dq=[q.diff(v) for v in x]
    divT=covariant_divergence(T,g,q,C,dT,dq)
    frame=frame_divergence(Sigma,F,w,[Sigma.diff(v) for v in x])
    ordinary=sm(s.Matrix([sum(s.diff(mixed[a,mu],x[a]) for a in IDX) for mu in IDX]))
    divt=sm(s.Matrix([sum(s.diff(t[a,mu],x[a]) for a in IDX) for mu in IDX]))
    divtotal=sm(ordinary+divt)
    exchange=sm(s.Matrix([sum(T[m,n]*dq[mu][m,n]/2 for m,n in product(IDX,repeat=2)) for mu in IDX]))
    return dict(T=T,mixed=mixed,trace=tr,Einstein=Einstein,Z=Z,Kcov=Kcov,U=U,t=t,total=total,
        divT=divT,frame=frame,ordinary=ordinary,divt=divt,divtotal=divtotal,exchange=exchange)
