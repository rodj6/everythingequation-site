#!/usr/bin/env python3
"""Designed exact checks for Einstein 1916 source lift I03, not general proofs."""
from __future__ import annotations
import argparse,json,platform
from pathlib import Path
from itertools import product
import sympy as s
from core import N,ETA,IDX,simp,sm,source_connection,connection,curvature,ricci,kinetic,geometry,jet_first_variation,source_connection_variation,source_ricci
checks=[];fixtures={}
def flat(obj):
    if isinstance(obj,s.MatrixBase): return list(obj)
    if isinstance(obj,(tuple,list)): return [a for v in obj for a in flat(v)]
    return [s.sympify(obj)]
def zero(name,obj,note=''):
    vals=[simp(a) for a in flat(obj)];bad=[str(a) for a in vals if a!=0]
    checks.append(dict(name=name,kind='exact_identity',passed=not bad,scalar_entries=len(vals),nonzero_residuals=bad[:8],note=note))
    print(('PASS ' if not bad else 'FAIL ')+name,flush=True)
def truth(name,ok,note='',control=True):
    checks.append(dict(name=name,kind='expected_failure_control' if control else 'exact_identity',passed=bool(ok),note=note))
    print(('PASS ' if ok else 'FAIL ')+name,flush=True)

# Unrestricted first jet; independently differentiate unsimplified H=q CC.
E0=s.Matrix([[2,1,0,1],[0,3,1,0],[1,0,2,1],[0,1,0,2]])
g=E0.T*ETA*E0;q=g.inv()
dq=[s.Matrix(N,N,lambda i,j:s.Rational((i+j+1)*(a+2)+(i+1)*(j+1),7+a)) for a in IDX]
dg=[-g*d*g for d in dq];C=connection(q,dg);A,H,K,tau=kinetic(q,C)
basis=[];pairs=[]
for i in IDX:
    for j in range(i,N):
        B=s.zeros(N);B[i,j]=B[j,i]=1;basis.append(B);pairs.append((i,j))
value_diffs=[];derivative_diffs=[];value_grad=[];derivative_grad=[]
for (i,j),B in zip(pairs,basis):
    dH,_=jet_first_variation(g,q,dq,C,B,[s.zeros(N) for _ in IDX])
    pred=-sum(A[m,n]*B[m,n] for m,n in product(IDX,repeat=2))
    value_diffs.append(dH-pred);value_grad.append(dH)
    for a in IDX:
        dk=[s.zeros(N) for _ in IDX];dk[a]=B
        dH,_=jet_first_variation(g,q,dq,C,s.zeros(N),dk)
        pred=-sum(C[m][a,n]*B[m,n] for m,n in product(IDX,repeat=2))
        derivative_diffs.append(dH-pred);derivative_grad.append(dH)
zero('H_value_gradient_all_ten_symmetric_directions',value_diffs)
zero('H_derivative_gradient_all_forty_symmetric_jet_directions',derivative_diffs)
zero('H_quadratic_homogeneity',-sum(C[m][a,n]*dq[a][m,n] for m,n,a in product(IDX,repeat=3))-2*H)
truth('opposite_momentum_sign_is_rejected',any(v!=0 for v in derivative_grad),'Direct differentiation selects p=Gamma_E=-C, as in numbered (48).')
fixtures['printed_variation_sign']={'correct_momentum':'Gamma_E=-C','printed_unnumbered_line':'-Gamma_E delta(q_,alpha)','numbered_equation_48':'+Gamma_E','direct_derivative_agrees_with':'numbered_equation_48'}
i,j=pairs[1];truth('off_diagonal_factor_of_two_needed',value_grad[1]==-2*A[i,j] and A[i,j]!=0)
k=s.Matrix(N,N,lambda i,j:s.Rational((i+j+2)+(i+1)*(j+1),5))
dk=[s.Matrix(N,N,lambda i,j:s.Rational((i+j+1)*(a+1)-(i+1)*(j+1),3+a)) for a in IDX]
P=-E0*k*g/2;h=P.T*ETA*E0+E0.T*ETA*P
zero('inverse_metric_variation_coverage',-q*h*q-k)
dE=[-E0*dq[a]*g/2 for a in IDX]
P_der=[-(dE[a]*k*g+E0*dk[a]*g+E0*k*dg[a])/2 for a in IDX]
h_der=[P_der[a].T*ETA*E0+P.T*ETA*dE[a]+dE[a].T*ETA*P+E0.T*ETA*P_der[a] for a in IDX]
zero('inverse_metric_first_jet_variation_coverage',[-dq[a]*h*q-q*h_der[a]*q-q*h*dq[a]-dk[a] for a in IDX])
F,w,Csrc=source_connection(E0,dE)
zero('generic_source_connection_recovery',[Csrc[a]-C[a] for a in IDX])
direct,_=jet_first_variation(g,q,dq,C,k,dk)
zero('source_action_variation_chain',direct+sum(A[m,n]*k[m,n] for m,n in product(IDX,repeat=2))+sum(C[m][a,n]*dk[a][m,n] for m,n,a in product(IDX,repeat=3)))
# Source-only comparison scalar and its independently differentiated lift.
Acal=[sm((dE[a]+w[a]*E0)*F) for a in IDX]
Pa=[sm(sum((F[m,a]*Acal[m] for m in IDX),s.zeros(N))) for a in IDX]
Hz=simp(sum(ETA[a,a]*s.trace(Pa[a]*Pa[a]) for a in IDX))
zero('source_only_comparison_scalar_recovers_H',Hz-H)
dw=source_connection_variation(E0,dE,P,P_der);dF=-F*P*F
DA=[sm((P_der[a]+dw[a]*E0+w[a]*P)*F+(dE[a]+w[a]*E0)*dF) for a in IDX]
DP=[sm(sum((dF[m,a]*Acal[m]+F[m,a]*DA[m] for m in IDX),s.zeros(N))) for a in IDX]
DHsource=simp(sum(2*ETA[a,a]*s.trace(Pa[a]*DP[a]) for a in IDX))
zero('source_only_action_variation_recovers_coordinate_variation',DHsource-direct)
zero('energy_current_canonical_vs_quadratic',[2*tau[a,sig]+sum(dq[sig][m,n]*(-C[m][a,n]) for m,n in product(IDX,repeat=2))-(1 if a==sig else 0)*H for a,sig in product(IDX,repeat=2)])
zero('energy_trace_in_four_dimensions',s.trace(tau)-H)

# Unrestricted second jet, with both pair symmetries.
ddq=[[s.Matrix(N,N,lambda i,j:s.Rational((a+b+2)*(i+j+3)+(a+1)*(b+1)*(i+1)*(j+1),a+b+5)) for b in IDX] for a in IDX]
ddg=[[g*dq[a]*g*dq[b]*g+g*dq[b]*g*dq[a]*g-g*ddq[a][b]*g for b in IDX] for a in IDX]
dC=[]
for a in IDX:
    c1=connection(dq[a],dg);c2=connection(q,ddg[a]);dC.append([sm(u+v) for u,v in zip(c1,c2)])
R=[[sm(dC[m][n]-dC[n][m]+C[m]*C[n]-C[n]*C[m]) for n in IDX] for m in IDX]
Ric=ricci(R);W=sm(s.Matrix(N,N,lambda m,n:-sum(dC[a][m][a,n] for a in IDX)+A[m,n]))
c=[s.trace(v) for v in C]
Sh=sm(s.Matrix(N,N,lambda m,n:s.trace(dC[m][n])-sum(C[m][a,n]*c[a] for a in IDX)))
zero('raw_Euler_curvature_and_volume_residual_identity',W+Ric+Sh)
truth('raw_volume_correction_cannot_be_dropped',any(v!=0 for v in Sh))
dH=[];dK=[]
for a in IDX:
    hh,cc=jet_first_variation(g,q,dq,C,dq[a],ddq[a]);dH.append(hh)
    zero(f'second_jet_connection_direction_{a+1}',[cc[m]-dC[a][m] for m in IDX])
    dK.append(sm(sum((dq[a][m,n]*C[m]*C[n]+q[m,n]*(dC[a][m]*C[n]+C[m]*dC[a][n]) for m,n in product(IDX,repeat=2)),s.zeros(N))))
dtau=[sm(s.eye(N)*dH[a]/2-dK[a]) for a in IDX]
zero('off_shell_translation_current_identity',[-2*sum(dtau[a][a,sig] for a in IDX)-sum(W[m,n]*dq[sig][m,n] for m,n in product(IDX,repeat=2)) for sig in IDX])
D=sm(s.Matrix(N,N,lambda sig,mu:-sum(dq[a][sig,b]*C[mu][a,b]+q[sig,b]*dC[a][mu][a,b] for a,b in product(IDX,repeat=2))+tau[sig,mu]-(s.trace(tau)/2 if sig==mu else 0)))
zero('equation51_full_off_shell_residual',D-q*W.T)
EL=2*ETA*E0*q*W*q
zero('source_field_variation_covector_identity',sum(EL[a,m]*P[a,m] for a,m in product(IDX,repeat=2))+sum(W[m,n]*k[m,n] for m,n in product(IDX,repeat=2)))
L=s.zeros(N);L[0,3]=L[3,0]=1;Pv=L*E0
zero('vertical_frame_variation_no_metric_change',Pv.T*ETA*E0+E0.T*ETA*Pv)
zero('vertical_frame_variation_no_bulk_response',sum(EL[a,m]*Pv[a,m] for a,m in product(IDX,repeat=2)))

x,y,z,t=s.symbols('x y z t',real=True);coords=[x,y,z,t]
NN=s.Function('N',positive=True)(x)
G=geometry(s.diag(1,1,1,NN),coords)
zero('lapse_raw_H',G['H']-(s.diff(NN,x)/NN)**2)
zero('lapse_volume_correction',G['W']+G['Ric']+G['S'])
zero('lapse_covariant_first_derivative_action',G['Lc'])
zero('lapse_boundary_current',G['V']-s.Matrix([2*s.diff(NN,x),0,0,0]))
zero('lapse_curvature_density',G['volume']*G['scalar']-2*s.diff(NN,x,2))
zero('lapse_full_action_boundary_identity',G['volume']*G['scalar']-G['Lc']-sum(s.diff(G['V'][a],coords[a]) for a in IDX))
f=x*(1-x);boundary_variation=2*(s.diff(f,x).subs(x,1)-s.diff(f,x).subs(x,0))
zero('boundary_variation_explicit_value',boundary_variation+4)
truth('fixed_metric_does_not_kill_bare_curvature_boundary',f.subs(x,0)==0 and f.subs(x,1)==0 and boundary_variation!=0)
fixtures['boundary_control']={'interval':[0,1],'delta_N':str(f),'delta_N_endpoints':[0,0],'delta_curvature_action_per_unit_transverse_volume':str(boundary_variation),'delta_first_derivative_action':'0'}

# Full four-dimensional Dirichlet example, not only two faces of a slab.
Nvariation=s.prod(v*(1-v) for v in coords)
linear_density=2*sum(s.diff(Nvariation,v,2) for v in coords[:3])
full_boundary_response=linear_density
for v in coords: full_boundary_response=s.integrate(full_boundary_response,(v,0,1))
zero('full_boundary_dirichlet_variation_value',full_boundary_response+s.Rational(1,18))
truth('all_boundary_values_fixed_but_curvature_action_changes',all(Nvariation.subs(v,end)==0 for v in coords for end in [0,1]) and full_boundary_response!=0)
fixtures['full_boundary_control']={'background':'Minkowski','domain':'[0,1]^4','delta_N':str(Nvariation),'delta_N_on_every_face':'0','delta_curvature_action':str(full_boundary_response),'delta_first_derivative_action':'0 (quadratic first-derivative density at a constant background)'}

# Same flat geometry, determinant-one nonlinear coordinate transformation.
Xmap=s.Matrix([s.exp(x),y,z,t*s.exp(-x)]);J=Xmap.jacobian(coords)
Gflat=geometry(J,coords)
zero('flat_nonlinear_unit_volume',Gflat['volume']-1)
zero('flat_nonlinear_source_connection',Gflat['w'])
zero('flat_nonlinear_curvature',Gflat['R'])
zero('flat_nonlinear_vacuum_residual',Gflat['W'])
zero('flat_nonlinear_H',Gflat['H']+2*s.exp(-2*x))
zero('flat_nonlinear_energy',Gflat['tau']-s.diag(0,-s.exp(-2*x),-s.exp(-2*x),0))
truth('gravitational_energy_is_not_coordinate_tensor',any(v!=0 for v in Gflat['tau']),'Zero in Cartesian coordinates, nonzero in this determinant-one chart.')
zero('flat_nonlinear_energy_divergence',[sum(s.diff(Gflat['tau'][a,sig],coords[a]) for a in IDX) for sig in IDX])
zero('flat_nonlinear_boundary_identity',Gflat['volume']*Gflat['scalar']-Gflat['Lc']-sum(s.diff(Gflat['V'][a],coords[a]) for a in IDX))
u=s.symbols('u',real=True);XX=2+s.Rational(4,3)*u;TT=s.Rational(5,3)*u
curve=s.Matrix([s.log(XX),0,0,XX*TT]);velocity=curve.diff(u);acceleration=velocity.diff(u)
subs=dict(zip(coords,list(curve)));Cv=[m.subs(subs) for m in Gflat['C']]
zero('particle_motion_equation46_recovered',acceleration+sum((Cv[m]*velocity*velocity[m] for m in IDX),s.zeros(N,1)))
zero('particle_proper_time_normalization',(velocity.T*Gflat['g'].subs(subs)*velocity)[0]-1)
calibrated=sm(J.subs(subs)*velocity)
zero('parallel_calibrated_particle_tangent',calibrated.diff(u))
fixtures['non_tensor_control']={'coordinate_map':[str(a) for a in Xmap],'det_J':'1','curvature':'0','kappa_t_diagonal':[str(Gflat['tau'][i,i]) for i in IDX]}

p=s.symbols('p',positive=True);co=[x,y,z,p]
Evac=s.diag(p**s.Rational(1,3),p**s.Rational(1,3),p**(-s.Rational(1,6)),p**(-s.Rational(1,2)))
Gvac=geometry(Evac,co)
zero('nonflat_vacuum_volume',Gvac['volume']-1)
zero('nonflat_vacuum_Ricci',Gvac['Ric'])
zero('nonflat_vacuum_Euler',Gvac['W'])
zero('nonflat_vacuum_curvature_value',Gvac['R'][0][3][0,3]-1/(18*p**2))
truth('vacuum_does_not_mean_flat',Gvac['R'][0][3][0,3]!=0)
Ovac=curvature(Gvac['w'],co)
zero('nonflat_vacuum_source_curvature_readout',[Gvac['F']*Ovac[m][n]*Evac-Gvac['R'][m][n] for m,n in product(IDX,repeat=2)])
zero('nonflat_vacuum_translation_conservation',[sum(s.diff(Gvac['tau'][a,sig],co[a]) for a in IDX) for sig in IDX])
Dvac=s.Matrix(N,N,lambda sig,mu:-sum(s.diff(Gvac['q'][sig,b]*Gvac['C'][mu][a,b],co[a]) for a,b in product(IDX,repeat=2))+Gvac['tau'][sig,mu]-(s.trace(Gvac['tau'])/2 if sig==mu else 0))
zero('nonflat_vacuum_equation51',Dvac)
fixtures['nonflat_vacuum']={'calibration_diagonal':[str(Evac[i,i]) for i in IDX],'Ricci':'0','R^1_414':str(Gvac['R'][0][3][0,3]),'volume':'1'}

Et=s.diag(p**s.Rational(1,3),p**s.Rational(1,3),p**s.Rational(1,3),1/p)
Gt=geometry(Et,co)
zero('trace_control_volume',Gt['volume']-1)
zero('trace_control_Ricci_value',Gt['Ric']+Gt['g']/3)
zero('trace_control_scalar_value',Gt['scalar']+s.Rational(4,3))
zero('tracefree_variation_erases_nonzero_vacuum_residual',Gt['W']-s.trace(Gt['q']*Gt['W'])*Gt['g']/4)
truth('gauge_first_stationarity_does_not_imply_equation47',any(v!=0 for v in Gt['W']))
kfree=s.diag(1/Gt['g'][0,0],-1/Gt['g'][1,1],0,0)
zero('tracefree_probe_is_volume_preserving',s.trace(Gt['g']*kfree))
zero('tracefree_probe_misses_residual',s.trace(Gt['W']*kfree))
truth('restored_trace_probe_detects_residual',simp(s.trace(Gt['W']*Gt['q']))!=0)
zero('conservation_can_hold_without_vacuum',[sum(s.diff(Gt['tau'][a,sig],co[a]) for a in IDX) for sig in IDX])
truth('energy_conservation_alone_insufficient',any(v!=0 for v in Gt['W']))
B=-Gt['Ric'];traceB=s.trace(Gt['q']*B)
zero('printed_uniqueness_footnote_exception_lambda_minus_quarter',B-Gt['g']*traceB/4)
truth('exception_does_not_imply_B_zero',any(v!=0 for v in B))
fixtures['trace_loss_control']={'calibration_diagonal':[str(Et[i,i]) for i in IDX],'Ricci_over_g':'-1/3','scalar':'-4/3','vacuum_residual':'nonzero','traceless_vacuum_residual':'0','energy_divergence':'0','exceptional_lambda':'-1/4'}
Ot=curvature(Gt['w'],co);RicFrame=source_ricci(Et,Ot)
zero('source_curvature_contraction_recovers_nonzero_Ricci',Et.T*RicFrame*Et-Gt['Ric'])
zero('source_curvature_scalar_recovers_covariant_density',Gt['volume']*s.trace(ETA*RicFrame)-Gt['volume']*Gt['scalar'])
zero('trace_control_covariant_action_boundary_identity',Gt['volume']*Gt['scalar']-Gt['Lc']-sum(s.diff(Gt['V'][a],co[a]) for a in IDX))
g1=Gt['g'].subs(p,1);q1=Gt['q'].subs(p,1)
dq1=[Gt['q'].diff(v).subs(p,1) for v in co];dg1=[-g1*d*g1 for d in dq1];C1=connection(q1,dg1)
_,H1,_,_=kinetic(q1,C1)
dHH,dc1=jet_first_variation(g1,q1,dq1,C1,k,dk)
f1=-s.trace(g1*k)/2
df=[-(s.trace(dg1[a]*k)+s.trace(g1*dk[a]))/2 for a in IDX]
zero('volume_trace_variation_identity',[s.trace(dc1[a])-df[a] for a in IDX])
avec=[sum(q1[m,n]*C1[m][a,n] for m,n in product(IDX,repeat=2)) for a in IDX]
cbase=[s.trace(v) for v in C1]
Jbase=sum(q1[m,n]*C1[m][a,n]*cbase[a] for m,n,a in product(IDX,repeat=3))
dJ=sum((k[m,n]*C1[m][a,n]+q1[m,n]*dc1[m][a,n])*cbase[a]+q1[m,n]*C1[m][a,n]*s.trace(dc1[a]) for m,n,a in product(IDX,repeat=3))
dLc=f1*(H1-Jbase)+dHH-dJ
zero('covariant_vs_specialized_first_variation_defect',dLc-dHH-f1*H1+sum(avec[a]*df[a] for a in IDX))
truth('gauge_value_equality_not_unrestricted_variation_equality',simp(dLc-dHH)!=0)
boost=s.eye(N);boost[0,0]=s.cosh(x);boost[0,3]=s.sinh(x);boost[3,0]=s.sinh(x);boost[3,3]=s.cosh(x)
Ein=sm(boost*J);Fin=sm(Ein.inv());wp=[sm(-boost.diff(v)*boost.inv()) for v in coords]
Cp=[sm(Fin*(Ein.diff(coords[a])+wp[a]*Ein)) for a in IDX]
zero('internal_frame_change_connection_invariance',[Cp[a]-Gflat['C'][a] for a in IDX])
_,Hp,_,tp=kinetic(Gflat['q'],Cp)
zero('internal_frame_change_energy_invariance',tp-Gflat['tau'])
Z=s.Matrix(N,N,lambda i,j:s.Rational(i+j+1,3));tr=s.trace(q*Z);Zrev=Z-g*tr/2
zero('trace_reversal_involution',Zrev-g*s.trace(q*Zrev)/2-Z)
truth('tracefree_map_has_nonzero_kernel',g!=s.zeros(N) and sm(g-g*s.trace(q*g)/4)==s.zeros(N))
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results.json'))
args=parser.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True)
report=dict(checkpoint='E1916-I03-v1.0',environment={'python':platform.python_version(),'sympy':s.__version__},summary={'groups':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'expected_failure_controls':sum(c['kind']=='expected_failure_control' for c in checks)},checks=checks,fixtures=fixtures)
args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(report['summary']),flush=True)
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
