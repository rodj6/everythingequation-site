"""Exact calibration/comparison and coordinate operations, n=4.
Connection constructor is the structure-coefficient route proved in I02.
No field equation is imposed inside these constructors.
"""
from itertools import product
import sympy as s
N=4
ETA=s.diag(-1,-1,-1,1)
IDX=range(N)
def simp(x): return s.factor(s.simplify(x))
def sm(m): return m.applyfunc(simp)
def source_connection(E,dE):
    F=sm(E.inv())
    dtheta=[s.Matrix(N,N,lambda m,n:dE[m][a,n]-dE[n][a,m]) for a in IDX]
    c=[sm(-F.T*d*F) for d in dtheta]
    cl=[ETA[a,a]*c[a] for a in IDX]
    low=[[[simp((cl[k][a,b]-cl[a][b,k]-cl[b][k,a])/2) for k in IDX] for b in IDX] for a in IDX]
    w=[sm(s.Matrix(N,N,lambda a,b:ETA[a,a]*sum(low[a][b][k]*E[k,m] for k in IDX))) for m in IDX]
    C=[sm(F*(dE[m]+w[m]*E)) for m in IDX]
    return F,w,C

def connection(q,dg):
    return [sm(s.Matrix(N,N,lambda r,v:sum(q[r,l]*(dg[m][l,v]+dg[v][l,m]-dg[l][m,v]) for l in IDX)/2)) for m in IDX]

def curvature(C,x):
    return [[sm(C[n].diff(x[m])-C[m].diff(x[n])+C[m]*C[n]-C[n]*C[m]) for n in IDX] for m in IDX]

def ricci(R):
    return sm(s.Matrix(N,N,lambda sig,n:sum(R[r][n][r,sig] for r in IDX)))

def kinetic(q,C):
    A=sm(s.Matrix(N,N,lambda m,n:s.trace(C[m]*C[n])))
    H=simp(sum(q[m,n]*A[m,n] for m,n in product(IDX,repeat=2)))
    K=sm(sum((q[m,n]*C[m]*C[n] for m,n in product(IDX,repeat=2)),s.zeros(N)))
    # tau = kappa * t, with row=upper index, column=lower index.
    tau=sm(s.eye(N)*H/2-K)
    return A,H,K,tau

def geometry(E,x):
    dE=[E.diff(v) for v in x]
    F,w,C=source_connection(E,dE)
    g=sm(E.T*ETA*E);q=sm(g.inv())
    R=curvature(C,x);Ric=ricci(R)
    A,H,K,tau=kinetic(q,C)
    W=sm(s.Matrix(N,N,lambda m,n:-sum(s.diff(C[m][a,n],x[a]) for a in IDX)+A[m,n]))
    volume=simp(E.det()) # fixtures select positive determinant branch
    c=[simp(s.trace(C[m])) for m in IDX]
    Sh=sm(s.Matrix(N,N,lambda m,n:s.diff(c[n],x[m])-sum(C[m][a,n]*c[a] for a in IDX)))
    scalar=simp(s.trace(q*Ric))
    V=s.Matrix([simp(volume*(sum(q[m,n]*C[m][a,n] for m,n in product(IDX,repeat=2))-sum(q[a,m]*c[m] for m in IDX))) for a in IDX])
    trace_term=simp(sum(q[m,n]*C[m][a,n]*c[a] for m,n,a in product(IDX,repeat=3)))
    Lc=simp(volume*(H-trace_term))
    return dict(E=E,F=F,w=w,C=C,g=g,q=q,R=R,Ric=Ric,A=A,H=H,K=K,tau=tau,W=W,volume=volume,c=c,S=Sh,scalar=scalar,V=V,Lc=Lc)

def jet_first_variation(g,q,dq,C,k,dk):
    """Differentiate the unsimplified H=q CC, not its claimed gradient formula."""
    dg=[-g*d*g for d in dq]
    hg=-g*k*g
    hdg=[-hg*dq[m]*g-g*dk[m]*g-g*dq[m]*hg for m in IDX]
    one=connection(k,dg);two=connection(q,hdg)
    dC=[sm(a+b) for a,b in zip(one,two)]
    dH=simp(sum(k[m,n]*s.trace(C[m]*C[n])+q[m,n]*s.trace(dC[m]*C[n]+C[m]*dC[n]) for m,n in product(IDX,repeat=2)))
    return dH,dC

def source_connection_variation(E,dE,P,dP):
    """Differentiate the coframe structure formula itself at an exact first jet."""
    F=E.inv();dF=-F*P*F
    D=[s.Matrix(N,N,lambda m,n:dE[m][a,n]-dE[n][a,m]) for a in IDX]
    DD=[s.Matrix(N,N,lambda m,n:dP[m][a,n]-dP[n][a,m]) for a in IDX]
    c=[sm(-F.T*D[a]*F) for a in IDX]
    dc=[sm(-dF.T*D[a]*F-F.T*DD[a]*F-F.T*D[a]*dF) for a in IDX]
    cl=[ETA[a,a]*c[a] for a in IDX];dcl=[ETA[a,a]*dc[a] for a in IDX]
    low=[[[simp((cl[k][a,b]-cl[a][b,k]-cl[b][k,a])/2) for k in IDX] for b in IDX] for a in IDX]
    dlow=[[[simp((dcl[k][a,b]-dcl[a][b,k]-dcl[b][k,a])/2) for k in IDX] for b in IDX] for a in IDX]
    dw=[sm(s.Matrix(N,N,lambda a,b:ETA[a,a]*sum(dlow[a][b][k]*E[k,m]+low[a][b][k]*P[k,m] for k in IDX))) for m in IDX]
    return dw

def source_ricci(E,O):
    F=sm(E.inv())
    return sm(s.Matrix(N,N,lambda a,b:sum(F[m,c]*F[n,b]*O[m][n][c,a] for c,m,n in product(IDX,repeat=3))))
