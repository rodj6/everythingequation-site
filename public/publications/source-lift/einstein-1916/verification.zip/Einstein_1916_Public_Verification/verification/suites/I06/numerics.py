#!/usr/bin/env python3
"""High-precision designed diagnostics, separate from exact symbolic checks.
Analytic remainder inequalities are proved in REPORT.md. These finite tests
are not interval certificates, astronomical data or independent review.
"""
import argparse,json,platform
from pathlib import Path
import mpmath as m
m.mp.dps=65
checks=[]
def strn(x):return m.nstr(x,55)
for ds,es in [('0.0001','0.2'),('0.0001','0.6'),('0.001','0.4'),('0.001','0.8'),('0.01','0.6')]:
 d,e=m.mpf(ds),m.mpf(es);q=d*(3+e)
 exact=2*m.quad(lambda ch:1/m.sqrt(1-d*(3+e*m.cos(ch))),[0,m.pi])-2*m.pi
 leading=3*m.pi*d
 bound=3*m.pi*d*d*(9+e*e/2)/(4*(1-q)**m.mpf('2.5'))
 err=exact-leading
 checks.append({'name':'apsidal_'+ds+'_'+es,'kind':'numerical_diagnostic','delta':ds,'eccentricity':es,'exact_integral':strn(exact),'leading':strn(leading),'error':strn(err),'analytic_bound':strn(bound),'error_bound_ratio':strn(err/bound),'passed':bool(0<err<bound)})
for ds in ['0.0001','0.001','0.01']:
 d=m.mpf(ds)
 def qopt(th):
  u=m.sin(th);return u+1/(1+u)
 exact=2*m.quad(lambda th:1/m.sqrt(1-d*qopt(th)),[0,m.pi/2])-m.pi
 leading=2*d*m.sqrt(1-d) # 2 alpha/b, with d=alpha/r_min
 bound=27*m.pi*d*d/(32*(1-3*d/2)**m.mpf('2.5'))+2*d*d/(1+m.sqrt(1-d))
 err=exact-leading
 checks.append({'name':'bending_'+ds,'kind':'numerical_diagnostic','alpha_over_rmin':ds,'exact_integral':strn(exact),'leading_2alpha_over_b':strn(leading),'error':strn(err),'analytic_bound':strn(bound),'error_bound_ratio':strn(err/bound),'passed':bool(0<err<bound)})
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_name('numerical_results.json'));a=parser.parse_args()
result={'checkpoint':'E1916-I06-v1.0','environment':{'python':platform.python_version(),'mpmath':m.__version__,'decimal_digits':m.mp.dps},'summary':{'diagnostics':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'checks':checks,'scope':'Designed dimensionless convergence checks. Analytic proofs are separate; no measured astronomical data.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary']))
for v in checks:print(v['name'],'error/bound =',v['error_bound_ratio'])
raise SystemExit(0 if all(v['passed'] for v in checks) else 1)
