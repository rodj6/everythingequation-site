"""Part D operations; no field equations are imposed by the constructors.
Signature (-,-,-,+), time in slot 4. Maxwell divergence uses SECOND index.
Einstein's field convention is F_{mu nu}=partial_nu phi_mu-partial_mu phi_nu.
"""
from itertools import product
import sympy as s
from core import IDX,ETA,sm,simp
from matter import covariant_divergence,frame_divergence

def fluid_stress(v,p,rho):
    low=ETA*v
    return sm(-p*ETA+rho*low*low.T)

def fluid_differential(v,p,rho,dv,dp,drho,Finv,w):
    low=ETA*v
    Sig=fluid_stress(v,p,rho)
    dSig=[sm(-dp[m]*ETA+drho[m]*low*low.T+rho*((ETA*dv[m])*low.T+low*(ETA*dv[m]).T)) for m in IDX]
    div=frame_divergence(Sig,Finv,w,dSig)
    dvc=[sm(dv[m]+w[m]*v) for m in IDX]
    gradp=s.Matrix([sum(Finv[m,b]*dp[m] for m in IDX) for b in IDX])
    gradr=s.Matrix([sum(Finv[m,b]*drho[m] for m in IDX) for b in IDX])
    theta=simp(sum(Finv[m,a]*dvc[m][a] for m,a in product(IDX,repeat=2)))
    acc=sm(ETA*sum((sum(v[a]*Finv[m,a] for a in IDX)*dvc[m] for m in IDX),s.zeros(4,1)))
    energy=simp((v.T*(gradr-gradp))[0]+rho*theta)
    proj=s.eye(4)-low*v.T
    euler=sm(rho*acc-proj*gradp)
    return dict(Sigma=Sig,dSigma=dSig,div=div,theta=theta,acc=acc,energy=energy,euler=euler,gradp=gradp,gradr=gradr,normalization=simp((v.T*ETA*v)[0]-1))

def field_from_potential(alpha,dalpha,Finv,w):
    D=[sm(dalpha[m]-w[m].T*alpha) for m in IDX]
    K=sm(s.Matrix(4,4,lambda a,b:sum(Finv[m,b]*D[m][a] for m in IDX)))
    return sm(K-K.T)

def coordinate_field(phi,x):
    return s.Matrix(4,4,lambda m,n:s.diff(phi[m],x[n])-s.diff(phi[n],x[m]))

def em_stress(f):
    up=ETA*f*ETA
    inv=simp(sum(f[a,b]*up[a,b] for a,b in product(IDX,repeat=2)))
    return sm(-f*ETA*f.T+ETA*inv/4),inv

def em_stress_derivative(f,df):
    up=ETA*f*ETA
    dinv=2*sum(df[a,b]*up[a,b] for a,b in product(IDX,repeat=2))
    return sm(-df*ETA*f.T-f*ETA*df.T+ETA*dinv/4)

def coordinate_em_stress(F,g,q):
    up=sm(q*F*q)
    inv=simp(sum(F[a,b]*up[a,b] for a,b in product(IDX,repeat=2)))
    return sm(-F*q*F.T+g*inv/4),up,inv

def field_ops_frame(f,df,j,Finv,w):
    Dc=[sm(df[m]-w[m].T*f-f*w[m]) for m in IDX]
    up=ETA*f*ETA
    Du=[sm(ETA*df[m]*ETA+w[m]*up+up*w[m].T) for m in IDX]
    hom=[[[simp(sum(Finv[m,a]*Dc[m][b,c]+Finv[m,b]*Dc[m][c,a]+Finv[m,c]*Dc[m][a,b] for m in IDX)) for c in IDX] for b in IDX] for a in IDX]
    mx=sm(s.Matrix([sum(Finv[m,b]*Du[m][a,b] for m,b in product(IDX,repeat=2))-j[a] for a in IDX]))
    Sig,I=em_stress(f);dSig=[em_stress_derivative(f,d) for d in df]
    div=frame_divergence(Sig,Finv,w,dSig)
    xi=sm(f*j)
    correction=sm(f*mx+s.Matrix([sum(up[a,b]*hom[c][a][b]/2 for a,b in product(IDX,repeat=2)) for c in IDX]))
    return dict(hom=hom,maxwell=mx,Sigma=Sig,dSigma=dSig,invariant=I,div=div,force=xi,defect=correction)

def field_ops_coord(F,dF,J,g,q,dg,dq,C):
    T,up,I=coordinate_em_stress(F,g,q)
    dup=[sm(dq[m]*F*q+q*dF[m]*q+q*F*dq[m]) for m in IDX]
    hom=[[[simp(dF[a][b,c]+dF[b][c,a]+dF[c][a,b]) for c in IDX] for b in IDX] for a in IDX]
    mx=sm(s.Matrix([sum(dup[n][m,n] for n in IDX)+sum(C[n][m,a]*up[a,n]+C[n][n,a]*up[m,a] for n,a in product(IDX,repeat=2))-J[m] for m in IDX]))
    dI=[simp(sum(dF[m][a,b]*up[a,b]+F[a,b]*dup[m][a,b] for a,b in product(IDX,repeat=2))) for m in IDX]
    dT=[sm(-dF[m]*q*F.T-F*dq[m]*F.T-F*q*dF[m].T+dg[m]*I/4+g*dI[m]/4) for m in IDX]
    div=covariant_divergence(T,g,q,C,dT,dq)
    return dict(T=T,up=up,invariant=I,hom=hom,maxwell=mx,dT=dT,div=div,force=sm(F*J))
