#!/usr/bin/env python3
"""Exact designed checks for the Part E source lift.
No expected value is fitted to numerical output. Symbolic checks do not replace proofs.
"""
import argparse,json,platform,traceback
from pathlib import Path
from itertools import product
import sympy as s
from core import ETA,IDX,simp,sm,source_connection,source_connection_variation,connection,curvature,ricci
checks=[];fixtures={}
def flat(v):
    if isinstance(v,s.MatrixBase):return list(v)
    if isinstance(v,(tuple,list)):return [a for b in v for a in flat(b)]
    return [v]
def zero(name,v):
    vals=[simp(x) for x in flat(v)];bad=[str(x) for x in vals if x!=0]
    checks.append({'name':name,'kind':'exact_identity','components':len(vals),'passed':not bad,'nonzero':bad[:8]})
    print(('PASS ' if not bad else 'FAIL ')+name,flush=True)
def control(name,witness):
    vals=[simp(x) for x in flat(witness)];nz=[str(x) for x in vals if x!=0]
    checks.append({'name':name,'kind':'expected_failure_control','passed':bool(nz),'nonzero_witness':nz[:8]})
    print(('PASS ' if nz else 'FAIL ')+name,flush=True)
def lin_connection(h,x):return connection(ETA,[h.diff(z) for z in x])
def lin_curvature(C,x):return [[sm(C[n].diff(x[m])-C[m].diff(x[n])) for n in IDX] for m in IDX]
def cotime(C,v):
    w=s.Matrix(list(v)+[1]);q=s.Matrix([sum(C[m][i,n]*w[m]*w[n] for m,n in product(IDX,repeat=2)) for i in IDX])
    return sm(-q[:3,0]+v*q[3])
def main():
    x,y,z,t=s.symbols('x y z t',real=True);co=[x,y,z,t]
    al,kap,Mass,K,c,R0,rho,bimpact=s.symbols('alpha kappa M K c R0 rho b',positive=True)
    ep=s.symbols('epsilon',real=True)
    # Generic flat-background first response: source construction and metric construction.
    E=s.eye(4);H=s.Matrix(4,4,lambda a,b:s.Rational(((a+1)*(b+3))%11-5,7))
    dH=[s.Matrix(4,4,lambda a,b:s.Rational(((m+2)*(a+3)+(b+1)**2)%13-6,5)) for m in IDX]
    h=H.T*ETA+ETA*H;dh=[d.T*ETA+ETA*d for d in dH]
    dw=source_connection_variation(E,[s.zeros(4) for _ in IDX],H,dH)
    dC=[sm(dH[m]+dw[m]) for m in IDX]
    Clinear=connection(ETA,dh)
    zero('linear_source_comparison_recovers_linear_metric_connection',[dC[m]-Clinear[m] for m in IDX])
    zero('linear_metric_readout',s.diff((E+ep*H).T*ETA*(E+ep*H),ep).subs(ep,0)-h)
    control('zeroth_order_limit_loses_perturbation',h)
    # Exact coordinate-time reparameterization at a dense non-diagonal jet.
    E=s.Matrix([[2,1,0,0],[0,1,1,0],[0,0,3,1],[1,0,0,2]])
    F,w,C=source_connection(E,dH)
    v=s.Matrix([s.Rational(1,7),s.Rational(-1,9),s.Rational(2,11)])
    wv=s.Matrix(list(v)+[1]);acc=cotime(C,v);dv=s.Matrix(list(acc)+[0])
    c4=sum(C[m][3,n]*wv[m]*wv[n] for m,n in product(IDX,repeat=2))
    Dframe=sum((wv[m]*(dH[m]+w[m]*E)*wv for m in IDX),s.zeros(4,1))+E*dv
    zero('source_geodesic_coordinate_time_reparameterization',Dframe-c4*E*wv)
    control('treating_coordinate_time_as_affine_fails',sum((wv[m]*(dH[m]+w[m]*E)*wv for m in IDX),s.zeros(4,1))+E*dv)
    # A general quadratic perturbation retains all time-derivative terms in Ric_44.
    h=s.Matrix(4,4,lambda i,j:sum(s.Rational(((i+j+2)*(m+1)+(i+1)*(j+1))%7-3,5)*co[m]**2 for m in IDX))
    C1=lin_connection(h,co);Ric1=ricci(lin_curvature(C1,co))
    rhs=sum(s.diff(h[3,3],co[i],2) for i in range(3))/2-sum(s.diff(h[i,3],co[i],t) for i in range(3))+sum(s.diff(h[i,i],t,2) for i in range(3))/2
    zero('complete_linear_Ricci44_with_time_terms',Ric1[3,3]-rhs)
    control('quasistatic_reduction_requires_time_derivative_control',Ric1[3,3]-sum(s.diff(h[3,3],co[i],2) for i in range(3))/2)
    hs=h.subs(t,0);Cs=lin_connection(hs,co)
    zero('static_slow_motion_acceleration',cotime(Cs,s.zeros(3,1))+s.Matrix([s.diff(hs[3,3],co[i])/2 for i in range(3)]))
    control('static_fast_motion_contains_extra_terms',cotime(Cs,v)+s.Matrix([s.diff(hs[3,3],co[i])/2 for i in range(3)]))
    # Matter approximation and the trace-reversed factor 1/2.
    TT=s.diag(0,0,0,rho);tr=s.trace(ETA*TT)
    zero('slow_pressureless_trace_reversal_44',(TT-ETA*tr/2)[3,3]-rho/2)
    zero('Poisson_recovery_from_Ricci44',kap*rho/2*2-kap*rho)
    pr=s.symbols('p',real=True);Tf=s.diag(pr,pr,pr,rho-pr)
    control('nonnegligible_pressure_cannot_be_dropped',(Tf-ETA*s.trace(ETA*Tf)/2)[3,3]-rho/2)
    # Green/flux operation and normalizer, original equations (67)-(69).
    rr=s.symbols('r',positive=True)
    phi=-kap*Mass/(8*s.pi*rr);a_correct=kap*Mass/(4*s.pi);a_print=kap*Mass/(8*s.pi)
    zero('point_potential_radial_flux',4*s.pi*rr**2*s.diff(phi,rr)-kap*Mass/2)
    zero('metric_potential_mass_matching',(1-a_correct/rr)-(1+2*phi))
    control('printed_70a_fails_preceding_Poisson_normalization',(1-a_print/rr)-(1+2*phi))
    zero('Newtonian_kappa_normalization',(kap/8/s.pi-K/c**2).subs(kap,8*s.pi*K/c**2))
    zero('energy_density_unit_conversion',(8*s.pi*K/c**2)/c**2-8*s.pi*K/c**4)
    zero('central_alpha_normalization',a_correct.subs(kap,8*s.pi*K/c**2)-2*K*Mass/c**2)
    pin=kap*rho*(rr**2-3*R0**2)/12;pout=-kap*rho*R0**3/(6*rr)
    zero('uniform_ball_interior_Poisson',s.diff(rr**2*s.diff(pin,rr),rr)/rr**2-kap*rho/2)
    zero('uniform_ball_exterior_harmonic',s.diff(rr**2*s.diff(pout,rr),rr)/rr**2)
    zero('uniform_ball_potential_boundary_join',pin.subs(rr,R0)-pout.subs(rr,R0))
    zero('uniform_ball_force_boundary_join',s.diff(pin,rr).subs(rr,R0)-s.diff(pout,rr).subs(rr,R0))
    zero('uniform_ball_mass_normalization',pout-phi.subs(Mass,4*s.pi*rho*R0**3/3))
    # Weak amplitude alone does not control curvature derivatives.
    eps=s.symbols('eps',positive=True);hf=eps**2*s.sin(x/eps)
    zero('high_frequency_second_derivative',s.diff(hf,x,2)+s.sin(x/eps))
    control('small_amplitude_does_not_force_small_second_derivative',s.diff(hf,x,2).subs(x,s.pi*eps/2))
    # The original full first-order central metric, not just its temporal component.
    rad=s.sqrt(x*x+y*y+z*z);X=s.Matrix([x,y,z]);P=X*X.T/rad**2
    h=s.zeros(4);h[:3,:3]=-al/rad*P;h[3,3]=-al/rad
    H=s.zeros(4);H[:3,:3]=al/(2*rad)*P;H[3,3]=-al/(2*rad)
    zero('original_70_first_coframe_coefficient',H.T*ETA+ETA*H-h)
    zero('original_70_linear_unit_volume',s.trace(ETA*h))
    C1=lin_connection(h,co);Rc1=ricci(lin_curvature(C1,co))
    zero('original_70_full_linear_vacuum',Rc1)
    zero('original_70_Newtonian_acceleration',cotime(C1,s.zeros(3,1))+al*X/(2*rad**3))
    htime=s.zeros(4);htime[3,3]=-al/rad
    Ct=lin_connection(htime,co)
    control('temporal_only_metric_not_full_vacuum',ricci(lin_curvature(Ct,co)))
    # Spherical raw source geometry, no vacuum solution inserted into its constructor.
    th,ph=s.symbols('theta phi',real=True);sco=[rr,th,ph,t]
    aa=s.Function('a')(rr);bb=s.Function('b')(rr)
    Er=s.diag(bb,rr,rr*s.sin(th),aa)
    Fr,wr,Cr=source_connection(Er,[Er.diff(vv) for vv in sco])
    gr=Er.T*ETA*Er;qr=gr.inv();Rr=curvature(Cr,sco);Ricr=ricci(Rr)
    Cd=connection(qr,[gr.diff(vv) for vv in sco])
    zero('raw_spherical_source_and_metric_connections',[Cr[m]-Cd[m] for m in IDX])
    zero('raw_spherical_Ricci_offdiagonal',[Ricr[i,j] for i in IDX for j in IDX if i!=j])
    zero('raw_spherical_angular_relation',Ricr[2,2]-s.sin(th)**2*Ricr[1,1])
    combo=Ricr[3,3]/aa**2+Ricr[0,0]/bb**2
    zero('vacuum_product_equation',combo-2*s.diff(aa*bb,rr)/(rr*aa*bb**3))
    ang=simp(Ricr[1,1].subs(bb,1/aa).doit())
    zero('vacuum_radial_ODE',ang-(1-aa**2-rr*s.diff(aa**2,rr)))
    A=1-al/rr
    def exact(expr):return simp(expr.subs(bb,1/aa).doit().subs(aa,s.sqrt(A)).doit())
    Re=Ricr.applyfunc(exact)
    zero('derived_exterior_vacuum_all_components',Re)
    Ce=[m.applyfunc(exact) for m in Cr];we=[m.applyfunc(exact) for m in wr]
    Ee=s.diag(1/s.sqrt(A),rr,rr*s.sin(th),s.sqrt(A));ge=Ee.T*ETA*Ee
    zero('derived_exterior_metric_readout',ge-s.diag(-1/A,-rr**2,-rr**2*s.sin(th)**2,A))
    O=curvature(we,sco);RC=curvature(Ce,sco)
    zero('exterior_source_curvature_intertwining',[Ee.inv()*O[i][j]*Ee-RC[i][j] for i,j in product(IDX,repeat=2)])
    control('vacuum_exterior_curvature_not_zero',RC)
    zero('spherical_volume_is_not_Cartesian_volume',Ee.det()-rr**2*s.sin(th))
    control('imposing_unit_volume_in_ordinary_spherical_chart_fails',Ee.det()-1)
    # Cartesian radial frame factorization is algebraic for any unit direction.
    nn=s.Matrix([s.Rational(2,7),s.Rational(3,7),s.Rational(6,7)]);PP=nn*nn.T
    az=s.symbols('az',positive=True)
    Ec=s.eye(4);Ec[:3,:3]=s.eye(3)+(1/az-1)*PP;Ec[3,3]=az
    zero('Cartesian_radial_projector',PP*PP-PP)
    zero('Cartesian_exact_unit_volume',Ec.det()-1)
    zero('Cartesian_exact_metric',(Ec.T*ETA*Ec)[:3,:3]+s.eye(3)+(1/az**2-1)*PP)
    zero('Cartesian_radial_length',((Ec.T*ETA*Ec)[:3,:3]*nn)+nn/az**2)
    # First-order truncation and its unlicensed exact extension.
    gw=s.diag(-(1+al/rr),-rr**2,-rr**2*s.sin(th)**2,1-al/rr)
    Cw=connection(gw.inv(),[gw.diff(vv) for vv in sco]);Ricw=ricci(curvature(Cw,sco))
    zero('weak_metric_vacuum_at_order_one',Ricw.diff(al).subs(al,0))
    control('literal_weak_metric_is_not_an_exact_vacuum',Ricw)
    zero('weak_Cartesian_determinant_defect',-(1+al/rr)*(1-al/rr)+1-al**2/rr**2)
    zero('exact_to_original_metric_first_order',(ge-gw).diff(al).subs(al,0))
    # Schwarzschild original radius mapping retained rather than silently equated.
    r0=s.symbols('r0',positive=True);R=(r0**3+al**3)**s.Rational(1,3)
    zero('cited_radial_map_volume',R**2*s.diff(R,r0)-r0**2)
    zero('cited_radius_agrees_through_second_order',[s.diff(R-r0,al,k).subs(al,0) for k in [0,1,2]])
    # Rods, clocks, calibration-frame invariance and static frequency transfer.
    zero('radial_unit_rod_first_order',s.diff(s.sqrt(A),al).subs(al,0)+1/(2*rr))
    zero('original_weak_radial_unit_rod_first_order',s.diff((1+al/rr)**s.Rational(-1,2),al).subs(al,0)+1/(2*rr))
    control('truncated_and_exact_rod_differ_at_second_order',s.diff(s.sqrt(A)-(1+al/rr)**s.Rational(-1,2),al,2).subs(al,0))
    tangent=s.Matrix([s.Rational(3,7),s.Rational(-2,7),0]);tangent=tangent/s.sqrt((tangent.T*tangent)[0])
    zero('tangential_unit_rod_readout',(tangent.T*(-(Ec.T*ETA*Ec)[:3,:3])*tangent)[0]-1)
    zero('static_clock_period_first_order',s.diff(A**s.Rational(-1,2),al).subs(al,0)-1/(2*rr))
    zero('clock_period_original_72',1/(2*rr)*a_correct-kap*Mass/(8*s.pi*rr))
    re,ro=s.symbols('r_emit r_observe',positive=True)
    ratio=s.sqrt((1-al/re)/(1-al/ro))
    zero('frequency_transfer_first_order',s.diff(ratio,al).subs(al,0)-(1/(2*ro)-1/(2*re)))
    zero('clock_redshift_composition',(s.sqrt(A)/(s.sqrt(1-al/re)))*(s.sqrt(1-al/re)/s.sqrt(1-al/ro))-s.sqrt(A)/s.sqrt(1-al/ro))
    L=s.eye(4);L[0,0]=L[3,3]=s.Rational(5,4);L[0,3]=L[3,0]=s.Rational(3,4)
    zero('local_Lorentz_frame_preserves_rod_clock_readouts',(L*Ec).T*ETA*(L*Ec)-Ec.T*ETA*Ec)
    control('clock_period_is_not_clock_rate',s.diff(A**s.Rational(-1,2)-s.sqrt(A),al).subs(al,0))
    # Direction-dependent null readout and actual ray operation.
    yy=s.symbols('Y',real=True);rb=s.sqrt(bimpact**2+yy**2)
    dgamma=-al/(2*rb)*(1+yy**2/rb**2)
    gamma_exact=s.sqrt((1-al/rb)/(1+al*yy**2/rb**3))
    zero('null_coordinate_speed_first_order',s.diff(gamma_exact,al).subs(al,0)-dgamma/al)
    printed_gamma=1-dgamma
    null_res=(1-al/rb)-(1+al*yy**2/rb**3)*printed_gamma**2
    control('printed_positive_gamma_fails_null_condition_at_first_order',s.diff(null_res,al).subs(al,0))
    I=s.diff(dgamma,bimpact)
    BI=al/(2*bimpact)*(yy/rb+yy**3/rb**3)
    zero('original_asymptotic_bending_integrand_primitive',s.diff(BI,yy)-I)
    Bend=s.limit(BI,yy,s.oo)-s.limit(BI,yy,-s.oo)
    zero('light_bending_in_alpha',Bend-2*al/bimpact)
    zero('light_bending_consistent_mass_normalization',Bend.subs(al,a_correct)-kap*Mass/(2*s.pi*bimpact))
    control('printed_mass_deflection_coefficient_is_half',Bend.subs(al,a_correct)-kap*Mass/(4*s.pi*bimpact))
    control('printed_speed_sign_reverses_inward_bending',(-Bend)-(2*al/bimpact))
    # Fermat expression, with slope p before truncating to a straight path.
    pp=s.symbols('slope',real=True)
    optical=s.sqrt(1+pp**2)+al*s.sqrt(1+pp**2)/(2*rb)+al*(bimpact*pp+yy)**2/(2*rb**3*s.sqrt(1+pp**2))
    pboundary=s.diff(optical,pp).subs(pp,0)
    axopt=simp(s.diff(optical,bimpact).subs(pp,0)-s.diff(pboundary,yy))
    zero('optical_endpoint_momentum',pboundary-al*bimpact*yy/rb**3)
    zero('optical_ray_curvature',axopt+3*al*bimpact**3/(2*rb**5))
    axgeo=cotime(C1,s.Matrix([0,1,0]))[0].subs({x:bimpact,y:yy,z:0})
    zero('source_geodesic_matches_optical_ray',axgeo-axopt)
    zero('full_ray_vs_original_integral_endpoint_identity',-axopt-I-s.diff(pboundary,yy))
    control('finite_endpoint_correction_not_zero',pboundary)
    zero('infinite_endpoint_correction_vanishes',[s.limit(pboundary,yy,s.oo),s.limit(pboundary,yy,-s.oo)])
    geo_primitive=al/(2*bimpact)*(3*yy/rb-yy**3/rb**3)
    zero('geodesic_bend_primitive',s.diff(geo_primitive,yy)+axopt)
    zero('two_asymptotic_bending_operations_agree',s.limit(geo_primitive,yy,s.oo)-s.limit(geo_primitive,yy,-s.oo)-Bend)
    Lseg=s.symbols('L',positive=True)
    zero('finite_segment_boundary_recovery',(geo_primitive-BI-pboundary).subs(yy,Lseg)-(geo_primitive-BI-pboundary).subs(yy,-Lseg))
    # Omit spatial curvature: same Newtonian g44 but half the leading bending.
    gamma_time=-al/(2*rb);prim_time=al*yy/(2*bimpact*rb)
    zero('temporal_only_bend_primitive',s.diff(prim_time,yy)-s.diff(gamma_time,bimpact))
    control('Newtonian_temporal_readout_does_not_determine_light_bending',Bend-(s.limit(prim_time,yy,s.oo)-s.limit(prim_time,yy,-s.oo)))
    # Exact null integral: explicit regularizer removes the turning endpoint.
    qv=s.symbols('q',real=True);qopt=(1+qv+qv**2)/(1+qv)
    d0=s.symbols('d0',positive=True)
    zero('null_cubic_endpoint_factorization',(1-d0)-qv**2+d0*qv**3-(1-qv**2)*(1-d0*qopt))
    theta=s.symbols('theta',real=True)
    optprim=-s.cos(theta)+s.tan(theta)-1/s.cos(theta)
    zero('exact_null_first_coefficient_primitive',s.diff(optprim,theta)-(s.sin(theta)+1/(1+s.sin(theta))))
    zero('exact_null_first_coefficient',s.limit(optprim,theta,s.pi/2,dir='-')-optprim.subs(theta,0)-2)
    zero('impact_vs_closest_approach_first_order',s.diff(2*d0*s.sqrt(1-d0),d0).subs(d0,0)-2)
    # Timelike source geodesic integrals on the derived vacuum exterior.
    vr,vph,vt=s.symbols('rdot phidot tdot',real=True)
    vel=s.Matrix([vr,0,vph,vt]);Cg=[m.subs(th,s.pi/2) for m in Ce]
    accel=s.Matrix([-sum(Cg[m][i,n]*vel[m]*vel[n] for m,n in product(IDX,repeat=2)) for i in IDX])
    zero('source_energy_integral',s.diff(A,rr)*vr*vt+A*accel[3])
    zero('source_angular_momentum_integral',2*rr*vr*vph+rr**2*accel[2])
    zero('equatorial_plane_preserved',accel[1])
    energy,ell,u=s.symbols('energy ell u',positive=True)
    norm=A*vt**2-vr**2/A-rr**2*vph**2
    zero('radial_first_integral_from_norm',simp((A*(norm-1)).subs({vt:energy/A,vph:ell/rr**2})-(energy**2-vr**2-A*(1+ell**2/rr**2))))
    cubic=(energy**2-1)/ell**2+al*u/ell**2-u**2+al*u**3
    radial=(energy**2-(1-al*u)*(1+ell**2*u**2))/ell**2
    zero('cited_1915_cubic_orbit_recovery',radial-cubic)
    zero('Binet_equation_coefficients',s.diff(cubic,u)/2-(-u+al/(2*ell**2)+3*al*u**2/2))
    # Exact turning-root factorization used to derive the original leading apsidal integral.
    um,up=s.symbols('u_min u_max',positive=True);S=um+up;Pp=um*up
    ell2=al/(S-al*(S*S-Pp));en2=1-ell2*Pp*(1-al*S)
    fct=(u-um)*(up-u)*(1-al*(S+u))
    zero('turning_point_factorization',cubic.subs({ell**2:ell2,energy**2:en2})-fct)
    p,e,chi=s.symbols('p e chi',positive=True);d=s.symbols('delta',nonnegative=True)
    uc=(1+e*s.cos(chi))/p
    zero('turning_point_regularization',((uc-(1-e)/p)*((1+e)/p-uc))-e**2*s.sin(chi)**2/p**2)
    zero('regularized_relativistic_factor',(1-al*(S+u)).subs({um:(1-e)/p,up:(1+e)/p,u:uc})-(1-al/p*(3+e*s.cos(chi))))
    zero('period_integral_first_coefficient',s.integrate(3+e*s.cos(chi),(chi,0,s.pi))-3*s.pi)
    zero('period_integral_second_moment',s.integrate((3+e*s.cos(chi))**2,(chi,0,s.pi))-s.pi*(9+e**2/2))
    advance=3*s.pi*al/p
    semiaxis,period=s.symbols('a_orbit T_seconds',positive=True)
    result=advance.subs({al:2*K*Mass/c**2,p:semiaxis*(1-e**2)})
    zero('original_75_from_Kepler_conversion',result.subs(K*Mass,4*s.pi**2*semiaxis**3/period**2)-24*s.pi**3*semiaxis**2/(period**2*c**2*(1-e**2)))
    control('discarding_cubic_orbit_term_removes_precession',s.diff(cubic-(-u**2+al*u/ell**2+(energy**2-1)/ell**2),u))
    # Same first-order metric does NOT fix the post-Newtonian observable.
    lam=s.symbols('lambda',real=True);Al=1-al/rr+lam*al**2/rr**2
    zero('second_order_alternative_same_first_order',s.diff(Al-A,al).subs(al,0))
    control('second_order_alternative_fails_radial_vacuum',1-Al-rr*s.diff(Al,rr))
    altered=(energy**2-(1-al*u+lam*al**2*u**2)*(1+ell**2*u**2))/ell**2
    zero('altered_orbit_complete_defect',altered-cubic+lam*al**2*(u**2/ell**2+u**4))
    ctrl=s.diff(altered-cubic,u)/2
    control('same_first_order_metric_changes_postNewtonian_orbit',ctrl.subs(ell**2,al*p/2))
    # Bound coefficient uses ordinary Taylor's theorem on a closed admissible interval.
    zz=s.symbols('zz',real=True)
    zero('Taylor_second_derivative_for_error_bounds',s.diff((1-zz)**s.Rational(-1,2),zz,2)-s.Rational(3,4)*(1-zz)**s.Rational(-5,2))
    fixtures.update({'mass_normalization':{'printed_alpha':'kappa*M/(8*pi)','recovered_alpha':str(a_correct),'reason':'(67)-(69), fixed asymptotic clock normalization and integrated Poisson flux'},'static_source':{'raw_E':str(Er),'raw_Ricci':str(Ricr),'product_equation':str(simp(combo)),'angular_equation_after_ab1':str(ang),'exact_A':str(A),'exact_E':str(Ee),'domain':'r>alpha>0, 0<theta<pi; Cartesian calibration uses radial projector'},'optics':{'gamma_first_order':str(1+dgamma),'original_integrand':str(simp(I)),'ray_acceleration':str(axopt),'finite_endpoint_momentum':str(pboundary),'asymptotic_bend':str(Bend)},'orbit':{'cubic':str(cubic),'turning_factorization':str(fct),'regularized_half_period':'integral_0^pi (1-delta*(3+e*cos chi))^(-1/2) dchi','leading_advance':str(advance),'validity':'0<e<1, delta=alpha/p>0, delta*(3+e)<1; first-order use delta<<1'},'historical_numerics':{'sun_arcsec':'1.7','Jupiter_arcsec':'0.02','Mercury_arcsec_per_century':'43','status':'Source-reported numbers, not recomputed from independently supplied ephemeris or mass/radius tables'}})

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results.json'));args=parser.parse_args()
err=None
try:main()
except Exception:
    err=traceback.format_exc();print(err,flush=True)
result={'checkpoint':'E1916-I06-v1.0','environment':{'python':platform.python_version(),'sympy':s.__version__},'summary':{'groups':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'expected_failure_controls':sum(c['kind']=='expected_failure_control' for c in checks),'execution_complete':err is None},'checks':checks,'fixtures':fixtures,'execution_error':err}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result['summary']),flush=True)
raise SystemExit(0 if err is None and all(c['passed'] for c in checks) else 1)
