#!/usr/bin/env python3
"""Exact, finite checks for Einstein 1916 source-lift iteration 1.

Run: python verification/verify.py --output verification/results.json
Uses SymPy only. These designed checks supplement the analytic proofs;
they do not establish general smooth-field theorems or physical selection.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from pathlib import Path
import sympy as s

ETA = s.diag(-1, -1, -1, 1)
checks: list[dict] = []

def simp(x):
    return s.simplify(s.trigsimp(x))

def zero(name: str, value, kind: str = 'exact_identity') -> None:
    entries = list(value) if isinstance(value, s.MatrixBase) else [value]
    residuals = [simp(v) for v in entries]
    ok = all(v == 0 for v in residuals)
    checks.append({'name': name, 'kind': kind, 'passed': bool(ok),
                   'residuals': [str(v) for v in residuals if v != 0],
                   'scalar_components_compared': len(entries)})

def condition(name: str, ok: bool, evidence: str, kind: str = 'exact_control') -> None:
    checks.append({'name': name, 'kind': kind, 'passed': bool(ok), 'evidence': evidence})

def metric(E: s.Matrix) -> s.Matrix:
    return s.simplify(E.T * ETA * E)

def section(g: s.Matrix) -> s.Matrix:
    """Concrete timelike-fourth-coordinate section; validates its domain.

    This routine is used with exact rational matrices so positivity decisions
    are decidable here. The smooth analytic construction is in the report.
    """
    if g.shape != (4, 4) or g != g.T:
        raise ValueError('A symmetric 4x4 target metric is required.')
    a = s.simplify(g[3, 3])
    if a.is_positive is not True:
        raise ValueError('This section requires g44 > 0; change local frame/chart.')
    b = g[:3, 3]
    C = g[:3, :3]
    S = s.simplify(b * b.T / a - C)
    R = S.cholesky().T  # S=R.T R; positive diagonal is the chosen section.
    E = s.zeros(4)
    E[:3, :3] = R
    E[3, :3] = b.T / s.sqrt(a)
    E[3, 3] = s.sqrt(a)
    return s.simplify(E)

# Frozen, nonsingular, non-diagonal exact fixture; no fit to target outputs.
E = s.Matrix([[2, s.Rational(1,4), -s.Rational(1,6), 0],
              [0, s.Rational(3,2), s.Rational(1,5), 0],
              [0, 0, s.Rational(4,3), 0],
              [s.Rational(1,2), -s.Rational(1,3), s.Rational(2,5), s.Rational(3,2)]])
g = metric(E)
v = s.Matrix(s.symbols('v1:5', real=True))
w = s.Matrix(s.symbols('w1:5', real=True))
q = lambda u: ((E*u).T*ETA*(E*u))[0]
zero('Einstein_1_2_3_interval_recovery', q(v) - (v.T*g*v)[0])
zero('metric_symmetry', g-g.T)
zero('determinant_signature_identity', g.det()+E.det()**2)
zero('polarization', (q(v+w)-q(v)-q(w))/2 - (v.T*g*w)[0])
I = s.eye(4)
gprobe=s.zeros(4)
for i in range(4):
    gprobe[i,i]=q(I[:,i])
    for j in range(i+1,4):
        gprobe[i,j]=gprobe[j,i]=(q(I[:,i]+I[:,j])-q(I[:,i])-q(I[:,j]))/2
zero('ten_probe_recovery', gprobe-g)
zero('Einstein_4_flat_special_case', metric(I)-ETA)

# A real Lorentz transformation with exact rational coefficients.
L=s.eye(4)
L[0,0]=L[3,3]=s.Rational(5,3)
L[0,3]=L[3,0]=s.Rational(4,3)
zero('Lorentz_calibration', L.T*ETA*L-ETA)
zero('Lorentz_metric_invariance', metric(L*E)-g)
zero('fibre_witness_recovered', (L*E)*E.inv()-L)
Ereturn=section(g)
zero('constructive_section_right_inverse', metric(Ereturn)-g)
zero('constructive_section_fixture', Ereturn-E)
Lreturn=(L*E)*Ereturn.inv()
zero('return_is_modulo_Lorentz', Lreturn.T*ETA*Lreturn-ETA)
condition('return_not_bare_identity', Ereturn != L*E,
          'section(pi(L E))=E, while L E != E; the inverse is on the Lorentz quotient.')

# Additional fixed finite fixtures exercise off-diagonal/time mixing in the domain.
for k in range(1,6):
    Ek=s.Matrix([[k+1,s.Rational(1,k+1),0,0],
                 [0,k+2,s.Rational(2,k+2),0],
                 [0,0,k+3,0],
                 [s.Rational(k,3),s.Rational(1,k+2),-s.Rational(1,2),k+4]])
    zero(f'section_additional_fixture_{k}', metric(section(metric(Ek)))-metric(Ek))

# Full symmetric target variations and arbitrary vertical Lie-algebra directions.
h=s.zeros(4)
for i in range(4):
    for j in range(i,4): h[i,j]=h[j,i]=s.Symbol(f'h{i+1}{j+1}', real=True)
H=E*g.inv()*h/2
zero('surjective_metric_tangent_lift', H.T*ETA*E+E.T*ETA*H-h)
W=s.zeros(4)
for i in range(4):
    for j in range(i+1,4):
        W[i,j]=s.Symbol(f'a{i+1}{j+1}',real=True); W[j,i]=-W[i,j]
A=ETA*W
zero('vertical_Lorentz_tangent', (A*E).T*ETA*E+E.T*ETA*(A*E))

# Nonlinear coordinate changes; the chain rule and interval agree in both routes.
y=s.Matrix(s.symbols('y1:5',real=True)); z=s.Matrix(s.symbols('z1:5',real=True))
x=s.Matrix([y[0],y[1]+y[0]**2,y[2]+y[0]*y[3],y[3]+y[0]**2/3])
J=x.jacobian(y)
zero('chart_Jacobian_nonsingular', J.det()-1)
Ey=E*J
gy=J.T*g*J
zero('chart_metric_equivariance', metric(Ey)-gy)
zero('chart_interval_equivariance', ((Ey*v).T*ETA*(Ey*v))[0]-(v.T*gy*v)[0])
yz=s.Matrix([z[0]+z[1]**2,z[1],z[2],z[3]])
subs=dict(zip(y,yz)); xz=x.subs(subs, simultaneous=True)
zero('chart_composition_chain_rule', xz.jacobian(z)-J.subs(subs, simultaneous=True)*yz.jacobian(z))
zero('frame_chart_operations_commute_with_readout',metric(L*E*J)-J.T*g*J)

# Position-dependent internal gauge: retain all derivatives before cancellation.
u=s.Symbol('u',real=True)
C=(1+u**2)/(1-u**2); S=2*u/(1-u**2)
Lu=s.eye(4); Lu[0,0]=Lu[3,3]=C; Lu[0,3]=Lu[3,0]=S
Eu=s.diag(1,1+u**2,2,1+u); gu=metric(Eu)
zero('local_Lorentz_at_each_point',Lu.T*ETA*Lu-ETA)
LUE=Lu*Eu
zero('local_Lorentz_derivative_cancellation',LUE.diff(u).T*ETA*LUE+LUE.T*ETA*LUE.diff(u)-s.diff(gu,u))
zero('metric_derivative_product_rule',s.diff(gu,u)-Eu.diff(u).T*ETA*Eu-Eu.T*ETA*Eu.diff(u))
condition('bare_calibration_derivative_is_not_invariant',Lu.diff(u).subs(u,0)!=s.zeros(4),
          'At u=0, derivative of the Lorentz boost is nonzero although its metric readout is unchanged.')

# Deliberately wrong reductions: the expected difference, not an asserted identity, passes.
D=s.diag(1,1,1,2)
condition('non_Lorentz_transformation_detected', metric(D*E)!=g,
          str(metric(D*E)-g), 'expected_failure_control')
Omega=1+u**2
zero('conformal_counterexample_same_null_direction',
     ((Omega*I*s.Matrix([1,0,0,1])).T*ETA*(Omega*I*s.Matrix([1,0,0,1])))[0])
zero('conformal_counterexample_clock_change_formula',metric(Omega*I)[3,3]-Omega**2)
condition('coincidence_only_projection_loses_scale',simp(Omega**2-1)!=0,
          'Same event set/charts and null directions; Q(e4) changes from 1 to (1+u^2)^2.',
          'expected_failure_control')
condition('singular_calibration_rejected',metric(s.diag(1,1,1,0)).det()==0,
          'A rank-three calibration produces a degenerate metric, outside the target domain.',
          'expected_failure_control')
gbad=s.diag(1,-1,-1,-1)
try:
    section(gbad)
    rejected=False
except ValueError:
    rejected=True
condition('section_domain_not_global_g44',rejected,
          'A Lorentz metric can have g44<0; this section then needs a different coordinate basis.',
          'expected_failure_control')
P=s.zeros(4); P[0,3]=P[1,1]=P[2,2]=P[3,0]=1
ggood=P.T*gbad*P
zero('section_domain_repaired_by_chart',metric(section(ggood))-ggood)

# Overlap residuals: matching maps imply matching metrics; mismatches are retained.
J0=s.Matrix([[1,1,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
Ej=L*E*J0
zero('compatible_overlap_metric_gluing',metric(Ej)-J0.T*g*J0)
zero('overlap_Lorentz_recovered_from_equal_metrics',
     (Ej*(E*J0).inv()).T*ETA*(Ej*(E*J0).inv())-ETA)
Ejbad=Ej+s.diag(0,0,0,1)
condition('nonzero_overlap_residual_retained',Ejbad-L*E*J0!=s.zeros(4),
          'Raw mismatched patch data are not removed by native source admission.',
          'expected_failure_control')

# Exact accelerated coordinates, with a!=0 and 1+a*x>0 on the chosen patch.
a=s.Symbol('a',nonzero=True,real=True); r,t=s.symbols('x t',real=True)
N=1+a*r
Xa=(r+1/a)*s.cosh(a*t)-1/a
Ta=(r+1/a)*s.sinh(a*t)
Ja=s.Matrix([Xa,Ta]).jacobian([r,t])
zero('accelerated_pullback_interval',Ja.T*s.diag(-1,1)*Ja-s.diag(-1,N**2))
stationary = Ja*s.Matrix([0,1])
zero('accelerated_stationary_clock',(stationary.T*s.diag(-1,1)*stationary)[0]-N**2)
null_forward = Ja*s.Matrix([N,1])
null_backward = Ja*s.Matrix([-N,1])
zero('accelerated_null_coordinate_speed',s.Matrix([(null_forward.T*s.diag(-1,1)*null_forward)[0],(null_backward.T*s.diag(-1,1)*null_backward)[0]]))
r0=s.Symbol('x0',real=True)
trajectory=(r0+1/a)/s.cosh(a*t)-1/a
zero('accelerated_inertial_trajectory',simp(Xa.subs(r,trajectory))-r0)
zero('accelerated_universal_initial_acceleration',trajectory.diff(t,2).subs(t,0)+a*(1+a*r0))
condition('accelerated_nonclosed_coframe',s.diff(N,r)==a,
          'd theta4 = a dx wedge dt is nonzero, despite the explicit Minkowski coordinate pullback.')

# Rotation: derive the metric from the actual Cartesian coordinate map.
r=s.Symbol('r',positive=True,real=True); ph,zz,om=s.symbols('phi z omega',real=True)
coords=s.Matrix([r,ph,zz,t])
Phi=s.Matrix([r*s.cos(ph+om*t),r*s.sin(ph+om*t),zz,t])
Jrot=Phi.jacobian(coords)
Erot=s.Matrix([[1,0,0,0],[0,r,0,om*r],[0,0,1,0],[0,0,0,1]])
grot=metric(Erot)
zero('rotation_Cartesian_pullback',Jrot.T*ETA*Jrot-grot)
zero('rotation_clock_rate_squared',grot[3,3]-(1-om**2*r**2))
spatial=-grot[:3,:3]+grot[:3,3]*grot[3,:3]/grot[3,3]
zero('rotation_local_rest_rod_metric',spatial-s.diag(1,r**2/(1-om**2*r**2),1))
R=s.Symbol('R',positive=True)
# Integrate a positive symbolic tangential rod scale H first, then substitute.
Hcirc=s.Symbol('Hcirc',positive=True)
circumference=s.integrate(Hcirc,(ph,0,2*s.pi)).subs(Hcirc,R/s.sqrt(1-om**2*R**2))
zero('rotation_circumference_diameter',circumference/(2*R)-s.pi/s.sqrt(1-om**2*R**2))
condition('rotation_timelike_observer_boundary',grot[3,3].subs(om,1/r)==0,
          'At |omega*r|=1 the stationary coordinate observer is null; the rod/clock contract excludes it.',
          'expected_failure_control')
zero('rotation_zero_speed_limit',spatial.subs(om,0)-s.diag(1,r**2,1))

# Anticipatory control only, not a completed source lift of section 12.
# Direct component connection/curvature from a lapse metric distinguishes
# nonclosed coframes from genuine curvature. Convention stated in the report.
x,y,z,t=s.symbols('x y z t',real=True)
Nfun=s.Function('N')(x)
gN=s.diag(-1,-1,-1,Nfun**2); invN=gN.inv(); qs=[x,y,z,t]
Gamma=[[[simp(sum(invN[k,l]*(s.diff(gN[l,j],qs[i])+s.diff(gN[l,i],qs[j])-s.diff(gN[i,j],qs[l])) for l in range(4))/2)
          for j in range(4)] for i in range(4)] for k in range(4)]
Rxtxt=s.diff(Gamma[0][3][3],x)-s.diff(Gamma[0][0][3],t)+sum(Gamma[0][0][k]*Gamma[k][3][3]-Gamma[0][3][k]*Gamma[k][0][3] for k in range(4))
zero('lapse_curvature_component',Rxtxt-Nfun*s.diff(Nfun,x,2))
zero('accelerated_lapse_curvature_component_zero',Rxtxt.subs(Nfun,1+a*x).doit())
k=s.Symbol('k',nonzero=True,real=True)
zero('nonflat_lapse_curvature_component',Rxtxt.subs(Nfun,s.exp(k*x)).doit()-k**2*s.exp(2*k*x))

parser=argparse.ArgumentParser(); parser.add_argument('--output',type=Path,required=True); args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
result={'suite':'E1916-I01 exact finite verification',
        'scope':'Designed symbolic and rational controls, not independent review or proof-assistant certification.',
        'python':platform.python_version(),'sympy':s.__version__,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'check_groups':len(checks),'passed':sum(x['passed'] for x in checks),
        'failed':sum(not x['passed'] for x in checks),
        'expected_failure_control_groups':sum(x['kind']=='expected_failure_control' for x in checks),
        'checks':checks}
args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
for item in checks:
    if not item['passed']: print('FAILED',item)
raise SystemExit(0 if result['failed']==0 else 1)
