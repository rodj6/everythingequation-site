#!/usr/bin/env python3
"""Exact finite checks for Einstein 1916 source lift, Iteration 2.
Forward route: solve coframe structure coefficients. Comparison route: compute
Christoffel symbols directly from metric derivatives. Designed checks, not proofs.
"""
from __future__ import annotations
import argparse, hashlib, json, platform
from pathlib import Path
from itertools import product, combinations
import sympy as s
n=4; eta=s.diag(-1,-1,-1,1); checks=[]
def simp(v): return s.simplify(s.expand(v))
def sm(M): return M.applyfunc(simp)
def entries(obj):
    if isinstance(obj,s.MatrixBase): return list(obj)
    if isinstance(obj,(list,tuple)): return [z for a in obj for z in entries(a)]
    return [s.sympify(obj)]
def zero(name,obj,kind='exact_identity',note=''):
    vals=[simp(a) for a in entries(obj)];bad=[str(a) for a in vals if a!=0]
    checks.append({'name':name,'kind':kind,'passed':not bad,'scalar_entries':len(vals),'nonzero_residuals':bad[:8],'note':note})
    print(('PASS ' if not bad else 'FAIL ')+name,flush=True)
def cond(name,test,note='',kind='expected_failure_control'):
    checks.append({'name':name,'kind':kind,'passed':bool(test),'scalar_entries':1,'note':note})
    print(('PASS ' if test else 'FAIL ')+name,flush=True)
def source_connection(E,dE):
    """dtheta^a=-1/2 c^a_bc theta^b wedge theta^c.
    omega_ab_c=1/2(c_cab-c_abc-c_bca), omega^a_b=eta^aa omega_ab.
    No metric Christoffel expression is used in this forward constructor.
    """
    F=sm(E.inv())
    dtheta=[s.Matrix(n,n,lambda mu,nu:dE[mu][a,nu]-dE[nu][a,mu]) for a in range(n)]
    c=[sm(-F.T*D*F) for D in dtheta];cl=[eta[a,a]*c[a] for a in range(n)]
    low=[[[simp((cl[c0][a,b]-cl[a][b,c0]-cl[b][c0,a])/2) for c0 in range(n)] for b in range(n)] for a in range(n)]
    w=[sm(s.Matrix(n,n,lambda a,b:eta[a,a]*sum(low[a][b][c0]*E[c0,mu] for c0 in range(n)))) for mu in range(n)]
    C=[sm(F*(dE[mu]+w[mu]*E)) for mu in range(n)]
    return F,c,w,C
def metric_connection(g,dg):
    gi=sm(g.inv())
    return [sm(s.Matrix(n,n,lambda r,v:sum(gi[r,l]*(dg[mu][l,v]+dg[v][l,mu]-dg[l][mu,v]) for l in range(n))/2)) for mu in range(n)]
def torsion(E,dE,w):
    return [s.Matrix(n,n,lambda mu,nu:simp(dE[mu][a,nu]-dE[nu][a,mu]+(w[mu]*E)[a,nu]-(w[nu]*E)[a,mu])) for a in range(n)]
def curvature(A,q):
    return [[sm(A[nu].diff(q[mu])-A[mu].diff(q[nu])+A[mu]*A[nu]-A[nu]*A[mu]) for nu in range(n)] for mu in range(n)]
def ricci(R):
    return sm(s.Matrix(n,n,lambda sigma,nu:sum(R[rho][nu][rho,sigma] for rho in range(n))))
def einstein_B(R):
    return sm(s.Matrix(n,n,lambda mu,nu:sum(R[nu][rho][rho,mu] for rho in range(n))))
def field(E,q):
    dE=[E.diff(z) for z in q];F,c,w,C=source_connection(E,dE)
    g=sm(E.T*eta*E);dg=[g.diff(z) for z in q]
    return dE,F,c,w,C,g,dg

# Generic non-diagonal exact first jet.
E0=s.Matrix([[2,1,0,1],[0,3,1,0],[1,0,2,1],[0,1,0,2]])
dE0=[s.Matrix(n,n,lambda a,b:s.Rational(((a+2)*(b+3)+(mu+1)*(a-b+2))%11-5,mu+2)) for mu in range(n)]
F0,c0,w0,C0=source_connection(E0,dE0)
g0=E0.T*eta*E0;dg0=[d.T*eta*E0+E0.T*eta*d for d in dE0]
CM0=metric_connection(g0,dg0)
zero('generic_jet_source_vs_metric_connection',[C0[i]-CM0[i] for i in range(n)])
zero('generic_jet_metric_residual',[w.T*eta+eta*w for w in w0])
zero('generic_jet_torsion_residual',torsion(E0,dE0,w0))
zero('generic_jet_projected_lower_index_symmetry',[C0[mu][r,nu]-C0[nu][r,mu] for r,mu,nu in product(range(n),repeat=3)])
zero('generic_jet_metric_compatibility',[dg0[mu]-C0[mu].T*g0-g0*C0[mu] for mu in range(n)])
zero('generic_jet_reconstruction_inverse',[E0*C0[mu]*F0-dE0[mu]*F0-w0[mu] for mu in range(n)])
zero('inverse_metric_recovery',F0*eta*F0.T-g0.inv())
zero('volume_squared_recovery',E0.det()**2+g0.det())
u=s.Matrix([2,-1,3,4]);a=s.Matrix([1,3,-2,5]);v=F0*u;alpha=E0.T*a
zero('vector_covector_roundtrip',[E0*v-u,F0.T*alpha-a])
zero('pairing_contraction',(alpha.T*v)[0]-(a.T*u)[0])
zero('lowering_commutes',g0*v-E0.T*eta*u)
zero('raising_commutes',g0.inv()*alpha-F0*eta*a)
U=s.Matrix(n,n,lambda i,j:2*i-3*j+i*j+1);V=sm(F0*U*E0)
zero('mixed_tensor_roundtrip',E0*V*F0-U)
zero('mixed_tensor_trace',s.trace(V)-s.trace(U))
zero('outer_product_commutes',F0*(u*a.T)*E0-v*alpha.T)
S=U+U.T;A=U-U.T
zero('symmetry_preserved',E0.T*S*E0-(E0.T*S*E0).T)
zero('antisymmetry_preserved',E0.T*A*E0+(E0.T*A*E0).T)
zero('determinant_first_jet',[s.trace(g0.inv()*dg0[mu])-2*s.trace(F0*dE0[mu]) for mu in range(n)])
zero('inverse_first_jet',[(-g0.inv()*dg0[mu]*g0.inv())*g0+g0.inv()*dg0[mu] for mu in range(n)])
zero('volume_trace_first_jet',[s.trace(C0[mu])-s.trace(F0*dE0[mu]) for mu in range(n)])
du=[s.Matrix([mu+1,-mu,2*mu+3,1-mu]) for mu in range(n)]
da=[s.Matrix([2*mu,mu+2,1,-3*mu]) for mu in range(n)]
dU=[s.Matrix(n,n,lambda i,j:(i+1)*(mu+2)-j) for mu in range(n)]
for mu in range(n):
    dv=-F0*dE0[mu]*v+F0*du[mu];dalpha=dE0[mu].T*a+E0.T*da[mu]
    dV=-F0*dE0[mu]*V+F0*dU[mu]*E0+F0*U*dE0[mu]
    zero(f'vector_derivative_intertwiner_{mu+1}',dv+C0[mu]*v-F0*(du[mu]+w0[mu]*u))
    zero(f'covector_derivative_intertwiner_{mu+1}',dalpha-C0[mu].T*alpha-E0.T*(da[mu]-w0[mu].T*a))
    zero(f'mixed_derivative_intertwiner_{mu+1}',dV+C0[mu]*V-V*C0[mu]-F0*(dU[mu]+w0[mu]*U-U*w0[mu])*E0)
raw=[s.Matrix(n,n,lambda i,j:s.Rational((mu+1)*(i+2)-3*j,7)) for mu in range(n)]
Cr=[F0*(dE0[mu]+raw[mu]*E0) for mu in range(n)];Theta=torsion(E0,dE0,raw)
zero('raw_nonmetricity_complete_identity',[dg0[mu]-Cr[mu].T*g0-g0*Cr[mu]+E0.T*(raw[mu].T*eta+eta*raw[mu])*E0 for mu in range(n)])
zero('raw_torsion_complete_identity',[Cr[mu][r,nu]-Cr[nu][r,mu]-sum(F0[r,a]*Theta[a][mu,nu] for a in range(n)) for r,mu,nu in product(range(n),repeat=3)])
cond('raw_nonzero_residuals_retained',any(z!=0 for z in entries(Theta)),'Raw candidates with nonzero torsion remain admitted to the raw realization.')
pairs=list(combinations(range(n),2));basis=[]
for i,j in pairs:
    L=s.zeros(n);L[i,j]=1;L[j,i]=-1;basis.append(eta*L)
cols=[]
for mu in range(n):
    for B in basis:
        ww=[s.zeros(n) for _ in range(n)];ww[mu]=B
        th=torsion(E0,[s.zeros(n) for _ in range(n)],ww)
        cols.append(s.Matrix([th[a][i,j] for a in range(n) for i,j in pairs]))
K=s.Matrix.hstack(*cols)
cond('torsion_system_rank24',K.rank()==24,'Finite rank check; the report proves general uniqueness.','exact_identity')


# Linearized reconstruction: solve differentiated source laws rather than assume delta-C.
h0=s.Matrix(n,n,lambda i,j:s.Rational((i+1)*(j+1)+i+j,5))
dh0=[s.Matrix(n,n,lambda i,j:s.Rational((mu+1)*(i+j+2)+(i+1)*(j+1),mu+3)) for mu in range(n)]
gi0=g0.inv();H0=E0*gi0*h0/2
DH0=[(dE0[mu]*gi0*h0-E0*gi0*dg0[mu]*gi0*h0+E0*gi0*dh0[mu])/2 for mu in range(n)]
zero('metric_variation_lift',H0.T*eta*E0+E0.T*eta*H0-h0)
basevar=[s.Matrix(n,n,lambda mu,nu:DH0[mu][a,nu]-DH0[nu][a,mu]+(w0[mu]*H0)[a,nu]-(w0[nu]*H0)[a,mu]) for a in range(n)]
rhs=-s.Matrix([basevar[a][i,j] for a in range(n) for i,j in pairs])
coeff=K.inv()*rhs
DW0=[sum((coeff[mu*len(pairs)+idx]*B for idx,B in enumerate(basis)),s.zeros(n)) for mu in range(n)]
zero('linearized_source_metric_law',[dw.T*eta+eta*dw for dw in DW0])
zero('linearized_source_torsion_law',[basevar[a][mu,nu]+(DW0[mu]*E0)[a,nu]-(DW0[nu]*E0)[a,mu] for a,mu,nu in product(range(n),repeat=3)])
DC0=[-F0*H0*C0[mu]+F0*(DH0[mu]+DW0[mu]*E0+w0[mu]*H0) for mu in range(n)]
NablaH=[dh0[mu]-C0[mu].T*h0-h0*C0[mu] for mu in range(n)]
DeltaC=[s.Matrix(n,n,lambda r,nu:sum(gi0[r,l]*(NablaH[mu][l,nu]+NablaH[nu][l,mu]-NablaH[l][mu,nu]) for l in range(n))/2) for mu in range(n)]
zero('connection_variation_recovery',[DC0[mu]-DeltaC[mu] for mu in range(n)])

# Position-dependent Lorentz frame of flat spacetime.
x,y,z,t=s.symbols('x y z t',real=True);q=[x,y,z,t]
L=s.eye(n);L[0,0]=s.cosh(x);L[0,3]=s.sinh(x);L[3,0]=s.sinh(x);L[3,3]=s.cosh(x)
dEL,FL,cL,wL,CL,gL,dgL=field(L,q)
zero('variable_frame_metric',gL-eta)
zero('variable_frame_connection_law',[wL[mu]+L.diff(q[mu])*FL for mu in range(n)])
zero('variable_frame_projected_connection_zero',CL)
fixed=s.Matrix([1,2,3,4]);changed=L*fixed
zero('variable_frame_correct_derivative',[changed.diff(q[mu])+wL[mu]*changed for mu in range(n)])
cond('bare_derivative_fails_frame_change',any(simp(v)!=0 for v in changed.diff(x)),'d(Lambda*u) includes dLambda*u.')
wrong=sm(changed.diff(x)+L.diff(x)*FL*changed)
cond('wrong_connection_transform_sign_rejected',any(v!=0 for v in wrong),'A plus sign doubles the frame derivative.')

# Nonlinear coordinate change of a holonomic coframe.
r,p,b,h=s.symbols('r p b h',real=True);yy=[r,p,b,h]
xmap=s.Matrix([r,p+r**2,b,h*s.exp(r)]);J=xmap.jacobian(yy)
dEJ,FJ,cJ,wJ,CJ,gJ,dgJ=field(J,yy);CMJ=metric_connection(gJ,dgJ)
zero('coordinate_holonomic_anholonomy_zero',cJ)
zero('coordinate_holonomic_frame_connection_zero',wJ)
zero('nonlinear_coordinate_connection',[CJ[mu]-FJ*J.diff(yy[mu]) for mu in range(n)])
zero('nonlinear_coordinate_metric_route',[CJ[mu]-CMJ[mu] for mu in range(n)])
zero('nonlinear_coordinate_curvature_zero',curvature(CJ,yy))

# Lapse family and source-to-target differential operations.
N=s.Function('N',positive=True)(x);E=s.diag(1,1,1,N)
dE,F,c,w,C,g,dg=field(E,q);CM=metric_connection(g,dg)
zero('lapse_connection_two_routes',[C[i]-CM[i] for i in range(n)])
expected=[s.zeros(n) for _ in range(n)];expected[3][0,3]=s.diff(N,x);expected[3][3,0]=s.diff(N,x)
zero('lapse_source_connection_explicit',[w[i]-expected[i] for i in range(n)])
Omega=curvature(w,q);R=curvature(C,q)
zero('lapse_curvature_intertwiner',[R[mu][nu]-F*Omega[mu][nu]*E for mu,nu in product(range(n),repeat=2)])
zero('lapse_curvature_component',R[0][3][0,3]-N*s.diff(N,x,2))
zero('lapse_einstein_B_sign',einstein_B(R)+ricci(R))
cond('wrong_ricci_sign_rejected',simp((einstein_B(R)-ricci(R))[3,3])!=0,'Einstein B_mu_nu=-Ric_mu_nu for the declared convention.')
vv=s.Matrix(s.symbols('v1:5',real=True));aa=s.Matrix(s.symbols('a1:5',real=True));uE=E*vv
source_acc=sum((w[mu]*uE*vv[mu] for mu in range(n)),s.zeros(n,1))+sum((dE[mu]*vv*vv[mu] for mu in range(n)),s.zeros(n,1))+E*aa
coord_acc=aa+sum((C[mu]*vv*vv[mu] for mu in range(n)),s.zeros(n,1))
zero('curve_derivative_intertwiner',source_acc-E*coord_acc)
length=s.sqrt((vv.T*g*vv)[0]);P=s.Matrix([s.diff(length,vv[i]) for i in range(n)])
dotL=sum(s.diff(length,q[i])*vv[i]+s.diff(length,vv[i])*aa[i] for i in range(n))
EL=s.Matrix([sum(s.diff(P[i],q[j])*vv[j]+s.diff(P[i],vv[j])*aa[j] for j in range(n))-s.diff(length,q[i]) for i in range(n)])
zero('proper_length_euler_residual',EL-g*(coord_acc-vv*dotL/length)/length,note='On Q>0 with fixed endpoints; null curves excluded from this length division.')
vfield=s.Matrix([x*y,z*t,x+t,y+z]);ufield=E*vfield
zero('field_vector_derivative',[vfield.diff(q[mu])+C[mu]*vfield-F*(ufield.diff(q[mu])+w[mu]*ufield) for mu in range(n)])
alpha=s.Matrix([x*t,y**2,z*x,t+x*y]);a_frame=F.T*alpha
Dalpha=[alpha.diff(q[mu])-C[mu].T*alpha for mu in range(n)]
zero('field_covector_derivative',[Dalpha[mu]-E.T*(a_frame.diff(q[mu])-w[mu].T*a_frame) for mu in range(n)])
T=s.Matrix(n,n,lambda i,j:(i+1)*x**2+(j+2)*y+(i-j)*z*t);Tf=F.T*T*F
zero('rank2_covariant_derivative',[T.diff(q[mu])-C[mu].T*T-T*C[mu]-E.T*(Tf.diff(q[mu])-w[mu].T*Tf-Tf*w[mu])*E for mu in range(n)])
vol=N
zero('volume_connection_trace',[s.trace(C[mu])-s.diff(vol,q[mu])/vol for mu in range(n)])
div=sum(vfield.diff(q[mu])[mu]+(C[mu]*vfield)[mu] for mu in range(n))
zero('vector_density_divergence',div-sum(s.diff(vol*vfield[mu],q[mu]) for mu in range(n))/vol)
curl=s.Matrix(n,n,lambda mu,nu:Dalpha[nu][mu]-Dalpha[mu][nu])
zero('einstein_rotation_sign',curl-s.Matrix(n,n,lambda mu,nu:s.diff(alpha[mu],q[nu])-s.diff(alpha[nu],q[mu])))
Btwo=T-T.T;covD=[Btwo.diff(q[mu])-C[mu].T*Btwo-Btwo*C[mu] for mu in range(n)]
zero('antisymmetric_three_index_derivative',[covD[k][i,j]+covD[i][j,k]+covD[j][k,i]-s.diff(Btwo[i,j],q[k])-s.diff(Btwo[j,k],q[i])-s.diff(Btwo[k,i],q[j]) for i,j,k in product(range(n),repeat=3)])
Aup=Btwo;Daup=[Aup.diff(q[mu])+C[mu]*Aup+Aup*C[mu].T for mu in range(n)]
zero('antisymmetric_density_divergence',[sum(Daup[nu][mu,nu] for nu in range(n))-sum(s.diff(vol*Aup[mu,nu],q[nu]) for nu in range(n))/vol for mu in range(n)])
Sym=T+T.T;Mix=Sym*g;Dmix=[Mix.diff(q[mu])+C[mu]*Mix-Mix*C[mu] for mu in range(n)]
zero('symmetric_mixed_density_divergence',[sum(Dmix[nu][nu,mu] for nu in range(n))-sum(s.diff(vol*Mix[nu,mu],q[nu]) for nu in range(n))/vol+s.Rational(1,2)*sum(dg[mu][i,j]*Sym[i,j] for i,j in product(range(n),repeat=2)) for mu in range(n)])
# Einstein (42): each derivative index is appended on the right.
first=s.Matrix(n,n,lambda mu,sigma:Dalpha[sigma][mu]);second=[first.diff(q[tau])-C[tau].T*first-first*C[tau] for tau in range(n)]
zero('einstein_covector_curvature_commutator',[second[tau][mu,sigma]-second[sigma][mu,tau]-sum(R[sigma][tau][rho,mu]*alpha[rho] for rho in range(n)) for mu,sigma,tau in product(range(n),repeat=3)])
logv=s.log(vol);B44=s.zeros(n)
for mu,nu in product(range(n),repeat=2):
    B44[mu,nu]=-sum(s.diff(C[mu][a,nu],q[a]) for a in range(n))+sum(C[mu][b,a]*C[nu][a,b] for a,b in product(range(n),repeat=2))+s.diff(logv,q[mu],q[nu])-sum(C[mu][a,nu]*s.diff(logv,q[a]) for a in range(n))
zero('einstein_equation44_full_density_terms',B44-einstein_B(R))

# Same metric, wrong differential law: flat but torsionful bare connection.
bare=[sm(F*dE[mu]) for mu in range(n)]
zero('bare_metric_compatibility',[dg[mu]-bare[mu].T*g-g*bare[mu] for mu in range(n)])
zero('bare_connection_flat',curvature(bare,q))
cond('bare_connection_torsion_detected',simp(bare[0][3,3]-bare[3][3,0])!=0)
cond('bare_connection_not_einstein',simp(C[3][0,3]-bare[3][0,3])!=0)
a0,k=s.symbols('a k',nonzero=True,real=True)
zero('accelerated_flat_all_components',[v.subs(N,1+a0*x).doit() for v in entries(R)])
zero('curved_lapse_component',R[0][3][0,3].subs(N,s.exp(k*x)).doit()-k**2*s.exp(2*k*x))
cond('zero_connection_wrong_curvature_detected',simp(R[0][3][0,3].subs(N,s.exp(k*x)).doit())!=0)

# Nonzero omega wedge omega: time-dependent spatial calibration.
H=s.symbols('H',nonzero=True,real=True);scale=s.exp(H*t);Es=s.diag(scale,scale,scale,1)
dEs,Fs,cs,ws,Cs,gs,dgs=field(Es,q);CMS=metric_connection(gs,dgs)
zero('scaled_connection_two_routes',[Cs[i]-CMS[i] for i in range(n)])
Os=curvature(ws,q);Rs=curvature(Cs,q)
zero('scaled_curvature_intertwiner',[Rs[mu][nu]-Fs*Os[mu][nu]*Es for mu,nu in product(range(n),repeat=2)])
cond('nonlinear_curvature_commutator_exercised',any(simp(v)!=0 for v in ws[0]*ws[1]-ws[1]*ws[0]),'Nonzero quadratic x-y curvature component.','exact_identity')
cond('omit_quadratic_curvature_rejected',any(simp(v)!=0 for v in Os[0][1]-(ws[1].diff(x)-ws[0].diff(y))))
zero('scaled_ricci_normalization',ricci(Rs)+3*H**2*gs)
zero('scaled_scalar_curvature',s.trace(gs.inv()*ricci(Rs))+12*H**2)
zero('scaled_einstein_B_sign',einstein_B(Rs)+ricci(Rs))
# Nonflat, position-dependent frame transformation.
Ep=sm(L*E);wp=[sm(L*w[mu]*FL-L.diff(q[mu])*FL) for mu in range(n)]
Cp=[sm(Ep.inv()*(Ep.diff(q[mu])+wp[mu]*Ep)) for mu in range(n)]
zero('nonflat_frame_metric_invariance',Ep.T*eta*Ep-g)
zero('nonflat_frame_connection_invariance',[Cp[i]-C[i] for i in range(n)])
Op=curvature(wp,q)
zero('nonflat_frame_curvature_covariance',[Op[mu][nu]-L*Omega[mu][nu]*FL for mu,nu in product(range(n),repeat=2)])
zero('frame_torsion_covariance',torsion(Ep,[Ep.diff(v) for v in q],wp))
# Raw curvature conjugacy away from both selection laws.
Ar=[s.zeros(n) for _ in range(n)]
Ar[0]=s.Matrix([[0,1,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,1]])
Ar[3]=s.Matrix([[0,0,0,0],[1,0,0,0],[0,0,2,0],[0,0,0,0]])
Acoord=[sm(F*(dE[mu]+Ar[mu]*E)) for mu in range(n)];Fr=curvature(Ar,q);Rr=curvature(Acoord,q)
zero('raw_curvature_intertwiner',[Rr[mu][nu]-F*Fr[mu][nu]*E for mu,nu in product(range(n),repeat=2)])
cond('raw_curvature_nonzero_control',any(simp(v)!=0 for v in entries(Fr)),'Noncommuting raw connection has nonzero curvature.','exact_identity')

# Complete raw covector commutator: retain the torsion-dependent derivative term.
Dalpha_raw=[alpha.diff(q[mu])-Acoord[mu].T*alpha for mu in range(n)]
first_raw=s.Matrix(n,n,lambda mu,sigma:Dalpha_raw[sigma][mu])
second_raw=[first_raw.diff(q[tau])-Acoord[tau].T*first_raw-first_raw*Acoord[tau] for tau in range(n)]
torsion_terms=[];raw_residual=[]
for mu,sigma,tau in product(range(n),repeat=3):
    extra=sum((Acoord[sigma][lam,tau]-Acoord[tau][lam,sigma])*Dalpha_raw[lam][mu] for lam in range(n))
    torsion_terms.append(extra)
    raw_residual.append(second_raw[tau][mu,sigma]-second_raw[sigma][mu,tau]-sum(Rr[sigma][tau][rho,mu]*alpha[rho] for rho in range(n))-extra)
zero('raw_covector_commutator_complete_identity',raw_residual)
cond('raw_commutator_torsion_term_needed',any(simp(v)!=0 for v in torsion_terms),'Dropping the torsion derivative term fails on the retained raw parent.')

# Original §6 prints Symmetrische; retain and flag this wording explicitly.
cond('printed_symmetric_rank5_statement_counterexample',s.Integer(1)**5==1,'A nonzero covector tensor-power five is symmetric and nonzero.','exact_identity')
cond('exterior_rank5_zero',all(len(set(i))<5 for i in product(range(4),repeat=5)),'Complete antisymmetry forces every repeated-index component to vanish.','exact_identity')

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
result={'suite':'E1916-I02 exact finite verification','python':platform.python_version(),'sympy':s.__version__,
'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'check_groups':len(checks),
'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
'expected_failure_control_groups':sum(c['kind']=='expected_failure_control' for c in checks),
'scalar_entries':sum(c['scalar_entries'] for c in checks),
'scope':'Designed symbolic/rational fixtures; not independent review, empirical data, or a formal proof-assistant certificate.','checks':checks}
args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2),flush=True)
raise SystemExit(0 if result['failed']==0 else 1)
