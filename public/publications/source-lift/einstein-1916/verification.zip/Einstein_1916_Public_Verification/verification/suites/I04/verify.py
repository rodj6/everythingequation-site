#!/usr/bin/env python3
"""Exact designed checks for E1916-I04; mathematical proofs are in REPORT.md."""
from __future__ import annotations
import argparse,json,platform
from pathlib import Path
from itertools import product
import sympy as s
from core import IDX,ETA,sm,simp,connection,source_connection,curvature,ricci,kinetic,geometry,source_ricci
from matter import reverse,covariant_divergence,frame_divergence,potentials,field_quantities
checks=[];fixtures={}
def flat(o):
    if isinstance(o,s.MatrixBase): return list(o)
    if isinstance(o,(tuple,list)): return [a for v in o for a in flat(v)]
    return [s.sympify(o)]
def zero(name,obj,note=''):
    vals=[simp(a) for a in flat(obj)];bad=[str(a) for a in vals if a!=0]
    checks.append(dict(name=name,kind='exact_identity',passed=not bad,scalar_entries=len(vals),nonzero_residuals=bad[:8],note=note))
    print(('PASS ' if not bad else 'FAIL ')+name,flush=True)
def control(name,condition,note=''):
    checks.append(dict(name=name,kind='expected_failure_control',passed=bool(condition),note=note))
    print(('PASS ' if condition else 'FAIL ')+name,flush=True)
def same(a,b): return all(simp(v)==0 for v in flat(a-b))

# Arbitrary non-diagonal rational first jet, independent matter values and derivatives.
E=s.Matrix([[2,1,0,1],[0,3,1,0],[1,0,2,1],[0,1,0,2]])
g=E.T*ETA*E;q=g.inv();F=E.inv();kap=s.Rational(2,7)
dq=[s.Matrix(4,4,lambda i,j:s.Rational((i+j+1)*(a+2)+(i+1)*(j+1),7+a)) for a in IDX]
dg=[-g*d*g for d in dq];dE=[-E*dq[a]*g/2 for a in IDX]
F,w,Csrc=source_connection(E,dE);C=connection(q,dg)
zero('generic_source_connection_reused',[Csrc[a]-C[a] for a in IDX])
Sigma=s.Matrix(4,4,lambda i,j:s.Rational(2*(i+j+1)+(i+1)*(j+1),5))
dSigma=[s.Matrix(4,4,lambda i,j:s.Rational((a+1)*(i+j+2)-(i+1)*(j+1),a+3)) for a in IDX]
T=E.T*Sigma*E;dT=[dE[a].T*Sigma*E+E.T*dSigma[a]*E+E.T*Sigma*dE[a] for a in IDX]
mixed=sm(q*T);tr=s.trace(mixed)
zero('stress_covariant_reconstruction',F.T*T*F-Sigma)
zero('stress_mixed_reconstruction',mixed-F*(ETA*Sigma)*E)
zero('stress_trace_recovery',tr-s.trace(ETA*Sigma))
zero('stress_symmetry_recovery',T-T.T)
zero('trace_reversal_commutes_with_readout',E.T*reverse(Sigma,ETA,ETA)*E-reverse(T,g,q))
zero('trace_reversal_is_involution',reverse(reverse(T,g,q),g,q)-T)
control('one_quarter_trace_subtraction_loses_metric_direction',same(g-g*s.trace(q*g)/4,s.zeros(4)))
control('wrong_trace_coefficient_does_not_reverse_back',not same(reverse(T-g*tr/4,g,q),T))
# Full tangent coverage for simultaneous metric and stress variations.
h=s.Matrix(4,4,lambda i,j:s.Rational((i+1)*(j+1)+i+j,13))
kT=s.Matrix(4,4,lambda i,j:s.Rational(2+i+j+(i+1)*(j+1),9))
H=E*q*h/2;Aframe=H*F
dS=F.T*kT*F-Aframe.T*Sigma-Sigma*Aframe
zero('joint_metric_tangent_coverage',H.T*ETA*E+E.T*ETA*H-h)
zero('joint_stress_tangent_coverage',H.T*Sigma*E+E.T*dS*E+E.T*Sigma*H-kT)
fixedS=-Aframe.T*Sigma-Sigma*Aframe
zero('horizontal_fixed_stress_response',H.T*Sigma*E+E.T*fixedS*E+E.T*Sigma*H)
control('freezing_frame_stress_is_not_fixed_coordinate_stress',not same(H.T*Sigma*E+E.T*Sigma*H,s.zeros(4)))
# Generic variable-frame covariance; derivative jets satisfy Lorentz tangent condition.
Lam=s.eye(4);Lam[0,0]=Lam[3,3]=s.Rational(5,3);Lam[0,3]=Lam[3,0]=s.Rational(4,3)
Li=Lam.inv(); generators=[]
for a in IDX:
    skew=s.Matrix(4,4,lambda i,j:s.Rational((i-j)*(a+1),7));generators.append(ETA*skew)
dLam=[A*Lam for A in generators];dLi=[-Li*v*Li for v in dLam]
Ep=Lam*E;Fp=F*Li;Sp=Li.T*Sigma*Li
wprime=[sm(Lam*w[a]*Li-dLam[a]*Li) for a in IDX]
dSp=[sm(dLi[a].T*Sigma*Li+Li.T*dSigma[a]*Li+Li.T*Sigma*dLi[a]) for a in IDX]
zero('Lorentz_calibration_preserves_metric',Ep.T*ETA*Ep-g)
zero('Lorentz_matter_readout_invariance',Ep.T*Sp*Ep-T)
control('unmatched_matter_frame_is_not_same_preparation',not same(Ep.T*Sigma*Ep,T))
cv=covariant_divergence(T,g,q,C,dT,dq)
fd=frame_divergence(Sigma,F,w,dSigma)
fdprime=frame_divergence(Sp,Fp,wprime,dSp)
zero('generic_source_matter_divergence_intertwiner',E.T*fd-cv)
zero('variable_frame_divergence_covariance',fdprime-Li.T*fd)
zero('variable_frame_covariant_matter_readout_invariance',Ep.T*fdprime-cv)
exchange=s.Matrix([sum(T[m,n]*dq[mu][m,n]/2 for m,n in product(IDX,repeat=2)) for mu in IDX])
ordinary=s.Matrix([sum((dq[a]*T+q*dT[a])[a,mu] for a in IDX) for mu in IDX])
c=[simp(s.trace(v)) for v in C]
zero('general_chart_density_and_exchange_identity',cv-ordinary-exchange-s.Matrix([sum(c[a]*mixed[a,mu] for a in IDX) for mu in IDX]))
force=s.Matrix([sum(C[a][b,mu]*mixed[a,b] for a,b in product(IDX,repeat=2)) for mu in IDX])
zero('exchange_matches_connection_contraction',force+exchange)
control('ordinary_divergence_is_not_covariant_divergence',not same(cv,ordinary))
Anti=s.zeros(4);Anti[0,1]=1;Anti[1,0]=-1
Ta=E.T*Anti*E;dTa=[dE[a].T*Anti*E+E.T*Anti*dE[a] for a in IDX]
ca=covariant_divergence(Ta,g,q,C,dTa,dq)
oa=s.Matrix([sum((dq[a]*Ta+q*dTa[a])[a,mu] for a in IDX) for mu in IDX]);ma=q*Ta
naive=oa+s.Matrix([sum(c[a]*ma[a,mu] for a in IDX) for mu in IDX])+s.Matrix([sum(Ta[m,n]*dq[mu][m,n]/2 for m,n in product(IDX,repeat=2)) for mu in IDX])
control('symmetry_is_needed_for_half_metric_exchange_formula',not same(ca,naive))

# Unrestricted rational third jet. All derivative-index symmetries are retained.
ddq=[[s.Matrix(4,4,lambda i,j:s.Rational((a+b+2)*(i+j+3)+(a+1)*(b+1)*(i+1)*(j+1),a+b+5)) for b in IDX] for a in IDX]
dddq=[[[s.Matrix(4,4,lambda i,j:s.Rational((a+b+c0+3)*(i+j+1)+(a+1)*(b+1)*(c0+1)*(i+1)*(j+1),a+b+c0+7)) for c0 in IDX] for b in IDX] for a in IDX]
ddg=[[sm(g*dq[a]*g*dq[b]*g+g*dq[b]*g*dq[a]*g-g*ddq[a][b]*g) for b in IDX] for a in IDX]
dddg=[[[sm(-g*(dddq[a][b][cc]*g+ddq[a][b]*dg[cc]+ddq[a][cc]*dg[b]+ddq[b][cc]*dg[a]+dq[a]*ddg[b][cc]+dq[b]*ddg[a][cc]+dq[cc]*ddg[a][b])) for cc in IDX] for b in IDX] for a in IDX]
dC=[[sm(u+v) for u,v in zip(connection(dq[a],dg),connection(q,ddg[a]))] for a in IDX]
ddC=[]
for a in IDX:
    row=[]
    for b in IDX:
        terms=[connection(ddq[a][b],dg),connection(dq[a],ddg[b]),connection(dq[b],ddg[a]),connection(q,dddg[a][b])]
        row.append([sm(sum((term[m] for term in terms),s.zeros(4))) for m in IDX])
    ddC.append(row)
zero('third_jet_inverse_metric_identity',[sum((dddq[a][b][cc]*g+ddq[a][b]*dg[cc]+ddq[a][cc]*dg[b]+ddq[b][cc]*dg[a]+dq[a]*ddg[b][cc]+dq[b]*ddg[a][cc]+dq[cc]*ddg[a][b]+q*dddg[a][b][cc] for cc in [c0]),s.zeros(4)) for a,b,c0 in product(IDX,repeat=3)])
# Direct double derivative of the original expression, not the reduced formula.
D54=[];D55=[];volume_defect=[]
for mu in IDX:
    dz=-sum(ddq[a][sig][sig,b]*C[mu][a,b]+dq[a][sig,b]*dC[sig][mu][a,b]+dq[sig][sig,b]*dC[a][mu][a,b]+q[sig,b]*ddC[a][sig][mu][a,b] for a,sig,b in product(IDX,repeat=3))
    dv=-sum(ddq[a][mu][l,b]*C[l][a,b]+dq[a][l,b]*dC[mu][l][a,b]+dq[mu][l,b]*dC[a][l][a,b]+q[l,b]*ddC[a][mu][l][a,b] for a,l,b in product(IDX,repeat=3))
    triple=sum(dddq[a][b][mu][a,b]/2 for a,b in product(IDX,repeat=2))
    defect=-sum(ddq[mu][a][a,b]*c[b]+dq[a][a,b]*s.trace(dC[mu][b])+dq[mu][a,b]*s.trace(dC[a][b])+q[a,b]*s.trace(ddC[mu][a][b]) for a,b in product(IDX,repeat=2))/2
    D54.append(dz-triple);D55.append(dz-dv/2);volume_defect.append(defect)
zero('equation54_unrestricted_third_jet',D54)
zero('equation55_complete_volume_defect',[D55[i]-volume_defect[i] for i in IDX])
control('equation55_zero_is_not_valid_off_gauge',any(simp(v)!=0 for v in D55))
fixtures['generic_volume_defect']=[str(simp(v)) for v in D55]

R=[[sm(dC[m][n]-dC[n][m]+C[m]*C[n]-C[n]*C[m]) for n in IDX] for m in IDX]
dR=[[[sm(ddC[a][m][n]-ddC[a][n][m]+dC[a][m]*C[n]+C[m]*dC[a][n]-dC[a][n]*C[m]-C[n]*dC[a][m]) for n in IDX] for m in IDX] for a in IDX]
Ric=ricci(R);dRic=[ricci(v) for v in dR];scalar=simp(s.trace(q*Ric));dscalar=[simp(s.trace(dq[a]*Ric+q*dRic[a])) for a in IDX]
Einstein=sm(Ric-g*scalar/2);dEin=[sm(dRic[a]-dg[a]*scalar/2-g*dscalar[a]/2) for a in IDX]
zero('contracted_curvature_identity_at_unrestricted_third_jet',covariant_divergence(Einstein,g,q,C,dEin,dq))
Kcov=sm(Einstein-kap*T);dKcov=[sm(dEin[a]-kap*dT[a]) for a in IDX]
zero('off_shell_field_residual_matter_divergence',covariant_divergence(Kcov,g,q,C,dKcov,dq)+kap*cv)
# Check differential Bianchi before contraction, all matrix components.
cyclic=[]
for a,m,n in product(IDX,repeat=3):
    cyclic.append(dR[a][m][n]+C[a]*R[m][n]-R[m][n]*C[a]+dR[m][n][a]+C[m]*R[n][a]-R[n][a]*C[m]+dR[n][a][m]+C[n]*R[a][m]-R[a][m]*C[n])
zero('full_matrix_differential_curvature_identity',cyclic)
A,H,K,tbar=kinetic(q,C)
W=sm(s.Matrix(4,4,lambda m,n:-sum(dC[a][m][a,n] for a in IDX)+A[m,n]))
Sh=sm(s.Matrix(4,4,lambda m,n:s.trace(dC[m][n])-sum(C[m][a,n]*c[a] for a in IDX)))
U=sm(W+kap*reverse(T,g,q));Zcov=sm(Ric-kap*reverse(T,g,q))
zero('raw_coupled_curvature_and_volume_residual',U+Zcov+Sh)
zero('trace_reversed_full_field_residual',reverse(Zcov,g,q)-Kcov)
Jtotal=tbar/kap+mixed
# Original equation (52) residual, computed by direct product differentiation.
D52=sm(s.Matrix(4,4,lambda sig,mu:-sum(dq[a][sig,b]*C[mu][a,b]+q[sig,b]*dC[a][mu][a,b] for a,b in product(IDX,repeat=2))+kap*(Jtotal[sig,mu]-(s.trace(Jtotal)/2 if sig==mu else 0))))
zero('equation52_exact_off_shell_residual',D52-q*U)
zero('equation52a_exact_off_shell_residual',D52-s.eye(4)*s.trace(D52)/2-q*reverse(U,g,q))
# Full exchange and differentiated total-current residual in the raw chart.
dA=[sm(s.Matrix(4,4,lambda m,n:s.trace(dC[a][m]*C[n]+C[m]*dC[a][n]))) for a in IDX]
dH=[simp(sum(dq[a][m,n]*A[m,n]+q[m,n]*dA[a][m,n] for m,n in product(IDX,repeat=2))) for a in IDX]
dK=[sm(sum((dq[a][m,n]*C[m]*C[n]+q[m,n]*(dC[a][m]*C[n]+C[m]*dC[a][n]) for m,n in product(IDX,repeat=2)),s.zeros(4))) for a in IDX]
dtbar=[sm(s.eye(4)*dH[a]/2-dK[a]) for a in IDX]
divt=s.Matrix([sum(dtbar[a][a,mu] for a in IDX)/kap for mu in IDX])
ucontract=s.Matrix([sum(U[m,n]*dq[mu][m,n] for m,n in product(IDX,repeat=2))/(2*kap) for mu in IDX])
zero('raw_exchange_identity_with_field_and_volume_residual',divt-exchange-tr*s.Matrix(c)/2+ucontract)
dW=[sm(s.Matrix(4,4,lambda m,n:-sum(ddC[a][b][m][b,n] for b in IDX)+dA[a][m,n])) for a in IDX]
dtr=[simp(s.trace(dq[a]*T+q*dT[a])) for a in IDX]
dU=[sm(dW[a]+kap*(dT[a]-dg[a]*tr/2-g*dtr[a]/2)) for a in IDX]
trU=simp(s.trace(q*U));dtrU=[simp(s.trace(dq[a]*U+q*dU[a])) for a in IDX]
dmixedU=[sm(dq[a]*reverse(U,g,q)+q*(dU[a]-dg[a]*trU/2-g*dtrU[a]/2)) for a in IDX]
zero('raw_total_divergence_complete_residual',s.Matrix(D55)+kap*(divt+ordinary)-s.Matrix([sum(dmixedU[a][a,mu] for a in IDX) for mu in IDX]))

# Algebraic antisymmetric potential, no field equation used.
v=s.Matrix([-sum(q[l,b]*C[l][a,b] for l,b in product(IDX,repeat=2)) for a in IDX])
divq=s.Matrix([sum(dq[b][a,b] for b in IDX) for a in IDX])
zero('contracted_connection_keeps_volume_trace',v-divq-q*s.Matrix(c))
Zpot=[s.Matrix(4,4,lambda a,sig:-sum(q[sig,b]*C[mu][a,b] for b in IDX)) for mu in IDX]
L=[sm(s.Matrix(4,4,lambda a,sig:sum(q[a,l]*q[sig,b]*(dg[l][mu,b]-dg[b][mu,l])/2 for l,b in product(IDX,repeat=2)))) for mu in IDX]
zero('original_potential_symmetric_derivative_split',[Zpot[mu]-L[mu]-dq[mu]/2 for mu in IDX])
zero('antisymmetric_potential_core',[v+v.T for v in L])
Qpot=[s.Matrix(4,4,lambda a,sig:L[mu][a,sig]+(divq[sig]/2 if a==mu else 0)-(divq[a]/2 if sig==mu else 0)) for mu in IDX]
zero('antisymmetric_improved_potential',[v+v.T for v in Qpot])

# Concrete raw non-unit-volume witness tests (55) without imposing a field equation.
x,y,z,t=s.symbols('x y z t',real=True);coords=[x,y,z,t]
Gn=geometry(s.diag(1,1,1,s.exp(x**3)),coords);pn=potentials(Gn,coords)
double=s.Matrix([sum(s.diff(pn['P'][mu][a,sig],coords[a],coords[sig]) for a,sig in product(IDX,repeat=2)) for mu in IDX])
zero('non_unit_volume_explicit_double_divergence',double-s.Matrix([3,0,0,0]))
control('unit_volume_cannot_be_deleted_from_original_identity',double[0]!=0)
fixtures['non_unit_volume_control']={'E':'diag(1,1,1,exp(x^3))','double_divergence_P':['3','0','0','0']}

# Two explicit joint geometric/matter realizations, stress specified independently.
r=s.symbols('r',positive=True);co=[x,y,z,r];kappa=s.symbols('kappa',nonzero=True,real=True)
Ed=s.diag(r**s.Rational(2,9),r**s.Rational(2,9),r**s.Rational(2,9),r**s.Rational(-2,3))
rho=4*r**s.Rational(-2,3)/(27*kappa)
Sd=s.diag(0,0,0,rho);Gd=geometry(Ed,co);Md=field_quantities(Gd,Sd,co,kappa)
Er=s.diag(r**s.Rational(1,5),r**s.Rational(1,5),r**s.Rational(1,5),r**s.Rational(-3,5))
rhor=3*r**s.Rational(-4,5)/(25*kappa)
Sr=s.diag(rhor/3,rhor/3,rhor/3,rhor);Gr=geometry(Er,co);Mr=field_quantities(Gr,Sr,co,kappa)
for label,GG,MM,SS,EE in [('pressureless_form',Gd,Md,Sd,Ed),('tracefree_isotropic',Gr,Mr,Sr,Er)]:
    zero(label+'_unit_volume',GG['volume']-1)
    Om=curvature(GG['w'],co);frameRic=source_ricci(EE,Om)
    zero(label+'_source_coupled_curvature_law',frameRic-kappa*reverse(SS,ETA,ETA))
    zero(label+'_full_field_equation',MM['Kcov'])
    zero(label+'_original_equation53',MM['U'])
    zero(label+'_source_matter_divergence',MM['frame'])
    zero(label+'_covariant_matter_divergence',MM['divT'])
    zero(label+'_total_energy_conservation',MM['divtotal'])
    zero(label+'_gravitational_exchange_sign',MM['divt']-MM['exchange'])
    zero(label+'_matter_equation57',MM['ordinary']+MM['exchange'])
    force=sm(s.Matrix([sum(GG['C'][a][b,mu]*MM['mixed'][a,b] for a,b in product(IDX,repeat=2)) for mu in IDX]))
    zero(label+'_matter_equation57a',MM['ordinary']-force)
    pp=potentials(GG,co)
    DP=sm(s.Matrix(4,4,lambda sig,mu:sum(s.diff(pp['P'][mu][a,sig],co[a]) for a in IDX)))
    DK=sm(s.Matrix(4,4,lambda sig,mu:sum(s.diff(pp['K'][mu][a,sig],co[a]) for a in IDX)))
    zero(label+'_equation52a',DP+kappa*MM['total'])
    zero(label+'_antisymmetric_recovery_operation',DK-DP)
    zero(label+'_equation55',[sum(s.diff(pp['P'][mu][a,sig],co[a],co[sig]) for a,sig in product(IDX,repeat=2)) for mu in IDX])
    control(label+'_matter_not_ordinary_conserved',any(v!=0 for v in MM['ordinary']))
zero('pressureless_stress_trace',Md['trace']-rho)
zero('isotropic_tracefree_stress',Mr['trace'])
zero('pressureless_exchange_exact',Md['exchange']-s.Matrix([0,0,0,8*r**s.Rational(-5,3)/(81*kappa)]))
zero('pressureless_gravitational_energy_array',Md['t']-s.diag(rho,rho,rho,-rho))
zero('pressureless_total_energy_array',Md['total']-s.diag(rho,rho,rho,0))
control('printed_p809_unnumbered_plus_sign_rejected',simp(Md['divt'][3]+Md['exchange'][3])!=0)
fixtures['source_sign_check']={'printed_page':809,'numbered_equation_57':'div T + e = 0 (correct)','preceding_unnumbered_printed_line':'div t + e = 0','recovered_gravity_line':'div t - e = 0','pressureless_e':'8/(81*kappa*r^(5/3))','residual_of_printed_gravity_line':'16/(81*kappa*r^(5/3))'}
fixtures['joint_pressureless_form']={'E_diagonal':[str(Ed[i,i]) for i in IDX],'Sigma_diagonal':[str(Sd[i,i]) for i in IDX],'source_coupled_residual':'0','total_current':'diag(rho,rho,rho,0)','ordinary_matter_divergence':'(0,0,0,-8/(81*kappa*r^(5/3)))','interpretation':'chosen algebraic stress fixture; fluid constitutive derivation is not claimed here'}
fixtures['joint_tracefree_isotropic']={'E_diagonal':[str(Er[i,i]) for i in IDX],'Sigma_diagonal':[str(Sr[i,i]) for i in IDX],'source_coupled_residual':'0','trace':'0','interpretation':'second independently specified algebraic stress fixture'}

# A varying metric can have zero ordinary matter exchange on a particular solution.
Ezero=s.diag(r**s.Rational(1,3),r**s.Rational(1,3),r**s.Rational(1,3),r**-1)
Gzero=geometry(Ezero,co);Szero=ETA/(3*kappa);Mzero=field_quantities(Gzero,Szero,co,kappa)
zero('constant_mixed_stress_joint_field_equation',Mzero['Kcov'])
zero('varying_metric_can_have_zero_ordinary_matter_divergence',Mzero['ordinary'])
zero('varying_metric_can_have_zero_exchange',Mzero['exchange'])
control('constant_metric_not_necessary_for_particular_zero_exchange',any(v!=0 for v in Gzero['g'].diff(r)))
fixtures['zero_exchange_varying_metric']={'E':'diag(r^(1/3),r^(1/3),r^(1/3),r^-1)','Sigma':'eta/(3*kappa)','T_mixed':'I/(3*kappa)','field_residual':'0','ordinary_matter_divergence':'0','exchange':'0','qualification':'constant metric suffices for all stress exchanges to vanish; it is not necessary for a particular stress'}

# Wrong-preparation and insufficient-conservation controls.
Mbad=field_quantities(Gd,2*Sd,co,kappa)
zero('rescaled_stress_still_covariantly_conserved',Mbad['divT'])
control('conserved_matter_not_sufficient_for_gravitational_equation',any(v!=0 for v in Mbad['Kcov']))
control('wrong_matter_amplitude_breaks_total_conservation',any(v!=0 for v in Mbad['divtotal']))
Gflat=geometry(s.eye(4),coords);Mflat=field_quantities(Gflat,s.diag(0,0,0,1),coords,kappa)
zero('flat_constant_stress_total_current_divergence',Mflat['divtotal'])
control('total_conservation_does_not_imply_full_field_equation',any(v!=0 for v in Mflat['Kcov']))
Mkernel=field_quantities(Gflat,s.diag(0,1+x**2,0,0),coords,kappa)
zero('divergence_readout_has_nontrivial_stress_kernel',Mkernel['divT'])
control('four_divergences_do_not_determine_ten_stress_components',Mkernel['T']!=s.zeros(4))
fixtures['non_solution_controls']={'flat_constant_stress':'conserved total current but K != 0; not labelled a gravitational solution','pressureless_scaled_stress':'same E, twice Sigma, div_cov T = 0 but K != 0','stress_divergence_kernel':'flat Sigma=diag(0,1+x^2,0,0) has div_cov T=0 and Sigma!=0'}

# Nonzero integrated flux on a joint solution in a new determinant-one affine chart.
u=s.symbols('u',positive=True);xx=s.symbols('xx',positive=True);new=[xx,y,z,u];Rnew=xx+2*u
J=s.eye(4);J[0,0]=1;J[0,3]=1;J[3,0]=1;J[3,3]=2
Etilt=Ed.subs(r,Rnew)*J;Stilt=Sd.subs(r,Rnew)
# Differentiate the actual transformed calibration, rather than reusing transformed C.
Ft,wt,Ct=source_connection(Etilt,[Etilt.diff(v) for v in new]);gt=sm(Etilt.T*ETA*Etilt);qt=sm(gt.inv())
_,Ht,_,tbart=kinetic(qt,Ct);Tt=sm(Etilt.T*Stilt*Etilt);tot=sm(tbart/kappa+qt*Tt)
expected=sm(J.inv()*Md['total'].subs(r,Rnew)*J)
zero('affine_chart_joint_total_current_recovery',tot-expected)
zero('affine_chart_field_equation',ricci(curvature(Ct,new))-kappa*reverse(Tt,gt,qt))
zero('affine_chart_local_total_conservation',[sum(s.diff(tot[a,mu],new[a]) for a in IDX) for mu in IDX])
Q=-4*((1+2*u)**s.Rational(1,3)-(2*u)**s.Rational(1,3))/(9*kappa)
outflow=simp(tot[0,3].subs(xx,1)-tot[0,3].subs(xx,0))
primitive=-4*(xx+2*u)**s.Rational(1,3)/(9*kappa)
zero('finite_flux_primitive_derivative',s.diff(primitive,xx)-tot[3,3])
zero('integrated_total_energy_from_density',primitive.subs(xx,1)-primitive.subs(xx,0)-Q)
zero('nonzero_finite_boundary_flux_balance',s.diff(Q,u)+outflow)
control('nonzero_boundary_flux_is_not_constant_charge',simp(s.diff(Q,u))!=0)
fixtures['finite_boundary_flux']={'map':'X=x+t, R=x+2t; Y=y,Z=z','det_J':str(J.det()),'slice_domain':'0<=x,y,z<=1; t>1/2','total_density_44':str(tot[3,3]),'total_flux_14':str(tot[0,3]),'integrated_Q4':str(Q),'outward_flux':str(outflow),'dQ_plus_flux':'0','note':'chart-tagged pseudotensor total current, not invariant positive local energy'}

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results.json'))
a=parser.parse_args();a.output.parent.mkdir(parents=True,exist_ok=True)
result=dict(checkpoint='E1916-I04-v1.0',environment={'python':platform.python_version(),'sympy':s.__version__},summary={'groups':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'expected_failure_controls':sum(c['kind']=='expected_failure_control' for c in checks)},checks=checks,fixtures=fixtures)
a.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result['summary']),flush=True)
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
