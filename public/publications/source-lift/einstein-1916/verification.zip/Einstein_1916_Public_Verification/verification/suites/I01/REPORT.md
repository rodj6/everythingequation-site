# Public guide to retained stage I01

The executable Python files in this directory are unchanged from the corresponding research checkpoint. Their historical comments that refer to `REPORT.md` refer in this release to this guide and to the complete manuscript at `manuscript/main.tex`. All essential proofs have been consolidated into that manuscript; no private report or conversation is needed to execute the suite.

Run this stage through `python verification/run_all.py --output replay`, from the package root. Stage I01 retains its original result schema and authored fixtures. Its scientific status, assumptions and equation correspondence are in the public `registers/` directory. This stage is not independent external review.
