#!/usr/bin/env python3
"""Consolidation regressions for the final manuscript.

Written separately from the six retained stage suites. Exact designed tests,
not independent peer review or proof-assistant certification. All domains and
universal proofs are stated in the accompanying paper.
"""
from __future__ import annotations
import argparse, hashlib, json, platform
from pathlib import Path
import sympy as s

checks: list[dict] = []

def flat(x):
    if isinstance(x, s.MatrixBase): return list(x)
    if isinstance(x, (list, tuple)): return [v for e in x for v in flat(e)]
    return [x]

def zero(name, expressions, expected_failure=False):
    vals = [s.simplify(s.trigsimp(v)) for v in flat(expressions)]
    iszero = all(v == 0 for v in vals)
    ok = (not iszero) if expected_failure else iszero
    checks.append({'name': name, 'kind': 'expected_failure_control' if expected_failure else 'exact_identity',
                   'passed': bool(ok), 'components': len(vals),
                   'nonzero_witness': next((str(v) for v in vals if v != 0), None)})
    print(('PASS ' if ok else 'FAIL ') + name, flush=True)

def truth(name, condition):
    checks.append({'name':name, 'kind':'exact_domain_check', 'passed':bool(condition)})
    print(('PASS ' if condition else 'FAIL ') + name, flush=True)

def christoffel(g, coords):
    q=g.inv(); n=len(coords)
    return [[[s.simplify(sum(q[a,l]*(s.diff(g[l,c],coords[b])+s.diff(g[l,b],coords[c])-s.diff(g[b,c],coords[l])) for l in range(n))/2)
              for c in range(n)] for b in range(n)] for a in range(n)]

def H_density(g, coords):
    q=g.inv(); C=christoffel(g,coords)
    return s.simplify(sum(q[m,n]*C[a][m][b]*C[b][n][a] for m in range(4) for n in range(4) for a in range(4) for b in range(4)))

eta=s.diag(-1,-1,-1,1)
E=s.Matrix([[2,1,0,0],[0,3,1,0],[1,0,2,0],[s.Rational(1,2),-1,s.Rational(2,3),2]])
g=E.T*eta*E; q=g.inv(); inv=E.inv()
zero('metric inverse and signature determinant', [q-inv*eta*inv.T, g.det()+E.det()**2])
a=g[3,3]; b=g[:3,3]; C=g[:3,:3]; S=b*b.T/a-C
R=S.cholesky().T
Sec=R.row_join(s.zeros(3,1)).col_join((b.T/s.sqrt(a)).row_join(s.Matrix([[s.sqrt(a)]])))
zero('explicit reverse calibration section',Sec.T*eta*Sec-g)
Lam=Sec*inv
zero('complete fibre witness Lorentz relation',Lam.T*eta*Lam-eta)
h=s.Matrix([[1,2,3,4],[2,-3,1,2],[3,1,5,0],[4,2,0,7]])
H=E*q*h/2
zero('all symmetric metric tangent recovery',H.T*eta*E+E.T*eta*H-h)
A=s.zeros(4); A[0,3]=A[3,0]=s.Rational(3,5)
zero('vertical Lorentz tangent', (A*E).T*eta*E+E.T*eta*(A*E))
k=h; HE=-E*k*g/2; dg=HE.T*eta*E+E.T*eta*HE
zero('inverse metric tangent coverage',-q*dg*q-k)
Sigma=s.Matrix([[3,1,0,2],[1,4,1,0],[0,1,5,3],[2,0,3,9]])
KT=2*h; A=H*inv; dSigma=inv.T*KT*inv-A.T*Sigma-Sigma*A
zero('joint fixed stress response',H.T*Sigma*E+E.T*dSigma*E+E.T*Sigma*H-KT)
zero('trace reversal involution', (h-g*s.trace(q*h)/2)-g*s.trace(q*(h-g*s.trace(q*h)/2))/2-h)
zero('trace-free projection is not trace reversal', (g-g*s.trace(q*g)/4)-g, True)
zero('trace-shift exceptional parameter witness',g-s.Rational(1,4)*g*s.trace(q*g))
zero('trace-shift witness nonzero',g,True)

x,y,z,t=s.symbols('x y z t',real=True)
eps=s.symbols('eps',real=True)
N=1+x*x; K=1+x+x*x
geps=s.diag(-1,-1,-1,N*N-eps*N**4*K)
Hvar=s.diff(H_density(geps,(x,y,z,t)),eps).subs(eps,0)
expected=-2*s.diff(N,x)**2*K-N*s.diff(N,x)*s.diff(K,x)
zero('unrestricted action variation from direct metric differentiation',Hvar-expected)
wrong=-2*s.diff(N,x)**2*K+N*s.diff(N,x)*s.diff(K,x)
zero('printed action sign rejected by nonzero derivative variation',Hvar-wrong,True)
fn=x*(1-x)*y*(1-y)*z*(1-z)*t*(1-t)
val=2*sum(s.diff(fn,c,2) for c in (x,y,z))
for c in (x,y,z,t): val=s.integrate(val,(c,0,1))
zero('finite boundary curvature response',val+s.Rational(1,18))
truth('fixed values do not remove curvature boundary response',val != 0)

r,kap=s.symbols('r kap',positive=True)
rho=s.Rational(4,27)/kap*r**s.Rational(-2,3)
e4=s.Rational(8,81)/kap*r**s.Rational(-5,3)
zero('nonzero opposite exchange', [s.diff(-rho,r)-e4,s.diff(rho,r)+e4])
zero('printed gravitational exchange sign rejected',s.diff(-rho,r)+e4,True)
p,enthalpy=s.symbols('p rho',real=True)
v=s.Matrix([0,0,0,1]); vl=eta*v
stress=-p*eta+enthalpy*vl*vl.T
zero('Einstein fluid density convention',stress-s.diag(p,p,p,enthalpy-p))
zero('modern energy density cannot replace original rho unconverted',stress-s.diag(p,p,p,enthalpy),True)

ex,ey,ez,bx,by,bz=s.symbols('ex ey ez bx by bz',real=True)
f=s.Matrix([[0,bz,-by,ex],[-bz,0,bx,ey],[by,-bx,0,ez],[-ex,-ey,-ez,0]])
raised=eta*f*eta; I=sum(f[a,b]*raised[a,b] for a in range(4) for b in range(4))
stress_em=-f*eta*f.T+eta*I/4
zero('electromagnetic stress symmetry and trace', [stress_em-stress_em.T,s.trace(eta*stress_em)])
energy=(ex**2+ey**2+ez**2+bx**2+by**2+bz**2)/2
zero('electromagnetic energy and Poynting signs', [stress_em[3,3]-energy, (eta*stress_em)[:3,3]-s.Matrix([ey*bz-ez*by,ez*bx-ex*bz,ex*by-ey*bx])])
minus=-(-f)*eta*(-f).T+eta*I/4
zero('field sign not separated by stress',minus-stress_em)
zero('field sign is not identical primitive',-f-f,True)

alpha,b,y=s.symbols('alpha b y',positive=True)
rr=s.sqrt(b*b+y*y)
Iray=alpha*b/(2*rr**3)*(1+3*y*y/rr**2)
pend=alpha*b*y/rr**3
actual=3*alpha*b**3/(2*rr**5)
zero('optical boundary derivative identity',actual-Iray-s.diff(pend,y))
zero('finite endpoint omission rejected',pend.subs(y,b)-pend.subs(y,0),True)
primitive=alpha/(2*b)*(y/rr+y**3/rr**3)
zero('optical primitive',s.diff(primitive,y)-Iray)
zero('asymptotic endpoint difference',s.limit(primitive,y,s.oo)-s.limit(primitive,y,-s.oo)-2*alpha/b)
Kgrav,M,c=s.symbols('K M c',positive=True)
kappa=8*s.pi*Kgrav/c**2
zero('mass-equivalent normalization and alpha join',kappa*M/(4*s.pi)-2*Kgrav*M/c**2)
zero('printed half-mass normalization rejected',kappa*M/(8*s.pi)-2*Kgrav*M/c**2,True)
aexp=s.symbols('aexp',real=True)
gamma=s.sqrt((1-aexp/rr)/(1+aexp*y*y/rr**3))
zero('null speed first coefficient',s.diff(gamma,aexp).subs(aexp,0)+(1+y*y/rr**2)/(2*rr))
zero('positive null speed coefficient rejected',s.diff(gamma,aexp).subs(aexp,0)-(1+y*y/rr**2)/(2*rr),True)

w,wm,wp=s.symbols('w wm wp',positive=True)
S=wm+wp;P=wm*wp
ell2=alpha/(S-alpha*(S*S-P)); energy2=1-ell2*P*(1-alpha*S)
poly=(energy2-1)/ell2+alpha/ell2*w-w*w+alpha*w**3
zero('turning polynomial factorization',poly-(w-wm)*(wp-w)*(1-alpha*(S+w)))
d,e,chi=s.symbols('delta e chi',positive=True)
En2=1-d*(1-e*e)*(1-2*d)/(2-d*(3+e*e))
zero('bound branch energy positivity factorization',En2-2*(1-d*(1+e))*(1-d*(1-e))/(2-d*(3+e*e)))
zero('orbit second moment',s.integrate((3+e*s.cos(chi))**2,(chi,0,s.pi))-s.pi*(9+e*e/2))
ao,T=s.symbols('a_o T',positive=True)
expr=6*s.pi*Kgrav*M/(ao*(1-e*e)*c*c)
zero('leading Kepler conversion only',expr.subs(Kgrav*M,4*s.pi**2*ao**3/T**2)-24*s.pi**3*ao**2/(T*T*c*c*(1-e*e)))
lam=s.symbols('lambda',real=True)
Ar=1-alpha/r+lam*alpha**2/r**2
zero('higher-order radial vacuum residual',1-Ar-r*s.diff(Ar,r)-lam*alpha**2/r**2)
zero('higher-order first-order match insufficient',1-Ar-r*s.diff(Ar,r),True)

# Explicit family demonstrates why an amplitude-only approximation is invalid.
qep=s.symbols('epsilon',positive=True)
small=qep**2*s.sin(x/qep)
zero('derivative topology control',s.diff(small,x,2)+s.sin(x/qep))
zero('nonzero second derivative despite small amplitude',s.diff(small,x,2).subs(x,s.pi*qep/2),True)
# Native constant support is kept fixed while the realization changes.
truth('realization freedom not native physical selection',s.diag(-1,-1,-1,1) != s.diag(-1,-1,-1,(1+x*x)**2))

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
result={'checkpoint':'E1916-PUBLICATION-AUDIT-1.0','environment':{'python':platform.python_version(),'sympy':s.__version__},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'summary':{'groups':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
                   'expected_failure_controls':sum(c['kind']=='expected_failure_control' for c in checks)},
        'checks':checks,'scope':'Separately written final-convention regressions; not independent external review or universal proof.'}
args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary']),flush=True)
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
