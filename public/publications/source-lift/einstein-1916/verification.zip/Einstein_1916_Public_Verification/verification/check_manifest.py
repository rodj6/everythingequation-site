#!/usr/bin/env python3
"""Check SHA256SUMS.json from any working directory. Extra files are reported, not hashed retroactively."""
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    data=json.loads((ROOT/'SHA256SUMS.json').read_text())
    failures=[]
    for rel,digest in data['files'].items():
        p=(ROOT/rel).resolve()
        if ROOT not in p.parents or not p.is_file(): failures.append({'file':rel,'reason':'missing or unsafe path'}); continue
        got=hashlib.sha256(p.read_bytes()).hexdigest()
        if got!=digest: failures.append({'file':rel,'reason':'hash mismatch','actual':got})
    known=set(data['files'])|set(data['excluded_receipt_files'])|{'SHA256SUMS.json'}
    extra=sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in known)
    print(json.dumps({'manifest_entries':len(data['files']),'all_entries_valid':not failures,'failures':failures,'unlisted_files':extra},indent=2))
    return 1 if failures else 0
if __name__=='__main__':sys.exit(main())
