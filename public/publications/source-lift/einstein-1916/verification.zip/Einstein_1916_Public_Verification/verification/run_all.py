#!/usr/bin/env python3
"""Execute and compare all public verification suites.
Usage: python verification/run_all.py --output replay --jobs 2
The output directory must be outside the immutable verification/results tree.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, platform, subprocess, sys, time
from pathlib import Path

HERE=Path(__file__).resolve().parent

def scientific(value):
    """Remove environment-only metadata for a separately reported comparison."""
    if isinstance(value,dict):
        return {k:scientific(v) for k,v in value.items()
                if k not in {'environment','python','sympy','mpmath'}}
    if isinstance(value,list):return [scientific(v) for v in value]
    return value

def summary_of(d):
    return d.get('summary',{k:d[k] for k in ('check_groups','passed','failed','expected_failure_control_groups') if k in d})

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path('replay'))
    p.add_argument('--jobs',type=int,default=2)
    p.add_argument('--timeout',type=int,default=1800,help='Per-suite safety timeout in seconds')
    a=p.parse_args()
    if not 1<=a.jobs<=8:p.error('--jobs must be between 1 and 8')
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    if out == (HERE/'results').resolve():p.error('Do not overwrite the retained release results')
    (out/'results').mkdir(exist_ok=True);(out/'logs').mkdir(exist_ok=True)
    jobs=[(f'I{i:02}',HERE/'suites'/f'I{i:02}'/'verify.py') for i in range(1,7)]
    jobs += [('I06_numerics',HERE/'suites/I06/numerics.py'),('publication_audit',HERE/'publication_audit.py')]
    def run(job):
        name,script=job;result=out/'results'/f'{name}.json';log=out/'logs'/f'{name}.log'
        cmd=[sys.executable,str(script),'--output',str(result)]
        start=time.monotonic();error=None;rc=None
        try:
            with log.open('w') as stream:
                rc=subprocess.run(cmd,cwd=script.parent,stdout=stream,stderr=subprocess.STDOUT,timeout=a.timeout).returncode
        except subprocess.TimeoutExpired:error='Per-suite safety timeout exceeded; not a completed check'
        except OSError as ex:error=str(ex)
        record={'suite':name,'returncode':rc,'elapsed_seconds':round(time.monotonic()-start,3),
                'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
                'result':'results/'+result.name,'log':'logs/'+log.name,'error':error}
        if result.exists() and rc==0:
            got=json.loads(result.read_text());expected=json.loads((HERE/'expected'/f'{name}.json').read_text())
            summary=summary_of(got)
            record.update(summary=summary,complete_object_equal=(got==expected),
                          scientific_content_equal=(scientific(got)==scientific(expected)),
                          passed=(summary.get('failed',1)==0 and scientific(got)==scientific(expected)))
        else:record['passed']=False
        print(name, 'PASS' if record['passed'] else 'FAIL',flush=True)
        return record
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:records=list(pool.map(run,jobs))
    receipt={'release':'E1916-1.0','environment':{'python':platform.python_version()},
             'all_suites_completed_and_passed':all(r['passed'] for r in records),
             'all_complete_result_objects_equal':all(r.get('complete_object_equal',False) for r in records),
             'suites':records,
             'scope':'Replay compares implementations and bytes, not independent review or universal theorem proof.'}
    (out/'replay_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='suites'},indent=2))
    return 0 if receipt['all_suites_completed_and_passed'] else 1

if __name__=='__main__':raise SystemExit(main())
