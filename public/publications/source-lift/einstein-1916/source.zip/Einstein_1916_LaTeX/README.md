# Editable manuscript

Entry point: `main.tex`. The complete mathematical content is in `sections/`; `references.bib` is the editable reference database. `main.bbl` supplies a generated bibliography fallback. `main.pdf` is the inspected release PDF.

Run `bash build.sh` from this directory with pdfLaTeX and BibTeX installed. On systems without a shell, run:

```
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The build script recognizes `bibtex.original` and `bibtex8` when `bibtex` is not installed. With no BibTeX executable, keep the supplied `main.bbl` and run pdfLaTeX twice. Rebuild the bibliography after reference edits. No custom font files, network downloads, external figures or private research files are required.

Author: Jeremy Rodgers, Independent Researcher. Website: https://everythingequation.com. Reserved publication DOI: 10.5281/zenodo.24064553. No external funding.

The original-equation and theorem registers in the full public package refer to the supplied release numbering. Editing the manuscript can change those numbers and page locations; update the registers before a new public release. Essential proofs are in this manuscript, not hidden in code or private notes.
